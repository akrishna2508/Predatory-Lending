'use client';

import { useEffect } from 'react';

export default function ScrollMotion() {
  useEffect(() => {
    const root = document.querySelector<HTMLElement>('.public-home');
    if (!root || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

    root.classList.add('motion-ready');
    const observer = new IntersectionObserver(entries => {
      for (const entry of entries) {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      }
    }, { threshold: 0.12, rootMargin: '0px 0px -25px 0px' });
    root.querySelectorAll('[data-reveal]').forEach(element => observer.observe(element));

    let frame = 0;
    const update = () => {
      if (frame) return;
      frame = requestAnimationFrame(() => {
        const hero = root.querySelector<HTMLElement>('.public-hero');
        if (hero) hero.style.setProperty('--hero-scroll', String(Math.min(window.scrollY, hero.offsetHeight)));
        frame = 0;
      });
    };
    window.addEventListener('scroll', update, { passive: true });
    return () => {
      observer.disconnect();
      window.removeEventListener('scroll', update);
      if (frame) cancelAnimationFrame(frame);
      root.classList.remove('motion-ready');
    };
  }, []);

  return null;
}
