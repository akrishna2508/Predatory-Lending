import { z } from 'zod';
import { resolveLocalDataset } from '@/server/modeling-paths';
import { isLocalWorkbenchRequest, runLocalPythonJson } from '@/server/modeling-runtime';

export const runtime = 'nodejs';

const bodySchema = z.object({
  source: z.enum(['statlog-german', 'lendingclub', 'home-credit', 'fico']),
  filename: z.string().min(1).max(240),
  rowLimit: z.number().int().min(10).max(100000).default(20000),
  seed: z.number().int().min(0).max(2147483647).default(42),
  confirmSourceTerms: z.boolean().default(false),
});

export async function POST(request: Request): Promise<Response> {
  if (!isLocalWorkbenchRequest(request)) return Response.json({ error: 'This modeling workbench accepts local requests only.' }, { status: 403 });
  let body: z.infer<typeof bodySchema>;
  try {
    body = bodySchema.parse(await request.json());
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : 'Invalid request.' }, { status: 400 });
  }
  try {
    const inputPath = await resolveLocalDataset(body.filename);
    const args = [
      '--source', body.source,
      '--input', inputPath,
      '--output', '-',
      '--row-limit', String(body.rowLimit),
      '--seed', String(body.seed),
    ];
    if (body.confirmSourceTerms) args.push('--confirm-source-terms');
    const report = await runLocalPythonJson('train_baseline.py', args);
    return Response.json(report);
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : 'Baseline training failed.' }, { status: 400 });
  }
}

