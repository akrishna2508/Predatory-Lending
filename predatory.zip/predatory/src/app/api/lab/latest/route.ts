import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { isLocalWorkbenchRequest } from '@/server/modeling-runtime';
import { resolveModelingProjectRoot } from '@/server/modeling-paths';

export const runtime = 'nodejs';

async function readSummary(filename: string) {
  try {
    const contents = await readFile(path.join(resolveModelingProjectRoot(), 'data', 'results', filename), 'utf-8');
    return JSON.parse(contents);
  } catch {
    return null;
  }
}

export async function GET(request: Request): Promise<Response> {
  if (!isLocalWorkbenchRequest(request)) return Response.json({ error: 'This modeling workbench accepts local requests only.' }, { status: 403 });
  const [baseline, complaints, archivedLoanComplaints, statlogGenerator, lendingClubGenerator] = await Promise.all([
    readSummary('baseline-latest.json'),
    readSummary('cfpb-latest.json'),
    readSummary('cfpb-loan-narratives-latest.json'),
    readSummary('generator-benchmark-statlog.json'),
    readSummary('generator-benchmark-lendingclub.json'),
  ]);
  return Response.json({
    baseline,
    complaints,
    archivedLoanComplaints,
    generatorBenchmarks: [statlogGenerator, lendingClubGenerator].filter(Boolean),
  }, { headers: { 'cache-control': 'no-store' } });
}
