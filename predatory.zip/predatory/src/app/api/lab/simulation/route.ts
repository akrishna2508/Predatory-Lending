import { mkdir } from 'node:fs/promises';
import path from 'node:path';
import { z } from 'zod';
import { isLocalWorkbenchRequest, runLocalPythonJson } from '@/server/modeling-runtime';
import { resolveModelingProjectRoot } from '@/server/modeling-paths';

export const runtime = 'nodejs';

const bodySchema = z.object({
  profile: z.enum(['gig-worker', 'student', 'low-income-family']),
  trials: z.number().int().min(10).max(100000).default(1000),
  seed: z.number().int().min(0).max(2147483647).default(42),
  engine: z.enum(['none', 'gan', 'diffusion']).default('none'),
  samples: z.number().int().min(10).max(5000).default(500),
});

export async function POST(request: Request): Promise<Response> {
  if (!isLocalWorkbenchRequest(request)) return Response.json({ error: 'This modeling workbench accepts local requests only.' }, { status: 403 });
  let body: z.infer<typeof bodySchema>;
  try {
    body = bodySchema.parse(await request.json());
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : 'Invalid request.' }, { status: 400 });
  }
  try {
    const args = [
      '--profile', body.profile,
      '--trials', String(body.trials),
      '--seed', String(body.seed),
      '--engine', body.engine,
      '--samples', String(body.samples),
      '--output', '-',
    ];
    if (body.engine !== 'none') {
      await mkdir(path.join(resolveModelingProjectRoot(), 'data', 'results'), { recursive: true });
      args.push('--synthetic-output', path.join('data', 'results', 'synthetic-latest.csv'));
    }
    return Response.json(await runLocalPythonJson('run_simulation.py', args));
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : 'Synthetic simulation failed.' }, { status: 400 });
  }
}
