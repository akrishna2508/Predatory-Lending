import { z } from 'zod';
import { resolveLocalDataset } from '@/server/modeling-paths';
import { isLocalWorkbenchRequest, runLocalPythonJson } from '@/server/modeling-runtime';

export const runtime = 'nodejs';

const bodySchema = z.object({
  filename: z.string().min(1).max(240),
  rowLimit: z.number().int().min(1).max(10000000).optional(),
  productContains: z.string().max(120).optional(),
});

export async function POST(request: Request): Promise<Response> {
  if (!isLocalWorkbenchRequest(request)) return Response.json({ error: 'This modeling workbench accepts local requests only.' }, { status: 403 });
  let body: z.infer<typeof bodySchema>;
  try {
    body = bodySchema.parse(await request.json());
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : 'Invalid request.' }, { status: 400 });
  }
  try {
    const inputPath = await resolveLocalDataset(body.filename);
    const args = ['--input', inputPath, '--output', '-'];
    if (body.rowLimit) args.push('--row-limit', String(body.rowLimit));
    if (body.productContains?.trim()) args.push('--product-contains', body.productContains.trim());
    return Response.json(await runLocalPythonJson('analyze_cfpb.py', args));
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : 'Complaint analysis failed.' }, { status: 400 });
  }
}
