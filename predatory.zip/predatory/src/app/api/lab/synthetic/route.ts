import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { isLocalWorkbenchRequest } from '@/server/modeling-runtime';
import { resolveModelingProjectRoot } from '@/server/modeling-paths';

export const runtime = 'nodejs';

export async function GET(request: Request): Promise<Response> {
  if (!isLocalWorkbenchRequest(request)) return Response.json({ error: 'This modeling workbench accepts local requests only.' }, { status: 403 });
  try {
    const content = await readFile(path.join(resolveModelingProjectRoot(), 'data', 'results', 'synthetic-latest.csv'));
    return new Response(content, {
      headers: {
        'content-type': 'text/csv; charset=utf-8',
        'content-disposition': 'attachment; filename="aegis-experimental-synthetic.csv"',
        'cache-control': 'no-store',
      },
    });
  } catch {
    return Response.json({ error: 'No synthetic table has been generated yet.' }, { status: 404 });
  }
}
