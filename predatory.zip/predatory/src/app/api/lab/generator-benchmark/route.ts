import { z } from 'zod';
import { resolveLocalDataset } from '@/server/modeling-paths';
import { isLocalWorkbenchRequest, runLocalPythonJson } from '@/server/modeling-runtime';

export const runtime = 'nodejs';

const bodySchema = z.object({
  source: z.enum(['statlog-german', 'lendingclub']),
  filename: z.string().min(1).max(240),
  rowLimit: z.number().int().min(100).max(50000).default(1000),
  samples: z.number().int().min(20).max(5000).default(500),
  seed: z.number().int().min(0).max(2147483647).default(42),
});

export async function POST(request: Request): Promise<Response> {
  if (!isLocalWorkbenchRequest(request)) return Response.json({ error: 'This modeling workbench accepts local requests only.' }, { status: 403 });
  let body: z.infer<typeof bodySchema>;
  try {
    body = bodySchema.parse(await request.json());
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : 'Invalid request.' }, { status: 400 });
  }
  try {
    const inputPath = await resolveLocalDataset(body.filename);
    const report = await runLocalPythonJson('benchmark_public_generators.py', [
      '--source', body.source,
      '--input', inputPath,
      '--row-limit', String(body.rowLimit),
      '--samples', String(body.samples),
      '--seed', String(body.seed),
      '--output', '-',
    ]);
    return Response.json(report);
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : 'Generator benchmark failed.' }, { status: 400 });
  }
}
