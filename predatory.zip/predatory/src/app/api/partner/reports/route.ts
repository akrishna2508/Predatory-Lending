import { randomUUID } from 'node:crypto';
import { MemberAuthError, resolveMemberIdentity } from '@/server/member-auth';
import { getDatabasePool, withPartnerTransaction } from '@/server/database';

export const runtime = 'nodejs';

export async function GET(request: Request) {
  let identity;
  try {
    identity = await resolveMemberIdentity(request);
  } catch (error) {
    const message = error instanceof MemberAuthError ? error.message : 'Authentication failed';
    return Response.json({ error: message }, { status: message === 'Tenant identifier required' ? 400 : 401 });
  }

  try {
    const summaries = await withPartnerTransaction(getDatabasePool(), identity, async client => {
      const result = await client.query('SELECT report_month, participating_members, saved_checks FROM aegis_partner_usage_summary()');
      await client.query(
        'INSERT INTO audit_events (tenant_id, actor_user_id, action, entity_type, request_id, metadata) VALUES ($1, $2, $3, $4, $5, $6::jsonb)',
        [identity.tenantId, identity.userId, 'partner_report.viewed', 'partner_report', randomUUID(), JSON.stringify({ report: 'monthly_usage' })],
      );
      return result.rows;
    });
    return Response.json({ summaries });
  } catch (error) {
    if (error instanceof Error && error.message === 'Partner membership required') {
      return Response.json({ error: 'Active partner staff access is required.' }, { status: 403 });
    }
    return Response.json({ error: 'Partner reporting is temporarily unavailable.' }, { status: 503 });
  }
}
