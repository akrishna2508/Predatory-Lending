import { MemberAuthError, resolveMemberSubject } from '@/server/member-auth';
import { getDatabasePool, listPartnerTenants } from '@/server/database';

export const runtime = 'nodejs';

export async function GET(request: Request) {
  let userId: string;
  try {
    userId = await resolveMemberSubject(request);
  } catch (error) {
    const message = error instanceof MemberAuthError ? error.message : 'Authentication failed';
    return Response.json({ error: message }, { status: 401 });
  }
  try {
    const tenants = await listPartnerTenants(getDatabasePool(), userId);
    return Response.json({ tenants });
  } catch {
    return Response.json({ error: 'Partner organizations are temporarily unavailable.' }, { status: 503 });
  }
}
