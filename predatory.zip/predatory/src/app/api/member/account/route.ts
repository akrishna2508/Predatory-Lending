import { MemberAuthError, resolveMemberSubject, hasSafeMutationOrigin } from '@/server/member-auth';
import { getDatabasePool, withIdentityTransaction } from '@/server/database';

export const runtime = 'nodejs';

export async function GET(request: Request) {
  let userId: string;
  try {
    userId = await resolveMemberSubject(request);
  } catch (error) {
    const message = error instanceof MemberAuthError ? error.message : 'Authentication failed';
    return Response.json({ error: message }, { status: 401 });
  }

  try {
    const status = await withIdentityTransaction(getDatabasePool(), userId, async client => {
      const result = await client.query('SELECT status FROM app_users WHERE id = $1', [userId]);
      return result.rows[0]?.status ?? null;
    });
    return Response.json({ deletionPending: status === 'deletion_pending' });
  } catch {
    return Response.json({ error: 'Account status is temporarily unavailable.' }, { status: 503 });
  }
}

export async function DELETE(request: Request) {
  if (!hasSafeMutationOrigin(request)) return Response.json({ error: 'Cross-origin request rejected.' }, { status: 403 });
  let userId: string;
  try {
    userId = await resolveMemberSubject(request);
  } catch (error) {
    const message = error instanceof MemberAuthError ? error.message : 'Authentication failed';
    return Response.json({ error: message }, { status: 401 });
  }

  let deletionStarted = false;
  try {
    const pool = getDatabasePool();
    const providerStatus = await withIdentityTransaction(pool, userId, async client => {
      const result = await client.query('SELECT aegis_begin_member_account_deletion() AS provider_status');
      return result.rows[0]?.provider_status;
    });
    deletionStarted = true;

    if (providerStatus === 'provider_pending') {
      await withIdentityTransaction(pool, userId, async client => {
        await client.query('SELECT aegis_mark_member_identity_deleted()');
      });
    } else if (providerStatus !== 'identity_deleted') {
      throw new Error('Unexpected account deletion state');
    }

    await withIdentityTransaction(pool, userId, async client => {
      await client.query('SELECT aegis_finalize_member_account_deletion()');
    });
    return Response.json({ deleted: true, message: 'Your Aegis records, sign-in profile, and active sessions have been deleted.' });
  } catch (error) {
    if (error instanceof Error && error.message === 'Mixed-role account deletion requires support') {
      return Response.json({ error: 'This account has partner staff access. Contact support to complete deletion safely.' }, { status: 409 });
    }
    if (error instanceof Error && error.message === 'Active member access required') {
      return Response.json({ error: 'An active member account is required.' }, { status: 403 });
    }
    if (deletionStarted) {
      return Response.json({
        error: 'Your transaction and offer records have been removed. Local sign-in cleanup is still pending; retry here to finish.',
        deletionPending: true,
      }, { status: 503 });
    }
    return Response.json({ error: 'Account deletion is temporarily unavailable.' }, { status: 503 });
  }
}
