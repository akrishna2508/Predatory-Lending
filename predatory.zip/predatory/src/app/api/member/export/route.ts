import { randomUUID } from 'node:crypto';
import { MemberAuthError, resolveMemberSubject } from '@/server/member-auth';
import { getDatabasePool, listMemberTenants, withMemberTransaction } from '@/server/database';

export const runtime = 'nodejs';

export async function GET(request: Request) {
  let userId: string;
  try {
    userId = await resolveMemberSubject(request);
  } catch (error) {
    const message = error instanceof MemberAuthError ? error.message : 'Authentication failed';
    return Response.json({ error: message }, { status: 401 });
  }

  try {
    const pool = getDatabasePool();
    const tenants = await listMemberTenants(pool, userId);
    const memberships = await Promise.all(tenants.map(async tenant => {
      return withMemberTransaction(pool, { tenantId: tenant.id, userId }, async client => {
        const [consents, offerChecks, offerOutcomes, cashflowProfiles, transactionImports, importedTransactions, auditEvents] = await Promise.all([
          client.query('SELECT id, purpose, action, policy_version, occurred_at FROM consent_events ORDER BY occurred_at'),
          client.query('SELECT id, title, input_payload, result_payload, calculation_version, data_as_of, created_at FROM offer_checks ORDER BY created_at'),
          client.query("SELECT id, offer_check_id, outcome, source, reported_at FROM offer_outcomes WHERE source = 'member_self_report' ORDER BY reported_at"),
          client.query('SELECT id, as_of_date, starting_balance, events, created_at, updated_at, expires_at FROM member_cashflow_profiles WHERE expires_at > now()'),
          client.query('SELECT id, transaction_count, created_at FROM transaction_imports ORDER BY created_at'),
          client.query('SELECT amount, transaction_date, description, created_at FROM imported_transactions ORDER BY transaction_date, id'),
          client.query('SELECT id, action, entity_type, entity_id, occurred_at, metadata FROM audit_events WHERE actor_user_id = $1 ORDER BY occurred_at', [userId]),
        ]);
        await client.query(
          'INSERT INTO audit_events (tenant_id, actor_user_id, action, entity_type, request_id, metadata) VALUES ($1, $2, $3, $4, $5, $6::jsonb)',
          [tenant.id, userId, 'member.data_exported', 'member_account', randomUUID(), JSON.stringify({})],
        );
        return { organization: { id: tenant.id, name: tenant.name }, consents: consents.rows, offerChecks: offerChecks.rows, offerOutcomes: offerOutcomes.rows, cashflowProfiles: cashflowProfiles.rows, transactionImports: transactionImports.rows, importedTransactions: importedTransactions.rows, auditEvents: auditEvents.rows };
      });
    }));
    const headers = new Headers({
      'content-type': 'application/json; charset=utf-8',
      'content-disposition': 'attachment; filename="aegis-member-data.json"',
      'cache-control': 'private, no-store, max-age=0',
    });
    return new Response(JSON.stringify({ exportedAt: new Date().toISOString(), memberships }), { headers });
  } catch {
    return Response.json({ error: 'Your data export is temporarily unavailable.' }, { status: 503 });
  }
}
