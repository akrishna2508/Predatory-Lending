import { randomUUID } from 'node:crypto';
import { z } from 'zod';
import { hasSafeMutationOrigin, MemberAuthError, resolveMemberIdentity } from '@/server/member-auth';
import { getDatabasePool, withMemberTransaction } from '@/server/database';
import { readJsonBody, RequestBodyError } from '@/server/http-body';

export const runtime = 'nodejs';

const consentSchema = z.object({
  purpose: z.enum(['manual_financial_profile', 'cashflow_profile_storage', 'transaction_history_upload', 'transaction_pattern_analysis', 'offer_check_storage', 'offer_outcome_reporting', 'research']),
  action: z.enum(['granted', 'revoked']),
}).strict();

const CONSENT_POLICY_VERSION = '2026-09-27.1';

export async function GET(request: Request) {
  const identity = await authenticate(request);
  if (identity instanceof Response) return identity;
  try {
    const consents = await withMemberTransaction(getDatabasePool(), identity, async client => {
      const result = await client.query(
        'SELECT DISTINCT ON (purpose) purpose, action, policy_version, occurred_at FROM consent_events ORDER BY purpose, event_seq DESC',
      );
      return result.rows;
    });
    return Response.json({ consents });
  } catch (error) {
    return databaseError(error);
  }
}

export async function POST(request: Request) {
  if (!hasSafeMutationOrigin(request)) return Response.json({ error: 'Cross-origin request rejected.' }, { status: 403 });
  const identity = await authenticate(request);
  if (identity instanceof Response) return identity;

  let payload: unknown;
  try {
    payload = await readJsonBody(request, 4_000);
  } catch (error) {
    if (error instanceof RequestBodyError) return Response.json({ error: error.message }, { status: error.status });
    return Response.json({ error: 'A JSON consent choice is required.' }, { status: 400 });
  }
  const parsed = consentSchema.safeParse(payload);
  if (!parsed.success) return Response.json({ error: 'Choose a supported consent purpose and action.' }, { status: 400 });

  const eventId = randomUUID();
  const requestId = randomUUID();
  try {
    await withMemberTransaction(getDatabasePool(), identity, async client => {
      await client.query(
        'INSERT INTO consent_events (id, tenant_id, member_user_id, purpose, action, policy_version, request_id) VALUES ($1, $2, $3, $4, $5, $6, $7)',
        [eventId, identity.tenantId, identity.userId, parsed.data.purpose, parsed.data.action, CONSENT_POLICY_VERSION, requestId],
      );
      if (parsed.data.purpose === 'transaction_history_upload' && parsed.data.action === 'revoked') {
        await client.query(
          "INSERT INTO consent_events (id, tenant_id, member_user_id, purpose, action, policy_version, request_id) VALUES ($1, $2, $3, 'transaction_pattern_analysis', 'revoked', $4, $5)",
          [randomUUID(), identity.tenantId, identity.userId, CONSENT_POLICY_VERSION, requestId],
        );
      }

      if (parsed.data.action === 'revoked' && ['manual_financial_profile', 'offer_check_storage'].includes(parsed.data.purpose)) {
        await client.query('DELETE FROM offer_checks WHERE tenant_id = $1 AND member_user_id = $2', [identity.tenantId, identity.userId]);
      }
      if (parsed.data.action === 'revoked' && ['manual_financial_profile', 'cashflow_profile_storage'].includes(parsed.data.purpose)) {
        await client.query('SELECT aegis_purge_member_cashflow_profile()');
      }
      if (parsed.data.action === 'revoked' && parsed.data.purpose === 'offer_outcome_reporting') {
        await client.query('DELETE FROM offer_outcomes WHERE tenant_id = $1 AND member_user_id = $2', [identity.tenantId, identity.userId]);
      }
      if (parsed.data.action === 'revoked' && parsed.data.purpose === 'transaction_history_upload') {
        await client.query('DELETE FROM transaction_imports WHERE tenant_id = $1 AND member_user_id = $2', [identity.tenantId, identity.userId]);
      }

      await client.query(
        'INSERT INTO audit_events (tenant_id, actor_user_id, action, entity_type, entity_id, request_id, metadata) VALUES ($1, $2, $3, $4, $5, $6, $7::jsonb)',
        [identity.tenantId, identity.userId, `consent.${parsed.data.action}`, 'consent_event', eventId, requestId, JSON.stringify({ purpose: parsed.data.purpose, ...(parsed.data.purpose === 'transaction_history_upload' && parsed.data.action === 'revoked' ? { alsoRevoked: ['transaction_pattern_analysis'] } : {}), policyVersion: CONSENT_POLICY_VERSION })],
      );
    });
    return Response.json({ consent: { id: eventId, ...parsed.data, policyVersion: CONSENT_POLICY_VERSION } }, { status: 201 });
  } catch (error) {
    return databaseError(error);
  }
}

async function authenticate(request: Request) {
  try {
    return await resolveMemberIdentity(request);
  } catch (error) {
    if (error instanceof MemberAuthError) {
      const status = error.message === 'Tenant identifier required' ? 400 : 401;
      return Response.json({ error: error.message }, { status });
    }
    return Response.json({ error: 'Authentication failed.' }, { status: 401 });
  }
}

function databaseError(error: unknown) {
  if (error instanceof Error && error.message === 'Active membership required') {
    return Response.json({ error: 'An active member account is required.' }, { status: 403 });
  }
  if (error instanceof Error && error.message === 'Member role required') {
    return Response.json({ error: 'This endpoint is available to members only.' }, { status: 403 });
  }
  return Response.json({ error: 'The member service is temporarily unavailable.' }, { status: 503 });
}
