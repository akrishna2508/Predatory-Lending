import { randomUUID } from 'node:crypto';
import { hasCashflowProfileStorageConsent, validateCashflowProfile } from '@/server/cashflow-profile';
import { hasSafeMutationOrigin, MemberAuthError, resolveMemberIdentity } from '@/server/member-auth';
import { getDatabasePool, withMemberTransaction, type MemberDatabaseClient } from '@/server/database';
import { readJsonBody, RequestBodyError } from '@/server/http-body';

export const runtime = 'nodejs';

const PROFILE_CONSENT_ERROR = 'Grant both financial-calculation and cash-flow storage consent before saving or loading this profile.';

export async function GET(request: Request) {
  const identity = await authenticate(request);
  if (identity instanceof Response) return identity;

  try {
    const result = await withMemberTransaction(getDatabasePool(), identity, async client => {
      const consentRows = await latestProfileConsents(client);
      if (!hasCashflowProfileStorageConsent(consentRows)) return { consentGranted: false, profile: null };
      const profileResult = await client.query(
        `SELECT id, as_of_date, starting_balance, events, created_at, updated_at, expires_at
         FROM member_cashflow_profiles WHERE expires_at > now() LIMIT 1`,
      );
      return { consentGranted: true, profile: profileResult.rows[0] ?? null };
    });
    if (!result.consentGranted) return json({ error: PROFILE_CONSENT_ERROR }, 403);
    return json({ profile: serializeProfile(result.profile) });
  } catch (error) {
    return databaseError(error);
  }
}

export async function PUT(request: Request) {
  if (!hasSafeMutationOrigin(request)) return json({ error: 'Cross-origin request rejected.' }, 403);
  const identity = await authenticate(request);
  if (identity instanceof Response) return identity;

  let payload: unknown;
  try {
    payload = await readJsonBody(request, 32_000);
  } catch (error) {
    if (error instanceof RequestBodyError) return json({ error: error.message }, error.status);
    return json({ error: 'A JSON cash-flow profile is required.' }, 400);
  }

  const validation = validateCashflowProfile(payload, new Date().toISOString().slice(0, 10));
  if (!validation.valid) return json({ error: validation.reason }, 400);

  const requestId = randomUUID();
  try {
    const result = await withMemberTransaction(getDatabasePool(), identity, async client => {
      const consentRows = await latestProfileConsents(client);
      if (!hasCashflowProfileStorageConsent(consentRows)) return { consentGranted: false, profile: null };

      const upserted = await client.query(
        `INSERT INTO member_cashflow_profiles
           (tenant_id, member_user_id, as_of_date, starting_balance, events, expires_at)
         VALUES ($1, $2, $3, $4, $5::jsonb, now() + interval '30 days')
         ON CONFLICT (tenant_id, member_user_id) DO UPDATE SET
           as_of_date = EXCLUDED.as_of_date,
           starting_balance = EXCLUDED.starting_balance,
           events = EXCLUDED.events,
           updated_at = now(),
           expires_at = now() + interval '30 days'
         RETURNING id, as_of_date, starting_balance, events, created_at, updated_at, expires_at`,
        [identity.tenantId, identity.userId, validation.profile.asOfDate, validation.profile.startingBalance, JSON.stringify(validation.profile.events)],
      );
      const profile = upserted.rows[0];
      await client.query(
        `INSERT INTO audit_events (tenant_id, actor_user_id, action, entity_type, entity_id, request_id, metadata)
         VALUES ($1, $2, 'member.cashflow_profile_saved', 'cashflow_profile', $3, $4, $5::jsonb)`,
        [identity.tenantId, identity.userId, profile.id, requestId, JSON.stringify({ asOfDate: validation.profile.asOfDate, itemCount: validation.profile.events.length })],
      );
      return { consentGranted: true, profile };
    });
    if (!result.consentGranted) return json({ error: PROFILE_CONSENT_ERROR }, 403);
    return json({ profile: serializeProfile(result.profile) });
  } catch (error) {
    return databaseError(error);
  }
}

export async function DELETE(request: Request) {
  if (!hasSafeMutationOrigin(request)) return json({ error: 'Cross-origin request rejected.' }, 403);
  const identity = await authenticate(request);
  if (identity instanceof Response) return identity;

  const requestId = randomUUID();
  try {
    const deleted = await withMemberTransaction(getDatabasePool(), identity, async client => {
      const result = await client.query(
        'DELETE FROM member_cashflow_profiles WHERE tenant_id = $1 AND member_user_id = $2 RETURNING id',
        [identity.tenantId, identity.userId],
      );
      if (result.rows[0]) {
        await client.query(
          `INSERT INTO audit_events (tenant_id, actor_user_id, action, entity_type, entity_id, request_id, metadata)
           VALUES ($1, $2, 'member.cashflow_profile_deleted', 'cashflow_profile', $3, $4, '{}'::jsonb)`,
          [identity.tenantId, identity.userId, result.rows[0].id, requestId],
        );
      }
      return Boolean(result.rows[0]);
    });
    return json({ deleted });
  } catch (error) {
    return databaseError(error);
  }
}

async function latestProfileConsents(client: MemberDatabaseClient) {
  const result = await client.query(
    `SELECT DISTINCT ON (purpose) purpose, action FROM consent_events
     WHERE purpose IN ('manual_financial_profile', 'cashflow_profile_storage')
     ORDER BY purpose, event_seq DESC`,
  );
  return result.rows.map(row => ({ purpose: String(row.purpose), action: String(row.action) }));
}

function serializeProfile(profile: Record<string, unknown> | null) {
  if (!profile) return null;
  return {
    id: profile.id,
    as_of_date: profile.as_of_date,
    starting_balance: Number(profile.starting_balance),
    events: profile.events,
    created_at: profile.created_at,
    updated_at: profile.updated_at,
    expires_at: profile.expires_at,
  };
}

async function authenticate(request: Request) {
  try {
    return await resolveMemberIdentity(request);
  } catch (error) {
    if (error instanceof MemberAuthError) {
      const status = error.message === 'Tenant identifier required' ? 400 : 401;
      return json({ error: error.message }, status);
    }
    return json({ error: 'Authentication failed.' }, 401);
  }
}

function databaseError(error: unknown) {
  if (error instanceof Error && error.message === 'Active membership required') {
    return json({ error: 'An active member account is required.' }, 403);
  }
  if (error instanceof Error && error.message === 'Member role required') {
    return json({ error: 'This endpoint is available to members only.' }, 403);
  }
  return json({ error: 'The member service is temporarily unavailable.' }, 503);
}

function json(body: unknown, status = 200) {
  return Response.json(body, {
    status,
    headers: { 'cache-control': 'private, no-store, max-age=0' },
  });
}
