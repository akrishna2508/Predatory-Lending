import { randomUUID } from 'node:crypto';
import { hasOfferCheckConsent, validateOfferCheck } from '@/server/offer-service';
import { hasSafeMutationOrigin, MemberAuthError, resolveMemberIdentity } from '@/server/member-auth';
import { getDatabasePool, withMemberTransaction } from '@/server/database';
import { readJsonBody, RequestBodyError } from '@/server/http-body';
import { OFFER_CALCULATION_VERSION } from '@/domain/finance';

export const runtime = 'nodejs';

export async function GET(request: Request) {
  const identity = await authenticate(request);
  if (identity instanceof Response) return identity;

  try {
    const records = await withMemberTransaction(getDatabasePool(), identity, async client => {
      const result = await client.query(
        `SELECT oc.id, oc.title, oc.input_payload, oc.result_payload, oc.calculation_version, oc.data_as_of, oc.created_at,
                latest.outcome, latest.outcome_source, latest.outcome_reported_at
         FROM offer_checks oc
         LEFT JOIN LATERAL (
           SELECT oo.outcome, oo.source AS outcome_source, oo.reported_at AS outcome_reported_at
           FROM offer_outcomes oo
           WHERE oo.offer_check_id = oc.id
           ORDER BY oo.reported_at DESC, oo.id DESC
           LIMIT 1
         ) latest ON true
         LEFT JOIN LATERAL (
           SELECT r.id AS reminder_id, r.reminder_at, r.reminder_at <= now() AS reminder_due
           FROM member_reminders r
           WHERE r.offer_check_id = oc.id AND r.status = 'scheduled'
           ORDER BY r.updated_at DESC
           LIMIT 1
         ) reminder ON true
         ORDER BY oc.created_at DESC LIMIT 50`,
      );
      return result.rows;
    });
    return Response.json({ offerChecks: records });
  } catch (error) {
    return databaseError(error);
  }
}

export async function POST(request: Request) {
  if (!hasSafeMutationOrigin(request)) return Response.json({ error: 'Cross-origin request rejected.' }, { status: 403 });
  const identity = await authenticate(request);
  if (identity instanceof Response) return identity;

  let payload: unknown;
  try {
    payload = await readJsonBody(request, 64_000);
  } catch (error) {
    if (error instanceof RequestBodyError) return Response.json({ error: error.message }, { status: error.status });
    return Response.json({ error: 'A JSON offer check is required.' }, { status: 400 });
  }
  const analysis = validateOfferCheck(payload);
  if (!analysis.valid) return Response.json({ error: analysis.reason }, { status: 422 });

  const checkId = randomUUID();
  const requestId = randomUUID();
  try {
    const result = await withMemberTransaction(getDatabasePool(), identity, async client => {
      const consentRows = await client.query(
        "SELECT DISTINCT ON (purpose) purpose, action FROM consent_events WHERE tenant_id = $1 AND member_user_id = $2 AND purpose IN ('manual_financial_profile', 'offer_check_storage') ORDER BY purpose, event_seq DESC",
        [identity.tenantId, identity.userId],
      );
      if (!hasOfferCheckConsent(consentRows.rows as Array<{ purpose: string; action: string }>)) {
        throw new ConsentRequiredError();
      }

      const inputPayload = { ...(payload as Record<string, unknown>) };
      if (!analysis.repeatBorrowingPrompt) delete inputPayload.recentShortTermLoanRepaymentDate;
      const saved = await client.query(
        'INSERT INTO offer_checks (id, tenant_id, member_user_id, input_payload, result_payload, calculation_version, data_as_of) VALUES ($1, $2, $3, $4::jsonb, $5::jsonb, $6, $7) RETURNING id, created_at',
        [checkId, identity.tenantId, identity.userId, JSON.stringify(inputPayload), JSON.stringify(analysis), OFFER_CALCULATION_VERSION, inputPayload.asOfDate],
      );
      await client.query(
        'INSERT INTO audit_events (tenant_id, actor_user_id, action, entity_type, entity_id, request_id, metadata) VALUES ($1, $2, $3, $4, $5, $6, $7::jsonb)',
        [identity.tenantId, identity.userId, 'offer_check.created', 'offer_check', checkId, requestId, JSON.stringify({ calculationVersion: OFFER_CALCULATION_VERSION })],
      );
      return saved.rows[0];
    });
    return Response.json({ offerCheck: { ...result, analysis } }, { status: 201 });
  } catch (error) {
    if (error instanceof ConsentRequiredError) return Response.json({ error: 'Grant financial profile and offer-check storage consent before saving an offer check.' }, { status: 403 });
    return databaseError(error);
  }
}

async function authenticate(request: Request) {
  try {
    return await resolveMemberIdentity(request);
  } catch (error) {
    if (error instanceof MemberAuthError) {
      const status = error.message === 'Tenant identifier required' ? 400 : 401;
      return Response.json({ error: error.message }, { status });
    }
    return Response.json({ error: 'Authentication failed.' }, { status: 401 });
  }
}

class ConsentRequiredError extends Error {}

function databaseError(error: unknown) {
  if (error instanceof Error && error.message === 'Active membership required') {
    return Response.json({ error: 'An active member account is required.' }, { status: 403 });
  }
  if (error instanceof Error && error.message === 'Member role required') {
    return Response.json({ error: 'This endpoint is available to members only.' }, { status: 403 });
  }
  return Response.json({ error: 'The member service is temporarily unavailable.' }, { status: 503 });
}
