import { randomUUID } from 'node:crypto';
import { hasMemberOfferOutcomeConsent, parseMemberOfferOutcome } from '@/domain/offer-outcome';
import { hasSafeMutationOrigin, MemberAuthError, resolveMemberIdentity } from '@/server/member-auth';
import { getDatabasePool, withMemberTransaction } from '@/server/database';
import { readJsonBody, RequestBodyError } from '@/server/http-body';

export const runtime = 'nodejs';

type RouteContext = { params: Promise<{ id: string }> };
const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

export async function POST(request: Request, context: RouteContext) {
  if (!hasSafeMutationOrigin(request)) return Response.json({ error: 'Cross-origin request rejected.' }, { status: 403 });
  let identity;
  try {
    identity = await resolveMemberIdentity(request);
  } catch (error) {
    if (error instanceof MemberAuthError) {
      const status = error.message === 'Tenant identifier required' ? 400 : 401;
      return Response.json({ error: error.message }, { status });
    }
    return Response.json({ error: 'Authentication failed.' }, { status: 401 });
  }

  const { id: offerCheckId } = await context.params;
  if (!uuid.test(offerCheckId)) return Response.json({ error: 'Saved offer check not found.' }, { status: 404 });

  let payload: unknown;
  try {
    payload = await readJsonBody(request, 16_000);
  } catch (error) {
    if (error instanceof RequestBodyError) return Response.json({ error: error.message }, { status: error.status });
    return Response.json({ error: 'A decision choice is required.' }, { status: 400 });
  }
  const parsed = parseMemberOfferOutcome(payload);
  if (!parsed.valid) return Response.json({ error: 'Choose one of the available decision options.' }, { status: 422 });

  const requestId = randomUUID();
  try {
    const outcome = await withMemberTransaction(getDatabasePool(), identity, async client => {
      const consentRows = await client.query(
        "SELECT DISTINCT ON (purpose) purpose, action FROM consent_events WHERE tenant_id = $1 AND member_user_id = $2 AND purpose IN ('manual_financial_profile', 'offer_check_storage', 'offer_outcome_reporting') ORDER BY purpose, event_seq DESC",
        [identity.tenantId, identity.userId],
      );
      if (!hasMemberOfferOutcomeConsent(consentRows.rows as Array<{ purpose: string; action: string }>)) throw new ConsentRequiredError();

      const saved = await client.query(
        `INSERT INTO offer_outcomes (tenant_id, member_user_id, offer_check_id, outcome)
         SELECT $1, $2, oc.id, $4
         FROM offer_checks oc
         WHERE oc.id = $3 AND oc.tenant_id = $1 AND oc.member_user_id = $2
         RETURNING id, offer_check_id, outcome, source, reported_at`,
        [identity.tenantId, identity.userId, offerCheckId, parsed.outcome],
      );
      if (!saved.rows[0]) throw new OfferCheckUnavailableError();

      await client.query(
        'INSERT INTO audit_events (tenant_id, actor_user_id, action, entity_type, entity_id, request_id, metadata) VALUES ($1, $2, $3, $4, $5, $6, $7::jsonb)',
        [identity.tenantId, identity.userId, 'member.offer_outcome.reported', 'offer_check', offerCheckId, requestId, JSON.stringify({ source: 'member_self_report' })],
      );
      return saved.rows[0];
    });
    return Response.json({ offerOutcome: outcome }, { status: 201 });
  } catch (error) {
    if (error instanceof ConsentRequiredError) return Response.json({ error: 'Grant financial profile and offer-check storage consent before saving a decision.' }, { status: 403 });
    if (error instanceof OfferCheckUnavailableError) return Response.json({ error: 'Saved offer check not found.' }, { status: 404 });
    if (error instanceof Error && error.message === 'Active membership required') return Response.json({ error: 'An active member account is required.' }, { status: 403 });
    if (error instanceof Error && error.message === 'Member role required') return Response.json({ error: 'This endpoint is available to members only.' }, { status: 403 });
    return Response.json({ error: 'Your decision could not be saved right now.' }, { status: 503 });
  }
}

class ConsentRequiredError extends Error {}
class OfferCheckUnavailableError extends Error {}
