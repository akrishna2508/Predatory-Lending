import { randomUUID } from 'node:crypto';
import { z } from 'zod';
import { hasSafeMutationOrigin, MemberAuthError, resolveMemberIdentity } from '@/server/member-auth';
import { getDatabasePool, withMemberTransaction } from '@/server/database';
import { readJsonBody, RequestBodyError } from '@/server/http-body';

export const runtime = 'nodejs';
const uuidSchema = z.string().uuid();
const bodySchema = z.object({ reminderAt: z.string().datetime({ offset: true }) }).strict();
const MIN_DELAY_MS = 2 * 60_000;
const MAX_DELAY_MS = 30 * 24 * 60 * 60_000;

export async function POST(request: Request, context: { params: Promise<{ id: string }> }) {
  if (!hasSafeMutationOrigin(request)) return Response.json({ error: 'Cross-origin request rejected.' }, { status: 403 });
  const identity = await authenticate(request);
  if (identity instanceof Response) return identity;
  const { id: offerCheckId } = await context.params;
  if (!uuidSchema.safeParse(offerCheckId).success) return Response.json({ error: 'Saved comparison was not found.' }, { status: 404 });

  let payload: unknown;
  try {
    payload = await readJsonBody(request, 1_000);
  } catch (error) {
    if (error instanceof RequestBodyError) return Response.json({ error: error.message }, { status: error.status });
    return Response.json({ error: 'A reminder time is required.' }, { status: 400 });
  }
  const parsed = bodySchema.safeParse(payload);
  if (!parsed.success) return Response.json({ error: 'Enter a valid date and time for your reminder.' }, { status: 400 });
  const reminderAt = new Date(parsed.data.reminderAt);
  const delay = reminderAt.getTime() - Date.now();
  if (!Number.isFinite(delay) || delay < MIN_DELAY_MS || delay > MAX_DELAY_MS) {
    return Response.json({ error: 'Choose a reminder at least two minutes from now and within 30 days.' }, { status: 422 });
  }

  try {
    const reminder = await withMemberTransaction(getDatabasePool(), identity, async client => {
      const consent = await client.query(
        "SELECT action FROM consent_events WHERE tenant_id = $1 AND member_user_id = $2 AND purpose = 'offer_check_storage' ORDER BY event_seq DESC LIMIT 1",
        [identity.tenantId, identity.userId],
      );
      if (consent.rows[0]?.action !== 'granted') return null;
      const result = await client.query(
        `INSERT INTO member_reminders (tenant_id, member_user_id, offer_check_id, reminder_at)
         VALUES ($1, $2, $3, $4)
         ON CONFLICT (tenant_id, member_user_id, offer_check_id) WHERE status = 'scheduled'
         DO UPDATE SET reminder_at = EXCLUDED.reminder_at, updated_at = now()
         RETURNING id, reminder_at, reminder_at <= now() AS due`,
        [identity.tenantId, identity.userId, offerCheckId, reminderAt.toISOString()],
      );
      return result.rows[0] ?? null;
    });
    if (!reminder) return Response.json({ error: 'Keep offer-comparison storage consent on to schedule a reminder.' }, { status: 403 });
    return Response.json({ reminder }, { status: 201, headers: { 'cache-control': 'private, no-store' } });
  } catch (error) {
    const code = typeof error === 'object' && error !== null && 'code' in error ? error.code : undefined;
    if (code === '23503') return Response.json({ error: 'Saved comparison was not found.' }, { status: 404 });
    return Response.json({ error: 'Your reminder could not be saved. Try again.' }, { status: 503 });
  }
}

export async function DELETE(request: Request, context: { params: Promise<{ id: string }> }) {
  if (!hasSafeMutationOrigin(request)) return Response.json({ error: 'Cross-origin request rejected.' }, { status: 403 });
  const identity = await authenticate(request);
  if (identity instanceof Response) return identity;
  const { id: offerCheckId } = await context.params;
  if (!uuidSchema.safeParse(offerCheckId).success) return Response.json({ error: 'Saved comparison was not found.' }, { status: 404 });

  try {
    const cancelled = await withMemberTransaction(getDatabasePool(), identity, async client => {
      const result = await client.query(
        "UPDATE member_reminders SET status = 'cancelled', updated_at = now() WHERE offer_check_id = $1 AND status = 'scheduled' RETURNING id",
        [offerCheckId],
      );
      return result.rows.length > 0;
    });
    if (!cancelled) return Response.json({ error: 'No scheduled reminder was found.' }, { status: 404 });
    return Response.json({ cancelled: true }, { headers: { 'cache-control': 'private, no-store' } });
  } catch {
    return Response.json({ error: 'Your reminder could not be cancelled. Try again.' }, { status: 503 });
  }
}

async function authenticate(request: Request) {
  try {
    return await resolveMemberIdentity(request);
  } catch (error) {
    if (error instanceof MemberAuthError) {
      const status = error.message === 'Tenant identifier required' ? 400 : 401;
      return Response.json({ error: error.message }, { status });
    }
    return Response.json({ error: 'Authentication failed.' }, { status: 401 });
  }
}
