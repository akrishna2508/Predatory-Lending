import { z } from 'zod';
import { MemberAuthError, resolveMemberIdentity } from '@/server/member-auth';
import { getDatabasePool, withMemberTransaction } from '@/server/database';
import { findRecurringCashflowSuggestions, type RecurringTransaction } from '@/domain/recurring-cashflow';
import { findShieldSignals } from '@/domain/transaction-shield';

export const runtime = 'nodejs';
const querySchema = z.object({
  limit: z.coerce.number().int().min(1).max(100).default(50),
  offset: z.coerce.number().int().min(0).max(5_000).default(0),
});

export async function GET(request: Request) {
  let identity;
  try { identity = await resolveMemberIdentity(request); }
  catch (error) {
    const message = error instanceof MemberAuthError ? error.message : 'Authentication failed';
    return Response.json({ error: message }, { status: message === 'Tenant identifier required' ? 400 : 401 });
  }
  const parsed = querySchema.safeParse(Object.fromEntries(new URL(request.url).searchParams));
  if (!parsed.success) return Response.json({ error: 'Transaction page is invalid.' }, { status: 400 });
  try {
    const asOfDate = new Date().toISOString().slice(0, 10);
    const result = await withMemberTransaction(getDatabasePool(), identity, async client => {
      const latestConsent = await client.query(
        "SELECT action FROM consent_events WHERE purpose = 'transaction_history_upload' ORDER BY event_seq DESC LIMIT 1",
      );
      if (latestConsent.rows[0]?.action !== 'granted') return { transactions: [], total: 0, cashflowSuggestions: [], shieldSignals: [] };
      const transactions = await client.query(
        `SELECT id, amount, to_char(transaction_date, 'YYYY-MM-DD') AS transaction_date, description AS name, description AS merchant_name,
                false AS pending, ARRAY[]::text[] AS categories, created_at AS updated_at
         FROM imported_transactions ORDER BY transaction_date DESC, id DESC LIMIT $1 OFFSET $2`,
        [parsed.data.limit, parsed.data.offset],
      );
      const total = await client.query('SELECT count(*)::integer AS total FROM imported_transactions');
      const analysisConsent = await client.query(
        "SELECT action FROM consent_events WHERE purpose = 'transaction_pattern_analysis' ORDER BY event_seq DESC LIMIT 1",
      );
      const history = await client.query(
        `SELECT 'csv-upload'::text AS account_id, description AS name, description AS merchant_name,
                amount, to_char(transaction_date, 'YYYY-MM-DD') AS transaction_date, false AS pending
         FROM imported_transactions WHERE transaction_date >= $1::date - interval '183 days'
           AND transaction_date <= $1::date ORDER BY transaction_date DESC LIMIT 5000`,
        [asOfDate],
      );
      const cashflowSuggestions = findRecurringCashflowSuggestions(history.rows.map(row => ({
        accountId: String(row.account_id), name: String(row.name),
        merchantName: row.merchant_name === null ? null : String(row.merchant_name),
        amount: Number(row.amount), date: String(row.transaction_date).slice(0, 10), pending: row.pending === true,
      })) satisfies RecurringTransaction[], asOfDate);
      const shieldSignals = analysisConsent.rows[0]?.action === 'granted'
        ? findShieldSignals(history.rows.map(row => ({
          description: String(row.name),
          amount: Number(row.amount),
          date: String(row.transaction_date).slice(0, 10),
        })), asOfDate)
        : [];
      return { transactions: transactions.rows, total: total.rows[0]?.total ?? 0, cashflowSuggestions, shieldSignals };
    });
    return Response.json(result, { headers: { 'cache-control': 'private, no-store' } });
  } catch {
    return Response.json({ error: 'Imported transactions are temporarily unavailable.' }, { status: 503 });
  }
}
