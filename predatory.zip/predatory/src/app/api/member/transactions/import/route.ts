import { createHash, randomUUID } from 'node:crypto';
import { hasSafeMutationOrigin, MemberAuthError, resolveMemberIdentity } from '@/server/member-auth';
import { getDatabasePool, withMemberTransaction } from '@/server/database';
import { readTextBody, RequestBodyError } from '@/server/http-body';
import { parseTransactionCsv, TransactionCsvError } from '@/domain/csv-transactions';

export const runtime = 'nodejs';
const MAX_UPLOAD_BYTES = 1_000_000;

export async function POST(request: Request) {
  if (!hasSafeMutationOrigin(request)) return Response.json({ error: 'Cross-origin request rejected.' }, { status: 403 });
  let identity;
  try { identity = await resolveMemberIdentity(request); }
  catch (error) {
    const message = error instanceof MemberAuthError ? error.message : 'Authentication failed';
    return Response.json({ error: message }, { status: message === 'Tenant identifier required' ? 400 : 401 });
  }
  if (!['text/csv', 'text/plain', 'application/vnd.ms-excel'].includes(request.headers.get('content-type')?.split(';')[0].trim() ?? '')) {
    return Response.json({ error: 'Upload a CSV transaction file.' }, { status: 415 });
  }

  let csv: string;
  try { csv = await readTextBody(request, MAX_UPLOAD_BYTES); }
  catch (error) {
    if (error instanceof RequestBodyError) return Response.json({ error: error.message }, { status: error.status });
    return Response.json({ error: 'The CSV upload could not be read.' }, { status: 400 });
  }

  let parsed;
  try { parsed = parseTransactionCsv(csv); }
  catch (error) {
    if (error instanceof TransactionCsvError) return Response.json({ error: error.message }, { status: 400 });
    return Response.json({ error: 'The CSV file is invalid.' }, { status: 400 });
  }
  const hash = createHash('sha256').update(csv).digest('hex');
  const importId = randomUUID();
  const requestId = randomUUID();

  try {
    const result = await withMemberTransaction(getDatabasePool(), identity, async client => {
      const latestConsent = await client.query(
        "SELECT action FROM consent_events WHERE purpose = 'transaction_history_upload' ORDER BY event_seq DESC LIMIT 1",
      );
      if (latestConsent.rows[0]?.action !== 'granted') return { error: 'consent' as const };

      const inserted = await client.query(
        `INSERT INTO transaction_imports (id, tenant_id, member_user_id, source_hash, transaction_count)
         VALUES ($1, $2, $3, decode($4, 'hex'), $5)
         ON CONFLICT (tenant_id, member_user_id, source_hash) DO NOTHING
         RETURNING id`,
        [importId, identity.tenantId, identity.userId, hash, parsed.transactions.length],
      );
      if (!inserted.rows.length) return { error: 'duplicate' as const };

      await client.query(
        `INSERT INTO imported_transactions
          (tenant_id, member_user_id, import_id, row_number, amount, transaction_date, description)
         SELECT $1, $2, $3, row_number, amount, transaction_date, description
         FROM unnest($4::integer[], $5::numeric[], $6::date[], $7::text[])
           AS rows(row_number, amount, transaction_date, description)`,
        [
          identity.tenantId,
          identity.userId,
          importId,
          parsed.transactions.map((_, index) => index + 1),
          parsed.transactions.map(transaction => transaction.amount),
          parsed.transactions.map(transaction => transaction.date),
          parsed.transactions.map(transaction => transaction.description),
        ],
      );
      await client.query(
        `INSERT INTO audit_events (tenant_id, actor_user_id, action, entity_type, entity_id, request_id, metadata)
         VALUES ($1, $2, 'member.transactions_imported', 'transaction_import', $3, $4, $5::jsonb)`,
        [identity.tenantId, identity.userId, importId, requestId, JSON.stringify({ transactionCount: parsed.transactions.length })],
      );
      return { imported: parsed.transactions.length, skippedRows: parsed.skippedRows };
    });
    if ('error' in result && result.error === 'consent') return Response.json({ error: 'Grant transaction upload consent before importing a file.' }, { status: 403 });
    if ('error' in result && result.error === 'duplicate') return Response.json({ error: 'This exact CSV has already been imported.' }, { status: 409 });
    return Response.json(result, { status: 201, headers: { 'cache-control': 'private, no-store' } });
  } catch (error) {
    if (error instanceof Error && error.message === 'Active membership required') return Response.json({ error: 'An active member account is required.' }, { status: 403 });
    if (error instanceof Error && error.message === 'Member role required') return Response.json({ error: 'This endpoint is available to members only.' }, { status: 403 });
    return Response.json({ error: 'The transaction import is temporarily unavailable.' }, { status: 503 });
  }
}
