import { createHash } from 'node:crypto';
import { MEMBER_SESSION_COOKIE } from '@/server/member-auth';
import { getDatabasePool } from '@/server/database';

export const runtime = 'nodejs';

export async function GET(request: Request) {
  const token = readCookie(request.headers.get('cookie'), MEMBER_SESSION_COOKIE);
  if (token && /^[A-Za-z0-9_-]{43}$/.test(token)) {
    try {
      await getDatabasePool().query('SELECT aegis_revoke_member_session($1)', [createHash('sha256').update(token).digest()]);
    } catch {
      const response = new Response(null, {
        status: 303,
        headers: { location: new URL('/?sign_out_error=1', request.url).toString(), 'cache-control': 'no-store' },
      });
      return response;
    }
  }
  const secure = process.env.NODE_ENV === 'production' ? '; Secure' : '';
  const response = new Response(null, {
    status: 303,
    headers: { location: new URL('/', request.url).toString(), 'cache-control': 'no-store' },
  });
  response.headers.append('Set-Cookie', `${MEMBER_SESSION_COOKIE}=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0${secure}`);
  return response;
}

function readCookie(header: string | null, name: string): string | null {
  for (const part of header?.split(';') ?? []) {
    const separator = part.indexOf('=');
    if (separator > 0 && part.slice(0, separator).trim() === name) return part.slice(separator + 1).trim();
  }
  return null;
}
