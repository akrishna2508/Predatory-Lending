import { createHash, randomBytes, scrypt as scryptCallback, timingSafeEqual } from 'node:crypto';
import { z } from 'zod';
import { hasSameOriginRequest, MEMBER_SESSION_COOKIE } from '@/server/member-auth';
import { getDatabasePool } from '@/server/database';
import { readJsonBody, RequestBodyError } from '@/server/http-body';

export const runtime = 'nodejs';
const SCRYPT_OPTIONS = { N: 16384, r: 8, p: 1, maxmem: 64 * 1024 * 1024 };
const loginSchema = z.object({
  email: z.string().trim().email().max(254),
  password: z.string().min(1).max(256),
}).strict();
const SESSION_DURATION_SECONDS = 12 * 60 * 60;

export async function GET(request: Request) {
  return Response.redirect(new URL('/login', request.url), 303);
}

export async function POST(request: Request) {
  if (!hasSameOriginRequest(request)) {
    return Response.json({ error: 'Cross-origin request rejected.' }, { status: 403, headers: noStore() });
  }
  let payload: unknown;
  try { payload = await readJsonBody(request, 4_000); }
  catch (error) {
    const status = error instanceof RequestBodyError ? error.status : 400;
    return Response.json({ error: 'Enter your email and password.' }, { status, headers: noStore() });
  }
  const parsed = loginSchema.safeParse(payload);
  if (!parsed.success) return Response.json({ error: 'Enter a valid email and password.' }, { status: 400, headers: noStore() });
  const email = parsed.data.email.toLowerCase();

  try {
    const pool = getDatabasePool();
    const result = await pool.query(
      'SELECT user_id, password_salt, password_hash, is_locked FROM aegis_lookup_local_credential($1)',
      [email],
    );
    const credential = result.rows[0];
    if (credential?.is_locked) return Response.json({ error: 'Sign-in is temporarily locked. Try again in 15 minutes.' }, { status: 429, headers: noStore() });
    if (!credential) {
      await derivePassword(parsed.data.password, Buffer.alloc(16));
      return Response.json({ error: 'Email or password is incorrect.' }, { status: 401, headers: noStore() });
    }

    const candidate = await derivePassword(parsed.data.password, Buffer.from(credential.password_salt));
    const expected = Buffer.from(credential.password_hash);
    if (candidate.byteLength !== expected.byteLength || !timingSafeEqual(candidate, expected)) {
      await pool.query('SELECT aegis_record_local_login_failure($1)', [email]);
      return Response.json({ error: 'Email or password is incorrect.' }, { status: 401, headers: noStore() });
    }

    const sessionToken = randomBytes(32).toString('base64url');
    const tokenHash = createHash('sha256').update(sessionToken).digest();
    const expiresAt = new Date(Date.now() + SESSION_DURATION_SECONDS * 1_000);
    const created = await pool.query(
      'SELECT aegis_create_member_session($1, $2, $3::timestamptz) AS created',
      [credential.user_id, tokenHash, expiresAt.toISOString()],
    );
    if (created.rows[0]?.created !== true) throw new Error('Local session could not be created');

    const secure = process.env.NODE_ENV === 'production' ? '; Secure' : '';
    const response = Response.json({ signedIn: true }, { headers: noStore() });
    response.headers.append('Set-Cookie', `${MEMBER_SESSION_COOKIE}=${sessionToken}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${SESSION_DURATION_SECONDS}${secure}`);
    return response;
  } catch (error) {
    console.error('Sign-in failed:', error instanceof Error ? error.message : error);
    return Response.json({ error: 'Sign-in is temporarily unavailable.' }, { status: 503, headers: noStore() });
  }
}

function noStore(): HeadersInit { return { 'cache-control': 'no-store', 'pragma': 'no-cache' }; }

function derivePassword(password: string, salt: Uint8Array): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    scryptCallback(password, salt, 64, SCRYPT_OPTIONS, (error, derived) => {
      if (error) reject(error);
      else resolve(derived as Buffer);
    });
  });
}
