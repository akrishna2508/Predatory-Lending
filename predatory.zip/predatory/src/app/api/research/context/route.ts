import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { resolveModelingProjectRoot } from '@/server/modeling-paths';

export const runtime = 'nodejs';

async function readAggregate(filename: string): Promise<Record<string, unknown> | null> {
  try {
    const content = await readFile(path.join(resolveModelingProjectRoot(), 'data', 'results', filename), 'utf8');
    const parsed: unknown = JSON.parse(content);
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed)
      ? parsed as Record<string, unknown>
      : null;
  } catch {
    return null;
  }
}

export async function GET(): Promise<Response> {
  const [baseline, complaints, archivedLoanComplaints] = await Promise.all([
    readAggregate('baseline-latest.json'),
    readAggregate('cfpb-latest.json'),
    readAggregate('cfpb-loan-narratives-latest.json'),
  ]);
  const metrics = baseline?.metrics as Record<string, unknown> | undefined;
  const source = baseline?.source as Record<string, unknown> | undefined;
  const coefficients = baseline?.coefficients as Record<string, unknown> | undefined;
  const complaintDate = complaints?.date_coverage as Record<string, unknown> | undefined;
  const topIssues = Array.isArray(complaints?.top_issues) ? complaints.top_issues.slice(0, 3) : [];
  const archivedNarratives = archivedLoanComplaints?.narrative_analysis as Record<string, unknown> | undefined;
  const archivedSignals = archivedNarratives?.signals as Record<string, unknown> | undefined;
  const archivedIssues = Array.isArray(archivedLoanComplaints?.top_issues) ? archivedLoanComplaints.top_issues.slice(0, 3) : [];

  return Response.json({
    baseline: baseline && metrics && source && coefficients ? {
      model: baseline.model,
      trainedAt: baseline.trained_at,
      totalRows: baseline.total_rows,
      trainRows: baseline.train_rows,
      testRows: baseline.test_rows,
      rocAuc: metrics.roc_auc,
      coefficients: { debtToIncome: coefficients.debt_to_income, loanAmount: coefficients.loan_amount },
      source: source.name,
      period: source.caveat,
    } : null,
    complaints: complaints ? {
      rowsUsed: complaints.rows_used,
      dateCoverage: complaintDate ?? null,
      topIssues,
      caveat: complaints.caveat,
    } : null,
    archivedLoanComplaints: archivedLoanComplaints && archivedNarratives && archivedSignals ? {
      rowsUsed: archivedLoanComplaints.rows_used,
      narrativesWithText: archivedNarratives.rows_with_text,
      narrativesWithSignals: archivedNarratives.rows_with_any_signal,
      signals: {
        feePressure: archivedSignals.fee_pressure,
        paymentDifficulty: archivedSignals.payment_difficulty,
        cashShortfall: archivedSignals.cash_shortfall,
        incomeDisruption: archivedSignals.income_disruption,
      },
      topIssues: archivedIssues,
      sourceUrl: archivedLoanComplaints.source_url,
      period: 'July 2026',
    } : null,
  }, { headers: { 'cache-control': 'no-store' } });
}
