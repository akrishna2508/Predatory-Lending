import { getDatabasePool } from '@/server/database';

export const runtime = 'nodejs';

export async function GET() {
  try {
    await getDatabasePool().query('SELECT 1');
    return Response.json(
      { status: 'ok', database: 'ok' },
      { headers: { 'cache-control': 'no-store' } },
    );
  } catch {
    return Response.json(
      { status: 'unavailable', database: 'unavailable' },
      { status: 503, headers: { 'cache-control': 'no-store' } },
    );
  }
}
