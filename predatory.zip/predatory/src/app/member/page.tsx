'use client';

import { FormEvent, useEffect, useMemo, useState } from 'react';
import { MEMBER_OFFER_OUTCOMES, type MemberOfferOutcome } from '@/domain/offer-outcome';
import { analyzeOffer, type CashEvent, type OfferInput, type Payment } from '@/domain/finance';
import { assessEvidenceShield } from '@/domain/evidence-shield';
import { previewMicroRoutes, type ShieldSignal } from '@/domain/transaction-shield';
import OfferTextReview from '@/app/check/OfferTextReview';
import EvidenceShieldReview, { useShieldResearch } from '@/app/check/EvidenceShieldReview';

type Tenant = { id: string; name: string; slug: string };
type Consent = { purpose: string; action: string; policy_version: string; occurred_at: string };
type SavedCheck = { id: string; input_payload: OfferInput; result_payload: Extract<ReturnType<typeof analyzeOffer>, { valid: true }>; created_at: string; outcome: MemberOfferOutcome | null; outcome_source: 'member_self_report' | null; outcome_reported_at: string | null; reminder_id: string | null; reminder_at: string | null; reminder_due: boolean | null };
type InputEvent = Omit<CashEvent, 'amount'> & { amount: number; source: 'member_entered' | 'transaction_suggestion' };
type SavedCashflowProfile = { id: string; as_of_date: string; starting_balance: number; events: InputEvent[]; created_at: string; updated_at: string; expires_at: string };
type CashflowSuggestion = { id: string; label: string; kind: 'income' | 'bill'; amount: number; nextDate: string; cadence: 'weekly' | 'biweekly' | 'monthly'; evidenceCount: number; confidence: 'possible' };
type BankTransaction = { id: string; amount: number | string; transaction_date: string; name: string; merchant_name: string | null; pending: boolean; categories: string[] };
type Purpose = 'manual_financial_profile' | 'cashflow_profile_storage' | 'offer_check_storage' | 'offer_outcome_reporting' | 'transaction_history_upload' | 'transaction_pattern_analysis';
type PersonalShieldCues = { pauseEveryOffer: boolean; pauseAfterRepeatBorrowing: boolean };
type MemberSection = 'check' | 'shield' | 'history' | 'privacy';
const EMPTY_SHIELD_CUES: PersonalShieldCues = { pauseEveryOffer: false, pauseAfterRepeatBorrowing: false };
const SHIELD_CUES_STORAGE_KEY = 'aegis-personal-shield-cues-v1';

function dayString(date: Date) { return date.toISOString().slice(0, 10); }
function dayOffset(offset: number) { const date = new Date(); date.setUTCDate(date.getUTCDate() + offset); return dayString(date); }
function usd(value: number) { return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(value); }
function localDateTimeValue(date: Date) { return new Date(date.getTime() - date.getTimezoneOffset() * 60_000).toISOString().slice(0, 16); }

export default function MemberPage() {
  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [activeSection, setActiveSection] = useState<MemberSection>('check');
  const [tenantId, setTenantId] = useState('');
  const [consents, setConsents] = useState<Consent[]>([]);
  const [savedChecks, setSavedChecks] = useState<SavedCheck[]>([]);
  const [savedCashflowProfile, setSavedCashflowProfile] = useState<SavedCashflowProfile | null>(null);
  const [cashflowProfileLoading, setCashflowProfileLoading] = useState(false);
  const [cashflowProfileAction, setCashflowProfileAction] = useState(false);
  const [cashflowSuggestions, setCashflowSuggestions] = useState<CashflowSuggestion[]>([]);
  const [shieldSignals, setShieldSignals] = useState<ShieldSignal[]>([]);
  const [offerText, setOfferText] = useState('');
  const shieldResearch = useShieldResearch();
  const [personalShieldCues, setPersonalShieldCues] = useState<PersonalShieldCues>(EMPTY_SHIELD_CUES);
  const [bankTransactions, setBankTransactions] = useState<BankTransaction[]>([]);
  const [bankAction, setBankAction] = useState(false);
  const [bankError, setBankError] = useState('');
  const [bankStatus, setBankStatus] = useState('');
  const [loading, setLoading] = useState(true);
  const [signedOut, setSignedOut] = useState(false);
  const [deletionPending, setDeletionPending] = useState(false);
  const [error, setError] = useState('');
  const [status, setStatus] = useState('');
  const [working, setWorking] = useState(false);
  const [asOfDate, setAsOfDate] = useState(dayString(new Date()));
  const [startingBalance, setStartingBalance] = useState('');
  const [events, setEvents] = useState<InputEvent[]>([]);
  const [proceeds, setProceeds] = useState('');
  const [receivedOn, setReceivedOn] = useState(dayOffset(0));
  const [recentLoanRepaymentDate, setRecentLoanRepaymentDate] = useState('');
  const [payments, setPayments] = useState<Payment[]>([{ date: dayOffset(7), amount: 0 }]);
  const [result, setResult] = useState<Extract<ReturnType<typeof analyzeOffer>, { valid: true }> | null>(null);
  const [resultSaved, setResultSaved] = useState(false);
  const [pendingOfferInput, setPendingOfferInput] = useState<OfferInput | null>(null);
  const [shieldPause, setShieldPause] = useState(false);
  const [accountAction, setAccountAction] = useState(false);
  const [outcomeSavingId, setOutcomeSavingId] = useState('');
  const [csvFile, setCsvFile] = useState<File | null>(null);
  const [reminderSavingId, setReminderSavingId] = useState('');
  const [reminderDateTimes, setReminderDateTimes] = useState<Record<string, string>>({});
  const [reminderMessage, setReminderMessage] = useState('');
  const [reminderError, setReminderError] = useState('');

  useEffect(() => {
    try {
      const raw = sessionStorage.getItem('aegis-quick-check-draft-v1');
      if (!raw) return;
      const draft = JSON.parse(raw) as { asOfDate?: string; receivedOn?: string; proceeds?: string; payments?: Payment[]; startingBalance?: string; events?: InputEvent[] };
      if (draft.asOfDate) setAsOfDate(draft.asOfDate);
      if (draft.receivedOn) setReceivedOn(draft.receivedOn);
      if (draft.proceeds) setProceeds(draft.proceeds);
      if (draft.payments?.length) setPayments(draft.payments);
      if (draft.startingBalance) setStartingBalance(draft.startingBalance);
      if (draft.events?.length) setEvents(draft.events.map(item => ({ ...item, amount: Number(item.amount), source: 'member_entered' })));
      setStatus('Your offer check draft is ready. Review the details below before comparing or saving.');
      sessionStorage.removeItem('aegis-quick-check-draft-v1');
    } catch { /* An invalid or unavailable browser draft is ignored. */ }
  }, []);

  useEffect(() => {
    try {
      const stored = localStorage.getItem(SHIELD_CUES_STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored) as Partial<PersonalShieldCues>;
        setPersonalShieldCues({
          pauseEveryOffer: parsed.pauseEveryOffer === true,
          pauseAfterRepeatBorrowing: parsed.pauseAfterRepeatBorrowing === true,
        });
      }
    } catch { /* Personal pause choices remain available for this browser session. */ }
  }, []);

  function updatePersonalShieldCue(key: keyof PersonalShieldCues, checked: boolean) {
    const next = { ...personalShieldCues, [key]: checked };
    setPersonalShieldCues(next);
    try { localStorage.setItem(SHIELD_CUES_STORAGE_KEY, JSON.stringify(next)); } catch { /* Keep the choice in memory if storage is unavailable. */ }
  }

  useEffect(() => {
    fetch('/api/member/tenants').then(async response => {
      if (response.status === 401) { setSignedOut(true); return; }
      if (!response.ok) throw new Error('Could not load your credit unions.');
      const body = await response.json() as { tenants: Tenant[] };
      setTenants(body.tenants);
      if (body.tenants[0]) setTenantId(body.tenants[0].id);
      else {
        const accountResponse = await fetch('/api/member/account');
        if (accountResponse.status === 401) { setSignedOut(true); return; }
        if (accountResponse.ok) {
          const account = await accountResponse.json() as { deletionPending?: boolean };
          setDeletionPending(account.deletionPending === true);
        }
      }
    }).catch(() => setError('We could not load your member workspace. Try again in a moment.'))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    if (!tenantId) return;
    const headers = { 'x-aegis-tenant-id': tenantId };
    setConsents([]);
    setSavedChecks([]);
    setSavedCashflowProfile(null);
    setBankTransactions([]);
    setCashflowSuggestions([]);
    setShieldSignals([]);
    setWorking(true);
    Promise.all([
      fetch('/api/member/consents', { headers }),
      fetch('/api/member/offer-checks', { headers }),
      fetch('/api/member/transactions?limit=12', { headers }),
    ]).then(async ([consentResponse, checkResponse, transactionResponse]) => {
      if (consentResponse.status === 401 || checkResponse.status === 401 || transactionResponse.status === 401) { setSignedOut(true); return; }
      if (!consentResponse.ok || !checkResponse.ok || !transactionResponse.ok) throw new Error('Could not load member information.');
      const consentBody = await consentResponse.json() as { consents: Consent[] };
      const checkBody = await checkResponse.json() as { offerChecks: SavedCheck[] };
      const transactionBody = await transactionResponse.json() as { transactions: BankTransaction[]; cashflowSuggestions: CashflowSuggestion[]; shieldSignals?: ShieldSignal[] };
      setConsents(consentBody.consents);
      setSavedChecks(checkBody.offerChecks);
      setBankTransactions(transactionBody.transactions);
      setCashflowSuggestions(transactionBody.cashflowSuggestions);
      setShieldSignals(transactionBody.shieldSignals ?? []);
    }).catch(() => setError('We could not load your saved information. Try again in a moment.'))
      .finally(() => setWorking(false));
  }, [tenantId]);

  const latestConsent = useMemo(() => new Map(consents.map(item => [item.purpose, item])), [consents]);
  const hasProfileConsent = latestConsent.get('manual_financial_profile')?.action === 'granted';
  const hasCashflowProfileStorageConsent = latestConsent.get('cashflow_profile_storage')?.action === 'granted';
  const hasStorageConsent = latestConsent.get('offer_check_storage')?.action === 'granted';
  const hasOutcomeConsent = latestConsent.get('offer_outcome_reporting')?.action === 'granted';
  const hasImportConsent = latestConsent.get('transaction_history_upload')?.action === 'granted';
  const hasPatternConsent = latestConsent.get('transaction_pattern_analysis')?.action === 'granted';
  const canSaveCashflowProfile = hasProfileConsent && hasCashflowProfileStorageConsent;
  const microRoutes = useMemo(() => previewMicroRoutes(events.map(({ source: _source, ...event }) => event), asOfDate), [events, asOfDate]);
  const microRouteTotals = useMemo(() => microRoutes.reduce((totals, route) => ({
    billsReserve: totals.billsReserve + route.billsReserve,
    remaining: totals.remaining + route.remaining,
  }), { billsReserve: 0, remaining: 0 }), [microRoutes]);
  const evidenceAlerts = result ? assessEvidenceShield({
    dollarCost: result.dollarCost,
    shortfall: Boolean(result.warning),
    offerText,
    hasDebtBills: events.some(item => item.kind === 'bill' && /loan|credit|card|debt|installment|mortgage/i.test(item.label)),
  }, shieldResearch) : [];

  useEffect(() => {
    if (!tenantId || !canSaveCashflowProfile) {
      setSavedCashflowProfile(null);
      setCashflowProfileLoading(false);
      return;
    }
    let active = true;
    setCashflowProfileLoading(true);
    fetch('/api/member/cashflow-profile', { headers: { 'x-aegis-tenant-id': tenantId }, cache: 'no-store' })
      .then(async response => {
        if (response.status === 401) { setSignedOut(true); return null; }
        if (!response.ok) throw new Error('Saved cash-flow details could not be loaded.');
        return response.json() as Promise<{ profile: SavedCashflowProfile | null }>;
      })
      .then(body => { if (active && body) setSavedCashflowProfile(body.profile); })
      .catch(() => { if (active) setError('Saved cash-flow details could not be loaded. Try again in a moment.'); })
      .finally(() => { if (active) setCashflowProfileLoading(false); });
    return () => { active = false; };
  }, [tenantId, canSaveCashflowProfile]);

  async function changeConsent(purpose: Purpose, checked: boolean) {
    setError(''); setStatus(''); setWorking(true);
    try {
      const response = await fetch('/api/member/consents', {
        method: 'POST', headers: { 'content-type': 'application/json', 'x-aegis-tenant-id': tenantId },
        body: JSON.stringify({ purpose, action: checked ? 'granted' : 'revoked' }),
      });
      const body = await response.json();
      if (!response.ok) throw new Error(body.error ?? 'Consent could not be saved.');
      setConsents(current => [
        ...current.filter(item => item.purpose !== purpose
          && !(purpose === 'transaction_history_upload' && !checked && item.purpose === 'transaction_pattern_analysis')),
        { purpose, action: checked ? 'granted' : 'revoked', policy_version: body.consent.policyVersion, occurred_at: new Date().toISOString() },
        ...(purpose === 'transaction_history_upload' && !checked ? [{
          purpose: 'transaction_pattern_analysis',
          action: 'revoked',
          policy_version: body.consent.policyVersion,
          occurred_at: new Date().toISOString(),
        }] : []),
      ]);
      if (!checked) {
        if (purpose === 'transaction_history_upload') {
          setBankTransactions([]);
          setCashflowSuggestions([]);
          setShieldSignals([]);
          setBankStatus('Uploaded transactions were deleted.');
        } else if (purpose === 'transaction_pattern_analysis') {
          setShieldSignals([]);
          setStatus('Personal transaction pattern analysis is off. Uploaded transactions remain until you delete them or revoke upload consent.');
        } else if (purpose === 'manual_financial_profile' || purpose === 'offer_check_storage') {
          setStatus('Consent revoked. Saved offer checks and related reports were deleted.');
          setSavedChecks([]);
          setResultSaved(false);
          if (purpose === 'manual_financial_profile') setSavedCashflowProfile(null);
        } else if (purpose === 'cashflow_profile_storage') {
          setSavedCashflowProfile(null);
          setStatus('Cash-flow storage consent revoked. Your saved cash-flow picture was deleted.');
        } else {
          setStatus('Self-report consent revoked. Your reported decisions were deleted; saved offer checks remain.');
          setSavedChecks(current => current.map(check => ({ ...check, outcome: null, outcome_source: null, outcome_reported_at: null })));
        }
      } else if (purpose === 'transaction_history_upload') setBankStatus('Upload consent is on. Choose a CSV export whenever you want to add recent transactions.');
      else if (purpose === 'transaction_pattern_analysis') {
        setStatus('Your personal shield is on. Aegis will check imported transaction descriptions for the disclosed patterns.');
        await refreshTransactions();
      }
      else setStatus('Your consent choice was saved.');
    } catch (cause) { setError(cause instanceof Error ? cause.message : 'Consent could not be saved.'); }
    finally { setWorking(false); }
  }

  async function importTransactions(event: FormEvent<HTMLFormElement>) {
    const form = event.currentTarget;
    event.preventDefault();
    if (!hasImportConsent) { setBankError('Turn on transaction upload consent first.'); return; }
    if (!csvFile) { setBankError('Choose a CSV file first.'); return; }
    setBankError(''); setBankStatus(''); setBankAction(true);
    try {
      const response = await fetch('/api/member/transactions/import', {
        method: 'POST',
        headers: { 'content-type': 'text/csv', 'x-aegis-tenant-id': tenantId },
        body: await csvFile.text(),
      });
      const body = await response.json() as { imported?: number; skippedRows?: number; error?: string };
      if (!response.ok) throw new Error(body.error ?? 'Transactions could not be imported.');
      setCsvFile(null);
      form.reset();
      const refreshed = await refreshTransactions();
      if (!refreshed) {
        setBankStatus(`${body.imported} transactions were imported. The shield could not refresh its analysis; reload this page to check them.`);
        return;
      }
      const patternCount = hasPatternConsent ? refreshed?.shieldSignals.length ?? 0 : 0;
      if (patternCount > 0 && result && !resultSaved) setShieldPause(true);
      setBankStatus(`${body.imported} transactions imported and checked.${body.skippedRows ? ` ${body.skippedRows} blank rows skipped.` : ''} ${hasPatternConsent ? `${patternCount} possible pattern ${patternCount === 1 ? 'alert' : 'alerts'}.` : 'Pattern alerts are off until you opt in.'} ${refreshed?.cashflowSuggestions.length ?? 0} possible repeating items. Review the findings below.`);
      window.setTimeout(() => document.getElementById('bank-activity-title')?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 80);
    } catch (cause) { setBankError(cause instanceof Error ? cause.message : 'Transactions could not be imported.'); }
    finally { setBankAction(false); }
  }

  async function refreshTransactions(): Promise<{ shieldSignals: ShieldSignal[]; cashflowSuggestions: CashflowSuggestion[] } | null> {
    const headers = { 'x-aegis-tenant-id': tenantId };
    try {
      const response = await fetch('/api/member/transactions?limit=12', { headers });
      if (!response.ok) throw new Error('Recent transaction information could not be refreshed.');
      const transactionBody = await response.json() as { transactions: BankTransaction[]; cashflowSuggestions: CashflowSuggestion[]; shieldSignals?: ShieldSignal[] };
      setBankTransactions(transactionBody.transactions);
      setCashflowSuggestions(transactionBody.cashflowSuggestions);
      setShieldSignals(transactionBody.shieldSignals ?? []);
      return { shieldSignals: transactionBody.shieldSignals ?? [], cashflowSuggestions: transactionBody.cashflowSuggestions };
    } catch (cause) {
      setBankError(cause instanceof Error ? cause.message : 'Recent transaction information could not be refreshed.');
      return null;
    }
  }

  function addSuggestedCashflow(suggestion: CashflowSuggestion) {
    setEvents(current => [...current, {
      id: crypto.randomUUID(),
      date: suggestion.nextDate,
      label: suggestion.label,
      amount: suggestion.amount,
      kind: suggestion.kind,
      source: 'transaction_suggestion',
    }]);
    setStatus(`${suggestion.label} was added as a possible item. Review its date and amount before using the forecast.`);
    setActiveSection('check');
  }


  function addEvent() {
    setEvents(current => [...current, { id: crypto.randomUUID(), date: dayOffset(1), label: '', amount: 0, kind: 'bill', source: 'member_entered' }]);
  }
  function updateEvent(index: number, key: keyof InputEvent, value: string) {
    setEvents(current => current.map((event, i) => i === index ? {
      ...event,
      [key]: key === 'amount' ? Number(value) : value,
    } as InputEvent : event));
  }

  function loadSavedCashflowProfile() {
    if (!savedCashflowProfile) return;
    setAsOfDate(savedCashflowProfile.as_of_date.slice(0, 10));
    setStartingBalance(String(savedCashflowProfile.starting_balance));
    setEvents(savedCashflowProfile.events);
    setResult(null);
    setResultSaved(false);
    setStatus('Saved cash-flow details loaded. Recheck the balance, dates, and each expected item before comparing. Offer terms were left unchanged.');
    setActiveSection('check');
    window.setTimeout(() => document.getElementById('offer-entry')?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 80);
  }

  async function saveCashflowProfile() {
    if (!canSaveCashflowProfile) {
      setError('Turn on both financial-calculation and cash-flow storage consent before saving.');
      return;
    }
    if (!startingBalance.trim()) {
      setError('Enter a starting balance before saving your cash-flow picture.');
      return;
    }
    setError(''); setStatus(''); setCashflowProfileAction(true);
    try {
      const response = await fetch('/api/member/cashflow-profile', {
        method: 'PUT',
        headers: { 'content-type': 'application/json', 'x-aegis-tenant-id': tenantId },
        body: JSON.stringify({ asOfDate, startingBalance: Number(startingBalance), events }),
      });
      const body = await response.json() as { profile?: SavedCashflowProfile; error?: string };
      if (!response.ok || !body.profile) throw new Error(body.error ?? 'Cash-flow details could not be saved.');
      setSavedCashflowProfile(body.profile);
      setStatus('Your cash-flow picture is saved for 30 days. You can load it, update it, or delete it here.');
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'Cash-flow details could not be saved.');
    } finally { setCashflowProfileAction(false); }
  }

  async function deleteCashflowProfile() {
    if (!window.confirm('Delete your saved cash-flow picture? Your offer comparisons will remain.')) return;
    setError(''); setStatus(''); setCashflowProfileAction(true);
    try {
      const response = await fetch('/api/member/cashflow-profile', {
        method: 'DELETE', headers: { 'x-aegis-tenant-id': tenantId },
      });
      const body = await response.json() as { error?: string };
      if (!response.ok) throw new Error(body.error ?? 'The saved cash-flow picture could not be deleted.');
      setSavedCashflowProfile(null);
      setStatus('Your saved cash-flow picture was deleted.');
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'The saved cash-flow picture could not be deleted.');
    } finally { setCashflowProfileAction(false); }
  }

  async function compareOffer(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setError(''); setStatus('');
    const input: OfferInput = {
      asOfDate,
      startingBalance: Number(startingBalance),
      events: events.map(({ source: _source, ...item }) => ({ ...item, amount: item.kind === 'bill' ? -Math.abs(item.amount) : Math.abs(item.amount) })),
      proceeds: Number(proceeds), receivedOn,
      payments,
      recentShortTermLoanRepaymentDate: recentLoanRepaymentDate || null,
    };
    const analysis = analyzeOffer(input);
    if (!analysis.valid) { setError(analysis.reason); setResult(null); return; }
    setResult(analysis); setResultSaved(false);
    setPendingOfferInput(input);
    setShieldPause(false);
    setStatus('Comparison ready. Review the numbers below, then choose whether to save it.');
    window.setTimeout(() => document.getElementById('member-result')?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 80);
  }

  async function requestSaveComparison() {
    if (!result || !pendingOfferInput) return;
    if (!hasProfileConsent || !hasStorageConsent) {
      setActiveSection('privacy');
      setStatus('Turn on comparison use and saving below, then return to Check offer to save this result.');
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    const repeatedBorrowingFound = (hasPatternConsent && shieldSignals.some(signal => signal.id === 'short_term_credit'))
      || Boolean(recentLoanRepaymentDate);
    const memberRequestedPause = personalShieldCues.pauseEveryOffer
      || (personalShieldCues.pauseAfterRepeatBorrowing && repeatedBorrowingFound);
    const needsPause = Boolean(result.warning || (hasPatternConsent && shieldSignals.length) || memberRequestedPause || evidenceAlerts.some(alert => alert.pause));
    if (needsPause) {
      setShieldPause(true);
      setStatus('Aegis paused saving this comparison so you can review the cash-flow warning and any transaction patterns first.');
      window.setTimeout(() => document.getElementById('decision-shield-review')?.scrollIntoView({ behavior: 'smooth', block: 'center' }), 80);
      return;
    }
    await persistOfferCheck(pendingOfferInput);
  }

  async function persistOfferCheck(input: OfferInput) {
    setWorking(true);
    try {
      const response = await fetch('/api/member/offer-checks', {
        method: 'POST', headers: { 'content-type': 'application/json', 'x-aegis-tenant-id': tenantId },
        body: JSON.stringify(input),
      });
      const body = await response.json();
      if (!response.ok) throw new Error(body.error ?? 'The comparison could not be saved.');
      setResult(body.offerCheck.analysis);
      setResultSaved(true);
      setStatus('Your comparison is saved to your account.');
      const refresh = await fetch('/api/member/offer-checks', { headers: { 'x-aegis-tenant-id': tenantId } });
      if (refresh.ok) setSavedChecks((await refresh.json() as { offerChecks: SavedCheck[] }).offerChecks);
    } catch (cause) { setError(cause instanceof Error ? cause.message : 'The comparison could not be saved.'); }
    finally { setWorking(false); }
  }

  async function continueAfterShieldReview() {
    if (!pendingOfferInput) return;
    const input = pendingOfferInput;
    setShieldPause(false);
    await persistOfferCheck(input);
  }

  function reviseOfferAfterShieldPause() {
    setShieldPause(false);
    setPendingOfferInput(null);
    setResult(null);
    document.getElementById('offer-entry')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  async function reportOfferOutcome(offerCheckId: string, outcome: MemberOfferOutcome) {
    setError(''); setStatus(''); setOutcomeSavingId(offerCheckId);
    try {
      const response = await fetch(`/api/member/offer-checks/${offerCheckId}/outcome`, {
        method: 'POST', headers: { 'content-type': 'application/json', 'x-aegis-tenant-id': tenantId },
        body: JSON.stringify({ outcome }),
      });
      const body = await response.json() as { error?: string; offerOutcome?: { outcome: MemberOfferOutcome; source: 'member_self_report'; reported_at: string } };
      if (!response.ok || !body.offerOutcome) throw new Error(body.error ?? 'Your decision could not be saved.');
      setSavedChecks(current => current.map(check => check.id === offerCheckId ? {
        ...check,
        outcome: body.offerOutcome!.outcome,
        outcome_source: body.offerOutcome!.source,
        outcome_reported_at: body.offerOutcome!.reported_at,
      } : check));
      setStatus('Your self-reported decision was saved. It is not verified transaction data.');
    } catch (cause) { setError(cause instanceof Error ? cause.message : 'Your decision could not be saved.'); }
    finally { setOutcomeSavingId(''); }
  }

  async function saveReminder(check: SavedCheck) {
    const reminderAt = reminderDateTimes[check.id] ?? (check.reminder_at ? localDateTimeValue(new Date(check.reminder_at)) : '');
    if (!reminderAt) { setReminderError('Choose a reminder date and time first.'); return; }
    setReminderError(''); setReminderMessage(''); setReminderSavingId(check.id);
    try {
      const response = await fetch(`/api/member/offer-checks/${check.id}/reminder`, {
        method: 'POST', headers: { 'content-type': 'application/json', 'x-aegis-tenant-id': tenantId },
        body: JSON.stringify({ reminderAt: new Date(reminderAt).toISOString() }),
      });
      const body = await response.json() as { error?: string; reminder?: { id: string; reminder_at: string; due: boolean } };
      if (!response.ok || !body.reminder) throw new Error(body.error ?? 'Your reminder could not be saved.');
      setSavedChecks(current => current.map(item => item.id === check.id ? {
        ...item, reminder_id: body.reminder!.id, reminder_at: body.reminder!.reminder_at, reminder_due: body.reminder!.due,
      } : item));
      setReminderDateTimes(current => ({ ...current, [check.id]: localDateTimeValue(new Date(body.reminder!.reminder_at)) }));
      setReminderMessage('Reminder set. It will appear in your Aegis workspace when due; no email or push message is sent.');
    } catch (cause) { setReminderError(cause instanceof Error ? cause.message : 'Your reminder could not be saved.'); }
    finally { setReminderSavingId(''); }
  }

  async function cancelReminder(check: SavedCheck) {
    setReminderError(''); setReminderMessage(''); setReminderSavingId(check.id);
    try {
      const response = await fetch(`/api/member/offer-checks/${check.id}/reminder`, { method: 'DELETE', headers: { 'x-aegis-tenant-id': tenantId } });
      const body = await response.json() as { error?: string };
      if (!response.ok) throw new Error(body.error ?? 'Your reminder could not be cancelled.');
      setSavedChecks(current => current.map(item => item.id === check.id ? { ...item, reminder_id: null, reminder_at: null, reminder_due: null } : item));
      setReminderMessage('Reminder cancelled.');
    } catch (cause) { setReminderError(cause instanceof Error ? cause.message : 'Your reminder could not be cancelled.'); }
    finally { setReminderSavingId(''); }
  }

  async function exportAccountData() {
    setError(''); setAccountAction(true);
    try {
      const response = await fetch('/api/member/export');
      if (!response.ok) throw new Error('Your data export could not be prepared.');
      const file = await response.blob();
      const url = URL.createObjectURL(file);
      const link = document.createElement('a');
      link.href = url; link.download = 'aegis-member-data.json'; link.click();
      URL.revokeObjectURL(url);
      setStatus('Your data export has been downloaded.');
    } catch (cause) { setError(cause instanceof Error ? cause.message : 'Your data export could not be prepared.'); }
    finally { setAccountAction(false); }
  }

  async function deleteAccountData() {
    const confirmation = deletionPending
      ? 'Finish deleting your Aegis sign-in and local session data? Your financial records and memberships are already deleted.'
      : 'Delete your Aegis financial records, consent history, and credit-union memberships, then remove your local sign-in profile? This cannot be undone.';
    if (!window.confirm(confirmation)) return;
    setError(''); setAccountAction(true);
    try {
      const response = await fetch('/api/member/account', { method: 'DELETE' });
      const body = await response.json() as { error?: string; deletionPending?: boolean };
      if (body.deletionPending) setDeletionPending(true);
      if (!response.ok) throw new Error(body.error ?? 'Account data could not be deleted.');
      window.location.assign('/api/auth/logout');
    } catch (cause) { setError(cause instanceof Error ? cause.message : 'Account data could not be deleted.'); }
    finally { setAccountAction(false); }
  }

  if (loading) return <main className="member-screen"><p className="member-loading">Loading your member workspace…</p></main>;
  if (signedOut) return <main className="member-screen"><section className="member-card member-gate"><span className="member-mark">A</span><p className="eyebrow">AEGIS MEMBER</p><h1>Your private workspace.</h1><p>Sign in to save comparisons, import transaction history with consent, and review your Shield. You can check an offer without an account.</p><a className="member-primary" href="/login?workspace=member">Sign in securely</a><a className="member-secondary-link" href="/check">Check an offer without signing in →</a></section></main>;
  if (!tenants.length) return <main className="member-screen"><section className="member-card member-gate"><span className="member-mark">A</span><p className="eyebrow">MEMBER ACCESS</p><h1>{deletionPending ? 'Your Aegis data is deleted.' : 'No linked credit union yet.'}</h1><p>{deletionPending ? 'Your transaction and offer records are erased. Local sign-in cleanup may still be completing. Retry here to check.' : 'Your credit union needs to activate your Aegis membership before you can use the member workspace.'}</p>{deletionPending && <button type="button" className="member-delete-button" disabled={accountAction} onClick={deleteAccountData}>{accountAction ? 'Working…' : 'Check deletion status'}</button>}{error && <p className="member-alert" role="alert">{error}</p>}<a className="member-secondary-link" href="/api/auth/logout">Sign out</a></section></main>;

  return <main className="member-screen member-hub">
    <header className="member-topbar"><a className="member-brand" href="/">Aegis</a><div className="member-top-actions"><a href="/check">Quick check</a><label htmlFor="member-tenant">Credit union</label><select id="member-tenant" value={tenantId} onChange={event => setTenantId(event.target.value)}>{tenants.map(tenant => <option value={tenant.id} key={tenant.id}>{tenant.name}</option>)}</select><a href="/api/auth/logout">Sign out</a></div></header>
    <div className="member-content">
      <div className="member-heading"><div><p className="eyebrow">YOUR AEGIS ACCOUNT</p><h1>{activeSection === 'check' ? 'Check an offer.' : activeSection === 'shield' ? 'Your transaction Shield.' : activeSection === 'history' ? 'Your saved details.' : 'Your privacy choices.'}</h1><p>{activeSection === 'check' ? 'Start with the offer. Add income and bills if you want a 30-day forecast. Review the result before deciding whether to save.' : activeSection === 'shield' ? 'Optional description matches and repeating-item suggestions from a CSV you choose to import.' : activeSection === 'history' ? 'Return to comparisons and cash-flow details you chose to save.' : 'Decide what Aegis may use or keep. Each choice can be changed here.'}</p></div><span className="member-private-tag">Private to you</span></div>
      <nav className="member-hub-tabs" aria-label="Member workspace sections">
        <button type="button" aria-pressed={activeSection === 'check'} onClick={() => setActiveSection('check')}><span>01</span> Check offer</button>
        <button type="button" aria-pressed={activeSection === 'shield'} onClick={() => setActiveSection('shield')}><span>02</span> My Shield</button>
        <button type="button" aria-pressed={activeSection === 'history'} onClick={() => setActiveSection('history')}><span>03</span> Saved</button>
        <button type="button" aria-pressed={activeSection === 'privacy'} onClick={() => setActiveSection('privacy')}><span>04</span> Privacy</button>
      </nav>
      {status && activeSection !== 'check' && <p className="member-status" role="status">{status}</p>}
      {error && activeSection !== 'check' && <p className="member-alert" role="alert">{error}</p>}

      {activeSection === 'privacy' && <div className="member-pane"><div className="member-pane-intro"><strong>Only turn on what you need.</strong><p>Manual comparisons can run in this browser. Saving, transaction upload, pattern alerts, and outcome notes each have their own choice.</p>{pendingOfferInput && result && !resultSaved && <button type="button" className="member-secondary-button" onClick={() => setActiveSection('check')}>Return to my comparison →</button>}</div>

      <section className="member-card consent-card" aria-labelledby="consent-title">
        <div className="member-section-heading"><div><p className="eyebrow">YOUR CHOICES</p><h2 id="consent-title">You control what Aegis keeps.</h2></div><span className="policy-tag">Policy 2026-09-27.1</span></div>
        <div className="consent-choice"><div><strong>Use details I enter to compare this offer</strong><p>Lets Aegis use the balance, dates, income, and bills you submit to calculate a 30-day cash-flow comparison. You can compare in this browser without granting this permission.</p></div><label className="consent-toggle"><input aria-label="Use entered financial details for a comparison" type="checkbox" checked={hasProfileConsent} disabled={working} onChange={event => changeConsent('manual_financial_profile', event.target.checked)} /><span>{hasProfileConsent ? 'On' : 'Off'}</span></label></div>
        <div className="consent-choice"><div><strong>Save my cash-flow picture for 30 days</strong><p>Stores the starting balance, balance date, and income and bills you confirm so you can load them later. This is separate from using details for a comparison. Revoking this choice or calculation consent deletes the saved picture.</p></div><label className="consent-toggle"><input aria-label="Save my cash-flow picture for 30 days" type="checkbox" checked={hasCashflowProfileStorageConsent} disabled={working} onChange={event => changeConsent('cashflow_profile_storage', event.target.checked)} /><span>{hasCashflowProfileStorageConsent ? 'On' : 'Off'}</span></label></div>
        <div className="consent-choice"><div><strong>Save my offer comparisons</strong><p>Stores your entered terms and calculation in your private member account so you can review them later. Revoking either permission deletes your saved checks.</p></div><label className="consent-toggle"><input aria-label="Save my offer comparisons" type="checkbox" checked={hasStorageConsent} disabled={working} onChange={event => changeConsent('offer_check_storage', event.target.checked)} /><span>{hasStorageConsent ? 'On' : 'Off'}</span></label></div>
        <div className="consent-choice"><div><strong>Save decisions I choose to report</strong><p>Separately stores whether you accepted, declined, changed the terms, or are still deciding about a saved offer. These are your self-reports, not verified transactions. Your credit union cannot see them; revoking this choice deletes them.</p></div><label className="consent-toggle"><input aria-label="Save decisions I choose to report" type="checkbox" checked={hasOutcomeConsent} disabled={working} onChange={event => changeConsent('offer_outcome_reporting', event.target.checked)} /><span>{hasOutcomeConsent ? 'On' : 'Off'}</span></label></div>
        <div className="consent-choice"><div><strong>Upload transaction history from a CSV file</strong><p>If you choose, Aegis stores the transaction date, description, and amount from the CSV you upload. It does not receive bank passwords or connect to your bank. Revoking this choice deletes uploaded transactions.</p></div><label className="consent-toggle"><input aria-label="Upload transaction history from a CSV file" type="checkbox" checked={hasImportConsent} disabled={working || bankAction} onChange={event => changeConsent('transaction_history_upload', event.target.checked)} /><span>{hasImportConsent ? 'On' : 'Off'}</span></label></div>
        <div className="consent-choice"><div><strong>Turn on my personal transaction shield</strong><p>With transaction upload consent on, Aegis checks up to 6 months of imported descriptions for repeated short-term credit and fee wording, plus variation in clearly labeled income deposits over the last 90 days. It shows the matched count and latest date. Merchant labels may be wrong. Aegis does not infer thoughts, intent, or a psychological profile. Turn this off any time.</p></div><label className="consent-toggle"><input aria-label="Turn on my personal transaction shield" type="checkbox" checked={hasPatternConsent} disabled={working || bankAction || (!hasImportConsent && !hasPatternConsent)} onChange={event => changeConsent('transaction_pattern_analysis', event.target.checked)} /><span>{hasPatternConsent ? 'On' : 'Off'}</span></label></div>
        <p className="consent-footnote">Your credit union receives aggregate reporting only. You can use manual entry without uploading financial data.</p>
      </section>
      </div>}

      {activeSection === 'history' && canSaveCashflowProfile && <section className="member-card saved-cashflow-card" aria-labelledby="saved-cashflow-title">
        <div className="member-section-heading"><div><p className="eyebrow">PRIVATE TO YOU · EXPIRES AFTER 30 DAYS</p><h2 id="saved-cashflow-title">Saved cash-flow picture</h2></div><span className="member-number">02</span></div>
        {cashflowProfileLoading ? <p className="member-empty-row">Checking for a saved cash-flow picture…</p> : savedCashflowProfile ? <>
          <p>Balance date: <strong>{new Date(`${savedCashflowProfile.as_of_date.slice(0, 10)}T12:00:00Z`).toLocaleDateString('en-US', { dateStyle: 'medium', timeZone: 'UTC' })}</strong> · {savedCashflowProfile.events.length} expected items</p>
          <p className="consent-footnote">Last updated {new Date(savedCashflowProfile.updated_at).toLocaleString('en-US', { dateStyle: 'medium', timeStyle: 'short' })}. Expires {new Date(savedCashflowProfile.expires_at).toLocaleDateString('en-US', { dateStyle: 'medium', timeZone: 'UTC' })}. Loading it leaves offer terms unchanged.</p>
          <div className="saved-cashflow-actions"><button type="button" className="member-primary" disabled={cashflowProfileAction} onClick={loadSavedCashflowProfile}>Load saved details</button><button type="button" className="member-secondary-button" disabled={cashflowProfileAction} onClick={() => void deleteCashflowProfile()}>{cashflowProfileAction ? 'Working…' : 'Delete saved picture'}</button></div>
        </> : <div className="member-empty-row"><p>No cash-flow picture is saved yet.</p><button type="button" className="member-secondary-button" onClick={() => setActiveSection('check')}>Go to offer check →</button></div>}
      </section>}

      {activeSection === 'shield' && <div className="member-pane"><div className="member-pane-intro"><strong>Connect the dots in your own history.</strong><p>With your permission, Aegis checks imported descriptions for repeated credit, fees, and variable income-like deposits. You can review suggestions before adding them to a forecast.</p>{(!hasImportConsent || !hasPatternConsent) && <button type="button" className="member-secondary-button" onClick={() => setActiveSection('privacy')}>Manage Shield permissions →</button>}</div>
      {shieldPause && result && !resultSaved && <div className="member-warning" role="alert"><strong>Your unsaved offer needs another look.</strong><p>New transaction patterns were found after your comparison. Review them before saving that offer.</p><button type="button" className="member-secondary-button" onClick={() => setActiveSection('check')}>Review my offer →</button></div>}
      <form className="member-card bank-connections-card" aria-labelledby="bank-title" onSubmit={importTransactions}>
        <div className="member-section-heading"><div><p className="eyebrow">OPTIONAL · LOCAL DATA IMPORT</p><h2 id="bank-title">Add transaction history</h2><p>Import a bank CSV so Aegis can suggest repeating income and bills for your forecast.</p></div><span className="member-number">02</span></div>
        <label className="member-field"><span>Transaction CSV file</span><input type="file" accept=".csv,text/csv" disabled={!hasImportConsent || bankAction} onChange={event => setCsvFile(event.target.files?.[0] ?? null)} /></label>
        <p className="consent-footnote">Supports Date, Description, Amount columns or Date, Description, Debit, Credit columns. Up to 5,000 rows and 1 MB. File names and account numbers are not stored.</p>
        <div className="bank-connect-actions"><button type="submit" className="member-primary" disabled={!hasImportConsent || !csvFile || bankAction}>{bankAction ? 'Importing…' : !hasImportConsent ? 'Turn on upload consent first' : 'Import transactions'}</button></div>
        {bankError && <p className="member-alert" role="alert">{bankError}</p>}
        {bankStatus && <p className="member-status" role="status">{bankStatus}</p>}
      </form>

      {hasImportConsent && bankTransactions.length > 0 && <section className="member-card bank-activity-card" aria-labelledby="bank-activity-title">
        <div className="member-section-heading"><div><p className="eyebrow">FROM POSTED TRANSACTIONS</p><h2 id="bank-activity-title">Possible repeating items</h2><p>These are pattern suggestions from recent history, not confirmed bills or income. Review each one before adding it to your forecast.</p></div><span className="member-number">03</span></div>
        {hasPatternConsent && <div className="shield-signals" aria-live="polite"><div className="shield-signals-heading"><span aria-hidden="true">◈</span><div><strong>Your personal shield</strong><p>Transaction description matches · last 6 months</p></div></div>
          {shieldSignals.length ? <ul>{shieldSignals.map(signal => <li key={signal.id}><div><strong>{signal.title}</strong><p>{signal.summary}</p><small>{signal.evidenceCount} matching descriptions · latest {new Date(`${signal.mostRecentDate}T12:00:00Z`).toLocaleDateString('en-US', { dateStyle: 'medium', timeZone: 'UTC' })}</small></div></li>)}</ul> : <p className="shield-clear">No repeated descriptions matched the shield’s current rules. This does not mean an offer is affordable or safe.</p>}
        </div>}
        {cashflowSuggestions.length > 0 ? <ul className="cashflow-suggestion-list">{cashflowSuggestions.map(suggestion => <li key={suggestion.id}>
          <div className="cashflow-suggestion-copy"><strong>{suggestion.label}</strong><span>Possible {suggestion.cadence} {suggestion.kind} · seen {suggestion.evidenceCount} times · next date estimated</span></div>
          <div className="cashflow-suggestion-amount"><strong>{usd(suggestion.amount)}</strong><span>{new Date(`${suggestion.nextDate}T12:00:00Z`).toLocaleDateString('en-US', { month: 'short', day: 'numeric', timeZone: 'UTC' })}</span></div>
          <button type="button" className="member-secondary-button" onClick={() => addSuggestedCashflow(suggestion)}>Add to forecast</button>
        </li>)}</ul> : <p className="member-empty-row cashflow-empty">There is not enough recent, regular activity to suggest a repeating item. Add expected income and bills yourself below.</p>}
        <div className="recent-transaction-list"><h3>Recent imported activity</h3>{bankTransactions.slice(0, 5).map(transaction => <div className="recent-transaction-row" key={transaction.id}>
          <div><strong>{transaction.merchant_name ?? transaction.name}</strong><span>{new Date(`${transaction.transaction_date.slice(0, 10)}T12:00:00Z`).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric', timeZone: 'UTC' })}{transaction.pending ? ' · Pending' : ''}</span></div>
          <strong className={Number(transaction.amount) > 0 ? 'transaction-income' : ''}>{usd(Number(transaction.amount))}</strong>
        </div>)}{bankTransactions.length === 0 && <p className="recent-transactions-empty">Recent transaction details will appear after the first import completes.</p>}</div>
      </section>}

      </div>}
      {activeSection === 'check' && <div className="member-pane"><div className="member-pane-intro"><strong>One offer, one clear answer.</strong><p>Enter the amount you receive and the repayment dates. Then add your balance and upcoming bills for a 30-day forecast. Your comparison stays unsaved until you choose to keep it.</p><a href="/check">Want a cost-only check without signing in? →</a></div>
      <form id="offer-entry" className="member-card offer-entry-card" onSubmit={compareOffer}>
        <div className="member-section-heading"><div><p className="eyebrow">YOUR OFFER · 30-DAY FORECAST</p><h2>Enter the offer and your money.</h2><p>Use the real amounts and dates. Aegis only calculates from what you enter.</p></div><span className="member-number">01</span></div>
        <p className="member-form-step">01 / OFFER DETAILS</p>
        <div className="member-form-grid">
          <label className="member-field"><span>Funds offered to you</span><div className="member-money"><span>$</span><input required aria-label="Funds offered to you" inputMode="decimal" type="number" min="0.01" max="1000000" step="0.01" value={proceeds} onChange={event => setProceeds(event.target.value)} placeholder="0.00" /></div></label>
          <label className="member-field"><span>Date funds arrive</span><input required type="date" value={receivedOn} onChange={event => setReceivedOn(event.target.value)} /></label>
        </div>
        <div className="member-list-heading"><div><h3>Offer payment schedule</h3><p>Include each payment amount and due date from the offer.</p></div><button type="button" className="member-add-button" onClick={() => setPayments(current => [...current, { date: '', amount: 0 }])}>＋ Add payment</button></div>
        <div className="member-input-list">{payments.map((payment, index) => <div className="member-input-row member-payment-row" key={index}>
          <span className="member-row-number">{String(index + 1).padStart(2, '0')}</span>
          <label className="member-field"><span className="sr-only">Payment {index + 1} amount</span><div className="member-money"><span>$</span><input required aria-label={`Payment ${index + 1} amount`} type="number" min="0.01" max="1000000" step="0.01" value={payment.amount || ''} onChange={event => setPayments(current => current.map((item, i) => i === index ? { ...item, amount: Number(event.target.value) } : item))} placeholder="0.00" /></div></label>
          <label className="member-field"><span className="sr-only">Payment {index + 1} date</span><input required aria-label={`Payment ${index + 1} date`} type="date" value={payment.date} onChange={event => setPayments(current => current.map((item, i) => i === index ? { ...item, date: event.target.value } : item))} /></label>
          {payments.length > 1 && <button type="button" className="member-remove-button" aria-label={`Remove payment ${index + 1}`} onClick={() => setPayments(current => current.filter((_, i) => i !== index))}>×</button>}
        </div>)}</div>
        <OfferTextReview value={offerText} onChange={setOfferText} />

        <div className="member-step-divider"><span>02 / CASH-FLOW CONTEXT</span><h3>See the effect on your next 30 days.</h3><p>Enter your balance and any income or bills you know about. For a cost-only result, use the quick check.</p></div>
        <div className="member-form-grid">
          <label className="member-field"><span>Starting balance</span><div className="member-money"><span>$</span><input required aria-label="Starting balance" inputMode="decimal" type="number" min="0" max="1000000" step="0.01" value={startingBalance} onChange={event => setStartingBalance(event.target.value)} placeholder="0.00" /></div></label>
          <label className="member-field"><span>Date to start forecast</span><input required type="date" value={asOfDate} onChange={event => setAsOfDate(event.target.value)} /></label>
        </div>
        <details className="member-optional"><summary>Optional repeat-borrowing reminder and pause rules</summary><div className="repeat-context-field">
          <label className="member-field"><span>Most recent repayment on another short-term loan (optional)</span><input type="date" max={asOfDate} value={recentLoanRepaymentDate} onChange={event => setRecentLoanRepaymentDate(event.target.value)} /></label>
          <p>Only enter this date if you want a reminder. If you separately turn on the personal shield, Aegis also checks imported descriptions using the rules shown above.</p>
        </div>
        <section className="shield-cue-controls" aria-labelledby="shield-cues-title"><div><p className="eyebrow">YOUR PERSONAL PAUSE RULES · THIS BROWSER</p><h3 id="shield-cues-title">Choose what should trigger an extra pause.</h3><p>These are your own settings. They are saved only in this browser and do not create a psychological profile.</p></div>
          <label><input type="checkbox" checked={personalShieldCues.pauseEveryOffer} onChange={event => updatePersonalShieldCue('pauseEveryOffer', event.target.checked)} /><span><strong>Pause before saving every offer comparison</strong><small>Give me a moment to compare total repayment with the amount I would receive.</small></span></label>
          <label><input type="checkbox" checked={personalShieldCues.pauseAfterRepeatBorrowing} onChange={event => updatePersonalShieldCue('pauseAfterRepeatBorrowing', event.target.checked)} /><span><strong>Pause if I report or my opted-in history shows repeat borrowing</strong><small>Show an extra check when a recent repayment date or repeated short-term-credit description is present.</small></span></label>
        </section></details>

        <div className="member-list-heading"><div><h3>Expected income and bills</h3><p>Use positive amounts. Aegis subtracts bills in the forecast.</p></div><button type="button" className="member-add-button" onClick={addEvent}>＋ Add item</button></div>
        {events.length === 0 ? <p className="member-empty-row">Add the income and bills you expect over the next 30 days. You can still compare the offer without them.</p> : <div className="member-input-list">{events.map((item, index) => <div className="member-input-row" key={item.id}>
          <label className="member-field"><span className="sr-only">Item {index + 1} name</span><input required aria-label={`Item ${index + 1} name`} maxLength={100} value={item.label} onChange={event => updateEvent(index, 'label', event.target.value)} placeholder="e.g. Rent" /><small className="event-source">{item.source === 'transaction_suggestion' ? 'Transaction suggestion · review before use' : 'Entered by you'}</small></label>
          <label className="member-field"><span className="sr-only">Item {index + 1} type</span><select aria-label={`Item ${index + 1} type`} value={item.kind} onChange={event => updateEvent(index, 'kind', event.target.value)}><option value="bill">Bill</option><option value="income">Income</option></select></label>
          <label className="member-field"><span className="sr-only">Item {index + 1} date</span><input aria-label={`Item ${index + 1} date`} type="date" required value={item.date} onChange={event => updateEvent(index, 'date', event.target.value)} /></label>
          <label className="member-field"><span className="sr-only">Item {index + 1} amount</span><div className="member-money"><span>$</span><input aria-label={`Item ${index + 1} amount`} type="number" min="0.01" max="1000000" step="0.01" required value={item.amount || ''} onChange={event => updateEvent(index, 'amount', event.target.value)} placeholder="0.00" /></div></label>
          <button type="button" className="member-remove-button" aria-label={`Remove item ${index + 1}`} onClick={() => setEvents(current => current.filter((_, i) => i !== index))}>×</button>
        </div>)}</div>}

        {microRoutes.length > 0 && <details className="member-optional"><summary>Preview a virtual bills reserve</summary><section className="micro-route-preview" aria-label="Automatic simulated bill reserve routing"><div className="micro-route-heading"><span aria-hidden="true">↗</span><div><strong>Automatic micro-routing · local simulator</strong><p>Aegis reruns the allocation as you edit confirmed income and bills, reserving for bills before the next payday.</p></div></div><div className="micro-route-totals"><div><span>Routed to virtual bills reserve</span><strong>{usd(microRouteTotals.billsReserve)}</strong></div><div><span>Remaining in virtual balance</span><strong>{usd(microRouteTotals.remaining)}</strong></div></div><ul>{microRoutes.map(route => <li key={route.payday}><span>Payday · {new Date(`${route.payday}T12:00:00Z`).toLocaleDateString('en-US', { month: 'short', day: 'numeric', timeZone: 'UTC' })}</span><strong>{usd(route.billsReserve)} → Bills reserve</strong><span>{usd(route.remaining)} → Remaining</span><small>{route.billCount} entered bill{route.billCount === 1 ? '' : 's'} · computed immediately</small></li>)}</ul><p className="consent-footnote">This local simulation uses only items you entered or confirmed. It does not connect to accounts or move real money.</p></section></details>}

        {error && <p className="member-alert" role="alert">{error}</p>}
        {status && <p className="member-status" role="status">{status}</p>}
        <div className="member-submit-row"><p>Compare privately first. Nothing is saved until you choose to save it.</p><div className="member-action-buttons">{canSaveCashflowProfile && <button type="button" className="member-secondary-button" disabled={cashflowProfileAction || working} onClick={() => void saveCashflowProfile()}>{cashflowProfileAction ? 'Saving…' : savedCashflowProfile ? 'Update cash-flow picture' : 'Save cash-flow picture'}</button>}<button className="member-primary" type="submit" disabled={working}>{working ? 'Working…' : 'See my result →'}</button></div></div>
      </form>

      {result && <section id="member-result" className="member-card member-result-card" aria-live="polite">
        <div className="member-section-heading"><div><p className="eyebrow">YOUR COMPARISON {resultSaved ? '· SAVED' : '· NOT SAVED'}</p><h2>What the numbers show</h2></div><span className="member-result-cost">{usd(result.dollarCost)}<small>cost above funds received</small></span></div>
        <div className="member-result-grid"><div><span>Total repayment</span><strong>{usd(result.totalRepayment)}</strong></div><div><span>Lowest balance without offer</span><strong>{usd(result.baseline.lowestBalance)}</strong><small>{result.baseline.lowestDate}</small></div><div><span>Lowest balance with offer</span><strong className={result.withOffer.lowestBalance < 0 ? 'member-negative' : ''}>{usd(result.withOffer.lowestBalance)}</strong><small>{result.withOffer.lowestDate}</small></div></div>
        <OfferTextReview value={offerText} />
        <EvidenceShieldReview alerts={evidenceAlerts} />
        {result.warning ? <div className="member-warning"><strong>A scheduled payment contributes to a projected shortfall.</strong><p>After “{result.warning.triggerLabel}” on {result.warning.date}, the projected balance is {usd(result.warning.balanceAfter)}. This uses only the dates and amounts entered above.</p></div> : <div className="member-neutral"><strong>No projected shortfall was triggered by these inputs.</strong><p>This is not an endorsement. It only reflects the dates and amounts entered above; real timing and expenses may differ.</p></div>}
        {result.repeatBorrowingPrompt && <div className="member-warning repeat-borrowing-prompt"><strong>You reported another short-term loan repayment {result.repeatBorrowingPrompt.daysSinceRepayment} {result.repeatBorrowingPrompt.daysSinceRepayment === 1 ? 'day' : 'days'} before this balance date.</strong><p>A new payment schedule close to another repayment may put more pressure on upcoming bills. Review the dates and cost, and consider lower-cost options if your credit union offers them. This reminder uses only the date you entered; it is not a judgment about your decision.</p></div>}
        {shieldPause && <div id="decision-shield-review" className="member-shield-hold" role="alert"><p className="eyebrow">AEGIS PAUSED THIS SAVE</p><h3>Review the pressure points before you continue.</h3><p>The comparison is ready but has not been saved. Review the evidence and your chosen pause rules, then decide whether to save it.</p>{result.warning && <p>Cash-flow warning: a scheduled payment contributes to a projected shortfall on {result.warning.date}.</p>}{evidenceAlerts.some(alert => alert.pause) && <ul>{evidenceAlerts.filter(alert => alert.pause).map(alert => <li key={alert.id}>{alert.title}: {alert.action}</li>)}</ul>}{hasPatternConsent && shieldSignals.length > 0 && <ul>{shieldSignals.map(signal => <li key={signal.id}>{signal.title} · {signal.evidenceCount} matched descriptions</li>)}</ul>}{personalShieldCues.pauseEveryOffer && <p>Your personal rule asks Aegis to pause every offer so you can compare total repayment with cash received.</p>}{personalShieldCues.pauseAfterRepeatBorrowing && ((hasPatternConsent && shieldSignals.some(signal => signal.id === 'short_term_credit')) || recentLoanRepaymentDate) && <p>Your personal rule asks for a pause when recent repeat borrowing is reported or appears in opted-in history.</p>}<div className="member-action-buttons"><button type="button" className="member-primary" disabled={working} onClick={() => void continueAfterShieldReview()}>I reviewed this · save comparison</button><button type="button" className="member-secondary-button" onClick={reviseOfferAfterShieldPause}>Change the offer details</button></div></div>}
        {!resultSaved && !shieldPause && <div className="member-result-actions"><p>Want to return to this later? Saving is optional and needs your permission.</p><button type="button" className="member-primary" disabled={working} onClick={() => void requestSaveComparison()}>{working ? 'Saving…' : 'Save this comparison →'}</button></div>}
        {resultSaved && <div className="member-result-actions"><p>This comparison is saved in your private history.</p><button type="button" className="member-secondary-button" onClick={() => setActiveSection('history')}>View saved comparisons →</button></div>}
        <p className="member-disclaimer">Aegis compares the entered terms with the entered cash-flow dates. It does not predict the future, recommend a loan, or determine whether an offer is suitable for you.</p>
      </section>}
      </div>}

      {activeSection === 'history' && <section className="member-card saved-card"><div className="member-section-heading"><div><p className="eyebrow">PRIVATE HISTORY</p><h2>Your saved comparisons</h2><p>Only you can see these records in Aegis. In-app reminders appear here when due; Aegis does not send email or push notifications.</p></div><span className="member-number">{String(savedChecks.length).padStart(2, '0')}</span></div>
        {reminderError && <p className="member-alert" role="alert">{reminderError}</p>}{reminderMessage && <p className="member-status" role="status">{reminderMessage}</p>}
        {savedChecks.length ? <ul className="saved-check-list">{savedChecks.map(check => <li key={check.id}><div><strong>{check.input_payload.proceeds ? `${usd(check.input_payload.proceeds)} offer` : 'Offer comparison'}</strong><span>{new Date(check.created_at).toLocaleDateString('en-US', { dateStyle: 'medium', timeZone: 'UTC' })}</span><label className="outcome-field"><span>Your decision · self-reported</span><select aria-label={`Your self-reported decision for the ${usd(check.input_payload.proceeds)} offer`} value={check.outcome ?? ''} disabled={outcomeSavingId === check.id || !hasProfileConsent || !hasStorageConsent || !hasOutcomeConsent} onChange={event => { const value = event.target.value as MemberOfferOutcome; if (MEMBER_OFFER_OUTCOMES.includes(value)) void reportOfferOutcome(check.id, value); }}><option value="" disabled>{hasOutcomeConsent ? 'Choose if you want' : 'Optional consent is off'}</option><option value="accepted">Accepted</option><option value="declined">Declined</option><option value="changed_terms">Changed the terms</option><option value="still_deciding">Still deciding</option></select></label></div><div><strong>{usd(check.result_payload.totalRepayment)}</strong><span>total repayment</span></div><div><strong>{usd(check.result_payload.dollarCost)}</strong><span>cost above proceeds</span></div><div className="saved-reminder-controls">
          {check.reminder_id && <div className={check.reminder_due ? 'saved-reminder-due' : 'saved-reminder-set'} role={check.reminder_due ? 'status' : undefined}><strong>{check.reminder_due ? 'Reminder due' : 'Reminder set'}</strong><span>{new Date(check.reminder_at!).toLocaleString('en-US', { dateStyle: 'medium', timeStyle: 'short' })}</span></div>}
          <label className="outcome-field"><span>{check.reminder_id ? 'Change reminder time' : 'Optional in-app reminder'}</span><input aria-label={`Reminder time for the ${usd(check.input_payload.proceeds)} offer`} type="datetime-local" min={localDateTimeValue(new Date(Date.now() + 2 * 60_000))} max={localDateTimeValue(new Date(Date.now() + 30 * 24 * 60 * 60_000))} value={reminderDateTimes[check.id] ?? (check.reminder_at ? localDateTimeValue(new Date(check.reminder_at)) : localDateTimeValue(new Date(Date.now() + 24 * 60 * 60_000)))} disabled={reminderSavingId === check.id || !hasProfileConsent || !hasStorageConsent} onChange={event => setReminderDateTimes(current => ({ ...current, [check.id]: event.target.value }))} /></label>
          <div className="saved-reminder-buttons"><button type="button" className="member-secondary-button" disabled={reminderSavingId === check.id || !hasProfileConsent || !hasStorageConsent} onClick={() => void saveReminder(check)}>{reminderSavingId === check.id ? 'Saving…' : check.reminder_id ? 'Reschedule' : 'Set reminder'}</button>{check.reminder_id && <button type="button" className="member-secondary-button" disabled={reminderSavingId === check.id} onClick={() => void cancelReminder(check)}>Cancel</button>}</div>
        </div></li>)}</ul> : <p className="member-empty-row">No saved comparisons for this credit union.</p>}
      </section>}
      {activeSection === 'privacy' && <section className="member-card member-data-controls"><div><p className="eyebrow">YOUR DATA</p><h2>{deletionPending ? 'Finish removing your Aegis account.' : 'Export or delete your Aegis records.'}</h2><p>{deletionPending ? 'Your transaction and offer records are erased. Local sign-in cleanup may still be completing.' : 'Export a copy of your Aegis records, or delete uploaded transactions, saved comparisons, consent history, memberships, and your local sign-in profile.'}</p></div><div className="member-data-buttons">{!deletionPending && <button type="button" className="member-secondary-button" disabled={accountAction} onClick={exportAccountData}>Download my data</button>}<button type="button" className="member-delete-button" disabled={accountAction} onClick={deleteAccountData}>{accountAction ? 'Working…' : deletionPending ? 'Check deletion status' : 'Delete Aegis data'}</button></div></section>}
      <footer className="member-footer"><span>Aegis · Your choices stay yours.</span><a href="/">Synthetic example</a></footer>
    </div>
  </main>;
}
