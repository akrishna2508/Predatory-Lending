'use client';

import { FormEvent, useState } from 'react';
import { useRouter } from 'next/navigation';

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [working, setWorking] = useState(false);

  async function signIn(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError('');
    setWorking(true);
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      const body = await response.json() as { error?: string };
      if (!response.ok) throw new Error(body.error ?? 'Sign-in failed. Try again.');
      router.replace(new URLSearchParams(window.location.search).get('workspace') === 'partner' ? '/partner' : '/member');
      router.refresh();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'Sign-in failed. Try again.');
    } finally { setWorking(false); }
  }

  return <main className="member-screen"><section className="member-card member-gate login-card">
    <a className="member-mark" href="/" aria-label="Aegis home">A</a>
    <p className="eyebrow">AEGIS MEMBER ACCESS</p>
    <h1>Sign in to your Aegis account.</h1>
    <p>Sign in to save offer checks and use your opt-in transaction Shield. Your credit union activates your account.</p>
    <form className="login-form" onSubmit={signIn}>
      <label className="member-field"><span>Email</span><input autoComplete="username" type="email" maxLength={254} required value={email} onChange={event => setEmail(event.target.value)} /></label>
      <label className="member-field"><span>Password</span><input autoComplete="current-password" type="password" maxLength={256} required value={password} onChange={event => setPassword(event.target.value)} /></label>
      {error && <p className="member-alert" role="alert">{error}</p>}
      <button className="member-primary" type="submit" disabled={working}>{working ? 'Signing in…' : 'Sign in'}</button>
    </form>
    <a className="member-secondary-link" href="/check">Check an offer without signing in →</a>
  </section></main>;
}
