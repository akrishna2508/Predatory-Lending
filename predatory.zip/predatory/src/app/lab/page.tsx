'use client';

import { FormEvent, useEffect, useState } from 'react';

type SourceId = 'statlog-german' | 'lendingclub' | 'home-credit' | 'fico';
type GeneratorId = 'none' | 'gan' | 'diffusion';
type ModelReport = {
  total_rows: number;
  train_rows: number;
  test_rows: number;
  metrics: { roc_auc: number; brier_score: number; accuracy_at_0_5: number; holdout_adverse_rate: number };
  coefficients: Record<string, number>;
  source: { name: string; license: string; use: string; caveat: string; url: string };
  caveat: string;
};
type ComplaintReport = {
  rows_used: number;
  rows_scanned?: number;
  product_filter?: string | null;
  source_url?: string;
  date_coverage: { from: string | null; to: string | null };
  top_products: Array<{ name: string; count: number }>;
  top_issues: Array<{ name: string; count: number }>;
  top_companies: Array<{ name: string; count: number }>;
  narrative_analysis?: {
    rows_with_text: number;
    rows_with_any_signal: number;
    signals: Record<string, number>;
    method: string;
    privacy_note: string;
  };
  caveat: string;
};
type GeneratorBenchmark = {
  source_id: 'statlog-german' | 'lendingclub';
  source: { name: string; url: string; license: string; caveat: string };
  rows_used: number; train_rows: number; holdout_rows: number; generated_rows_per_engine: number;
  engines: Record<'gan' | 'diffusion', { name: string; holdout_distances: { mean_distance_scaled: number; spread_distance_scaled: number; correlation_distance: number } }>;
  generated_rows_saved: boolean; caveat: string;
};
type SimulationReport = {
  profile_type: string;
  trials: number;
  seed: number;
  metrics: Record<string, number>;
  caveat: string;
  generator?: { engine: string; rows_generated: number; artifact: string; caveat: string };
};

const sourceInfo: Record<SourceId, { name: string; note: string; defaultFile: string }> = {
  'statlog-german': {
    name: 'Statlog German Credit',
    note: 'Open UCI benchmark · CC BY 4.0 · 1,000 historical German records',
    defaultFile: 'statlog-german/german.data',
  },
  lendingclub: {
    name: 'LendingClub records',
    note: 'U.S. personal-loan benchmark · CC0 · 2007–2018',
    defaultFile: 'lendingclub/loans.csv',
  },
  'home-credit': {
    name: 'Home Credit Default Risk',
    note: '2018 Kaggle competition data · review terms',
    defaultFile: 'home-credit/application_train.csv',
  },
  fico: {
    name: 'FICO Explainable ML / HELOC',
    note: 'Challenge terms must be checked before use',
    defaultFile: 'fico/heloc_dataset.csv',
  },
};

const usd = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 });
const count = new Intl.NumberFormat('en-US');
const percent = (value: number) => `${(value * 100).toFixed(1)}%`;

async function postJson<T>(url: string, body: unknown): Promise<T> {
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || 'The local modeling request failed.');
  return result as T;
}

export default function Home() {
  const [source, setSource] = useState<SourceId>('lendingclub');
  const [baselineFile, setBaselineFile] = useState(sourceInfo.lendingclub.defaultFile);
  const [rowLimit, setRowLimit] = useState('100000');
  const [termsConfirmed, setTermsConfirmed] = useState(false);
  const [baseline, setBaseline] = useState<ModelReport | null>(null);
  const [complaintFile, setComplaintFile] = useState('cfpb/payday-complaints.csv');
  const [complaintProductFilter, setComplaintProductFilter] = useState('');
  const [complaint, setComplaint] = useState<ComplaintReport | null>(null);
  const [archivedLoanComplaint, setArchivedLoanComplaint] = useState<ComplaintReport | null>(null);
  const [generatorBenchmarks, setGeneratorBenchmarks] = useState<GeneratorBenchmark[]>([]);
  const [publicGeneratorSource, setPublicGeneratorSource] = useState<'statlog-german' | 'lendingclub'>('statlog-german');
  const [publicGeneratorFile, setPublicGeneratorFile] = useState(sourceInfo['statlog-german'].defaultFile);
  const [publicGeneratorRows, setPublicGeneratorRows] = useState('1000');
  const [publicGeneratorSamples, setPublicGeneratorSamples] = useState('500');
  const [profile, setProfile] = useState('gig-worker');
  const [trials, setTrials] = useState('1000');
  const [seed, setSeed] = useState('42');
  const [engine, setEngine] = useState<GeneratorId>('none');
  const [samples, setSamples] = useState('500');
  const [simulation, setSimulation] = useState<SimulationReport | null>(null);
  const [busy, setBusy] = useState<'baseline' | 'complaints' | 'simulation' | 'benchmark' | null>(null);
  const [error, setError] = useState('');

  useEffect(() => {
    let active = true;
    fetch('/api/lab/latest', { cache: 'no-store' })
      .then(response => response.ok ? response.json() : null)
      .then(result => {
        if (!active || !result) return;
        if (result.baseline) setBaseline(result.baseline as ModelReport);
        if (result.complaints) setComplaint(result.complaints as ComplaintReport);
        if (result.archivedLoanComplaints) setArchivedLoanComplaint(result.archivedLoanComplaints as ComplaintReport);
        if (Array.isArray(result.generatorBenchmarks)) setGeneratorBenchmarks(result.generatorBenchmarks as GeneratorBenchmark[]);
      })
      .catch(() => undefined);
    return () => { active = false; };
  }, []);

  function changeSource(value: SourceId) {
    setSource(value);
    setBaselineFile(sourceInfo[value].defaultFile);
    setTermsConfirmed(false);
    setBaseline(null);
    setError('');
  }

  async function train(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy('baseline');
    setError('');
    try {
      const report = await postJson<ModelReport>('/api/lab/baseline', {
        source, filename: baselineFile, rowLimit: Number(rowLimit), seed: 42, confirmSourceTerms: termsConfirmed,
      });
      setBaseline(report);
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : 'Baseline training failed.');
    } finally {
      setBusy(null);
    }
  }

  async function analyzeComplaints(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy('complaints');
    setError('');
    try {
      const report = await postJson<ComplaintReport>('/api/lab/complaints', { filename: complaintFile, productContains: complaintProductFilter });
      setComplaint(report);
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : 'Complaint analysis failed.');
    } finally {
      setBusy(null);
    }
  }

  async function benchmarkPublicGenerators(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy('benchmark');
    setError('');
    try {
      const report = await postJson<GeneratorBenchmark>('/api/lab/generator-benchmark', {
        source: publicGeneratorSource,
        filename: publicGeneratorFile,
        rowLimit: Number(publicGeneratorRows),
        samples: Number(publicGeneratorSamples),
        seed: 42,
      });
      setGeneratorBenchmarks(current => [...current.filter(item => item.source_id !== report.source_id), report]);
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : 'Public generator benchmark failed.');
    } finally {
      setBusy(null);
    }
  }

  async function simulate(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy('simulation');
    setError('');
    try {
      const report = await postJson<SimulationReport>('/api/lab/simulation', {
        profile, trials: Number(trials), seed: Number(seed), engine, samples: Number(samples),
      });
      setSimulation(report);
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : 'Simulation failed.');
    } finally {
      setBusy(null);
    }
  }

  const needsTermsConfirmation = source === 'home-credit' || source === 'fico';
  return <main className="lab-shell">
    <aside className="lab-sidebar" aria-label="Aegis modeling navigation">
      <a href="#top" className="lab-brand"><span className="lab-mark" aria-hidden="true">A</span><span>AEGIS<span className="brand-caption">MODELING LAB</span></span></a>
      <nav className="lab-nav">
        <a href="/check"><span>↗</span> Consumer offer check</a>
        <a href="#phase-1"><span>01</span> Baseline models</a>
        <a href="#phase-2"><span>02</span> Synthetic ecosystem</a>
      </nav>
      <div className="sidebar-local"><span className="local-indicator"/> LOCAL WORKSPACE</div>
      <div className="sidebar-note"><strong>Data stays on this machine.</strong><p>Raw files are read locally. Reports contain aggregate metrics only.</p></div>
      <div className="sidebar-version">AEGIS <span>·</span> RESEARCH BUILD</div>
    </aside>

    <div className="lab-content" id="top">
      <header className="lab-topbar">
        <div className="breadcrumb">AEGIS <span>/</span> RESEARCH WORKBENCH</div>
        <div className="topbar-right"><span className="local-indicator"/> Local only <a href="https://www.consumerfinance.gov/data-research/consumer-complaints/" target="_blank" rel="noreferrer">Data sources ↗</a></div>
      </header>

      <div className="lab-page">
        <div className="page-intro">
          <div><div className="eyebrow">RESEARCH WORKSPACE · PUBLIC SIGNALS · SYNTHETIC SCENARIOS</div><h1>Model the pressure points.</h1><p>This area explains the research behind Aegis. Explore public repayment patterns and test fictional cash-flow scenarios locally. For your own offer, use the <a href="/check">consumer offer check →</a></p></div>
          <div className="scope-pill"><span>●</span> public data + fictional scenarios</div>
        </div>

        <section className="phase-section" id="phase-1" aria-labelledby="phase-one-title">
          <div className="phase-heading"><div className="phase-number">01</div><div><div className="eyebrow">Phase 1 · PUBLIC DATA</div><h2 id="phase-one-title">Baseline macro models</h2><p>Train a transparent repayment benchmark and inspect descriptive complaint trends.</p></div><span className="phase-state">LOCAL MODELING</span></div>

          <div className="source-grid" aria-label="Public dataset catalog">
            <SourceCard name="Statlog German Credit" meta="UCI · CC BY 4.0" status="Ready to run" tone="ready" href="https://archive.ics.uci.edu/dataset/144/statlog+german+credit+data" body="1,000 historical records. German benchmark, not U.S. market data." />
            <SourceCard name="CFPB complaints" meta="U.S. public API + official archive" status="Market context" tone="context" href="https://www.consumerfinance.gov/foia-requests/foia-electronic-reading-room/cfpb-consumer-complaint-database-narratives-archive/" body="Current payday metadata and an archived July 2026 lending slice with 410 published narratives. Complaints are not verified outcomes." />
            <SourceCard name="LendingClub" meta="CC0 · U.S. personal loans · 2007–2018" status="Primary baseline" tone="ready" href="https://www.kaggle.com/datasets/wordsforthewise/lending-club" body="Historical repayment outcomes and debt features; useful as a U.S. benchmark, not payday-specific or current member data." />
            <SourceCard name="Home Credit Default Risk" meta="Kaggle · 2018 competition" status="Review terms" tone="restricted" href="https://www.kaggle.com/c/home-credit-default-risk/rules" body="Confirm that the original competition rules permit your research use; do not redistribute the data." />
            <SourceCard name="FICO HELOC" meta="xML Challenge · OpenML mirror" status="Review terms" tone="restricted" href="https://www.openml.org/search?id=45026&sort=runs&type=data" body="The OpenML listing says ‘See source’ for its license. Confirm source rights before using a local file." />
          </div>

          <div className="phase-one-grid">
            <section className="lab-card" aria-labelledby="train-title">
              <div className="card-head"><div><span className="card-index">MODEL 01</span><h3 id="train-title">Train a repayment baseline</h3></div><span className="card-icon">↗</span></div>
              <p className="card-copy">The model uses labeled historical records and a fixed holdout split. Its result is a dataset benchmark, never a member score.</p>
              <form onSubmit={train} className="lab-form">
                <label className="form-field"><span>Dataset</span><select value={source} onChange={event => changeSource(event.target.value as SourceId)}>
                  <option value="statlog-german">Statlog German Credit · open benchmark</option>
                  <option value="lendingclub">LendingClub · historical U.S. loans</option>
                  <option value="home-credit">Home Credit · competition data</option>
                  <option value="fico">FICO Explainable ML · challenge data</option>
                </select></label>
                <label className="form-field"><span>Filename under <code>data/raw</code></span><input value={baselineFile} onChange={event => setBaselineFile(event.target.value)} required spellCheck={false} /></label>
                <div className="form-row">
                  <label className="form-field"><span>Maximum labeled rows</span><input type="number" min="10" max="100000" value={rowLimit} onChange={event => setRowLimit(event.target.value)} /></label>
                  <div className="form-field source-note"><span>Source use</span><p>{sourceInfo[source].note}</p></div>
                </div>
                {needsTermsConfirmation && <label className="check-field"><input type="checkbox" checked={termsConfirmed} onChange={event => setTermsConfirmed(event.target.checked)} /><span>I checked the source terms and will use this file only for an allowed purpose.</span></label>}
                <button className="primary-button" type="submit" disabled={busy !== null || (needsTermsConfirmation && !termsConfirmed)}>{busy === 'baseline' ? <><span className="spinner"/> Training locally…</> : 'Train local baseline'}</button>
              </form>
              {baseline ? <BaselineResult report={baseline}/> : <div className="empty-report"><span className="report-icon">▤</span><div><strong>No baseline run selected</strong><p>Place an eligible file under <code>data/raw</code>, then train the model.</p></div></div>}
            </section>

            <section className="lab-card" aria-labelledby="cfpb-title">
              <div className="card-head"><div><span className="card-index">MARKET CONTEXT</span><h3 id="cfpb-title">CFPB complaint context</h3></div><span className="card-icon">≋</span></div>
              <p className="card-copy">Summarize reported issues and, when present, aggregate phrase flags from archived complaint narratives. This file is not a statistical sample.</p>
              <form onSubmit={analyzeComplaints} className="lab-form">
                <label className="form-field"><span>Filename under <code>data/raw</code></span><input value={complaintFile} onChange={event => setComplaintFile(event.target.value)} required spellCheck={false} /></label>
                <label className="form-field"><span>Product phrase filter · optional</span><input value={complaintProductFilter} maxLength={120} onChange={event => setComplaintProductFilter(event.target.value)} placeholder="e.g. payday loan" /></label>
                <button className="source-download archive-preset" type="button" onClick={() => { setComplaintFile('cfpb/historical-jul-2026.zip'); setComplaintProductFilter('payday loan'); }}>Use the archived lending slice →</button>
                <a className="source-download" href="https://www.consumerfinance.gov/data-research/consumer-complaints/" target="_blank" rel="noreferrer">Get current complaint data ↗</a>
                <a className="source-download" href="https://www.consumerfinance.gov/foia-requests/foia-electronic-reading-room/cfpb-consumer-complaint-database-narratives-archive/" target="_blank" rel="noreferrer">Official historical narrative archive ↗</a>
                <div className="cfpb-caveat"><strong>How to read this</strong><p>Complaint volume depends on company size and who chooses to complain; it does not establish that a company broke the law. Current CFPB downloads omit narratives. Historical public narratives are analyzed locally as aggregate phrase counts only.</p></div>
                <button className="secondary-button" type="submit" disabled={busy !== null}>{busy === 'complaints' ? <><span className="spinner dark"/> Summarizing locally…</> : 'Analyze local complaint file'}</button>
              </form>
              {complaint ? <ComplaintResult report={complaint}/> : <div className="empty-report compact"><span className="report-icon">⌕</span><div><strong>Complaint summary appears here</strong><p>Only counts and date coverage are included in the report.</p></div></div>}
              {archivedLoanComplaint && <details className="archived-loan-report"><summary>July 2026 archived lending slice · {count.format(archivedLoanComplaint.rows_used)} complaints · {count.format(archivedLoanComplaint.narrative_analysis?.rows_with_text ?? 0)} narratives</summary><ComplaintResult report={archivedLoanComplaint}/></details>}
            </section>
          </div>

          <section className="lab-card public-generator-card" aria-labelledby="public-generator-title">
            <div className="card-head"><div><span className="card-index">PUBLIC MATRIX BENCHMARK</span><h3 id="public-generator-title">Test GAN and diffusion on real credit data</h3></div><span className="card-icon">◇</span></div>
            <p className="card-copy">The local experiment trains both samplers on numeric features from an open dataset, then compares generated values with held-out records. It saves aggregate distances only. These models are research prototypes and do not analyze members.</p>
            <form onSubmit={benchmarkPublicGenerators} className="lab-form public-generator-form">
              <div className="form-row"><label className="form-field"><span>Open benchmark</span><select value={publicGeneratorSource} onChange={event => { const next = event.target.value as 'statlog-german' | 'lendingclub'; setPublicGeneratorSource(next); setPublicGeneratorFile(sourceInfo[next].defaultFile); setPublicGeneratorRows(next === 'lendingclub' ? '5000' : '1000'); }}><option value="statlog-german">Statlog German Credit</option><option value="lendingclub">LendingClub U.S. loan records</option></select></label><label className="form-field"><span>Filename under <code>data/raw</code></span><input required value={publicGeneratorFile} onChange={event => setPublicGeneratorFile(event.target.value)} /></label></div>
              <div className="form-row"><label className="form-field"><span>Source rows</span><input type="number" min="100" max="50000" required value={publicGeneratorRows} onChange={event => setPublicGeneratorRows(event.target.value)} /></label><label className="form-field"><span>Generated rows per engine</span><input type="number" min="20" max="5000" required value={publicGeneratorSamples} onChange={event => setPublicGeneratorSamples(event.target.value)} /></label></div>
              <button className="secondary-button" type="submit" disabled={busy !== null}>{busy === 'benchmark' ? <><span className="spinner dark"/> Running both engines…</> : 'Run public data benchmark'}</button>
            </form>
            {generatorBenchmarks.length > 0 ? <div className="public-generator-results">{generatorBenchmarks.map(report => <GeneratorBenchmarkResult key={report.source_id} report={report} />)}</div> : <p className="empty-report compact">No public generator benchmark has been run on this machine yet.</p>}
          </section>
        </section>

        <section className="phase-section phase-two" id="phase-2" aria-labelledby="phase-two-title">
          <div className="phase-heading"><div className="phase-number violet">02</div><div><div className="eyebrow">Phase 2 · GENERATED DATA</div><h2 id="phase-two-title">Synthetic ecosystem</h2><p>Explore how cash timing, stress events, and offer terms interact across fictional cohorts.</p></div><span className="phase-state violet-state">ALL PROFILES FICTIONAL</span></div>
          <div className="phase-two-grid">
            <section className="lab-card simulator-card" aria-labelledby="sim-title">
              <div className="card-head"><div><span className="card-index violet-text">AGENT SIMULATOR</span><h3 id="sim-title">Set up a scenario</h3></div><span className="card-icon purple-icon">◇</span></div>
              <p className="card-copy">Each run creates new fictional income dates, essential bills, cash shocks, and a synthetic offer trigger.</p>
              <form onSubmit={simulate} className="lab-form">
                <fieldset className="profile-picker"><legend>Fictional cohort</legend>
                  <label className={profile === 'gig-worker' ? 'profile-option selected' : 'profile-option'}><input type="radio" name="profile" value="gig-worker" checked={profile === 'gig-worker'} onChange={() => setProfile('gig-worker')}/><span className="profile-symbol">↗</span><span><strong>Gig worker</strong><small>Variable weekly income</small></span></label>
                  <label className={profile === 'student' ? 'profile-option selected' : 'profile-option'}><input type="radio" name="profile" value="student" checked={profile === 'student'} onChange={() => setProfile('student')}/><span className="profile-symbol">⌂</span><span><strong>Student</strong><small>Staggered pay dates</small></span></label>
                  <label className={profile === 'low-income-family' ? 'profile-option selected' : 'profile-option'}><input type="radio" name="profile" value="low-income-family" checked={profile === 'low-income-family'} onChange={() => setProfile('low-income-family')}/><span className="profile-symbol">○</span><span><strong>Low-income family</strong><small>Fixed bills and paydays</small></span></label>
                </fieldset>
                <div className="form-row sim-settings">
                  <label className="form-field"><span>Monte Carlo trials</span><select value={trials} onChange={event => setTrials(event.target.value)}><option value="100">100 runs</option><option value="1000">1,000 runs</option><option value="5000">5,000 runs</option></select></label>
                  <label className="form-field"><span>Seed</span><input type="number" min="0" max="2147483647" value={seed} onChange={event => setSeed(event.target.value)} /></label>
                </div>
                <label className="form-field"><span>Tabular generator</span><select value={engine} onChange={event => setEngine(event.target.value as GeneratorId)}><option value="none">Agent simulation only</option><option value="gan">Experimental NumPy GAN</option><option value="diffusion">Experimental Diffusion sampler</option></select></label>
                {engine !== 'none' && <label className="form-field"><span>Synthetic rows to generate</span><input type="number" min="10" max="5000" value={samples} onChange={event => setSamples(event.target.value)} /></label>}
                <div className="synthetic-traits"><span className="trait-icon">✳</span><p><strong>Impulse and stress are generated variables.</strong> Aegis does not infer them from public or personal records.</p></div>
                <button className="primary-button violet-button" type="submit" disabled={busy !== null}>{busy === 'simulation' ? <><span className="spinner"/> Running synthetic trials…</> : 'Run synthetic scenario'}</button>
              </form>
            </section>

            <section className="lab-card result-card" aria-labelledby="result-title">
              <div className="card-head"><div><span className="card-index violet-text">SIMULATION OUTPUT</span><h3 id="result-title">What the scenarios show</h3></div><span className="result-stamp">SYNTHETIC</span></div>
              {simulation ? <SimulationResult report={simulation}/> : <div className="simulation-empty"><div className="orbit orbit-one"/><div className="orbit orbit-two"/><div className="orbit-core">A</div><strong>Waiting for a scenario</strong><p>Choose a cohort and run repeatable trials to see how cash pressure and payday timing affect the simulated outcomes.</p></div>}
              <details className="trigger-details"><summary>How the synthetic trigger is formed</summary><p>Cash shortfall pressure, days to payday, offer fee ratio, and generated impulse/stress knobs combine into a bounded scenario propensity. The formula is a simulation rule, not a psychological measurement.</p></details>
            </section>
          </div>
        </section>

        {error && <div className="error-toast" role="alert"><span>!</span><div><strong>Run could not complete</strong><p>{error}</p></div><button onClick={() => setError('')} aria-label="Dismiss error">×</button></div>}
        <footer className="lab-footer"><span>AEGIS · LOCAL MODELING BUILD</span><span>Research benchmarks and fictional scenarios only.</span><a href="https://www.consumerfinance.gov/data-research/consumer-complaints/" target="_blank" rel="noreferrer">CFPB data source ↗</a></footer>
      </div>
    </div>
  </main>;
}

function SourceCard({ name, meta, status, tone, href, body }: { name: string; meta: string; status: string; tone: string; href: string; body: string }) {
  return <a className="source-card" href={href} target="_blank" rel="noreferrer"><div className="source-card-top"><span>{meta}</span><span className={`source-status ${tone}`}>{status}</span></div><h3>{name}<span>↗</span></h3><p>{body}</p></a>;
}

function BaselineResult({ report }: { report: ModelReport }) {
  const coefficients = Object.entries(report.coefficients).sort((a, b) => Math.abs(b[1]) - Math.abs(a[1]));
  const maxCoefficient = Math.max(0.001, ...coefficients.map(([, value]) => Math.abs(value)));
  return <div className="result-block" aria-label="Baseline model report" aria-live="polite">
    <div className="result-block-head"><div><span className="success-dot"/><strong>{report.source.name}</strong></div><a href={report.source.url} target="_blank" rel="noreferrer">Source ↗</a></div>
    <div className="metric-strip three-metrics"><Metric label="Holdout ROC-AUC" value={report.metrics.roc_auc.toFixed(3)} detail="0.5 is random ranking"/><Metric label="Brier score" value={report.metrics.brier_score.toFixed(3)} detail="Lower is better"/><Metric label="Holdout accuracy" value={percent(report.metrics.accuracy_at_0_5)} detail={`${report.test_rows} test records`}/></div>
    <div className="model-meta"><span><strong>{count.format(report.total_rows)}</strong> labeled rows</span><span><strong>{percent(report.metrics.holdout_adverse_rate)}</strong> adverse labels in holdout</span><span>Seeded 80 / 20 split</span></div>
    <div className="coefficient-list"><div className="mini-section-title">Largest standardized coefficients <span>direction in this benchmark</span></div>{coefficients.slice(0, 5).map(([name, value]) => <div className="coefficient-row" key={name}><span>{name.replaceAll('_', ' ')}</span><div className="coefficient-track"><i className={value >= 0 ? 'positive-coeff' : 'negative-coeff'} style={{ width: `${Math.max(4, Math.abs(value) / maxCoefficient * 100)}%` }}/></div><strong>{value > 0 ? '+' : ''}{value.toFixed(3)}</strong></div>)}</div>
    <p className="source-caveat">{report.source.caveat} {report.caveat}</p>
  </div>;
}

function ComplaintResult({ report }: { report: ComplaintReport }) {
  const narrativeLabels: Record<string, string> = {
    income_disruption: 'Income disruption',
    payment_difficulty: 'Payment difficulty',
    cash_shortfall: 'Cash shortfall',
    fee_pressure: 'Fee pressure',
  };
  const narrative = report.narrative_analysis;
  const signalRows = narrative
    ? Object.entries(narrative.signals).map(([name, value]) => ({ name: narrativeLabels[name] || name.replaceAll('_', ' '), count: value }))
    : [];
  return <div className="result-block" aria-label="CFPB complaint summary" aria-live="polite">
    <div className="result-block-head"><div><span className="context-dot"/><strong>{count.format(report.rows_used)} complaints summarized</strong></div><span>{report.date_coverage.from || 'Date unknown'} – {report.date_coverage.to || 'date unknown'}</span></div>
    {report.product_filter && <p className="report-filter-note">Products containing “{report.product_filter}” · {count.format(report.rows_scanned ?? report.rows_used)} archive rows scanned</p>}
    <div className="complaint-columns"><RankedList title="Reported issues" rows={report.top_issues.slice(0, 4)}/><RankedList title="Companies in this file" rows={report.top_companies.slice(0, 4)}/></div>
    {narrative && <div className="narrative-flags"><div className="mini-section-title">Archived narrative phrase flags <span>{count.format(narrative.rows_with_any_signal)} of {count.format(narrative.rows_with_text)} narratives matched</span></div><RankedList title="Aggregate financial-pressure phrases" rows={signalRows}/><p>{narrative.method} {narrative.privacy_note}</p></div>}
    <p className="source-caveat">{report.caveat} {report.source_url && <a href={report.source_url} target="_blank" rel="noreferrer">Source ↗</a>}</p>
  </div>;
}

function GeneratorBenchmarkResult({ report }: { report: GeneratorBenchmark }) {
  return <article className="public-generator-result" aria-label={`${report.source.name} generator benchmark`}>
    <div className="public-generator-result-head"><h4>{report.source.name}</h4><span>{count.format(report.train_rows)} train · {count.format(report.holdout_rows)} holdout · {count.format(report.generated_rows_per_engine)} generated per engine</span></div>
    <div className="public-generator-engine-grid">{(['gan', 'diffusion'] as const).map(engine => {
      const result = report.engines[engine];
      return <div key={engine}><strong>{result.name}</strong><dl><div><dt>Mean gap</dt><dd>{percent(result.holdout_distances.mean_distance_scaled)}</dd></div><div><dt>Spread gap</dt><dd>{percent(result.holdout_distances.spread_distance_scaled)}</dd></div><div><dt>Correlation gap</dt><dd>{result.holdout_distances.correlation_distance.toFixed(3)}</dd></div></dl></div>;
    })}</div>
    <p>Smaller gaps mean generated feature summaries are closer to this holdout. They are not a safety, privacy, or predictive score. {report.caveat} <a href={report.source.url} target="_blank" rel="noreferrer">Dataset source ↗</a></p>
  </article>;
}

function RankedList({ title, rows }: { title: string; rows: Array<{ name: string; count: number }> }) {
  return <div className="ranked-list"><div className="mini-section-title">{title}</div>{rows.length ? rows.map((row, index) => <div className="rank-row" key={`${row.name}-${index}`}><span className="rank-number">{String(index + 1).padStart(2, '0')}</span><span className="rank-name">{row.name}</span><strong>{count.format(row.count)}</strong></div>) : <p className="no-rows">No grouped rows</p>}</div>;
}

function Metric({ label, value, detail }: { label: string; value: string; detail: string }) {
  return <div className="metric-cell"><span>{label}</span><strong>{value}</strong><small>{detail}</small></div>;
}

function SimulationResult({ report }: { report: SimulationReport }) {
  const metrics = report.metrics;
  const items = [
    { label: 'Offer acceptance', value: metrics.acceptance_rate ?? 0, color: 'purple-bar' },
    { label: 'Shortfall after offer', value: metrics.with_offer_shortfall_rate ?? 0, color: 'amber-bar' },
    { label: 'Repeat borrowing', value: metrics.repeat_borrowing_rate ?? 0, color: 'blue-bar' },
    { label: 'Payday capture', value: metrics.payday_capture_rate ?? 0, color: 'gray-bar' },
  ];
  return <div className="simulation-report" aria-live="polite">
    <div className="simulation-meta"><span className="profile-result">{report.profile_type.replaceAll('-', ' ')}</span><span>{count.format(report.trials)} trials</span><span>Seed {report.seed}</span></div>
    <div className="simulation-bars">{items.map(item => <div className="sim-bar-row" key={item.label}><div><span>{item.label}</span><strong>{percent(item.value)}</strong></div><div className="sim-track"><i className={item.color} style={{ width: percent(item.value) }}/></div></div>)}</div>
    <div className="simulation-extra"><span><small>Mean trigger strength</small><strong>{(metrics.mean_temptation_trigger ?? 0).toFixed(3)}</strong></span><span><small>Mean time to payday</small><strong>{(metrics.mean_days_to_payday ?? 0).toFixed(1)} days</strong></span><span><small>Simulated fees p90</small><strong>{usd.format(metrics.simulated_fees_p90 ?? 0)}</strong></span></div>
    {report.generator && <div className="generator-result"><div><span className="success-dot"/><strong>{report.generator.engine}</strong><small>{count.format(report.generator.rows_generated)} numeric rows · experimental</small></div><a className="download-button" href="/api/lab/synthetic">Download CSV ↓</a><p>{report.generator.caveat}</p></div>}
    <p className="simulation-caveat">{report.caveat} Rates describe these seeded scenarios only.</p>
  </div>;
}
