import Link from 'next/link';
import ScrollMotion from './ScrollMotion';

const examplePayments = [
  { date: 'Oct 12', amount: '$287.50' },
  { date: 'Oct 26', amount: '$287.50' },
];

export default function Home() {
  return (
    <main className="public-home">
      <ScrollMotion />
      <div className="public-top-ticker"><div>YOUR MONEY. YOUR MOVE. ✦ KNOW THE COST BEFORE YOU COMMIT. ✦ YOUR MONEY. YOUR MOVE. ✦ KNOW THE COST BEFORE YOU COMMIT. ✦</div></div>
      <header className="public-header">
        <Link className="public-brand" href="/" aria-label="Aegis home"><span className="public-brand-mark" aria-hidden="true">A</span><span>AEGIS</span></Link>
        <nav className="public-nav" aria-label="Main navigation">
          <a href="#how-it-works">How it works</a>
          <Link href="/check">Check an offer</Link>
          <Link href="/lab">Research lab</Link>
          <Link href="/shield-demo">Shield demo</Link>
          <Link className="public-nav-signin" href="/login">Member sign in</Link>
        </nav>
      </header>

      <section className="public-hero" aria-labelledby="public-title">
        <svg className="hero-ribbon" viewBox="0 0 1500 850" fill="none" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
          <defs><filter id="ribbon-texture"><feTurbulence type="fractalNoise" baseFrequency="0.16" numOctaves="2" seed="8" result="grain"/><feColorMatrix in="grain" type="saturate" values="0" result="gray"/><feComposite in="gray" in2="SourceGraphic" operator="in"/></filter></defs>
          <path d="M-170 350 C 50 675 175 655 345 480 S 525 95 770 175 S 1000 590 1210 515 S 1410 355 1560 590" stroke="#0754c0" strokeWidth="180" strokeLinecap="round"/>
          <path d="M-170 350 C 50 675 175 655 345 480 S 525 95 770 175 S 1000 590 1210 515 S 1410 355 1560 590" stroke="#278fff" strokeWidth="145" strokeLinecap="round"/>
          <path d="M-170 350 C 50 675 175 655 345 480 S 525 95 770 175 S 1000 590 1210 515 S 1410 355 1560 590" stroke="#8bd4ff" strokeWidth="23" strokeLinecap="round" opacity=".6"/>
          <path d="M-170 350 C 50 675 175 655 345 480 S 525 95 770 175 S 1000 590 1210 515 S 1410 355 1560 590" stroke="#fff" strokeWidth="145" strokeLinecap="round" opacity=".16" filter="url(#ribbon-texture)"/>
        </svg>
        <span className="hero-sticker hero-sticker-star" aria-hidden="true">✦</span>
        <span className="hero-sticker hero-sticker-coin" aria-hidden="true">$</span>
        <span className="hero-sticker hero-sticker-shield" aria-hidden="true">✓</span>
        <div className="public-hero-copy" data-reveal>
          <p className="public-kicker"><span aria-hidden="true" /> A CLEARER WAY TO REVIEW A LOAN OFFER</p>
          <h1 id="public-title">AEGIS</h1>
          <p className="public-hero-subtitle">Your money. Your move.</p>
          <div className="public-actions">
            <Link className="public-primary" href="/check">Check an offer <span aria-hidden="true">↗</span></Link>
            <Link className="public-secondary" href="/shield-demo">Try a fictional sample <span aria-hidden="true">↗</span></Link>
          </div>
          <p className="public-hero-note">See the cost before you decide.</p>
        </div>
        <a className="public-scroll-cue" href="#how-it-works">SCROLL TO EXPLORE <span aria-hidden="true">↓</span></a>
      </section>

      <div className="public-ticker" aria-label="Know the cost. Keep your choice."><div aria-hidden="true">✦ KNOW THE COST &nbsp; ✦ KEEP YOUR CHOICE &nbsp; ✦ PROTECT YOUR PAYDAY &nbsp; ✦ KNOW THE COST &nbsp; ✦ KEEP YOUR CHOICE &nbsp; ✦ PROTECT YOUR PAYDAY &nbsp;</div></div>

      <section className="public-story" id="how-it-works" aria-labelledby="story-title">
        <div className="public-story-heading" data-reveal>
          <p className="public-kicker">A CLEARER VIEW, BEFORE YOU COMMIT</p>
          <h2 id="story-title">See the cost.<br/>Keep the choice.</h2>
          <p>Check an offer against your upcoming bills, spot repeated loan or fee descriptions, and preview a reserve for the next payday. You decide what happens next.</p>
          <Link className="public-primary" href="/check">Check your offer <span aria-hidden="true">↗</span></Link>
        </div>
        <div className="public-story-visual" data-reveal>
          <div className="story-orbit story-orbit-one" aria-hidden="true">$</div><div className="story-orbit story-orbit-two" aria-hidden="true">✓</div><div className="story-orbit story-orbit-three" aria-hidden="true">!</div>
          <section className="public-example" aria-labelledby="example-title">
            <div className="example-topline"><span className="example-dot" /> ILLUSTRATIVE EXAMPLE <span className="example-fictional">FICTIONAL INPUTS</span></div>
            <div className="example-title-row"><div><p>Offer summary</p><h3 id="example-title">Short-term installment offer</h3></div><span className="example-label">Example</span></div>
            <div className="example-received"><span>Funds received</span><strong>$500.00</strong></div>
            <div className="example-payment-list" aria-label="Illustrative repayment schedule">{examplePayments.map(payment => <div className="example-payment" key={payment.date}><span><i aria-hidden="true" /> {payment.date}</span><strong>{payment.amount}</strong></div>)}</div>
            <div className="example-total"><span>Total repayment</span><strong>$575.00</strong></div>
            <div className="example-cost"><span>Cost above funds received</span><strong>$75.00</strong></div>
            <p className="example-caveat">Illustrative example. Actual terms and your cash flow may differ. This is not an endorsement or a prediction.</p>
          </section>
        </div>
      </section>

      <section className="public-how" aria-labelledby="how-title">
        <div className="public-section-heading" data-reveal>
          <p className="public-kicker">THREE WAYS TO STAY A STEP AHEAD</p>
          <h2 id="how-title">A little pause.<br/>A lot more clarity.</h2>
          <p>Start with details you provide. Review the numbers, assumptions, and any projected shortfall before choosing what to do.</p>
        </div>
        <div className="public-steps">
          <article data-reveal><span>01</span><h3>Enter<br/>the offer</h3><p>Add the amount you would receive and each payment date and amount.</p></article>
          <article data-reveal><span>02</span><h3>Get your<br/>shield alert</h3><p>If you opt in, Aegis flags repeated loan or fee descriptions and pauses a save when the offer forecast shows a shortfall.</p></article>
          <article data-reveal><span>03</span><h3>Plan each<br/>payday</h3><p>Preview how entered income could be divided between an upcoming-bills reserve and the remaining balance.</p></article>
        </div>
      </section>

      <section className="public-footer-cta" data-reveal><div><p className="public-kicker">YOU STAY IN CONTROL</p><h2>Aegis explains the signals.<br/>You choose the move.</h2></div><Link className="public-primary" href="/check">Start an offer check <span aria-hidden="true">↗</span></Link></section>
      <footer className="public-footer"><Link className="public-brand footer-brand" href="/"><span className="public-brand-mark" aria-hidden="true">A</span><span>AEGIS</span></Link><p>Aegis provides estimates from the information entered. It does not decide whether an offer is safe, legal, or right for you.</p><div><Link href="/check">Check an offer</Link><Link href="/member">Member workspace</Link><Link href="/lab">Research lab</Link><Link href="/shield-demo">Fictional sample</Link><Link href="/partner">Partner access</Link></div></footer>
    </main>
  );
}
