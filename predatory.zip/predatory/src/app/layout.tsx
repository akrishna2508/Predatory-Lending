import type { Metadata } from 'next';
import './globals.css';
import './aegis-theme.css';
import './experience.css';

export const metadata: Metadata = {
  title: 'Aegis — Financial Clarity',
  description: 'Member-controlled transaction alerts, loan-cost comparisons, payday reserve planning, and a local research lab.',
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
