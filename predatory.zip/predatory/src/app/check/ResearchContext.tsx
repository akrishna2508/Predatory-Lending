'use client';

import { useEffect, useState } from 'react';

type Context = {
  baseline: null | {
    model: string; trainedAt: string; totalRows: number; trainRows: number; testRows: number; rocAuc: number;
    coefficients: { debtToIncome?: number; loanAmount?: number }; source: string; period: string;
  };
  complaints: null | {
    rowsUsed: number; dateCoverage: { from?: string | null; to?: string | null } | null;
    topIssues: Array<{ name: string; count: number }>; caveat: string;
  };
  archivedLoanComplaints: null | {
    rowsUsed: number; narrativesWithText: number; narrativesWithSignals: number;
    signals: { feePressure: number; paymentDifficulty: number; cashShortfall: number; incomeDisruption: number };
    topIssues: Array<{ name: string; count: number }>; sourceUrl: string; period: string;
  };
};

const count = new Intl.NumberFormat('en-US');

export default function ResearchContext() {
  const [context, setContext] = useState<Context | null>(null);
  useEffect(() => {
    let active = true;
    fetch('/api/research/context', { cache: 'no-store' })
      .then(response => response.ok ? response.json() as Promise<Context> : null)
      .then(value => { if (active && value) setContext(value); })
      .catch(() => undefined);
    return () => { active = false; };
  }, []);

  if (!context || (!context.baseline && !context.complaints && !context.archivedLoanComplaints)) return null;
  return <details className="research-context">
    <summary>What U.S. research informs Aegis?</summary>
    <div className="research-context-body">
      <p className="research-context-lede">These aggregate findings add context to the shield's review questions. Your cost and cash-flow result still comes only from the offer terms, balance, income, and bills you enter.</p>
      {context.baseline && <section>
        <div className="research-context-kicker">TRAINED U.S. LOAN BENCHMARK</div>
        <h3>{count.format(context.baseline.totalRows)} historical LendingClub records</h3>
        <p>Local logistic-regression benchmark trained on {count.format(context.baseline.trainRows)} records and evaluated on a separate {count.format(context.baseline.testRows)}-record holdout. Holdout ROC AUC: <strong>{context.baseline.rocAuc.toFixed(3)}</strong>.</p>
        <p>Debt-to-income and loan amount were positive model associations with adverse repayment in this sample. This is not causal evidence, a payday-loan model, or a score for you.</p>
        <small>U.S. personal loans from 2007–2018. Historical data may not represent today's products or Aegis members.</small>
      </section>}
      {context.complaints && <section>
        <div className="research-context-kicker">CFPB PAYDAY-PRODUCT COMPLAINTS · {count.format(context.complaints.rowsUsed)} RECORDS</div>
        <h3>Commonly reported issues</h3>
        <ul>{context.complaints.topIssues.map(issue => <li key={issue.name}><span>{issue.name}</span><strong>{count.format(issue.count)}</strong></li>)}</ul>
        <p>Use these as questions while reviewing an offer:</p>
        <ul className="research-prompts"><li>Are all fees included in the total repayment?</li><li>When and how will each payment be collected?</li><li>What happens if a payment is late or unaffordable?</li></ul>
        <small>Complaint counts are self-reported, not verified findings or rates per loan. They do not prove that a lender broke the law.</small>
      </section>}
      {context.archivedLoanComplaints && <section>
        <div className="research-context-kicker">ARCHIVED CFPB LENDING COMPLAINTS · {context.archivedLoanComplaints.period}</div>
        <h3>{count.format(context.archivedLoanComplaints.narrativesWithText)} published narratives reviewed</h3>
        <p>From {count.format(context.archivedLoanComplaints.rowsUsed)} complaints about payday, title, personal, or advance loans. Transparent phrase checks found fee wording in {count.format(context.archivedLoanComplaints.signals.feePressure)} narratives and payment difficulty wording in {count.format(context.archivedLoanComplaints.signals.paymentDifficulty)}. A narrative may match more than one category.</p>
        <ul>{context.archivedLoanComplaints.topIssues.map(issue => <li key={issue.name}><span>{issue.name}</span><strong>{count.format(issue.count)}</strong></li>)}</ul>
        <small>These are self-reported experiences and phrase matches, not measures of a lender or an individual's stress. <a href={context.archivedLoanComplaints.sourceUrl} target="_blank" rel="noreferrer">CFPB historical archive ↗</a></small>
      </section>}
      <p className="research-context-foot">Public reports guide review prompts. Your personal details are not sent to the public-data models or used to retrain them.</p>
    </div>
  </details>;
}
