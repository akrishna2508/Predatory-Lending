'use client';

import { analyzeLoanOfferText } from '@/domain/loan-offer-signals';
import { useId } from 'react';

type Props = { value: string; onChange?: (value: string) => void };

export default function OfferTextReview({ value, onChange }: Props) {
  const titleId = useId();
  const signals = analyzeLoanOfferText(value);
  const sourceLinks = [...new Map(signals.flatMap(signal => signal.source ? [[signal.source.href, signal.source] as const] : [])).values()];
  const review = value.trim() ? signals.length ? <ul className="offer-signal-list" aria-live="polite">{signals.map(signal => <li className={`offer-signal offer-signal-${signal.kind}`} key={signal.id}>
    <div><span className="offer-signal-kind">{signal.kind === 'high-concern' ? 'HIGH CONCERN' : signal.kind === 'review' ? 'REVIEW THIS' : 'INFORMATION CHECK'}</span><strong>{signal.title}</strong><p>{signal.explanation}</p>{signal.evidence && <blockquote>“{signal.evidence}”</blockquote>}{signal.source && <a href={signal.source.href} target="_blank" rel="noreferrer">{signal.source.label} ↗</a>}</div>
  </li>)}</ul> : <p className="offer-text-empty">No covered phrases were found. That does not confirm the offer or lender is safe.</p> : null;
  const sources = sourceLinks.length > 0 && <p className="offer-text-sources">Aegis uses transparent phrase checks. Review the source guidance directly before acting: {sourceLinks.map((source, index) => <span key={source.href}>{index > 0 ? ' · ' : ''}<a href={source.href} target="_blank" rel="noreferrer">{source.label}</a></span>)}</p>;

  if (onChange) return <details className="offer-text-review offer-text-review-input">
    <summary aria-controls={`${titleId}-body`}><span><small>OPTIONAL · ON THIS DEVICE</small><strong>Check the offer’s wording</strong><em>Paste text to see evidence-based warning signs.</em></span><b aria-hidden="true">＋</b></summary>
    <div className="offer-text-review-body" id={`${titleId}-body`}>
      <p>Aegis checks only the words you paste here. It does not open or read the lender’s website. Leave out account numbers and other private details.</p>
      <label className="member-field offer-text-label"><span>Offer wording or key terms</span><textarea aria-label="Offer wording or key terms" maxLength={20_000} rows={5} value={value} onChange={event => onChange(event.target.value)} placeholder="Paste the offer text here…" /></label>
      {review}
      {sources}
      {value.trim() && <p className="offer-text-limit">These transparent phrase checks can flag wording to review. They cannot verify a lender or determine whether an offer is a scam.</p>}
    </div>
  </details>;

  if (!value.trim()) return null;
  return <section className="offer-text-review offer-text-review-results" aria-labelledby={`${titleId}-title`}>
    <div className="offer-text-review-heading"><div><p className="eyebrow">PASTED OFFER TEXT · CHECKED IN THIS BROWSER</p><h3 id={`${titleId}-title`}>Wording to review</h3></div></div>
    {review}
    {sources}
    <p className="offer-text-limit">These transparent phrase checks can flag wording to review. They cannot verify a lender or determine whether an offer is a scam.</p>
  </section>;
}
