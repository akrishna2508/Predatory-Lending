'use client';

import Link from 'next/link';
import { FormEvent, useState } from 'react';
import { analyzeOffer, type CashEvent, type Payment } from '@/domain/finance';
import { assessEvidenceShield } from '@/domain/evidence-shield';
import { shiftDate } from '@/domain/shield-demo';
import ResearchContext from './ResearchContext';
import OfferTextReview from './OfferTextReview';
import EvidenceShieldReview, { useShieldResearch } from './EvidenceShieldReview';

type DraftEvent = { id: string; label: string; kind: 'income' | 'bill'; date: string; amount: string };
type ValidAnalysis = Extract<ReturnType<typeof analyzeOffer>, { valid: true }>;
type ResultMode = 'cost' | 'forecast';

const money = (value: number) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(value);
const today = () => new Date().toISOString().slice(0, 10);
const friendlyDate = (value: string) => new Date(`${value}T12:00:00Z`).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric', timeZone: 'UTC' });

export default function CheckPage() {
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [asOfDate, setAsOfDate] = useState(today);
  const [receivedOn, setReceivedOn] = useState(today);
  const [proceeds, setProceeds] = useState('');
  const [payments, setPayments] = useState<Payment[]>([{ date: shiftDate(today(), 14), amount: 0 }]);
  const [startingBalance, setStartingBalance] = useState('');
  const [events, setEvents] = useState<DraftEvent[]>([]);
  const [offerText, setOfferText] = useState('');
  const [analysis, setAnalysis] = useState<ValidAnalysis | null>(null);
  const [reviewAcknowledged, setReviewAcknowledged] = useState(false);
  const [mode, setMode] = useState<ResultMode>('cost');
  const [error, setError] = useState('');
  const shieldResearch = useShieldResearch();

  const totalRepayment = Math.round(payments.reduce((sum, payment) => sum + Math.round(Number(payment.amount) * 100), 0)) / 100;
  const cost = Math.round((totalRepayment - Number(proceeds)) * 100) / 100;
  const evidenceAlerts = step === 3 ? assessEvidenceShield({
    dollarCost: cost,
    shortfall: Boolean(analysis?.warning),
    offerText,
    hasDebtBills: events.some(item => item.kind === 'bill' && /loan|credit|card|debt|installment|mortgage/i.test(item.label)),
  }, shieldResearch) : [];
  const pauseAlerts = evidenceAlerts.filter(alert => alert.pause);

  function continueFromOffer(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError('');
    setReviewAcknowledged(false);
    if (!Number.isFinite(Number(proceeds)) || Number(proceeds) <= 0 || !receivedOn) return setError('Enter the amount you receive and its date.');
    if (payments.length === 0 || payments.some(payment => !payment.date || !Number.isFinite(Number(payment.amount)) || Number(payment.amount) <= 0)) return setError('Add every payment amount and due date.');
    if (payments.some(payment => payment.date < receivedOn)) return setError('Payment dates must be on or after the funds arrive.');
    setStep(2);
  }

  function showCostOnly() {
    setError('');
    setReviewAcknowledged(false);
    setMode('cost');
    setAnalysis(null);
    setStep(3);
  }

  function showForecast(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setReviewAcknowledged(false);
    if (startingBalance === '' || !Number.isFinite(Number(startingBalance)) || Number(startingBalance) < 0) return setError('Enter your current balance, or choose the cost-only result.');
    if (events.length === 0) return setError('Add at least one expected bill or income item, or choose the cost-only result.');
    const cashEvents: CashEvent[] = events.map(item => ({ id: item.id, label: item.label, kind: item.kind, date: item.date, amount: item.kind === 'bill' ? -Number(item.amount) : Number(item.amount) }));
    const result = analyzeOffer({ asOfDate, startingBalance: Number(startingBalance), proceeds: Number(proceeds), receivedOn, payments, events: cashEvents });
    if (!result.valid) return setError(result.reason.replace('Synthetic cash-flow events', 'Expected income and bills'));
    setError('');
    setAnalysis(result);
    setMode('forecast');
    setStep(3);
  }

  function loadSample() {
    const date = today();
    const samplePayments = [{ date: shiftDate(date, 14), amount: 287.5 }, { date: shiftDate(date, 28), amount: 287.5 }];
    const sampleEvents: DraftEvent[] = [
      { id: 'sample-rent', label: 'Rent', kind: 'bill', date: shiftDate(date, 2), amount: '300' },
      { id: 'sample-income-1', label: 'Gig income', kind: 'income', date: shiftDate(date, 7), amount: '300' },
      { id: 'sample-utilities', label: 'Utilities', kind: 'bill', date: shiftDate(date, 10), amount: '220' },
      { id: 'sample-bill', label: 'Essential bill', kind: 'bill', date: shiftDate(date, 16), amount: '100' },
      { id: 'sample-income-2', label: 'Gig income', kind: 'income', date: shiftDate(date, 21), amount: '40' },
    ];
    const result = analyzeOffer({ asOfDate: date, startingBalance: 340, proceeds: 500, receivedOn: date, payments: samplePayments, events: sampleEvents.map(item => ({ id: item.id, label: item.label, kind: item.kind, date: item.date, amount: item.kind === 'bill' ? -Number(item.amount) : Number(item.amount) })) });
    setAsOfDate(date); setReceivedOn(date); setProceeds('500'); setPayments(samplePayments); setStartingBalance('340'); setEvents(sampleEvents);
    setError(''); setReviewAcknowledged(false); setMode('forecast'); setAnalysis(result.valid ? result : null); setStep(3);
  }

  function carryDraft() {
    try {
      sessionStorage.setItem('aegis-quick-check-draft-v1', JSON.stringify({ asOfDate, receivedOn, proceeds, payments, startingBalance, events }));
    } catch { /* The member can still re-enter details if browser storage is unavailable. */ }
  }

  return <main className="check-screen">
    <header className="member-topbar"><Link className="member-brand" href="/">Aegis</Link><div className="member-top-actions"><Link href="/shield-demo">See a sample</Link><Link href="/login">Member sign in</Link></div></header>
    <div className="check-shell">
      <div className="check-intro"><p className="eyebrow">PRIVATE OFFER CHECK · NO SIGN-IN NEEDED</p><h1>Know the cost.<br/>See the timing.</h1><p>Start with the loan terms. Add your upcoming money details only if you want a cash-flow forecast. This check stays in this browser and is not saved.</p></div>
      <nav className="check-progress" aria-label="Offer check progress"><span aria-current={step === 1 ? 'step' : undefined}><b>1</b> Offer</span><span aria-current={step === 2 ? 'step' : undefined}><b>2</b> Your money <small>optional</small></span><span aria-current={step === 3 ? 'step' : undefined}><b>3</b> Result</span></nav>

      {step === 1 && <section className="check-panel" aria-labelledby="check-offer-title"><div className="check-panel-head"><p className="eyebrow">STEP 1 OF 3</p><h2 id="check-offer-title">What would you receive and repay?</h2><p>Use the amounts and dates written in the offer. No account details are needed.</p></div>
        <form onSubmit={continueFromOffer} className="check-form">
          <div className="check-grid"><label className="member-field"><span>Amount you would receive</span><div className="member-money"><span>$</span><input aria-label="Amount you would receive" required inputMode="decimal" type="number" min="0.01" step="0.01" value={proceeds} onChange={event => setProceeds(event.target.value)} placeholder="500.00" /></div></label><label className="member-field"><span>Date the money arrives</span><input required type="date" value={receivedOn} onChange={event => setReceivedOn(event.target.value)} /></label></div>
          <div className="check-row-title"><div><h3>Repayments</h3><p>Add each amount and due date shown in the offer.</p></div><button type="button" className="member-add-button" onClick={() => setPayments(current => [...current, { date: shiftDate(receivedOn || today(), 21), amount: 0 }])}>+ Add payment</button></div>
          <div className="check-payment-list">{payments.map((payment, index) => <div className="check-payment" key={index}><span className="check-count">{String(index + 1).padStart(2, '0')}</span><label className="member-field"><span>Payment amount</span><div className="member-money"><span>$</span><input aria-label={`Payment ${index + 1} amount`} required type="number" min="0.01" step="0.01" value={payment.amount || ''} onChange={event => setPayments(current => current.map((item, i) => i === index ? { ...item, amount: Number(event.target.value) } : item))} placeholder="287.50" /></div></label><label className="member-field"><span>Due date</span><input aria-label={`Payment ${index + 1} date`} required type="date" value={payment.date} onChange={event => setPayments(current => current.map((item, i) => i === index ? { ...item, date: event.target.value } : item))} /></label>{payments.length > 1 && <button type="button" className="member-remove-button" aria-label={`Remove payment ${index + 1}`} onClick={() => setPayments(current => current.filter((_, i) => i !== index))}>Remove</button>}</div>)}</div>
          <OfferTextReview value={offerText} onChange={setOfferText} />
          {error && <p className="member-alert" role="alert">{error}</p>}
          <div className="check-footer"><button className="member-primary" type="submit">Continue to money details →</button><button type="button" className="check-text-button" onClick={loadSample}>Use a fictional sample instead</button></div>
        </form>
      </section>}

      {step === 2 && <section className="check-panel" aria-labelledby="check-money-title"><div className="check-panel-head"><p className="eyebrow">STEP 2 OF 3 · OPTIONAL</p><h2 id="check-money-title">Could the payments fit?</h2><p>Add a balance and the income or bills you already know. Skip this step if you only want the loan cost.</p></div>
        <form className="check-form" onSubmit={showForecast}><div className="check-grid"><label className="member-field"><span>Current balance</span><div className="member-money"><span>$</span><input aria-label="Current balance" type="number" min="0" step="0.01" value={startingBalance} onChange={event => setStartingBalance(event.target.value)} placeholder="340.00" /></div></label><label className="member-field"><span>Balance as of</span><input type="date" value={asOfDate} onChange={event => setAsOfDate(event.target.value)} /></label></div>
          <div className="check-row-title"><div><h3>Upcoming income and bills</h3><p>Add what you expect over the next 30 days. Enter positive amounts; Aegis subtracts bills.</p></div><button type="button" className="member-add-button" onClick={() => setEvents(current => [...current, { id: `item-${Date.now()}-${current.length}`, label: '', kind: 'bill', date: shiftDate(asOfDate || today(), 7), amount: '' }])}>+ Add item</button></div>
          {events.length === 0 && <p className="check-empty">Nothing added yet. Add a payday or bill to see a forecast, or skip to the cost result.</p>}
          <div className="check-event-list">{events.map((item, index) => <div className="check-event" key={item.id}><label className="member-field"><span>Name</span><input aria-label={`Item ${index + 1} name`} required value={item.label} onChange={event => setEvents(current => current.map((row, i) => i === index ? { ...row, label: event.target.value } : row))} placeholder="Rent or payday" /></label><label className="member-field"><span>Type</span><select aria-label={`Item ${index + 1} type`} value={item.kind} onChange={event => setEvents(current => current.map((row, i) => i === index ? { ...row, kind: event.target.value as DraftEvent['kind'] } : row))}><option value="bill">Bill</option><option value="income">Income</option></select></label><label className="member-field"><span>Date</span><input aria-label={`Item ${index + 1} date`} required type="date" value={item.date} onChange={event => setEvents(current => current.map((row, i) => i === index ? { ...row, date: event.target.value } : row))} /></label><label className="member-field"><span>Amount</span><div className="member-money"><span>$</span><input aria-label={`Item ${index + 1} amount`} required type="number" min="0.01" step="0.01" value={item.amount} onChange={event => setEvents(current => current.map((row, i) => i === index ? { ...row, amount: event.target.value } : row))} /></div></label><button type="button" className="member-remove-button" onClick={() => setEvents(current => current.filter((_, i) => i !== index))}>Remove</button></div>)}</div>
          {error && <p className="member-alert" role="alert">{error}</p>}<div className="check-footer"><button type="submit" className="member-primary">Show my forecast →</button><button type="button" className="member-secondary-button" onClick={showCostOnly}>Skip—show the cost only</button><button type="button" className="check-text-button" onClick={() => { setError(''); setStep(1); }}>← Edit offer</button></div>
        </form>
      </section>}

      {step === 3 && <section className="check-panel check-results" aria-labelledby="check-result-title"><div className="check-panel-head"><p className="eyebrow">STEP 3 OF 3 · YOUR RESULT</p><h2 id="check-result-title">Here is what the numbers show.</h2><p>{mode === 'forecast' ? 'A 30-day estimate from the dates and amounts you entered.' : 'Loan cost only. Add your income and bills for a cash-flow forecast.'}</p></div>
        <div className="check-metrics"><div><span>You receive</span><strong>{money(Number(proceeds))}</strong></div><div><span>You repay</span><strong>{money(totalRepayment)}</strong></div><div className="check-cost"><span>Cost above what you receive</span><strong>{money(cost)}</strong></div></div>
        <OfferTextReview value={offerText} />
        {cost < 0 && <p className="member-neutral">Repayment is less than the amount received. Check that every fee and payment is included.</p>}
        {mode === 'forecast' && analysis && <><div className="check-comparison"><div><span>Lowest balance without this offer</span><strong>{money(analysis.baseline.lowestBalance)}</strong><small>{friendlyDate(analysis.baseline.lowestDate)}</small></div><div className={analysis.withOffer.lowestBalance < 0 ? 'check-negative' : ''}><span>Lowest balance with this offer</span><strong>{money(analysis.withOffer.lowestBalance)}</strong><small>{friendlyDate(analysis.withOffer.lowestDate)}</small></div></div>{analysis.warning ? <div className="check-warning"><strong>This payment may leave you short.</strong><p>After {analysis.warning.triggerLabel.toLowerCase()} on {friendlyDate(analysis.warning.date)}, the estimated balance is {money(analysis.warning.balanceAfter)}. Review the repayment timing before deciding.</p></div> : <div className="member-neutral"><strong>No offer-related shortfall appeared in this estimate.</strong><p>Unentered bills or changes in income could change the result.</p></div>}</>}
        <EvidenceShieldReview alerts={evidenceAlerts} />
        {pauseAlerts.length > 0 && !reviewAcknowledged && <div className="check-shield-pause" role="alert"><strong>Pause and review before continuing.</strong><p>{pauseAlerts.length} warning {pauseAlerts.length === 1 ? 'needs' : 'need'} a closer look. Check the reasons above, then choose whether to continue.</p><button type="button" className="member-primary" onClick={() => setReviewAcknowledged(true)}>I reviewed the warnings · continue</button></div>}
        <ResearchContext />
        <div className="check-footer"><button type="button" className="member-secondary-button" onClick={() => { setReviewAcknowledged(false); setStep(1); }}>Edit the offer</button><button type="button" className="member-secondary-button" onClick={() => { setReviewAcknowledged(false); setStep(2); }}>Edit money details</button>{(pauseAlerts.length === 0 || reviewAcknowledged) && <><Link className="member-primary" href="/">Done for now</Link><Link className="member-secondary-button" href="/member" onClick={carryDraft}>Save in my member account →</Link></>}</div><p className="consent-footnote">Nothing from this check is saved to an account. The save link carries this draft in this browser so you can review and choose what to keep after signing in.</p>
      </section>}
      <aside className="check-side-note"><span aria-hidden="true">✦</span><p><strong>Your choice stays yours.</strong> Aegis shows costs and possible shortfalls. It does not apply for a loan, decide whether one is suitable, or move money.</p></aside>
    </div>
  </main>;
}
