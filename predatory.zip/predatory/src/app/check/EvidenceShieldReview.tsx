'use client';

import { useEffect, useState } from 'react';
import type { EvidenceAlert, ShieldResearch } from '@/domain/evidence-shield';

export function useShieldResearch(): ShieldResearch | null {
  const [research, setResearch] = useState<ShieldResearch | null>(null);
  useEffect(() => {
    let active = true;
    fetch('/api/research/context', { cache: 'no-store' })
      .then(response => response.ok ? response.json() as Promise<ShieldResearch> : null)
      .then(value => { if (active && value) setResearch(value); })
      .catch(() => undefined);
    return () => { active = false; };
  }, []);
  return research;
}

export default function EvidenceShieldReview({ alerts }: { alerts: EvidenceAlert[] }) {
  if (!alerts.length) return null;
  return <section className="evidence-shield-review" aria-label="Aegis shield review" aria-live="polite">
    <div className="evidence-shield-heading"><span className="eyebrow">AEGIS SHIELD · YOUR OFFER + PUBLIC RESEARCH</span><h3>What to check before you decide</h3><p>Public reports add context to these checks. Your own offer and cash-flow details trigger them.</p></div>
    <ol>{alerts.map(alert => <li key={alert.id} className={alert.pause ? 'evidence-shield-pause' : ''}>
      <div className="evidence-shield-marker" aria-hidden="true">{alert.pause ? '!' : '✓'}</div>
      <div><strong>{alert.title}</strong><p>{alert.detail}</p><p className="evidence-shield-action">Next: {alert.action}</p><small>Basis: {alert.source}{alert.sourceUrl && <> · <a href={alert.sourceUrl} target="_blank" rel="noreferrer">View source ↗</a></>}</small></div>
    </li>)}</ol>
    <p className="evidence-shield-limit">Complaint counts are self-reported, not odds that this offer is harmful. Aegis does not verify lenders or predict whether you will repay.</p>
  </section>;
}
