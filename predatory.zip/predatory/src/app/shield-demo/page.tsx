'use client';

import { FormEvent, useEffect, useMemo, useState } from 'react';
import { buildShieldDemoScenario, shiftDate } from '@/domain/shield-demo';

type DemoStage = 'ready' | 'review' | 'complete';

const usd = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' });

export default function ShieldDemoPage() {
  const [asOfDate, setAsOfDate] = useState('');
  const [startingBalance, setStartingBalance] = useState('340');
  const [stage, setStage] = useState<DemoStage>('ready');
  const [reviewed, setReviewed] = useState(false);

  useEffect(() => {
    const today = new Date();
    today.setMinutes(today.getMinutes() - today.getTimezoneOffset());
    setAsOfDate(today.toISOString().slice(0, 10));
  }, []);

  const balance = Number(startingBalance);
  const scenario = useMemo(() => asOfDate ? buildShieldDemoScenario(asOfDate, balance) : null, [asOfDate, balance]);
  const events = scenario?.events ?? [];
  const signals = scenario?.signals ?? [];
  const analysis = scenario?.analysis ?? null;
  const routes = scenario?.routes ?? [];
  const holdReasons = [
    ...(analysis?.valid && analysis.warning ? ['The second scheduled payment creates a projected shortfall in this example.'] : []),
    ...signals.map(signal => signal.title),
  ];

  function submitDemo(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!analysis?.valid) return;
    setReviewed(false);
    setStage('review');
  }

  function finishDemo() {
    if (!reviewed) return;
    setStage('complete');
  }

  function resetDemo() {
    setReviewed(false);
    setStage('ready');
  }

  return <main className="member-screen shield-demo-screen">
    <header className="member-topbar"><a className="member-brand" href="/">Aegis</a><div className="member-top-actions"><a href="/check">Check your own offer</a><a href="/member">Member workspace</a><a href="/">Home</a></div></header>
    <div className="member-content">
      <div className="member-heading">
        <p className="eyebrow">INTERACTIVE LOCAL DEMO · FICTIONAL DATA</p>
        <h1>See the pause before a short-term offer.</h1>
        <p>See the Shield with made-up transactions, income, bills, and loan terms. This sample stores nothing. Ready for your own numbers? Use the private offer check.</p><a className="member-primary" href="/check">Check my own offer →</a>
      </div>

      <section className="member-card demo-offer-card" aria-labelledby="demo-offer-title">
        <div className="member-section-heading">
          <div><p className="eyebrow">SAMPLE OFFER · FICTIONAL</p><h2 id="demo-offer-title">$500 today. Two payments of $287.50.</h2></div>
          <span className="policy-tag">30-day example</span>
        </div>
        <p className="demo-urgency">Limited-time offer · Act now to get instant approval.</p>
        <div className="example-received"><span>Amount received</span><strong>$500.00</strong></div>
        <div className="example-payment"><span>Payment 1 · {asOfDate ? formatDate(shiftDate(asOfDate, 14)) : '…'}</span><strong>$287.50</strong></div>
        <div className="example-payment"><span>Payment 2 · {asOfDate ? formatDate(shiftDate(asOfDate, 28)) : '…'}</span><strong>$287.50</strong></div>
        <div className="example-total"><span>Total repayment</span><strong>$575.00</strong></div>
        <div className="example-cost"><span>Cost above the amount received</span><strong>$75.00</strong></div>
        <p className="example-caveat">Aegis shows the arithmetic and dates. These signals do not determine whether a real offer is predatory, legal, or right for you.</p>

        <div className="demo-scenario-inputs">
          <label className="member-field"><span>Fictional starting balance</span><span className="demo-balance-input"><span>$</span><input type="number" min="0" max="1000000" step="1" value={startingBalance} onChange={event => { setStartingBalance(event.target.value); resetDemo(); }} /></span></label>
          <p>Change the balance to see how it affects the cash-flow forecast. All dates are relative to today.</p>
        </div>

        {asOfDate && <div className="demo-event-list" aria-label="Fictional upcoming cash-flow events">
          <div className="member-list-heading"><strong>Upcoming fictional income and bills</strong><span>Next 30 days</span></div>
          {events.map(event => <div className="demo-event-row" key={`${event.date}-${event.label}`}><span>{formatDate(event.date)} · {event.label}</span><strong className={event.kind === 'income' ? 'demo-income' : ''}>{event.amount < 0 ? '−' : '+'}{usd.format(Math.abs(event.amount))}</strong></div>)}
        </div>}

        {stage === 'ready' && <form onSubmit={submitDemo}><button type="submit" className="member-primary" disabled={!asOfDate || !analysis?.valid}>Apply now · local demo button</button><p className="consent-footnote">This button only opens the review step. No application is sent.</p></form>}

        {stage === 'review' && <section className="member-card member-shield-hold" aria-labelledby="demo-review-title" role="alert">
          <p className="eyebrow">AEGIS PAUSED THE DEMO</p>
          <h3 id="demo-review-title">Review the signals before you continue.</h3>
          <p>This is a fictional cash-flow forecast using the sample starting balance and dates shown above.</p>
          {analysis?.valid && <div className="demo-forecast-pair">
            <div><span>Lowest balance without this offer</span><strong>{usd.format(analysis.baseline.lowestBalance)}</strong><small>{formatDate(analysis.baseline.lowestDate)}</small></div>
            <div><span>Lowest balance with this offer</span><strong>{usd.format(analysis.withOffer.lowestBalance)}</strong><small>{formatDate(analysis.withOffer.lowestDate)}</small></div>
          </div>}
          {holdReasons.length > 0 ? <ul>{holdReasons.map(reason => <li key={reason}>{reason}</li>)}</ul> : <p>No rule triggered a warning for these fictional inputs. Review the repayment dates and total cost before proceeding.</p>}
          <div className="demo-signal-list"><strong>Sample transaction matches</strong>
            {signals.length ? <ul>{signals.map(signal => <li key={signal.id}>{signal.title} · {signal.evidenceCount} fictional descriptions</li>)}</ul> : <p>No sample patterns matched.</p>}
          </div>
          <label className="demo-review-check"><input type="checkbox" checked={reviewed} onChange={event => setReviewed(event.target.checked)} /><span>I reviewed the amount, repayment dates, and sample cash-flow warning.</span></label>
          <div className="member-action-buttons"><button type="button" className="member-primary" disabled={!reviewed} onClick={finishDemo}>I reviewed this · finish demo</button><button type="button" className="member-secondary-button" onClick={resetDemo}>Edit scenario</button></div>
        </section>}

        {stage === 'complete' && <div className="member-status" role="status"><strong>Demo complete.</strong> No loan application was sent, and no information was stored.<div><button type="button" className="member-secondary-button" onClick={resetDemo}>Run the example again</button></div></div>}
      </section>

      <section className="member-card micro-route-preview" aria-labelledby="demo-routing-title">
        <div className="micro-route-heading"><span aria-hidden="true">↗</span><div><strong id="demo-routing-title">Virtual payday routing</strong><p>Preview a bills reserve from the same fictional income and bill schedule.</p></div></div>
        {routes.length ? <ul>{routes.map(route => <li key={route.payday}><span>Income · {formatDate(route.payday)}</span><strong>{usd.format(route.billsReserve)} → Bills reserve</strong><span>{usd.format(route.remaining)} → Remaining</span><small>{route.billCount} upcoming bill{route.billCount === 1 ? '' : 's'} in this interval · preview only</small></li>)}</ul> : <p>Preparing the fictional scenario…</p>}
        <p className="consent-footnote">This allocation uses fictional events. It does not connect to a bank or move money.</p>
      </section>

      <section className="member-card shield-signals" aria-labelledby="demo-patterns-title">
        <div className="shield-signals-heading"><span aria-hidden="true">◈</span><div><strong id="demo-patterns-title">Transaction pattern example</strong><p>Simple description matches from fictional local data</p></div></div>
        {signals.length ? <ul>{signals.map(signal => <li key={signal.id}><div><strong>{signal.title}</strong><p>{signal.summary}</p><small>{signal.evidenceCount} sample descriptions · latest {formatDate(signal.mostRecentDate)}</small></div></li>)}</ul> : <p className="shield-clear">Preparing the fictional transaction example…</p>}
        <p className="consent-footnote">These are transparent keyword matches, not inferred intent or a psychological profile.</p>
      </section>

      <footer className="member-footer"><a href="/">Back to Aegis</a> · <a href="/check">Check an offer</a> · <a href="/member">Member workspace</a> · <a href="/lab">Research lab</a></footer>
    </div>
  </main>;
}

function formatDate(value: string): string {
  if (!value) return '…';
  return new Intl.DateTimeFormat('en-US', { month: 'short', day: 'numeric', timeZone: 'UTC' })
    .format(new Date(`${value}T12:00:00Z`));
}
