'use client';

import { useEffect, useMemo, useState } from 'react';

type Tenant = { id: string; name: string; slug: string };
type Summary = { report_month: string; participating_members: number | string; saved_checks: number | string };

export default function PartnerPage() {
  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [tenantId, setTenantId] = useState('');
  const [summaries, setSummaries] = useState<Summary[]>([]);
  const [loading, setLoading] = useState(true);
  const [signedOut, setSignedOut] = useState(false);
  const [unauthorized, setUnauthorized] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    fetch('/api/partner/tenants').then(async response => {
      if (response.status === 401) { setSignedOut(true); return; }
      if (!response.ok) throw new Error('Could not load partner organizations.');
      const body = await response.json() as { tenants: Tenant[] };
      setTenants(body.tenants);
      if (body.tenants[0]) setTenantId(body.tenants[0].id);
    }).catch(() => setError('Partner access could not be loaded. Try again later.'))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    if (!tenantId) return;
    fetch('/api/partner/reports', { headers: { 'x-aegis-tenant-id': tenantId } }).then(async response => {
      const body = await response.json();
      if (response.status === 403) { setUnauthorized(true); return; }
      if (!response.ok) throw new Error(body.error ?? 'Could not load the report.');
      setUnauthorized(false);
      setSummaries(body.summaries);
    }).catch(() => setError('The aggregate report could not be loaded. Try again later.'));
  }, [tenantId]);

  const chartMaximum = useMemo(() => Math.max(1, ...summaries.map(row => Number(row.saved_checks))), [summaries]);
  const totalMembers = summaries.reduce((total, row) => total + Number(row.participating_members), 0);
  const totalChecks = summaries.reduce((total, row) => total + Number(row.saved_checks), 0);

  if (loading) return <main className="partner-screen"><p className="member-loading">Loading partner workspace…</p></main>;
  if (signedOut) return <main className="member-screen"><section className="member-card member-gate"><span className="member-mark">A</span><p className="eyebrow">CREDIT UNION STAFF ONLY</p><h1>Partner reporting.</h1><p>Sign in with an active staff account to view privacy-protected usage totals. Consumers can check an offer without this access.</p><a className="member-primary" href="/login?workspace=partner">Staff sign in</a><a className="member-secondary-link" href="/check">Go to consumer offer check →</a></section></main>;
  if (!tenants.length) return <main className="member-screen"><section className="member-card member-gate"><span className="member-mark">A</span><p className="eyebrow">PARTNER ACCESS</p><h1>No staff workspace yet.</h1><p>This account does not have an active partner reporting role.</p><a className="member-secondary-link" href="/api/auth/logout">Sign out</a></section></main>;

  return <main className="partner-screen">
    <header className="member-topbar"><a className="member-brand" href="/">Aegis · Partner</a><div className="member-top-actions"><a href="/check">Consumer check</a><label htmlFor="partner-tenant">Organization</label><select id="partner-tenant" value={tenantId} onChange={event => setTenantId(event.target.value)}>{tenants.map(tenant => <option value={tenant.id} key={tenant.id}>{tenant.name}</option>)}</select><a href="/api/auth/logout">Sign out</a></div></header>
    <div className="partner-content">
      <div className="member-heading"><div><p className="eyebrow">CREDIT UNION REPORTING</p><h1>Member engagement, in aggregate.</h1><p>Monthly counts for members who saved an offer comparison. This workspace cannot view individual member activity or financial details.</p></div><span className="member-private-tag">Cohort minimum: 20</span></div>
      {error && <p className="member-alert" role="alert">{error}</p>}
      {unauthorized ? <section className="member-card partner-empty"><h2>Partner role required.</h2><p>Your account does not have an active partner reporting role for this organization.</p></section> : <>
        <div className="partner-stat-grid"><article className="member-card"><span>Member-months shown</span><strong>{totalMembers.toLocaleString('en-US')}</strong><small>each month has at least 20 participating members</small></article><article className="member-card"><span>Saved offer comparisons</span><strong>{totalChecks.toLocaleString('en-US')}</strong><small>for the months shown below</small></article><article className="member-card"><span>Privacy threshold</span><strong>20+</strong><small>smaller monthly cohorts are suppressed</small></article></div>
        <section className="member-card partner-report-card"><div className="member-section-heading"><div><p className="eyebrow">MONTHLY ACTIVITY</p><h2>Saved comparisons by month</h2><p>Only organization-level totals are returned by the reporting service.</p></div></div>
          {summaries.length ? <><div className="partner-chart" role="img" aria-label="Bar chart of saved offer comparisons by month">{[...summaries].reverse().map(row => {
            const count = Number(row.saved_checks);
            const width = Math.max(3, count / chartMaximum * 100);
            return <div className="partner-bar-row" key={row.report_month}><span>{new Date(`${row.report_month}T00:00:00Z`).toLocaleDateString('en-US', { month: 'short', year: 'numeric', timeZone: 'UTC' })}</span><div className="partner-bar-track"><div className="partner-bar" style={{ width: `${width}%` }} /></div><strong>{count}</strong></div>;
          })}</div>
          <div className="partner-table-wrap"><table className="partner-table"><thead><tr><th>Month</th><th>Participating members</th><th>Saved comparisons</th></tr></thead><tbody>{summaries.map(row => <tr key={row.report_month}><th scope="row">{new Date(`${row.report_month}T00:00:00Z`).toLocaleDateString('en-US', { month: 'long', year: 'numeric', timeZone: 'UTC' })}</th><td>{Number(row.participating_members).toLocaleString('en-US')}</td><td>{Number(row.saved_checks).toLocaleString('en-US')}</td></tr>)}</tbody></table></div></> : <div className="partner-empty-state"><strong>No reportable month yet.</strong><p>A month appears only after at least 20 distinct members have saved a comparison. Smaller groups are not displayed.</p></div>}
        </section>
        <p className="partner-privacy-note">This report excludes member names, balances, transactions, loan terms, and individual timelines. Do not use this aggregate to make eligibility or lending decisions.</p>
      </>}
      <footer className="member-footer"><span>Aegis · Aggregate partner reporting</span><a href="/check">Consumer offer check</a></footer>
    </div>
  </main>;
}
