import { startRetentionScheduler } from './server/retention-scheduler';

export function startNodeRuntime() {
  if (!process.env.DATABASE_URL) return;
  startRetentionScheduler();
}
