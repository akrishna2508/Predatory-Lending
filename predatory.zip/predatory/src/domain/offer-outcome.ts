export const MEMBER_OFFER_OUTCOMES = ['accepted', 'declined', 'changed_terms', 'still_deciding'] as const;
export type MemberOfferOutcome = (typeof MEMBER_OFFER_OUTCOMES)[number];
export type OutcomeConsent = { purpose: string; action: string };

export function hasMemberOfferOutcomeConsent(states: OutcomeConsent[]): boolean {
  const latest = new Map(states.map(state => [state.purpose, state.action]));
  return latest.get('manual_financial_profile') === 'granted'
    && latest.get('offer_check_storage') === 'granted'
    && latest.get('offer_outcome_reporting') === 'granted';
}

export function parseMemberOfferOutcome(value: unknown):
  | { valid: true; outcome: MemberOfferOutcome }
  | { valid: false } {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) return { valid: false };
  const payload = value as Record<string, unknown>;
  if (Object.keys(payload).length !== 1 || !MEMBER_OFFER_OUTCOMES.includes(payload.outcome as MemberOfferOutcome)) {
    return { valid: false };
  }
  return { valid: true, outcome: payload.outcome as MemberOfferOutcome };
}
