import { analyzeLoanOfferText } from './loan-offer-signals';

export type ShieldResearch = {
  baseline?: null | { totalRows: number; coefficients?: { debtToIncome?: number } };
  complaints?: null | { rowsUsed: number; topIssues: Array<{ name: string; count: number }> };
  archivedLoanComplaints?: null | {
    rowsUsed: number;
    narrativesWithText: number;
    signals: { feePressure: number; paymentDifficulty: number; cashShortfall: number };
    sourceUrl: string;
  };
};

export type EvidenceAlert = {
  id: 'upfront-payment' | 'missing-terms' | 'fee-review' | 'payment-shortfall' | 'debt-bills';
  title: string;
  detail: string;
  action: string;
  pause: boolean;
  source: string;
  sourceUrl?: string;
  priority: number;
};

type Inputs = {
  dollarCost: number;
  shortfall: boolean;
  offerText: string;
  hasDebtBills: boolean;
};

const CFPB_ARCHIVE = 'https://www.consumerfinance.gov/foia-requests/foia-electronic-reading-room/cfpb-consumer-complaint-database-narratives-archive/';
const CFPB_COMPLAINTS = 'https://www.consumerfinance.gov/data-research/consumer-complaints/';

/**
 * Public reports add context to review prompts; only the person's entered facts
 * trigger an alert. Complaint counts never become a personal risk score.
 */
export function assessEvidenceShield(input: Inputs, research: ShieldResearch | null): EvidenceAlert[] {
  const textSignals = analyzeLoanOfferText(input.offerText);
  const feeIssue = research?.complaints?.topIssues?.find(item => /fees? or interest|fees? you didn/i.test(item.name));
  const paymentIssue = research?.complaints?.topIssues?.find(item => /making payments|struggling to pay/i.test(item.name));
  const complaintRows = research?.complaints?.rowsUsed ?? 0;
  const feePriority = feeIssue && complaintRows > 0 ? feeIssue.count / complaintRows : 0;
  const paymentPriority = paymentIssue && complaintRows > 0 ? paymentIssue.count / complaintRows : 0;
  const narrative = research?.archivedLoanComplaints;
  const alerts: EvidenceAlert[] = [];

  if (textSignals.some(signal => signal.id === 'pay_to_release' && signal.kind === 'high-concern')) {
    alerts.push({
      id: 'upfront-payment', title: 'Pause before paying a fee to receive loan funds',
      detail: 'The wording you pasted asks for money before funds are released. This is a specific warning sign, not a verified finding about the lender.',
      action: 'Do not send money until you verify the lender and the written terms independently.',
      pause: true, source: 'FTC advance-fee loan guidance',
      sourceUrl: 'https://consumer.ftc.gov/articles/what-know-about-advance-fee-loans', priority: 1,
    });
  }

  if (input.shortfall) {
    alerts.push({
      id: 'payment-shortfall', title: 'A payment may leave you short',
      detail: paymentIssue
        ? `Your entered cash flow shows a shortfall. Payment problems appeared in ${paymentIssue.count.toLocaleString('en-US')} of ${complaintRows.toLocaleString('en-US')} CFPB payday-product complaints in this local report.`
        : 'Your entered cash flow shows a shortfall after a scheduled payment.',
      action: 'Review the due date against your paydays and essential bills before deciding.',
      pause: true, source: paymentIssue ? 'CFPB complaint issue counts + your cash-flow dates' : 'Your cash-flow dates',
      sourceUrl: paymentIssue ? CFPB_COMPLAINTS : undefined, priority: 2 - paymentPriority,
    });
  }

  const pastedText = input.offerText.trim().length > 0;
  if (pastedText && textSignals.some(signal => signal.id === 'missing_total_repayment')) {
    alerts.push({
      id: 'missing-terms', title: 'Total repayment was not found in the pasted wording',
      detail: feeIssue
        ? `Unexpected fees or interest were reported in ${feeIssue.count.toLocaleString('en-US')} of ${complaintRows.toLocaleString('en-US')} CFPB payday-product complaints. Your excerpt may be incomplete; this does not mean the lender hid a fee.`
        : 'Your excerpt may be incomplete; this does not mean the lender hid a fee.',
      action: 'Check the full written agreement against every payment and fee you entered.',
      pause: true, source: feeIssue ? 'CFPB complaint issue counts + your pasted offer wording' : 'Your pasted offer wording',
      sourceUrl: feeIssue ? CFPB_COMPLAINTS : undefined, priority: 3 - feePriority,
    });
  }

  if (input.dollarCost > 0 && narrative && narrative.narrativesWithText > 0) {
    alerts.push({
      id: 'fee-review', title: 'Check the full cost above the cash you receive',
      detail: `Your entered payments exceed the cash received by $${input.dollarCost.toFixed(2)}. Fee or interest wording appeared in ${narrative.signals.feePressure.toLocaleString('en-US')} of ${narrative.narrativesWithText.toLocaleString('en-US')} published lending complaint narratives reviewed locally.`,
      action: 'Confirm the APR, every fee, and total repayment in the written offer.',
      pause: false, source: 'Archived CFPB narrative phrase counts + your offer amounts',
      sourceUrl: narrative.sourceUrl || CFPB_ARCHIVE, priority: 4 - feePriority,
    });
  }

  if (!input.hasDebtBills && (research?.baseline?.coefficients?.debtToIncome ?? 0) > 0) {
    alerts.push({
      id: 'debt-bills', title: 'Add other debt payments for a fuller check',
      detail: 'The historical LendingClub benchmark found a positive association between debt-to-income and adverse repayment. Aegis cannot calculate your debt-to-income from this offer alone.',
      action: 'If you have other loan or card payments, add them as bills before relying on the cash-flow preview.',
      pause: false, source: `LendingClub historical benchmark (${research?.baseline?.totalRows?.toLocaleString('en-US') ?? 'local'} records)`,
      priority: 5,
    });
  }

  return alerts.sort((a, b) => a.priority - b.priority);
}
