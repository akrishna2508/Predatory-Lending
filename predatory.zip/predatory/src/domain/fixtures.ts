import type { CashEvent, OfferInput } from './finance';

export const syntheticStartingBalance = 840;
export const syntheticEvents: CashEvent[] = [
  { id: 'power', date: '2026-09-28', label: 'Electric bill', amount: -128, kind: 'bill' },
  { id: 'rent', date: '2026-10-01', label: 'Rent', amount: -760, kind: 'bill' },
  { id: 'paycheck', date: '2026-10-06', label: 'Paycheck', amount: 1240, kind: 'income' },
  { id: 'phone', date: '2026-10-09', label: 'Phone bill', amount: -72, kind: 'bill' },
  { id: 'insurance', date: '2026-10-15', label: 'Car insurance', amount: -164, kind: 'bill' },
  { id: 'paycheck-2', date: '2026-10-20', label: 'Paycheck', amount: 1240, kind: 'income' },
  { id: 'groceries', date: '2026-10-24', label: 'Groceries', amount: -185, kind: 'bill' },
];

export const exampleOffer: OfferInput = {
  asOfDate: '2026-09-25',
  startingBalance: syntheticStartingBalance,
  events: syntheticEvents,
  proceeds: 200,
  receivedOn: '2026-09-25',
  payments: [
    { date: '2026-10-02', amount: 250 },
    { date: '2026-10-16', amount: 215 },
  ],
};
