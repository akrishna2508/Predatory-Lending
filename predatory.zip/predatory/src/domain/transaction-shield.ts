export type ShieldTransaction = {
  amount: number;
  date: string;
  description: string;
};

export type ShieldSignal = {
  id: 'short_term_credit' | 'financial_fees' | 'variable_income';
  title: string;
  evidenceCount: number;
  mostRecentDate: string;
  summary: string;
};

const SHORT_TERM_CREDIT = /\b(payday loan|title loan|cash advance|installment loan|short term loan|short term credit|tribal lending)\b/i;
const FINANCIAL_FEE = /\b(overdraft|nsf|non sufficient funds|insufficient funds|returned payment|return item|late fee|late charge|past due fee)\b/i;
const INCOME_LIKE = /\b(payroll|salary|wages|gig income|direct deposit|doordash|instacart|uber earnings|lyft earnings)\b/i;
const DAY_MS = 86_400_000;

/**
 * Descriptive transaction matching only. It does not estimate intent, psychology,
 * creditworthiness, or whether an offer is predatory. Matches need member review.
 */
export function findShieldSignals(transactions: ShieldTransaction[], asOfDate: string): ShieldSignal[] {
  const asOf = dayNumber(asOfDate);
  if (asOf === null || !Array.isArray(transactions)) return [];
  const evidence = { short_term_credit: [] as string[], financial_fees: [] as string[] };
  const incomeLikeDeposits: Array<{ date: string; amount: number }> = [];
  for (const row of transactions.slice(0, 5_000)) {
    if (!row || typeof row.description !== 'string' || !Number.isFinite(row.amount) || row.amount === 0) continue;
    const date = dayNumber(row.date);
    if (date === null || date > asOf || asOf - date > 183) continue;
    if (SHORT_TERM_CREDIT.test(row.description)) evidence.short_term_credit.push(row.date);
    if (FINANCIAL_FEE.test(row.description)) evidence.financial_fees.push(row.date);
    if (row.amount > 0 && asOf - date <= 90 && INCOME_LIKE.test(row.description)) {
      incomeLikeDeposits.push({ date: row.date, amount: row.amount });
    }
  }
  const signals: ShieldSignal[] = [];
  if (evidence.short_term_credit.length >= 2) {
    signals.push({
      id: 'short_term_credit',
      title: 'Possible repeated short-term credit activity',
      evidenceCount: evidence.short_term_credit.length,
      mostRecentDate: evidence.short_term_credit.sort().at(-1)!,
      summary: 'Descriptions in your imported history matched common loan or cash-advance terms more than once. A merchant label can be wrong; check the transactions and your new payment dates.',
    });
  }
  if (evidence.financial_fees.length >= 2) {
    signals.push({
      id: 'financial_fees',
      title: 'Repeated fee descriptions in recent history',
      evidenceCount: evidence.financial_fees.length,
      mostRecentDate: evidence.financial_fees.sort().at(-1)!,
      summary: 'Your imported descriptions matched common overdraft, returned-payment, or late-fee terms more than once. This is a record of labels, not a judgment about why they occurred.',
    });
  }
  const distinctIncomeDates = [...new Map(incomeLikeDeposits.map(item => [item.date, item])).values()];
  if (distinctIncomeDates.length >= 3) {
    const amounts = distinctIncomeDates.map(item => item.amount);
    const lowest = Math.min(...amounts);
    const highest = Math.max(...amounts);
    const dates = distinctIncomeDates.map(item => item.date).sort();
    if (highest - lowest >= 100 && lowest <= highest * 0.6
      && (dayNumber(dates.at(-1)!)! - dayNumber(dates[0])!) >= 14) {
      signals.push({
        id: 'variable_income',
        title: 'Income-like deposits varied in recent history',
        evidenceCount: distinctIncomeDates.length,
        mostRecentDate: dates.at(-1)!,
        summary: 'Amounts on descriptions such as payroll or gig income varied across recent dates. Check your next expected payday amount before counting on it for a loan payment; transaction labels may be incomplete.',
      });
    }
  }
  return signals;
}

export type RoutingInput = { date: string; label: string; amount: number; kind: 'income' | 'bill' };
export type MicroRoute = { payday: string; income: number; billsReserve: number; remaining: number; billCount: number };

/**
 * Makes a virtual allocation preview from items the member entered or confirmed.
 * It never initiates a transfer or claims a bank balance is available.
 */
export function previewMicroRoutes(events: RoutingInput[], asOfDate: string): MicroRoute[] {
  const asOf = dayNumber(asOfDate);
  if (asOf === null || !Array.isArray(events)) return [];
  const normalized = events.filter(event => event && dayNumber(event.date) !== null
    && dayNumber(event.date)! >= asOf && dayNumber(event.date)! < asOf + 30
    && Number.isFinite(event.amount) && event.amount > 0)
    .map(event => ({ ...event, day: dayNumber(event.date)! }))
    .sort((a, b) => a.day - b.day || a.date.localeCompare(b.date));
  const incomes = normalized.filter(event => event.kind === 'income');
  return incomes.map((income, index) => {
    const nextPayday = incomes[index + 1]?.day ?? asOf + 30;
    const bills = normalized.filter(event => event.kind === 'bill'
      && event.day >= income.day && event.day < nextPayday);
    const billsTotal = bills.reduce((sum, bill) => sum + bill.amount, 0);
    const reserved = Math.min(income.amount, billsTotal);
    return {
      payday: income.date,
      income: roundCents(income.amount),
      billsReserve: roundCents(reserved),
      remaining: roundCents(Math.max(0, income.amount - reserved)),
      billCount: bills.length,
    };
  });
}

function dayNumber(value: string): number | null {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return null;
  const [year, month, day] = value.split('-').map(Number);
  const timestamp = Date.UTC(year, month - 1, day);
  const parsed = new Date(timestamp);
  return parsed.getUTCFullYear() === year && parsed.getUTCMonth() === month - 1 && parsed.getUTCDate() === day
    ? timestamp / DAY_MS : null;
}

function roundCents(value: number): number { return Math.round(value * 100) / 100; }
