export type NormalizedProviderTransaction = {
  transactionId: string;
  accountId: string;
  amount: number;
  date: string;
  authorizedDate: string | null;
  name: string;
  merchantName: string | null;
  pending: boolean;
  pendingTransactionId: string | null;
  categories: string[];
};

export type TransactionChange =
  | { kind: 'added' | 'modified'; transaction: NormalizedProviderTransaction }
  | { kind: 'removed'; transactionId: string };

export type TransactionSyncPage = {
  added: NormalizedProviderTransaction[];
  modified: NormalizedProviderTransaction[];
  removed: Array<{ transactionId: string }>;
  hasMore: boolean;
  nextCursor: string;
};

const MAX_SYNC_PAGES = 100;

/**
 * Fetch a complete provider cursor update before returning any changes. The caller
 * can then apply all mutations and persist the final cursor in one DB transaction.
 * If any page fails, reject the whole batch so the worker retries from its original cursor.
 */
export async function collectTransactionUpdates(
  fetchPage: (cursor: string | null) => Promise<TransactionSyncPage>,
  initialCursor: string | null,
): Promise<{ changes: TransactionChange[]; nextCursor: string }> {
  const seenCursors = new Set<string>();
  if (initialCursor !== null) seenCursors.add(initialCursor);
  const changes: TransactionChange[] = [];
  let cursor = initialCursor;

  for (let pageNumber = 0; pageNumber < MAX_SYNC_PAGES; pageNumber++) {
    const page = await fetchPage(cursor);
    if (!page || !Array.isArray(page.added) || !Array.isArray(page.modified) || !Array.isArray(page.removed)
      || typeof page.hasMore !== 'boolean' || typeof page.nextCursor !== 'string') {
      throw new Error('Provider returned an invalid transaction sync page');
    }

    for (const transaction of page.added) changes.push({ kind: 'added', transaction });
    for (const transaction of page.modified) changes.push({ kind: 'modified', transaction });
    for (const transaction of page.removed) changes.push({ kind: 'removed', transactionId: transaction.transactionId });

    if (!page.hasMore) return { changes, nextCursor: page.nextCursor };
    if (!page.nextCursor || page.nextCursor === cursor || seenCursors.has(page.nextCursor)) {
      throw new Error('Provider did not advance its cursor');
    }
    seenCursors.add(page.nextCursor);
    cursor = page.nextCursor;
  }
  throw new Error('Provider exceeded the transaction sync page limit');
}

/** Accept only bounded, well-formed values from a bank-data provider before persistence. */
export function normalizeProviderTransaction(value: unknown): NormalizedProviderTransaction | null {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
  const transaction = value as Record<string, unknown>;
  const transactionId = boundedText(transaction.transactionId, 200);
  const accountId = boundedText(transaction.accountId, 200);
  const name = boundedText(transaction.name, 200);
  const date = validDate(transaction.date);
  const authorizedDate = transaction.authorizedDate === null || transaction.authorizedDate === undefined
    ? null
    : validDate(transaction.authorizedDate);
  const merchantName = transaction.merchantName === null || transaction.merchantName === undefined
    ? null
    : boundedText(transaction.merchantName, 200);
  const pendingTransactionId = transaction.pendingTransactionId === null || transaction.pendingTransactionId === undefined
    ? null
    : boundedText(transaction.pendingTransactionId, 200);
  const categories = Array.isArray(transaction.categories)
    ? transaction.categories.slice(0, 10).map(category => boundedText(category, 100))
    : null;
  const normalizedCategories = categories?.filter((category): category is string => category !== null) ?? null;

  if (!transactionId || !accountId || !name || !date
    || (transaction.authorizedDate !== null && transaction.authorizedDate !== undefined && !authorizedDate)
    || (transaction.merchantName !== null && transaction.merchantName !== undefined && !merchantName)
    || (transaction.pendingTransactionId !== null && transaction.pendingTransactionId !== undefined && !pendingTransactionId)
    || !Number.isFinite(transaction.amount) || Math.abs(transaction.amount as number) > 1_000_000_000
    || typeof transaction.pending !== 'boolean' || !categories || !normalizedCategories || normalizedCategories.length !== categories.length) {
    return null;
  }

  return {
    transactionId,
    accountId,
    amount: Math.round((transaction.amount as number) * 100) / 100,
    date,
    authorizedDate,
    name,
    merchantName,
    pending: transaction.pending,
    pendingTransactionId,
    categories: normalizedCategories,
  };
}

function boundedText(value: unknown, maxLength: number): string | null {
  if (typeof value !== 'string') return null;
  const text = value.trim();
  return text.length > 0 && text.length <= maxLength ? text : null;
}

function validDate(value: unknown): string | null {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return null;
  const [year, month, day] = value.split('-').map(Number);
  const date = new Date(Date.UTC(year, month - 1, day));
  return date.getUTCFullYear() === year && date.getUTCMonth() === month - 1 && date.getUTCDate() === day ? value : null;
}
