import { analyzeOffer } from './finance';
import { findShieldSignals, previewMicroRoutes, type ShieldTransaction } from './transaction-shield';

export type ShieldDemoEvent = { date: string; label: string; amount: number; kind: 'income' | 'bill' };

/** Build a fictional, browser-local scenario that exercises the member shield calculations. */
export function buildShieldDemoScenario(asOfDate: string, startingBalance: number) {
  const events: ShieldDemoEvent[] = [
    { date: shiftDate(asOfDate, 2), label: 'Rent', amount: -300, kind: 'bill' },
    { date: shiftDate(asOfDate, 7), label: 'Gig income', amount: 300, kind: 'income' },
    { date: shiftDate(asOfDate, 10), label: 'Utilities', amount: -220, kind: 'bill' },
    { date: shiftDate(asOfDate, 16), label: 'Essential bill', amount: -100, kind: 'bill' },
    { date: shiftDate(asOfDate, 21), label: 'Gig income', amount: 40, kind: 'income' },
  ];
  const transactions: ShieldTransaction[] = [
    { date: shiftDate(asOfDate, -35), description: 'Payday loan payment', amount: -88 },
    { date: shiftDate(asOfDate, -21), description: 'Payday loan payment', amount: -88 },
    { date: shiftDate(asOfDate, -7), description: 'Payday loan payment', amount: -88 },
    { date: shiftDate(asOfDate, -30), description: 'Overdraft fee', amount: -34 },
    { date: shiftDate(asOfDate, -14), description: 'Overdraft fee', amount: -34 },
  ];
  const cashEvents = events.map((event, index) => ({ id: `sample-${index}`, ...event }));
  const analysis = analyzeOffer({
    asOfDate,
    startingBalance,
    events: cashEvents,
    proceeds: 500,
    receivedOn: asOfDate,
    payments: [
      { date: shiftDate(asOfDate, 14), amount: 287.5 },
      { date: shiftDate(asOfDate, 28), amount: 287.5 },
    ],
  });
  const routes = previewMicroRoutes(events.map(event => ({
    date: event.date,
    label: event.label,
    amount: Math.abs(event.amount),
    kind: event.kind,
  })), asOfDate);

  return { events, transactions, analysis, signals: findShieldSignals(transactions, asOfDate), routes };
}

export function shiftDate(isoDate: string, days: number): string {
  const [year, month, day] = isoDate.split('-').map(Number);
  return new Date(Date.UTC(year, month - 1, day + days)).toISOString().slice(0, 10);
}
