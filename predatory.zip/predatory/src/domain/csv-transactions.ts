export type ImportedTransaction = { date: string; description: string; amount: number };
export type ParsedTransactionCsv = { transactions: ImportedTransaction[]; skippedRows: number };

export class TransactionCsvError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'TransactionCsvError';
  }
}

const DEFAULT_MAX_BYTES = 1_000_000;
const DEFAULT_MAX_ROWS = 5_000;

/** Parse common bank CSV exports without retaining account numbers or provider credentials. */
export function parseTransactionCsv(
  input: string,
  options: { maxBytes?: number; maxRows?: number } = {},
): ParsedTransactionCsv {
  const maxBytes = options.maxBytes ?? DEFAULT_MAX_BYTES;
  const maxRows = options.maxRows ?? DEFAULT_MAX_ROWS;
  if (Buffer.byteLength(input, 'utf8') > maxBytes) throw new TransactionCsvError('The CSV file is larger than the 1 MB limit.');
  if (!input.trim()) throw new TransactionCsvError('Choose a CSV file with transaction rows.');

  const rows = readRows(input);
  const nonempty = rows.filter(row => row.some(value => value.trim() !== ''));
  if (nonempty.length < 2) throw new TransactionCsvError('The CSV needs a header row and at least one transaction.');
  if (nonempty.length - 1 > maxRows) throw new TransactionCsvError(`The CSV exceeds the ${maxRows} transaction row limit.`);
  const headers = nonempty[0].map(normalizeHeader);
  const dateIndex = findColumn(headers, ['date', 'transactiondate', 'postingdate', 'posteddate', 'clearingdate']);
  const descriptionIndex = findColumn(headers, ['description', 'transactiondescription', 'name', 'payee', 'details', 'merchant']);
  const amountIndex = findColumn(headers, ['amount', 'transactionamount', 'value']);
  const debitIndex = findColumn(headers, ['debit', 'withdrawal', 'withdrawals', 'moneyout']);
  const creditIndex = findColumn(headers, ['credit', 'deposit', 'deposits', 'moneyin']);

  if (dateIndex < 0 || descriptionIndex < 0 || (amountIndex < 0 && (debitIndex < 0 || creditIndex < 0))) {
    throw new TransactionCsvError('Include Date, Description, and Amount columns, or Date, Description, Debit, and Credit columns.');
  }
  if (amountIndex >= 0 && (debitIndex >= 0 || creditIndex >= 0)) {
    throw new TransactionCsvError('Use either Amount or Debit and Credit columns, not both formats.');
  }

  let skippedRows = 0;
  const transactions: ImportedTransaction[] = [];
  for (let rowIndex = 1; rowIndex < nonempty.length; rowIndex += 1) {
    const row = nonempty[rowIndex];
    const dateText = cell(row, dateIndex);
    const description = cell(row, descriptionIndex).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '').trim();
    const debitText = debitIndex >= 0 ? cell(row, debitIndex) : '';
    const creditText = creditIndex >= 0 ? cell(row, creditIndex) : '';
    if (!dateText && !description && !(amountIndex >= 0 ? cell(row, amountIndex) : debitText || creditText)) {
      skippedRows += 1;
      continue;
    }
    const date = parseDate(dateText);
    if (!date) throw new TransactionCsvError(`Row ${rowIndex + 1} has an invalid transaction date.`);
    if (!description || description.length > 200 || /^[=@]/.test(description)) {
      throw new TransactionCsvError(`Row ${rowIndex + 1} has an invalid transaction description.`);
    }
    const amount = amountIndex >= 0
      ? parseAmount(cell(row, amountIndex))
      : parseAmount(debitText) * -1 + parseAmount(creditText);
    if (!Number.isFinite(amount) || amount === 0 || Math.abs(amount) > 1_000_000_000 || Math.round(amount * 100) !== amount * 100) {
      throw new TransactionCsvError(`Row ${rowIndex + 1} has an invalid transaction amount.`);
    }
    transactions.push({ date, description, amount: Math.round(amount * 100) / 100 });
  }
  if (!transactions.length) throw new TransactionCsvError('The CSV contains no valid transaction rows.');
  return { transactions, skippedRows };
}

function readRows(input: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let field = '';
  let quoted = false;
  let closedQuote = false;
  for (let i = 0; i < input.length; i += 1) {
    const char = input[i];
    if (quoted) {
      if (char === '"' && input[i + 1] === '"') { field += '"'; i += 1; }
      else if (char === '"') { quoted = false; closedQuote = true; }
      else field += char;
      continue;
    }
    if (char === '"') {
      if (field.length || closedQuote) throw new TransactionCsvError('The CSV contains a misplaced quote.');
      quoted = true;
    } else if (char === ',') {
      row.push(field); field = ''; closedQuote = false;
    } else if (char === '\n' || char === '\r') {
      row.push(field); rows.push(row); row = []; field = ''; closedQuote = false;
      if (char === '\r' && input[i + 1] === '\n') i += 1;
    } else {
      if (closedQuote && !/\s/.test(char)) throw new TransactionCsvError('The CSV contains text after a quoted value.');
      if (!closedQuote) field += char;
    }
  }
  if (quoted) throw new TransactionCsvError('The CSV contains an unclosed quoted value.');
  if (field.length || row.length) { row.push(field); rows.push(row); }
  if (!rows.length || rows.some(value => value.length > 64)) throw new TransactionCsvError('The CSV has an invalid number of columns.');
  const width = rows[0]?.length ?? 0;
  if (!width || rows.some(value => value.length !== width)) throw new TransactionCsvError('Every CSV row must use the same number of columns.');
  return rows;
}

function normalizeHeader(value: string): string {
  return value.replace(/^\ufeff/, '').toLowerCase().replace(/[^a-z]/g, '');
}

function findColumn(headers: string[], options: string[]): number {
  const matches = options.map(name => headers.indexOf(name)).filter(index => index >= 0);
  if (matches.length > 1) throw new TransactionCsvError('The CSV has multiple columns for the same transaction field.');
  return matches[0] ?? -1;
}

function cell(row: string[], index: number): string {
  return index < 0 ? '' : (row[index] ?? '').trim();
}

function parseDate(value: string): string | null {
  let year: number; let month: number; let day: number;
  const iso = /^(\d{4})-(\d{1,2})-(\d{1,2})$/.exec(value);
  const us = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(value);
  if (iso) [, year, month, day] = iso.map(Number) as unknown as [string, number, number, number];
  else if (us) [, month, day, year] = us.map(Number) as unknown as [string, number, number, number];
  else return null;
  const date = new Date(Date.UTC(year, month - 1, day));
  return date.getUTCFullYear() === year && date.getUTCMonth() === month - 1 && date.getUTCDate() === day
    ? `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}` : null;
}

function parseAmount(value: string): number {
  if (!value) return 0;
  const normalized = value.replace(/[$,\s]/g, '');
  const parentheses = /^\((.+)\)$/.exec(normalized);
  const numericText = parentheses ? `-${parentheses[1]}` : normalized;
  if (!/^-?(?:\d+|\d*\.\d{1,2})$/.test(numericText)) return Number.NaN;
  return Number(numericText);
}
