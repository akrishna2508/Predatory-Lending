import { createHash } from 'node:crypto';

export type RecurringTransaction = {
  accountId: string;
  name: string;
  merchantName: string | null;
  amount: number;
  date: string;
  pending: boolean;
};

export type RecurringCashflowSuggestion = {
  id: string;
  label: string;
  kind: 'income' | 'bill';
  amount: number;
  nextDate: string;
  cadence: 'weekly' | 'biweekly' | 'monthly';
  evidenceCount: number;
  confidence: 'possible';
};

type Observation = { date: string; amount: number };
type Group = { accountId: string; normalizedLabel: string; label: string; observations: Observation[] };

const DAY_MS = 86_400_000;
const MAX_INPUT = 5_000;
const MAX_SUGGESTIONS = 8;

function ordinal(date: string): number | null {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return null;
  const [year, month, day] = date.split('-').map(Number);
  const timestamp = Date.UTC(year, month - 1, day);
  const parsed = new Date(timestamp);
  return parsed.getUTCFullYear() === year && parsed.getUTCMonth() === month - 1 && parsed.getUTCDate() === day
    ? timestamp / DAY_MS
    : null;
}

function displayLabel(value: string): string {
  return value.replace(/\s+/g, ' ').trim().slice(0, 80);
}

function normalizeLabel(value: string): string {
  return value.normalize('NFKC').toLocaleLowerCase('en-US').replace(/[^a-z0-9]+/g, ' ').trim();
}

function cadenceFor(intervals: number[]): RecurringCashflowSuggestion['cadence'] | null {
  if (intervals.length < 2) return null;
  const average = intervals.reduce((sum, value) => sum + value, 0) / intervals.length;
  const spread = Math.max(...intervals) - Math.min(...intervals);
  if (average >= 6 && average <= 8 && spread <= 2) return 'weekly';
  if (average >= 12 && average <= 16 && spread <= 3) return 'biweekly';
  if (average >= 26 && average <= 35 && spread <= 5) return 'monthly';
  return null;
}

function nextOccurrence(date: string, cadence: RecurringCashflowSuggestion['cadence']): string {
  const [year, month, day] = date.split('-').map(Number);
  let next: Date;
  if (cadence === 'monthly') {
    const targetMonth = month;
    const targetYear = year + Math.floor(targetMonth / 12);
    const normalizedMonth = targetMonth % 12;
    const lastDay = new Date(Date.UTC(targetYear, normalizedMonth + 1, 0)).getUTCDate();
    next = new Date(Date.UTC(targetYear, normalizedMonth, Math.min(day, lastDay)));
  } else {
    const days = cadence === 'weekly' ? 7 : 14;
    next = new Date(Date.UTC(year, month - 1, day + days));
  }
  return next.toISOString().slice(0, 10);
}

function median(values: number[]): number {
  const sorted = [...values].sort((a, b) => a - b);
  const middle = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2;
}

/**
 * Finds cautious, member-reviewable cash-flow candidates from posted history.
 * A candidate is never persisted or treated as confirmed by this function.
 */
export function findRecurringCashflowSuggestions(
  transactions: RecurringTransaction[],
  asOfDate: string,
): RecurringCashflowSuggestion[] {
  const asOf = ordinal(asOfDate);
  if (asOf === null || !Array.isArray(transactions)) return [];

  const groups = new Map<string, Group>();
  for (const transaction of transactions.slice(0, MAX_INPUT)) {
    if (!transaction || transaction.pending || !Number.isFinite(transaction.amount) || transaction.amount === 0
      || Math.abs(transaction.amount) > 1_000_000 || typeof transaction.accountId !== 'string' || !transaction.accountId
      || typeof transaction.name !== 'string') continue;
    const date = ordinal(transaction.date);
    if (date === null || date > asOf || asOf - date > 183) continue;
    const label = displayLabel(transaction.merchantName || transaction.name);
    const normalizedLabel = normalizeLabel(label);
    if (normalizedLabel.length < 3) continue;
    const key = `${transaction.accountId}\u0000${normalizedLabel}`;
    const group = groups.get(key) ?? { accountId: transaction.accountId, normalizedLabel, label, observations: [] };
    group.observations.push({ date: transaction.date, amount: transaction.amount });
    groups.set(key, group);
  }

  const results: RecurringCashflowSuggestion[] = [];
  for (const group of groups.values()) {
    const byDate = new Map<string, Observation>();
    for (const observation of group.observations) byDate.set(observation.date, observation);
    const observations = [...byDate.values()].sort((a, b) => a.date.localeCompare(b.date));
    if (observations.length < 3) continue;

    const intervals: number[] = [];
    for (let i = 1; i < observations.length; i++) {
      const previous = ordinal(observations[i - 1].date)!;
      const current = ordinal(observations[i].date)!;
      intervals.push(current - previous);
    }
    const cadence = cadenceFor(intervals);
    if (!cadence) continue;

    const representative = median(observations.map(item => Math.abs(item.amount)));
    const tolerance = Math.max(2, representative * 0.1);
    if (observations.some(item => Math.abs(Math.abs(item.amount) - representative) > tolerance)) continue;

    const last = observations[observations.length - 1];
    const nextDate = nextOccurrence(last.date, cadence);
    const next = ordinal(nextDate)!;
    if (next <= asOf || next > asOf + 30) continue;
    const hash = createHash('sha256').update(`${group.accountId}\u0000${group.normalizedLabel}\u0000${cadence}`).digest('hex').slice(0, 16);
    results.push({
      id: hash,
      label: group.label,
      kind: last.amount > 0 ? 'income' : 'bill',
      amount: Math.round(representative * 100) / 100,
      nextDate,
      cadence,
      evidenceCount: observations.length,
      confidence: 'possible',
    });
  }

  return results.sort((a, b) => a.nextDate.localeCompare(b.nextDate) || a.label.localeCompare(b.label)).slice(0, MAX_SUGGESTIONS);
}
