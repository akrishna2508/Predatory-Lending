export type CashEvent = {
  id: string;
  date: string;
  label: string;
  amount: number;
  kind: 'income' | 'bill';
};

export type Payment = { date: string; amount: number };
export type OfferInput = {
  asOfDate: string;
  startingBalance: number;
  events: CashEvent[];
  proceeds: number;
  receivedOn: string;
  payments: Payment[];
  recentShortTermLoanRepaymentDate?: string | null;
};
type ProjectionPoint = { date: string; label: string; amount: number; balance: number; kind: string };
export type Projection = { lowestBalance: number; lowestDate: string; points: ProjectionPoint[] };
export type Analysis =
  | { valid: false; reason: string }
  | { valid: true; asOfDate: string; startingBalance: number; totalRepayment: number; dollarCost: number; baseline: Projection; withOffer: Projection; warning: { date: string; paymentDate: string; paymentAmount: number; balanceAfter: number; paymentIndex: number; triggerLabel: string } | null; repeatBorrowingPrompt: { recentRepaymentDate: string; daysSinceRepayment: number } | null };
type Entry = { date: string; label: string; amount: number; kind: string; order: number; paymentIndex?: number };

export const OFFER_CALCULATION_VERSION = 'offer-model-v2';

function dateOrdinal(value: string): number | null {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return null;
  const [year, month, day] = value.split('-').map(Number);
  const timestamp = Date.UTC(year, month - 1, day);
  const date = new Date(timestamp);
  if (date.getUTCFullYear() !== year || date.getUTCMonth() !== month - 1 || date.getUTCDate() !== day) return null;
  return timestamp / 86_400_000;
}
function inForecast(date: string, asOf: number): boolean {
  const ordinal = dateOrdinal(date);
  return ordinal !== null && ordinal >= asOf && ordinal < asOf + 30;
}
function cents(amount: number): number { return Math.round(amount * 100); }
function dollars(amountInCents: number): number { return amountInCents / 100; }

function compareEntries(a: Entry, b: Entry): number {
  return a.date.localeCompare(b.date) || a.order - b.order;
}
function project(startingBalance: number, asOfDate: string, entries: Entry[]): Projection {
  let balanceInCents = cents(startingBalance);
  let lowestInCents = balanceInCents;
  let lowestDate = asOfDate;
  const points: ProjectionPoint[] = [{ date: asOfDate, label: 'Starting balance', amount: 0, balance: startingBalance, kind: 'opening' }];
  for (const entry of [...entries].sort(compareEntries)) {
    const amountInCents = cents(entry.amount);
    balanceInCents += amountInCents;
    if (balanceInCents < lowestInCents) {
      lowestInCents = balanceInCents;
      lowestDate = entry.date;
    }
    points.push({ date: entry.date, label: entry.label, amount: dollars(amountInCents), balance: dollars(balanceInCents), kind: entry.kind });
  }
  return { lowestBalance: dollars(lowestInCents), lowestDate, points };
}

export function analyzeOffer(input: OfferInput): Analysis {
  const asOf = dateOrdinal(input.asOfDate);
  if (asOf === null) return { valid: false, reason: 'Enter a valid as-of date for the forecast.' };
  const recentRepaymentDate = input.recentShortTermLoanRepaymentDate ?? null;
  const recentRepayment = recentRepaymentDate === null ? null : dateOrdinal(recentRepaymentDate);
  if (recentRepaymentDate !== null && (recentRepayment === null || recentRepayment > asOf)) {
    return { valid: false, reason: 'Enter a valid recent repayment date on or before the balance date.' };
  }
  if (!Number.isFinite(input.startingBalance) || input.startingBalance < 0) return { valid: false, reason: 'Starting balance must be zero or more.' };
  if (!Number.isFinite(input.proceeds) || input.proceeds <= 0 || dateOrdinal(input.receivedOn) === null) return { valid: false, reason: 'Enter funds received and a valid receipt date.' };
  if (!inForecast(input.receivedOn, asOf)) return { valid: false, reason: 'The receipt date must fall within the 30-day forecast.' };
  if (!input.payments.length || input.payments.some(p => !Number.isFinite(p.amount) || p.amount <= 0 || dateOrdinal(p.date) === null)) return { valid: false, reason: 'Add at least one payment with a positive amount and valid date.' };
  if (input.payments.some(p => !inForecast(p.date, asOf))) return { valid: false, reason: 'Every payment date must fall within the 30-day forecast.' };
  if (input.payments.some(p => p.date < input.receivedOn)) return { valid: false, reason: 'Each payment date must be on or after the funds receipt date.' };
  if (input.events.some(e => !inForecast(e.date, asOf) || !Number.isFinite(e.amount))) return { valid: false, reason: 'Synthetic cash-flow events must have valid amounts and dates within the 30-day forecast.' };

  const baselineEntries: Entry[] = input.events.map(e => ({ date: e.date, label: e.label, amount: e.amount, kind: e.kind, order: e.kind === 'income' ? 0 : 1 }));
  const offerEntries: Entry[] = [...baselineEntries,
    { date: input.receivedOn, label: 'Offer funds received', amount: input.proceeds, kind: 'proceeds', order: 0 },
    ...input.payments.map((p, i) => ({ date: p.date, label: `Offer payment ${i + 1}`, amount: -p.amount, kind: 'payment', order: 2, paymentIndex: i })),
  ];
  const baseline = project(input.startingBalance, input.asOfDate, baselineEntries);
  const withOffer = project(input.startingBalance, input.asOfDate, offerEntries);

  let offerBalanceInCents = cents(input.startingBalance);
  let baselineBalanceInCents = cents(input.startingBalance);
  let lastPayment: Entry | null = null;
  let warning: Extract<Analysis, { valid: true }>['warning'] = null;
  const orderedOffer = [...offerEntries].sort(compareEntries);
  let baselineIndex = 0;
  const orderedBaseline = [...baselineEntries].sort(compareEntries);
  for (const entry of orderedOffer) {
    offerBalanceInCents += cents(entry.amount);

    while (baselineIndex < orderedBaseline.length && compareEntries(orderedBaseline[baselineIndex], entry) <= 0) {
      baselineBalanceInCents += cents(orderedBaseline[baselineIndex].amount);
      baselineIndex++;
    }

    if (entry.kind === 'income') lastPayment = null;
    if (entry.kind === 'payment') lastPayment = entry;
    if ((entry.kind === 'payment' || entry.kind === 'bill') && offerBalanceInCents < 0 && offerBalanceInCents < baselineBalanceInCents && lastPayment) {
      const paymentIndex = lastPayment.paymentIndex!;
      warning = {
        date: entry.date,
        paymentDate: lastPayment.date,
        paymentAmount: input.payments[paymentIndex].amount,
        balanceAfter: dollars(offerBalanceInCents),
        paymentIndex,
        triggerLabel: entry.label,
      };
      break;
    }
  }
  const totalRepaymentInCents = input.payments.reduce((sum, payment) => sum + cents(payment.amount), 0);
  const daysSinceRepayment = recentRepayment === null ? null : asOf - recentRepayment;
  const repeatBorrowingPrompt = recentRepaymentDate !== null && daysSinceRepayment !== null && daysSinceRepayment <= 14
    ? { recentRepaymentDate: recentRepaymentDate!, daysSinceRepayment }
    : null;
  return { valid: true, asOfDate: input.asOfDate, startingBalance: input.startingBalance, totalRepayment: dollars(totalRepaymentInCents), dollarCost: dollars(totalRepaymentInCents - cents(input.proceeds)), baseline, withOffer, warning, repeatBorrowingPrompt };
}
