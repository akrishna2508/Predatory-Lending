export type LoanOfferSignalKind = 'high-concern' | 'review' | 'information';

export type LoanOfferSignal = {
  id: 'guaranteed_approval' | 'pay_to_release' | 'time_pressure' | 'lead_generation' | 'missing_apr' | 'missing_total_repayment';
  kind: LoanOfferSignalKind;
  title: string;
  explanation: string;
  evidence?: string;
  source?: { label: string; href: string };
};

const FTC_ADVANCE_FEE = 'https://consumer.ftc.gov/articles/what-know-about-advance-fee-loans';
const CFPB_ONLINE_PAYDAY = 'https://www.consumerfinance.gov/ask-cfpb/what-should-i-consider-if-im-thinking-about-getting-a-payday-loan-online-en-1617/';

function evidence(text: string, pattern: RegExp): string | undefined {
  return text.match(pattern)?.[0]?.replace(/\s+/g, ' ').trim();
}

/**
 * Finds explicit phrases in text the user chose to paste. These rules flag
 * review cues; they do not determine whether a lender or offer is fraudulent.
 */
export function analyzeLoanOfferText(value: string): LoanOfferSignal[] {
  const text = typeof value === 'string' ? value.slice(0, 20_000) : '';
  if (!text.trim()) return [];

  const signals: LoanOfferSignal[] = [];
  const guaranteed = evidence(text, /\b(?:guaranteed|guarantee|pre[- ]?approved)\b.{0,80}\b(?:loan|approval|approved|credit|funds)\b|\b(?:loan|approval|credit|funds)\b.{0,80}\bguaranteed\b/i);
  const payToRelease = evidence(text, /\b(?:pay|send|wire|transfer)\b.{0,55}\b(?:an?\s+)?(?:up[- ]?front\s+)?(?:fee|payment|money)\b.{0,70}\b(?:before|prior to)\b.{0,55}\b(?:receiv\w*|releas\w*|disburs\w*|unlock\w*)\b|\b(?:fee|payment)\b.{0,60}\b(?:required|must be paid)\b.{0,50}\b(?:to release|to receive|before disbursement)\b/i);
  const genericUpfrontFee = evidence(text, /\b(?:up[- ]?front|advance|processing|insurance|application)\s+fees?\b/i);
  const urgency = evidence(text, /\b(?:act now|limited[- ]time|today only|offer expires|ends tonight|last chance|don't delay|apply now|borrow now)\b/i);
  const leadGeneration = evidence(text, /\b(?:match(?:ing)? you with|connect(?:ing)? you (?:to|with)|network of (?:participating )?lenders|participating lenders|share your (?:request|application) with (?:our )?partners)\b/i);

  if (payToRelease) {
    signals.push({
      id: 'pay_to_release',
      kind: 'high-concern',
      title: 'Payment requested before loan funds',
      explanation: guaranteed
        ? 'The pasted text combines a loan or approval promise with a payment request before funds are released. The FTC identifies paying an upfront fee for a promised or guaranteed loan as a major scam warning sign. Verify the company independently before sending money.'
        : 'The pasted text appears to request payment before loan funds are released. Verify the company and the fee independently; Aegis cannot determine from this phrase alone whether the offer is fraudulent.',
      evidence: payToRelease,
      source: { label: 'FTC loan scam guidance', href: FTC_ADVANCE_FEE },
    });
  }

  if (guaranteed && !payToRelease) {
    signals.push({
      id: 'guaranteed_approval',
      kind: payToRelease ? 'high-concern' : 'review',
      title: 'Guaranteed loan or approval claim',
      explanation: 'A guarantee is a reason to verify the offer and lender. The FTC says legitimate lenders do not guarantee credit before you apply; a fee demanded to secure a promised loan raises particular concern.',
      evidence: guaranteed,
      source: { label: 'FTC loan scam guidance', href: FTC_ADVANCE_FEE },
    });
  } else if (genericUpfrontFee && !payToRelease) {
    signals.push({
      id: 'pay_to_release',
      kind: 'review',
      title: 'An upfront fee is mentioned',
      explanation: 'Check what the fee covers, who receives it, and whether it is in the written terms. Some application or appraisal fees can be legitimate; this phrase alone does not establish a scam.',
      evidence: genericUpfrontFee,
      source: { label: 'FTC loan fee guidance', href: FTC_ADVANCE_FEE },
    });
  }

  if (urgency) {
    signals.push({
      id: 'time_pressure',
      kind: 'review',
      title: 'Time-pressure wording',
      explanation: 'The pasted text urges you to act quickly. Take time to review the full repayment amount, dates, and written terms before deciding.',
      evidence: urgency,
    });
  }

  if (leadGeneration) {
    signals.push({
      id: 'lead_generation',
      kind: 'information',
      title: 'The text may describe a loan-matching service',
      explanation: 'The site may send your request to multiple lenders. Check who will receive your information and whether the site is the lender or a lead generator.',
      evidence: leadGeneration,
      source: { label: 'CFPB online payday loan checklist', href: CFPB_ONLINE_PAYDAY },
    });
  }

  if (!/\b(?:APR|annual percentage rate)\b/i.test(text)) {
    signals.push({
      id: 'missing_apr',
      kind: 'information',
      title: 'APR not found in the text you pasted',
      explanation: 'It may appear elsewhere in the offer or agreement. Find it in the written terms before comparing loans.',
    });
  }
  if (!/\b(?:total repayment|total of payments|total amount to be repaid|amount you will repay|you will repay a total of)\b/i.test(text)) {
    signals.push({
      id: 'missing_total_repayment',
      kind: 'information',
      title: 'Total repayment not found in the text you pasted',
      explanation: 'It may appear elsewhere in the offer or agreement. Add every payment and fee to Aegis’s offer check before deciding.',
    });
  }

  const rank: Record<LoanOfferSignalKind, number> = { 'high-concern': 0, review: 1, information: 2 };
  return signals.sort((a, b) => rank[a.kind] - rank[b.kind]);
}
