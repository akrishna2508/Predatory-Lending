export type PrincipalRole = 'member' | 'partner_admin' | 'partner_analyst' | 'support';

export type Principal = {
  subject: string;
  tenantId: string;
  role: PrincipalRole;
};

type MemberRecord = {
  tenantId: string;
  memberSubject: string;
};

type PartnerAggregate = {
  tenantId: string;
  cohortSize: number;
};

const MINIMUM_PARTNER_COHORT = 20;

/** Members may read only their own records inside their active partner tenant. */
export function canReadMemberRecord(principal: Principal, record: MemberRecord): boolean {
  return principal.role === 'member'
    && principal.subject.length > 0
    && principal.tenantId.length > 0
    && principal.tenantId === record.tenantId
    && principal.subject === record.memberSubject;
}

/** Partner staff may see only same-tenant aggregates large enough to resist singling out. */
export function canReadPartnerAggregate(principal: Principal, aggregate: PartnerAggregate): boolean {
  return (principal.role === 'partner_admin' || principal.role === 'partner_analyst')
    && principal.tenantId.length > 0
    && principal.tenantId === aggregate.tenantId
    && Number.isSafeInteger(aggregate.cohortSize)
    && aggregate.cohortSize >= MINIMUM_PARTNER_COHORT;
}
