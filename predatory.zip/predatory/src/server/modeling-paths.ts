import { realpath, stat } from 'node:fs/promises';
import path from 'node:path';

export function resolveModelingProjectRoot(env: NodeJS.ProcessEnv = process.env): string {
  const configuredRoot = env.AEGIS_PROJECT_ROOT?.trim();
  return configuredRoot ? path.resolve(configuredRoot) : process.cwd();
}

export async function resolveLocalDataset(filename: string, root = resolveModelingProjectRoot()): Promise<string> {
  if (typeof filename !== 'string' || !filename.trim() || filename.length > 240) {
    throw new Error('Enter a dataset filename under data/raw.');
  }
  if (path.isAbsolute(filename) || path.win32.isAbsolute(filename) || filename.split(/[\\/]/).includes('..')) {
    throw new Error('Dataset files must stay inside data/raw.');
  }
  const extension = path.extname(filename).toLowerCase();
  if (!['.csv', '.zip', '.data', '.txt'].includes(extension)) {
    throw new Error('Choose a CSV, ZIP, or Statlog data file.');
  }

  const rawRoot = path.resolve(root, 'data', 'raw');
  const candidate = path.resolve(rawRoot, filename);
  if (!candidate.startsWith(`${rawRoot}${path.sep}`)) {
    throw new Error('Dataset files must stay inside data/raw.');
  }
  try {
    const [realRoot, realFile] = await Promise.all([realpath(rawRoot), realpath(candidate)]);
    const relative = path.relative(realRoot, realFile);
    if (!relative || relative.startsWith('..') || path.isAbsolute(relative)) {
      throw new Error('Dataset files must stay inside data/raw.');
    }
    const details = await stat(realFile);
    if (!details.isFile()) throw new Error('Dataset path must point to a regular file.');
    return realFile;
  } catch (error) {
    if (error instanceof Error && error.message.startsWith('Dataset files must stay')) throw error;
    if (error instanceof Error && error.message.startsWith('Dataset path must')) throw error;
    throw new Error('Local dataset file was not found under data/raw.');
  }
}
