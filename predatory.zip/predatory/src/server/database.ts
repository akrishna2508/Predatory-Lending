import { Pool } from 'pg';

export type TenantIdentity = {
  tenantId: string;
  userId: string;
};

export type MemberDatabaseClient = {
  query(sql: string, values?: unknown[]): Promise<{ rows: Array<Record<string, unknown>> }>;
  release(): void;
};

export type MemberDatabasePool = {
  connect(): Promise<MemberDatabaseClient>;
};

export type MemberOperation<T> = (client: MemberDatabaseClient) => Promise<T>;

const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

/**
 * Runs a member operation in one transaction with transaction-local tenant identity.
 * The database login must be a member of the restricted aegis_runtime role.
 */
export async function withMemberTransaction<T>(
  pool: MemberDatabasePool,
  identity: TenantIdentity,
  operation: MemberOperation<T>,
): Promise<T> {
  if (!UUID_PATTERN.test(identity.tenantId) || !UUID_PATTERN.test(identity.userId)) {
    throw new Error('Valid tenant and user identifiers are required');
  }

  const client = await pool.connect();
  let transactionStarted = false;

  try {
    await client.query('BEGIN');
    transactionStarted = true;
    await client.query('SET LOCAL ROLE aegis_runtime');
    await client.query(
      "SELECT set_config('aegis.tenant_id', $1, true), set_config('aegis.user_id', $2, true)",
      [identity.tenantId, identity.userId],
    );
    await client.query(
      "SELECT pg_advisory_xact_lock(hashtextextended($1::text, 0))",
      [identity.userId],
    );

    const membership = await client.query(
      "SELECT m.role FROM memberships m JOIN app_users u ON u.id = m.user_id JOIN organizations o ON o.id = m.tenant_id WHERE m.tenant_id = $1 AND m.user_id = $2 AND m.status = 'active' AND u.status = 'active' AND o.status = 'active'",
      [identity.tenantId, identity.userId],
    );

    if (!membership.rows.length) throw new Error('Active membership required');
    if (membership.rows[0].role !== 'member') throw new Error('Member role required');

    const result = await operation(client);
    await client.query('COMMIT');
    transactionStarted = false;
    return result;
  } catch (error) {
    if (transactionStarted) {
      try {
        await client.query('ROLLBACK');
      } catch {
        // Keep the original failure; releasing the connection lets pg discard a bad client.
      }
    }
    throw error;
  } finally {
    client.release();
  }
}

export async function withPartnerTransaction<T>(
  pool: MemberDatabasePool,
  identity: TenantIdentity,
  operation: MemberOperation<T>,
): Promise<T> {
  if (!UUID_PATTERN.test(identity.tenantId) || !UUID_PATTERN.test(identity.userId)) {
    throw new Error('Valid tenant and user identifiers are required');
  }
  const client = await pool.connect();
  let transactionStarted = false;
  try {
    await client.query('BEGIN');
    transactionStarted = true;
    await client.query('SET LOCAL ROLE aegis_runtime');
    await client.query(
      "SELECT set_config('aegis.tenant_id', $1, true), set_config('aegis.user_id', $2, true)",
      [identity.tenantId, identity.userId],
    );
    await client.query(
      "SELECT pg_advisory_xact_lock(hashtextextended($1::text, 0))",
      [identity.userId],
    );
    const membership = await client.query(
      "SELECT m.role FROM memberships m JOIN app_users u ON u.id = m.user_id JOIN organizations o ON o.id = m.tenant_id WHERE m.tenant_id = $1 AND m.user_id = $2 AND m.status = 'active' AND u.status = 'active' AND o.status = 'active' AND m.role IN ('partner_admin', 'partner_analyst')",
      [identity.tenantId, identity.userId],
    );
    if (!membership.rows.length) throw new Error('Partner membership required');
    const result = await operation(client);
    await client.query('COMMIT');
    transactionStarted = false;
    return result;
  } catch (error) {
    if (transactionStarted) {
      try { await client.query('ROLLBACK'); } catch { /* Preserve the original error. */ }
    }
    throw error;
  } finally {
    client.release();
  }
}

/** Runs only the narrowly granted, signature-gated webhook database function. */
export async function withWebhookTransaction<T>(
  pool: MemberDatabasePool,
  operation: MemberOperation<T>,
): Promise<T> {
  const client = await pool.connect();
  let transactionStarted = false;
  try {
    await client.query('BEGIN');
    transactionStarted = true;
    await client.query('SET LOCAL ROLE aegis_runtime');
    await client.query("SELECT set_config('aegis.tenant_id', '', true), set_config('aegis.user_id', '', true)");
    const result = await operation(client);
    await client.query('COMMIT');
    transactionStarted = false;
    return result;
  } catch (error) {
    if (transactionStarted) {
      try { await client.query('ROLLBACK'); } catch { /* Preserve the original failure. */ }
    }
    throw error;
  } finally {
    client.release();
  }
}

export async function withIdentityTransaction<T>(
  pool: MemberDatabasePool,
  userId: string,
  operation: MemberOperation<T>,
): Promise<T> {
  if (!UUID_PATTERN.test(userId)) throw new Error('Valid user identifier is required');
  const client = await pool.connect();
  let transactionStarted = false;
  try {
    await client.query('BEGIN');
    transactionStarted = true;
    await client.query('SET LOCAL ROLE aegis_runtime');
    await client.query("SELECT set_config('aegis.tenant_id', '', true), set_config('aegis.user_id', $1, true)", [userId]);
    await client.query("SELECT pg_advisory_xact_lock(hashtextextended($1::text, 0))", [userId]);
    const result = await operation(client);
    await client.query('COMMIT');
    transactionStarted = false;
    return result;
  } catch (error) {
    if (transactionStarted) {
      try { await client.query('ROLLBACK'); } catch { /* Preserve the original error. */ }
    }
    throw error;
  } finally {
    client.release();
  }
}

export type MemberTenant = { id: string; name: string; slug: string };

/** Discover a member's own active credit-union memberships before choosing a tenant context. */
export async function listMemberTenants(pool: MemberDatabasePool, userId: string): Promise<MemberTenant[]> {
  if (!UUID_PATTERN.test(userId)) throw new Error('Valid user identifier is required');
  const client = await pool.connect();
  let transactionStarted = false;
  try {
    await client.query('BEGIN');
    transactionStarted = true;
    await client.query('SET LOCAL ROLE aegis_runtime');
    await client.query("SELECT set_config('aegis.tenant_id', '', true), set_config('aegis.user_id', $1, true)", [userId]);
    const tenants = await client.query(
      "SELECT o.id, o.name, o.slug FROM memberships m JOIN organizations o ON o.id = m.tenant_id JOIN app_users u ON u.id = m.user_id WHERE m.role = 'member' AND m.status = 'active' AND o.status = 'active' AND u.status = 'active' ORDER BY o.name",
    );
    await client.query('COMMIT');
    transactionStarted = false;
    return tenants.rows as unknown as MemberTenant[];
  } catch (error) {
    if (transactionStarted) {
      try { await client.query('ROLLBACK'); } catch { /* Preserve the original error. */ }
    }
    throw error;
  } finally {
    client.release();
  }
}

export async function listPartnerTenants(pool: MemberDatabasePool, userId: string): Promise<MemberTenant[]> {
  if (!UUID_PATTERN.test(userId)) throw new Error('Valid user identifier is required');
  const client = await pool.connect();
  let transactionStarted = false;
  try {
    await client.query('BEGIN');
    transactionStarted = true;
    await client.query('SET LOCAL ROLE aegis_runtime');
    await client.query("SELECT set_config('aegis.tenant_id', '', true), set_config('aegis.user_id', $1, true)", [userId]);
    const tenants = await client.query(
      "SELECT o.id, o.name, o.slug FROM memberships m JOIN organizations o ON o.id = m.tenant_id JOIN app_users u ON u.id = m.user_id WHERE m.role IN ('partner_admin', 'partner_analyst') AND m.status = 'active' AND o.status = 'active' AND u.status = 'active' ORDER BY o.name",
    );
    await client.query('COMMIT');
    transactionStarted = false;
    return tenants.rows as unknown as MemberTenant[];
  } catch (error) {
    if (transactionStarted) {
      try { await client.query('ROLLBACK'); } catch { /* Preserve the original error. */ }
    }
    throw error;
  } finally {
    client.release();
  }
}

let pool: Pool | undefined;

/** Shared server-side pool. Never expose DATABASE_URL to client bundles. */
export function getDatabasePool(): Pool {
  if (pool) return pool;
  const connectionString = process.env.DATABASE_URL;
  if (!connectionString) throw new Error('DATABASE_URL is required');
  const maxPoolSize = Number(process.env.DATABASE_POOL_MAX ?? 10);
  if (!Number.isSafeInteger(maxPoolSize) || maxPoolSize < 1 || maxPoolSize > 50) {
    throw new Error('DATABASE_POOL_MAX must be an integer from 1 to 50');
  }

  const isRenderInternal = connectionString.includes('dpg-') && !connectionString.includes('.render.com');
  const useSsl = process.env.DATABASE_SSL === 'true' || (process.env.NODE_ENV === 'production' && process.env.DATABASE_SSL !== 'false');
  const rejectUnauthorized = process.env.DATABASE_SSL_REJECT_UNAUTHORIZED === 'true'
    ? true
    : process.env.DATABASE_SSL_REJECT_UNAUTHORIZED === 'false' || isRenderInternal
      ? false
      : true;

  pool = new Pool({
    connectionString,
    max: maxPoolSize,
    idleTimeoutMillis: 30_000,
    connectionTimeoutMillis: 5_000,
    statement_timeout: 5_000,
    idle_in_transaction_session_timeout: 10_000,
    ...(useSsl ? { ssl: { rejectUnauthorized } } : { ssl: false }),
  });
  pool.on('error', error => {
    console.error('Unexpected PostgreSQL pool error', { code: (error as Error & { code?: string }).code ?? 'unknown' });
  });
  return pool;
}
