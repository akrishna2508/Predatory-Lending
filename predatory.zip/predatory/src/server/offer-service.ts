import { z } from 'zod';
import { analyzeOffer, type Analysis, type OfferInput } from '../domain/finance';

const eventSchema = z.object({
  id: z.string().trim().min(1).max(80),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  label: z.string().trim().min(1).max(100),
  amount: z.number().finite().min(-1_000_000).max(1_000_000),
  kind: z.enum(['income', 'bill']),
}).strict();

const offerInputSchema = z.object({
  asOfDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  startingBalance: z.number().finite().min(0).max(1_000_000),
  events: z.array(eventSchema).max(60),
  proceeds: z.number().finite().positive().max(1_000_000),
  receivedOn: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  recentShortTermLoanRepaymentDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).nullable().optional(),
  payments: z.array(z.object({
    date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
    amount: z.number().finite().positive().max(1_000_000),
  }).strict()).min(1).max(20),
}).strict();

export function validateOfferCheck(input: unknown): Analysis {
  const parsed = offerInputSchema.safeParse(input);
  if (!parsed.success) return { valid: false, reason: 'Offer details are incomplete or outside the supported limits.' };
  return analyzeOffer(parsed.data as OfferInput);
}

export type ConsentState = { purpose: string; action: string };

/** Expects at most one row per purpose: the latest event for each purpose. */
export function hasOfferCheckConsent(states: ConsentState[]): boolean {
  const latest = new Map(states.map(state => [state.purpose, state.action]));
  return latest.get('manual_financial_profile') === 'granted'
    && latest.get('offer_check_storage') === 'granted';
}
