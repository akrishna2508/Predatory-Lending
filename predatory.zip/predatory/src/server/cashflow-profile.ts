import { z } from 'zod';

const cashflowEventSchema = z.object({
  id: z.string().trim().min(1).max(80),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  label: z.string().trim().min(1).max(100),
  amount: z.number().finite().min(0.01).max(1_000_000),
  kind: z.enum(['income', 'bill']),
  source: z.enum(['member_entered', 'transaction_suggestion']),
}).strict();

const cashflowProfileSchema = z.object({
  asOfDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  startingBalance: z.number().finite().min(0).max(1_000_000),
  events: z.array(cashflowEventSchema).max(60),
}).strict();

export type CashflowProfileInput = z.infer<typeof cashflowProfileSchema>;
export type CashflowConsentState = { purpose: string; action: string };

function dateOrdinal(value: string): number | null {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return null;
  const [year, month, day] = value.split('-').map(Number);
  const timestamp = Date.UTC(year, month - 1, day);
  const date = new Date(timestamp);
  if (date.getUTCFullYear() !== year || date.getUTCMonth() !== month - 1 || date.getUTCDate() !== day) return null;
  return timestamp / 86_400_000;
}

export function validateCashflowProfile(input: unknown, today: string):
  | { valid: true; profile: CashflowProfileInput }
  | { valid: false; reason: string } {
  const parsed = cashflowProfileSchema.safeParse(input);
  const todayOrdinal = dateOrdinal(today);
  if (!parsed.success || todayOrdinal === null) {
    return { valid: false, reason: 'Cash-flow details are incomplete or outside the supported limits.' };
  }

  const asOfOrdinal = dateOrdinal(parsed.data.asOfDate);
  if (asOfOrdinal === null || asOfOrdinal > todayOrdinal) {
    return { valid: false, reason: 'Choose a valid balance date that is today or earlier.' };
  }
  if (parsed.data.events.some(event => {
    const ordinal = dateOrdinal(event.date);
    return ordinal === null || ordinal < asOfOrdinal || ordinal >= asOfOrdinal + 30;
  })) {
    return { valid: false, reason: 'Each expected item must fall within the 30-day cash-flow window.' };
  }

  return { valid: true, profile: parsed.data };
}

/** Expects at most one row per purpose: the latest event for each purpose. */
export function hasCashflowProfileStorageConsent(states: CashflowConsentState[]): boolean {
  const latest = new Map(states.map(state => [state.purpose, state.action]));
  return latest.get('manual_financial_profile') === 'granted'
    && latest.get('cashflow_profile_storage') === 'granted';
}
