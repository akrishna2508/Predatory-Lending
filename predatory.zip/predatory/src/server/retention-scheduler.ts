import { getDatabasePool } from './database';

const DAY = 24 * 60 * 60 * 1_000;
const RETRY = 15 * 60 * 1_000;
const STARTUP_DELAY = 30 * 1_000;
let started = false;

/** The local web process owns this daily maintenance schedule; routines are safe to repeat. */
export function startRetentionScheduler() {
  if (started) return;
  started = true;

  function schedule(delay: number) {
    const timer = setTimeout(() => { void run(); }, delay);
    timer.unref();
  }

  const run = async () => {
    try {
      const result = await getDatabasePool().query(
        'SELECT aegis_purge_expired_imported_transactions() AS transactions, aegis_purge_expired_local_sessions() AS sessions, aegis_purge_expired_member_cashflow_profiles() AS cashflow_profiles',
      );
      console.info('Aegis retention sweep completed', {
        deletedTransactions: Number(result.rows[0]?.transactions ?? 0),
        expiredSessions: Number(result.rows[0]?.sessions ?? 0),
        expiredCashflowProfiles: Number(result.rows[0]?.cashflow_profiles ?? 0),
      });
      schedule(DAY);
    } catch {
      console.error('Aegis retention sweep failed');
      schedule(RETRY);
    }
  };

  schedule(STARTUP_DELAY);
}
