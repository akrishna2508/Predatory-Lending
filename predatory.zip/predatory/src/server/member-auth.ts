import { createHash } from 'node:crypto';
import { getDatabasePool } from './database';
import type { TenantIdentity } from './database';

type VerifiedAccessToken = { sub?: unknown; exp?: number };
export type AccessTokenVerifier = (token: string) => Promise<VerifiedAccessToken>;
export const MEMBER_SESSION_COOKIE = 'aegis_session';

export class MemberAuthError extends Error {
  constructor(message: 'Authentication required' | 'Authentication failed' | 'Tenant identifier required') {
    super(message);
    this.name = 'MemberAuthError';
  }
}

const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

/** Validate an opaque, server-side local session and bind it to an explicit partner tenant. */
export async function resolveMemberIdentity(
  request: Request,
  verifyAccessToken: AccessTokenVerifier = verifyMemberSession,
): Promise<TenantIdentity> {
  const userId = await resolveMemberSubject(request, verifyAccessToken);
  const tenantId = request.headers.get('x-aegis-tenant-id');
  if (!tenantId || !UUID_PATTERN.test(tenantId)) throw new MemberAuthError('Tenant identifier required');

  return { tenantId, userId };
}

export async function resolveMemberSubject(
  request: Request,
  verifyAccessToken: AccessTokenVerifier = verifyMemberSession,
): Promise<string> {
  const token = getRequestAccessToken(request);
  if (!token) throw new MemberAuthError('Authentication required');
  let claims: VerifiedAccessToken;
  try {
    claims = await verifyAccessToken(token);
  } catch {
    throw new MemberAuthError('Authentication failed');
  }
  if (typeof claims.sub !== 'string' || !UUID_PATTERN.test(claims.sub)) throw new MemberAuthError('Authentication failed');
  return claims.sub;
}

/** Cookie-authenticated mutations require a same-origin browser request to prevent CSRF. */
export function hasSafeMutationOrigin(request: Request): boolean {
  const authorization = request.headers.get('authorization');
  if (authorization?.match(/^Bearer ([^\s]+)$/i)) return true;
  if (!readCookie(request.headers.get('cookie'), MEMBER_SESSION_COOKIE)) return true;
  return hasSameOriginRequest(request);
}

/** Compare browser Origin with the host received by Next, not its 0.0.0.0 bind address. */
export function hasSameOriginRequest(request: Request): boolean {
  const origin = request.headers.get('origin');
  if (!origin) return false;
  try {
    const host = request.headers.get('host') ?? new URL(request.url).host;
    const originUrl = new URL(origin);
    const forwardedProtocol = request.headers.get('x-forwarded-proto')?.split(',')[0]?.trim();
    const requestProtocol = forwardedProtocol === 'http' || forwardedProtocol === 'https'
      ? forwardedProtocol
      : new URL(request.url).protocol.slice(0, -1);
    if (originUrl.protocol !== `${requestProtocol}:`) return false;
    return originUrl.origin === new URL(`${requestProtocol}://${host}`).origin;
  } catch {
    return false;
  }
}

function getRequestAccessToken(request: Request): string | null {
  const authorization = request.headers.get('authorization');
  const match = authorization?.match(/^Bearer ([^\s]+)$/i);
  return match?.[1] ?? readCookie(request.headers.get('cookie'), MEMBER_SESSION_COOKIE);
}

function readCookie(header: string | null, name: string): string | null {
  if (!header) return null;
  for (const part of header.split(';')) {
    const [key, ...value] = part.trim().split('=');
    if (key === name && value.length) return value.join('=');
  }
  return null;
}

export async function verifyMemberSession(token: string): Promise<VerifiedAccessToken> {
  if (!/^[A-Za-z0-9_-]{43}$/.test(token)) throw new Error('Session is malformed');
  const tokenHash = createHash('sha256').update(token).digest();
  const result = await getDatabasePool().query('SELECT aegis_resolve_member_session($1) AS user_id', [tokenHash]);
  const userId = result.rows[0]?.user_id;
  if (typeof userId !== 'string') throw new Error('Session is expired or revoked');
  return { sub: userId };
}
