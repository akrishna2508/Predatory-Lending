import { execFile } from 'node:child_process';
import path from 'node:path';
import { resolveModelingProjectRoot } from './modeling-paths';

const ALLOWED_SCRIPTS = new Set(['train_baseline.py', 'analyze_cfpb.py', 'run_simulation.py', 'benchmark_public_generators.py']);

export function isLocalWorkbenchRequest(request: Request): boolean {
  const hostHeader = request.headers.get('host');
  if (!hostHeader) return false;
  let parsedHost: URL;
  try {
    parsedHost = new URL(`http://${hostHeader}`);
  } catch {
    return false;
  }
  const hostname = parsedHost.hostname.replace(/^\[|\]$/g, '').toLowerCase();
  if (!['localhost', '127.0.0.1', '::1'].includes(hostname)) return false;

  const origin = request.headers.get('origin');
  if (!origin) return true;
  try {
    return new URL(origin).host.toLowerCase() === hostHeader.toLowerCase();
  } catch {
    return false;
  }
}

export async function runLocalPythonJson(scriptName: string, args: string[]): Promise<unknown> {
  if (!ALLOWED_SCRIPTS.has(scriptName)) throw new Error('Unsupported local modeling command.');
  const root = resolveModelingProjectRoot();
  const python = process.env.AEGIS_PYTHON || (process.platform === 'win32' ? 'python' : 'python3');
  const scriptPath = path.join(root, 'scripts', scriptName);
  const stdout = await new Promise<string>((resolve, reject) => {
    execFile(python, [scriptPath, ...args], {
      cwd: root,
      timeout: 120_000,
      maxBuffer: 2 * 1024 * 1024,
      env: { ...process.env, PYTHONUNBUFFERED: '1' },
    }, (error, output, stderr) => {
      if (error) {
        const details = stderr.trim().slice(-1200);
        reject(new Error(details || error.message));
        return;
      }
      resolve(output);
    });
  });
  try {
    return JSON.parse(stdout);
  } catch {
    throw new Error('Local modeling command returned an invalid report.');
  }
}
