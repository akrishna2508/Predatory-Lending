# Member portal reference lock

**Designing:** the signed-in Aegis member workspace for credit-union members on responsive web.
**Goal:** grant or revoke data uses, enter cash-flow details, and compare a short-term offer before deciding.
**Tone:** calm, clear, member-controlled.
**Main risk:** the interface must not imply that a calculation is financial advice, a loan endorsement, or a guaranteed prediction.
**Constraints:** preserve the existing Aegis visual system; manual entry remains available; optional consented read-only transaction history; no money movement.

## References

- **Primary product direction — existing Aegis alpha:** deep navy text, white and cool-gray surfaces, fine dividers, restrained blue actions, and explicit synthetic-data labels. Keep this visual language consistent across public demo and member workspace.
- **Style reference — N26, “Teal and White Ledger”** ([Refero style](https://refero.design/styles/59911817-9d14-445a-9f1b-617418001061)): borrow the high-contrast financial ledger, compact but legible data hierarchy, restrained color, and clear separation of primary action from disclosure. Keep Aegis blue as the primary action color; do not import N26 teal.
- **Screen reference — Equals financial workbook** ([Refero screen](https://refero.design/pages/5b7eef4c-faae-4c7f-b1d6-adffd6f26170)): adapt the date-and-balance table into a simple cash-flow event editor and saved-check history; do not copy spreadsheet density or toolbar complexity.
- **Screen reference — Monarch account-link setup** ([Refero screen](https://refero.design/pages/2cf76d9a-8078-40fc-a921-251a319aca7c)): borrow its single-column setup hierarchy and one clear next action. Replace the bank-link push with optional manual entry and clear consent choices.
- **Flow reference — PayPal bank selection** ([Refero flow](https://refero.design/flows/7379)): borrow the explicit fallback when a preferred path is unavailable. Aegis keeps manual entry available; it does not present bank linking as required.

## Decisions

- Keep the existing navy/blue, white, and pale-gray roles. Warning amber and shortfall red remain semantic states only.
- Use a responsive single-column workflow: institution selection, consent, manual cash-flow inputs, result, saved checks.
- Keep consent purposes separate with current status, policy version, and a direct revoke action.
- Label outputs as estimates from member-entered inputs; show assumptions beside the result. Never display a “safe” or approval badge.
- Use compact tables only for dated events and saved checks; use larger, readable controls for money and dates.
- Reuse existing typography, 6px control radius, thin borders, and limited elevation; do not introduce a new decorative illustration system.
- Respect reduced-motion preferences; no animation is needed to understand the workflow.

## Bank connection extension — 2026-09-25

**Research:** Refero `Raise` style (style `f72e18d0-98f4-4e88-9754-5426589564ea`) reaffirmed white canvas, navy hierarchy, single blue action, compact financial rows, and thin dividers. `N26 / The online bank` (style `59911817-9d14-445a-9f1b-617418001061`) contributes ledger clarity and semantic-only warning colors; its teal is not imported. PayPal's `Bank Selection for Linking` flow (flow `7379`, https://refero.design/flows/7379) uses a searchable bank list and fallback path; for Aegis, Plaid owns institution search and manual offer entry stays visible underneath. Wealthsimple's `Connect vs enter manually` screen in flow `8504` reinforces that connection is optional. These references support the existing Raise-based Aegis visual lock; they do not change its palette or shape tokens.

**New decisions:** Add an optional bank-connection panel after separate consent choices and before the manual offer form. State plainly that connection reads checking/savings transaction history, does not move money, and can be disconnected; show institution name and most recent successful sync time, with explicit stale/error/disconnect-pending labels. The connect action remains disabled until the member grants bank-specific consent. Manual entry remains available whether bank linking is enabled, declined, or unavailable. Use Plaid's hosted Link interface for institution selection and authentication; never create a bank list, credential form, or fake Plaid UI inside Aegis. Keep the financial warning colors semantic only.

**Cash-flow suggestion extension:** Show recent imported transactions and conservative possible recurring items below the connection controls. Each item names its cadence, evidence count, and estimated next date, then requires a member action before it enters the forecast. Keep the pattern in the same ledger rows and divider system; do not add a prediction score, “financial health” badge, vulnerability label, or automatic confirmation. Revoking bank consent clears the visible imported activity immediately.

**Repeat-borrowing prompt:** Ask for an optional, member-reported date of the most recent repayment on another short-term loan. Keep it beside the offer inputs, explain that Aegis does not infer this from transaction activity, and show a calm reminder only when the date is within 14 days of the comparison's balance date. It must not label the person or the offer.
