# Member cash-flow storage controls — reference lock

**Date:** 2026-09-26  
**Surface:** Member workspace, mobile-first web  
**Task:** Grant or revoke optional cash-flow storage, then load, update, or delete the member's confirmed picture.

## Research

- **Raise / Open Collective** is the primary visual foundation: white surfaces, navy text, restrained blue actions, fine separators, and readable financial rows. Its institutional clarity fits a credit-union member benefit.
- **N26** contributes ledger discipline: clear labels, timestamps, and semantic warning colors kept distinct from brand color.
- **Fruitful** supports calm, uncluttered personal-finance surfaces and compact rounded cards. Its green accent is not adopted; Aegis keeps its existing blue action token.
- **Revolut privacy settings** show a permission list where each switch sits beside a specific title and explanation. Aegis uses that grouping to keep calculation consent separate from storage consent.
- **Monarch account setup** uses labeled fields and a clear save action. Aegis adapts the explicit load/update/delete actions and does not copy its modal or orange brand accent.

## Reference lock

- **Primary direction:** Raise's white/navy/blue financial clarity.
- **Preserve:** existing Aegis navy ink, blue primary action, white card surfaces, thin gray borders, concise labels, and responsive form layout.
- **Borrow:** N26's dated ledger presentation and Revolut's independently described permission switches.
- **Token roles:** `--blue` is for primary actions and active states; `--ink` for primary text; `--muted` for helper copy; `--line` for card and row boundaries; red remains reserved for warnings and destructive confirmation.
- **Controls:** show a separate storage-consent row with its duration and revocation effect. Show the saved profile's balance date, last update, and expiration; make loading explicit and preserve offer terms. Keep delete separate from load/update and require confirmation.
- **Reject:** extra accent colors, promotional badges, unconfirmed “smart” labels, automatic form replacement, and dense transaction-level previews in the saved-profile summary.

## Decision ledger

| Decision | Source | Source role | Rationale |
|---|---|---|---|
| Separate storage toggle from calculation-use toggle | Revolut privacy settings; approved Aegis consent boundary | Permission hierarchy | Members can understand and revoke the two different uses independently. |
| Use an outlined, dated summary card | Raise and N26 | Financial clarity | The profile is private member data; its date and expiry matter more than decorative emphasis. |
| Provide explicit Load, Update, and Delete actions | Monarch labeled finance form; Aegis product requirement | Form actions | Members choose when saved data enters a forecast and can remove it without deleting offer checks. |
| Retain Aegis blue and navy tokens | Existing Aegis visual system and Raise | Brand/action roles | Keeps controls consistent and avoids repurposing reference accents. |
