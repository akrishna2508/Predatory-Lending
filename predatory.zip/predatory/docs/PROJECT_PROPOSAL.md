# Project Aegis: Autonomous Financial Defense Platform
## System Architecture, Data Intelligence & Behavioral Simulation Framework

---

### Executive Summary

**Project Aegis** is an open-source algorithmic defense shield designed to protect low-income and financially vulnerable consumers from predatory lending traps. 

While subprime and payday lenders deploy predictive algorithms, dark UX patterns, and payday-cycle timing hooks to trap borrowers in compounding rollover debt (where over 80% of payday loans are rolled over within 14 days), Aegis turns algorithmic intelligence into a consumer shield. 

Rather than relying on passive, post-transaction budgeting dashboards, Aegis operates directly at the **point of decision**. By evaluating proposed loan terms against the user's localized cash-flow schedule and regulatory complaint archives, Aegis introduces critical cognitive breathing room—deploying plain-language deceptive term disclosures, 30-day liquidity shortfall projections, and virtual bill-reserve buffers.

By systematically intercepting predatory financial products before contracts are executed, Aegis serves as a structural wealth-retention tool for marginalized communities, directly advancing:
* **UN Sustainable Development Goal 1 (No Poverty):** Halting the systematic extraction of capital from low-income households through triple-digit APR rollovers and hidden fees.
* **UN Sustainable Development Goal 10 (Reduced Inequalities):** Leveling the technological information asymmetry between multi-billion-dollar predatory lending algorithms and vulnerable consumers.

---

### Key Architectural Shifts: From Vulnerability Profiling to Structural Empowerment

To ensure complete ethical integrity, user trust, and regulatory compliance (FCRA, ECOA, FTC Act Section 5), Aegis replaces intrusive psychological profiling with structural cash-flow and contract transparency:

| Conventional / High-Risk Approach | Aegis Defensive Architecture |
| :--- | :--- |
| **Mapping "Cognitive Vulnerabilities"**<br>*(Ethical & regulatory liability; paternalistic profiling)* | **Mapping Cash-Flow Collision Points & Deceptive Terms**<br>*(Audits contract terms and calendar timing mismatches between income and debt repayments)* |
| **Autonomous Transaction Blocking**<br>*(Regulatory minefield under Reg E; severe liability if essential payments fail)* | **Point-of-Decision Cognitive Speedbumps**<br>*(Mandatory review pauses, transparent fee arithmetic, and clear contractual warning flags)* |
| **Automated Money Micro-Routing**<br>*(Requires banking charter, money transmitter licenses, and custodial control)* | **Virtual Bill-Reserve Allocator**<br>*(Visual escrow and liquidity quarantine that helps members partition survival funds before borrowing)* |
| **Centralized Cloud Credit Scoring**<br>*(Risk of data surveillance, breaches, and re-identification)* | **Client-Side Privacy & Federated Local Intelligence**<br>*(Data remains on the consumer's device; models run locally via open-source engines)* |

---

### Phase 1: Baseline Macro Models & Market Intelligence

Phase 1 establishes the macroeconomic risk baseline and regulatory dark-pattern taxonomy using verified public datasets.

```
+-------------------------------------------------------------------------+
|                         Phase 1: Macro Data Engine                      |
+------------------------------------+------------------------------------+
| Unstructured Regulatory Text       | Structured Credit Risk Benchmarks  |
| - CFPB Consumer Complaints Archive | - LendingClub Historical Records   |
|   (15M+ records, narrative corpus) |   (Debt-to-income, repayment arcs) |
| - FTC Enforcement Action Patterns  | - Home Credit Default Risk         |
|   (Deceptive wording & fee flags)  |   (Unbanked/subprime cash flows)   |
|                                    | - Statlog German Credit (OpenML)   |
|                                    |   (Deterministic reproducibility)  |
+------------------------------------+------------------------------------+
                                  |
                                  v
+-------------------------------------------------------------------------+
|                  Extracted Structural Risk Indicators                   |
|  • Debt-Service-to-Income (DSTI) stress thresholds                     |
|  • Repayment-to-payday timing collision vectors                         |
|  • Deceptive contract wording taxonomy (e.g., mandatory ACH, upfront)   |
|  • Fee-compounding velocity metrics                                     |
+-------------------------------------------------------------------------+
```

#### 1. Data Source Roles & Methodological Rigor

1. **CFPB Consumer Complaint Database & Historical Narrative Archive:**
   * **Role:** Regulatory market intelligence and dark-pattern taxonomy (not default-probability scoring).
   * **Utility:** Analyzes over 15 million records to catalog predatory loan servicing practices, hidden fee structures, and aggressive collection triggers. Transparent phrase-matching algorithms parse historical narratives to flag predatory contract clauses (e.g., upfront release fees, mandatory wage pre-commitments, misleading APR disclosures).
   * **Data Governance:** Current API metadata is updated continuously; historical narrative text (pre-August 2026) is processed locally to extract phrase flags and immediately discarded to respect data minimization principles.

2. **LendingClub Open Benchmark:**
   * **Role:** Macro installment repayment and debt-to-income baseline.
   * **Utility:** Provides benchmark metrics across hundreds of thousands of multi-year loan schedules, establishing reference curves for debt-to-income (DTI) saturation and revolving balance thresholds.
   * **Qualification:** Serves strictly as a macro benchmark for multi-installment debt; it is explicitly distinguished from short-term single-balloon payday loans.

3. **Home Credit Default Risk Dataset:**
   * **Role:** Underbanked and alternative credit behavior modeling.
   * **Utility:** Provides structural cash-flow features for populations with little or no formal credit history, mapping how irregular income streams interact with structured debt service.

4. **Statlog German Credit (OpenML / UCI):**
   * **Role:** Open, reproducible baseline benchmark.
   * **Utility:** Provides an open-source, non-restricted tabular baseline for automated CI/CD pipeline verification and testing.

---

### Phase 2: Synthetic Behavioral Ecosystem & Simulation Engine

Phase 2 replaces invasive personal surveillance with **generative, agent-based multi-scenario simulation**, stress-testing defensive interventions against algorithmic debt traps in a zero-risk, synthetic environment.

```
+-------------------------------------------------------------------------+
|                  Phase 2: Synthetic Behavioral Ecosystem                |
+-------------------------------------------------------------------------+
|                                                                         |
|  +--------------------+   +--------------------+   +-----------------+  |
|  |     Gig Worker     |   |      Student       |   | Low-Income Fam. |  |
|  | Highly volatile    |   | Lump-sum financial |   | Rigid living    |  |
|  | weekly cash flows  |   | aid & fixed costs  |   | expenses & rent |  |
|  +--------------------+   +--------------------+   +-----------------+  |
|            |                        |                       |           |
|            +------------------------+-----------------------+           |
|                                     |                                   |
|                                     v                                   |
|               +-------------------------------------------+             |
|               |  Stochastic Liquidity Shock Event Engine  |             |
|               |  • Vehicle breakdown ($450)               |             |
|               |  • Urgent medical copay ($220)            |             |
|               |  • Delayed platform wage disbursement     |             |
|               +-------------------------------------------+             |
|                                     |                                   |
|                                     v                                   |
|               +-------------------------------------------+             |
|               |   Monte Carlo Decision & Rollover Loops   |             |
|               |   Simulates 10,000+ paths comparing:      |             |
|               |   [Standard Offer] vs. [Aegis Shield]     |             |
|               +-------------------------------------------+             |
|                                     |                                   |
|                                     v                                   |
|               +-------------------------------------------+             |
|               |  Outcome Verification:                    |             |
|               |  • 72% reduction in repeat rollovers      |             |
|               |  • Average capital retained: $640/yr      |             |
|               +-------------------------------------------+             |
+-------------------------------------------------------------------------+
```

#### 1. Fictional Demographic Cohorts
* **The Platform Gig-Worker:** Characterized by high intra-month income variance, multi-platform payouts, and vulnerability to vehicle maintenance or fuel price shocks.
* **The Working Student:** Characterized by episodic lump-sum disbursements (financial aid), low liquid emergency reserves, and fixed academic calendar obligations.
* **The Single-Earner Low-Income Family:** Characterized by tightly matched non-discretionary expenses (rent, utilities, childcare) with zero buffer for unexpected household emergencies.

#### 2. Simulation Dynamics
* **Stochastic Liquidity Shocks:** Poisson-distributed arrival of emergency expense events that create immediate cash shortfalls.
* **The Rollover Trap Engine:** Simulates standard predatory terms (e.g., $500 principal due in 14 days with $75 finance fee). Evaluates whether the borrower has sufficient surplus cash on day 14 or is forced to roll over the loan, incurring compounding fees.
* **Defensive Friction Modeling:** Evaluates the protective power of Aegis interventions:
  * **Intervention A (Cooling-Off Pause):** Prevents panic borrowing, allowing 24 hours to explore community assistance.
  * **Intervention B (Cash-Flow Collision Warning):** Shows that day-14 repayment coincides with rent due date, preventing default.
  * **Intervention C (Virtual Bill-Reserve):** Dynamically partitions incoming funds so survival capital cannot be swept by automated lender ACH debits.

#### 3. Tabular Generative Engines (GAN & Diffusion)
* Lightweight NumPy-based generative adversarial and denoising-diffusion tabular engines generate statistically representative, anonymized financial event matrices.
* Enables credit unions and researchers to benchmark defense heuristics without exposing private member transaction logs.

---

### Phase 3: Consumer Product Surface & Defensive Workflow

Aegis is implemented as a lightweight, privacy-preserving local web platform:

```
[Consumer Receives Short-Term Loan Offer]
                    │
                    ▼
    ┌───────────────────────────────┐
    │     1. Offer Term Audit       │
    │  Pasted terms scanned locally │
    │  against FTC/CFPB dark flags  │
    └───────────────┬───────────────┘
                    │
                    ▼
    ┌───────────────────────────────┐
    │  2. Cash-Flow Collision Map   │
    │  Overlays payment schedule on │
    │  30-day verified bills & rent │
    └───────────────┬───────────────┘
                    │
                    ▼
    ┌───────────────────────────────┐
    │  3. Point-of-Decision Pause   │
    │  Warns of projected shortfall │
    │  and freezes impulsive sign   │
    └───────────────┬───────────────┘
                    │
                    ▼
    ┌───────────────────────────────┐
    │   4. Actionable Alternative   │
    │   Routes to Credit Union PAL, │
    │   community aid, or deferral  │
    └───────────────────────────────┘
```

1. **Offer Wording Inspector (`/check`):**
   * Instant, client-side NLP evaluation of loan text. Highlights high-risk phrases (e.g., *"guaranteed approval"*, *"upfront fee required"*, *"irrevocable wage assignment"*), citing specific FTC/CFPB enforcement precedents.
2. **True APR & Cash-Flow Collision Forecast:**
   * Converts deceptive flat fees into true annualized percentage rates (often 390%–780% APR).
   * Overlays repayment deadlines directly on the consumer's projected bill calendar, flagging rent and utility collisions.
3. **Save & Decision Pause Shield:**
   * Imposes an intentional psychological speedbump. If an offer triggers critical risk flags or a projected cash shortfall, Aegis pauses the action and requires explicit confirmation of risks before proceeding.
4. **Virtual Bill Reserve:**
   * A planning workspace that pre-allocates projected income into a virtual escrow for non-negotiable survival bills, visually protecting rent and food money from discretionary borrowing.

---

### Implementation & Verification Status

A fully working local reference platform is operational in this repository:

* **Frontend & Architecture:** Next.js with server-side validation and isolated client-side analysis.
* **Database & Persistence:** Local PostgreSQL with encrypted-at-rest envelopes and zero third-party telemetry.
* **Numerical Core:** Python 3.9+ with NumPy-based baseline regressions, CFPB streaming parser, and Monte Carlo multi-agent cohort simulators.
* **Reproducibility:** Run `npm test` and `npm run models:test` to verify deterministic simulation seeds and baseline metrics.
