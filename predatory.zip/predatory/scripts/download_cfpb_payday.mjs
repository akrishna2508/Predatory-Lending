import { createWriteStream } from 'node:fs';
import { mkdir, mkdtemp, rm } from 'node:fs/promises';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { Readable } from 'node:stream';
import { pipeline } from 'node:stream/promises';

const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const outputDir = path.join(projectRoot, 'data', 'raw', 'cfpb');
await mkdir(outputDir, { recursive: true });
const tempDir = await mkdtemp(path.join(outputDir, '.cfpb-download-'));
const temporaryCsv = path.join(tempDir, 'complaints.csv');
const params = new URLSearchParams({
  search_term: 'payday',
  field: 'all',
  format: 'csv',
  no_aggs: 'true',
  size: '100000',
  sort: 'created_date_desc',
});
const sourceUrl = `https://www.consumerfinance.gov/data-research/consumer-complaints/search/api/v1/?${params}`;

try {
  const response = await fetch(sourceUrl);
  if (!response.ok || !response.body || !(response.headers.get('content-type') || '').toLowerCase().includes('csv')) {
    throw new Error(`CFPB API did not return a CSV export (HTTP ${response.status}).`);
  }
  await pipeline(Readable.fromWeb(response.body), createWriteStream(temporaryCsv, { flags: 'wx', mode: 0o600 }));
  const result = spawnSync('python3', [
    path.join(projectRoot, 'scripts', 'process_cfpb_payday.py'),
    '--input', temporaryCsv,
    '--output-dir', outputDir,
    '--source-url', sourceUrl,
  ], { cwd: projectRoot, stdio: 'inherit' });
  if (result.error) throw result.error;
  if (result.status !== 0) throw new Error(`CFPB data processing failed (exit ${result.status ?? 'unknown'}).`);
} finally {
  await rm(tempDir, { recursive: true, force: true });
}
