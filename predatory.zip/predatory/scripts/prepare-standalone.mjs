import { access, cp, mkdir } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

async function copyIfPresent(source, destination) {
  try {
    await access(source);
  } catch {
    return;
  }
  await mkdir(path.dirname(destination), { recursive: true });
  await cp(source, destination, { recursive: true, force: true });
}

export async function copyStandaloneAssets(root = process.cwd()) {
  await copyIfPresent(
    path.join(root, '.next', 'static'),
    path.join(root, '.next', 'standalone', '.next', 'static'),
  );
  await copyIfPresent(
    path.join(root, 'public'),
    path.join(root, '.next', 'standalone', 'public'),
  );
}

const invokedPath = process.argv[1] ? path.resolve(process.argv[1]) : '';
if (invokedPath && invokedPath === fileURLToPath(import.meta.url)) {
  await copyStandaloneAssets();
}
