import { readdir, readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { Pool } from 'pg';

const connectionString = process.env.AEGIS_MIGRATION_DATABASE_URL;
if (!connectionString) {
  console.error('Set AEGIS_MIGRATION_DATABASE_URL to the local migration-role connection string.');
  process.exit(2);
}

const pool = new Pool({ connectionString, max: 1, connectionTimeoutMillis: 5000 });
let client;
try {
  client = await pool.connect();
  await client.query('CREATE TABLE IF NOT EXISTS aegis_schema_migrations (name text PRIMARY KEY, applied_at timestamptz NOT NULL DEFAULT now())');
  await client.query("SELECT pg_advisory_lock(hashtext('aegis-schema-migrations'))");
  const directory = join(import.meta.dirname, '..', 'db', 'migrations');
  const files = (await readdir(directory)).filter(name => /^\d{4}_[a-z0-9_]+\.sql$/.test(name)).sort();
  for (const name of files) {
    const existing = await client.query('SELECT 1 FROM aegis_schema_migrations WHERE name = $1', [name]);
    if (existing.rows.length) continue;
    await client.query(await readFile(join(directory, name), 'utf8'));
    await client.query('INSERT INTO aegis_schema_migrations(name) VALUES ($1)', [name]);
    console.log(`Applied ${name}`);
  }
  await client.query("SELECT pg_advisory_unlock(hashtext('aegis-schema-migrations'))");
} catch (error) {
  console.error(error instanceof Error ? error.message : 'Database migration failed.');
  process.exitCode = 1;
} finally {
  client?.release();
  await pool.end();
}
