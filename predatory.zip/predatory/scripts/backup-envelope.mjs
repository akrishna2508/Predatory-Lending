import { createCipheriv, createDecipheriv, randomBytes } from 'node:crypto';
import { constants } from 'node:fs';
import { open } from 'node:fs/promises';
import { Transform } from 'node:stream';

const MAGIC = Buffer.from('AEGISBK1', 'ascii');
const NONCE_BYTES = 12;
const TAG_BYTES = 16;
const HEADER_BYTES = MAGIC.length + NONCE_BYTES;
const KEY_BYTES = 32;
export const BACKUP_HEADER_BYTES = HEADER_BYTES;
export const BACKUP_MIN_BYTES = HEADER_BYTES + TAG_BYTES + 1;

export function parseBackupKey(value) {
  if (!value) throw new Error('AEGIS_BACKUP_KEY must contain a base64-encoded 32-byte key.');
  const key = Buffer.from(value, 'base64');
  if (key.byteLength !== KEY_BYTES || key.toString('base64') !== value) {
    throw new Error('AEGIS_BACKUP_KEY must contain a base64-encoded 32-byte key.');
  }
  return key;
}

export async function loadBackupKey({ keyFile = process.env.AEGIS_BACKUP_KEY_FILE, envKey = process.env.AEGIS_BACKUP_KEY } = {}) {
  if (keyFile && envKey) throw new Error('Set either AEGIS_BACKUP_KEY_FILE or AEGIS_BACKUP_KEY, not both.');
  if (!keyFile) return parseBackupKey(envKey);

  const noFollow = constants.O_NOFOLLOW ?? 0;
  const file = await open(keyFile, constants.O_RDONLY | noFollow);
  try {
    const info = await file.stat();
    if (!info.isFile() || (process.platform !== 'win32' && (info.mode & 0o077) !== 0)) {
      throw new Error('Backup key file must be a regular file with owner-only permissions (0600 or stricter).');
    }
    return parseBackupKey((await file.readFile({ encoding: 'utf8' })).trim());
  } finally {
    await file.close();
  }
}

export function createBackupEncryption(key, nonce = randomBytes(NONCE_BYTES)) {
  assertKeyAndNonce(key, nonce);
  const cipher = createCipheriv('aes-256-gcm', key, nonce);
  return {
    header: Buffer.concat([MAGIC, nonce]),
    transform: new Transform({
      transform(chunk, _encoding, callback) {
        try {
          const encrypted = cipher.update(chunk);
          if (encrypted.byteLength) this.push(encrypted);
          callback();
        } catch (error) {
          callback(error instanceof Error ? error : new Error('Backup encryption failed.'));
        }
      },
      flush(callback) {
        try {
          const final = cipher.final();
          if (final.byteLength) this.push(final);
          this.push(cipher.getAuthTag());
          callback();
        } catch (error) {
          callback(error instanceof Error ? error : new Error('Backup encryption failed.'));
        }
      },
    }),
  };
}

export function createBackupDecryption(header, key) {
  if (key.byteLength !== KEY_BYTES) throw new Error('Backup encryption key must be 32 bytes.');
  if (header.byteLength !== HEADER_BYTES || !header.subarray(0, MAGIC.length).equals(MAGIC)) {
    throw new Error('Unsupported or invalid Aegis backup envelope.');
  }
  const decipher = createDecipheriv('aes-256-gcm', key, header.subarray(MAGIC.length));
  let tail = Buffer.alloc(0);
  const tagStripper = new Transform({
    transform(chunk, _encoding, callback) {
      const combined = tail.byteLength ? Buffer.concat([tail, chunk]) : chunk;
      if (combined.byteLength <= TAG_BYTES) {
        tail = Buffer.from(combined);
        callback();
        return;
      }
      const bodyLength = combined.byteLength - TAG_BYTES;
      this.push(combined.subarray(0, bodyLength));
      tail = Buffer.from(combined.subarray(bodyLength));
      callback();
    },
    flush(callback) {
      if (tail.byteLength !== TAG_BYTES) {
        callback(new Error('Backup is truncated or missing its authentication tag.'));
        return;
      }
      try {
        decipher.setAuthTag(tail);
        callback();
      } catch (error) {
        callback(error instanceof Error ? error : new Error('Backup authentication failed.'));
      }
    },
  });
  const transform = new Transform({
    transform(chunk, _encoding, callback) {
      try {
        const decrypted = decipher.update(chunk);
        if (decrypted.byteLength) this.push(decrypted);
        callback();
      } catch (error) {
        callback(error instanceof Error ? error : new Error('Backup decryption failed.'));
      }
    },
    flush(callback) {
      try {
        const final = decipher.final();
        if (final.byteLength) this.push(final);
        callback();
      } catch {
        callback(new Error('Backup authentication failed; key is wrong or backup was changed.'));
      }
    },
  });
  return { tagStripper, transform };
}

function assertKeyAndNonce(key, nonce) {
  if (key.byteLength !== KEY_BYTES) throw new Error('Backup encryption key must be 32 bytes.');
  if (nonce.byteLength !== NONCE_BYTES) throw new Error('Backup nonce must be 12 bytes.');
}
