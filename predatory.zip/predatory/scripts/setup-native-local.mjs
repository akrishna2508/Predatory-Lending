import { existsSync, mkdirSync, writeFileSync } from 'node:fs';
import { randomBytes } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import path from 'node:path';
import { Pool } from 'pg';

// An isolated loopback-only development database; never touches an existing server.
const root = process.cwd();
const directory = path.join(root, '.aegis.local');
const pgBin = process.env.AEGIS_PG_BIN || '/opt/homebrew/opt/postgresql@14/bin';
const port = '55433';
const envFile = path.join(root, '.env.local');
if (existsSync(directory) || existsSync(envFile)) {
  throw new Error('Local setup already exists. Follow LOCAL-ACCESS.local.md to restart it. Existing data was not changed.');
}
mkdirSync(directory, { mode: 0o700 });
function run(binary, args, env = process.env) {
  const result = spawnSync(binary, args, { cwd: root, env, encoding: 'utf8' });
  if (result.status !== 0) throw new Error(result.stderr || result.stdout || String(result.error));
  return result.stdout;
}
const adminPassword = randomBytes(32).toString('hex');
const appPassword = randomBytes(32).toString('hex');
const operatorPassword = randomBytes(32).toString('hex');
const memberPassword = randomBytes(18).toString('base64url');
const partnerPassword = randomBytes(18).toString('base64url');
const passFile = path.join(directory, 'init-password');
writeFileSync(passFile, adminPassword, { mode: 0o600 });
run(path.join(pgBin, 'initdb'), ['-D', path.join(directory, 'db'), '-U', 'aegis_local_admin', '-A', 'scram-sha-256', '--pwfile', passFile, '--no-locale']);
run(path.join(pgBin, 'pg_ctl'), ['-D', path.join(directory, 'db'), '-l', path.join(directory, 'postgres.log'), '-o', `-p ${port} -h 127.0.0.1 -k ${directory}`, '-w', 'start']);
const adminUrl = `postgresql://aegis_local_admin:${adminPassword}@127.0.0.1:${port}/postgres`;
const admin = new Pool({ connectionString: adminUrl });
try {
  await admin.query('CREATE DATABASE aegis');
  await admin.query(`CREATE ROLE aegis_app LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT NOBYPASSRLS PASSWORD '${appPassword}'`);
  await admin.query(`CREATE ROLE aegis_operator LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT NOBYPASSRLS PASSWORD '${operatorPassword}'`);
} finally { await admin.end(); }
const migrationUrl = adminUrl.replace('/postgres', '/aegis');
const appUrl = `postgresql://aegis_app:${appPassword}@127.0.0.1:${port}/aegis`;
const operatorUrl = `postgresql://aegis_operator:${operatorPassword}@127.0.0.1:${port}/aegis`;
const env = { ...process.env, AEGIS_MIGRATION_DATABASE_URL: migrationUrl, AEGIS_PROVISIONING_DATABASE_URL: operatorUrl, AEGIS_OPERATOR_PRINCIPAL: 'local-development-setup', DATABASE_SSL: 'false' };
run(process.execPath, ['scripts/migrate-local.mjs'], env);
const pool = new Pool({ connectionString: migrationUrl });
try {
  await pool.query('GRANT aegis_runtime TO aegis_app');
  await pool.query('ALTER ROLE aegis_app INHERIT');
  await pool.query('GRANT aegis_provisioner TO aegis_operator');
} finally { await pool.end(); }
const organizationOutput = run(process.execPath, ['scripts/provision-organization.mjs', 'Aegis Local Demo CU', 'aegis-local-demo'], env);
const tenantId = organizationOutput.match(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i)?.[0];
if (!tenantId) throw new Error('Organization provisioned but its ID could not be parsed.');
run(process.execPath, ['scripts/provision-membership.mjs', tenantId, 'member@aegis.local', 'member'], { ...env, AEGIS_MEMBER_INITIAL_PASSWORD: memberPassword });
run(process.execPath, ['scripts/provision-membership.mjs', tenantId, 'partner@aegis.local', 'partner_admin'], { ...env, AEGIS_MEMBER_INITIAL_PASSWORD: partnerPassword });
writeFileSync(envFile, `DATABASE_URL=${appUrl}\nDATABASE_SSL=false\nDATABASE_POOL_MAX=10\n`, { mode: 0o600 });
writeFileSync(path.join(directory, 'operator.env'), `AEGIS_MIGRATION_DATABASE_URL=${migrationUrl}\nAEGIS_PROVISIONING_DATABASE_URL=${operatorUrl}\nAEGIS_OPERATOR_PRINCIPAL=local-development-operator\n`, { mode: 0o600 });
writeFileSync(path.join(root, 'LOCAL-ACCESS.local.md'), `# Local Aegis access\n\nThese randomly generated credentials are for fictional local test accounts only. Keep this file private.\n\nMember: member@aegis.local\n\nPassword: ${memberPassword}\n\nPartner: partner@aegis.local\n\nPassword: ${partnerPassword}\n\nOpen http://127.0.0.1:3001/login for member access, or http://127.0.0.1:3001/login?workspace=partner for staff.\n\nDatabase restart:\n\n\`\`\`sh\n${pgBin}/pg_ctl -D '${directory}/db' -l '${directory}/postgres.log' -o '-p ${port} -h 127.0.0.1 -k ${directory}' -w start\n\`\`\`\n\nApp restart (Node 22):\n\n\`\`\`sh\nPORT=3001 node --env-file=.env.local scripts/start-local.mjs\n\`\`\`\n`, { mode: 0o600 });
console.log('Local database and fictional accounts created. Credentials: LOCAL-ACCESS.local.md');
