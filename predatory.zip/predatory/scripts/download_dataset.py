"""Download the openly licensed UCI Statlog German Credit benchmark."""

import argparse
import hashlib
import io
import json
import os
from pathlib import Path
import urllib.request
import zipfile


STATLOG_ARCHIVE_URL = "https://archive.ics.uci.edu/static/public/144/statlog+german+credit+data.zip"
ATTRIBUTION = (
    "Hans Hofmann (1994), Statlog (German Credit Data), UCI Machine Learning Repository.\n"
    "https://doi.org/10.24432/C5NC77\n"
    "Licensed under Creative Commons Attribution 4.0 International (CC BY 4.0).\n"
    "This is a 1,000-record historical German benchmark, not representative U.S. data.\n"
)


def download_statlog(output_dir, opener=urllib.request.urlopen):
    """Fetch and safely write only the expected data file and attribution notice."""
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    data_path = output_dir / "german.data"
    attribution_path = output_dir / "STATLOG-ATTRIBUTION.txt"
    if data_path.exists() or attribution_path.exists():
        raise FileExistsError("Statlog dataset already exists; remove it explicitly before replacing")

    with opener(STATLOG_ARCHIVE_URL, timeout=30) as response:
        chunks = []
        total = 0
        while True:
            block = response.read(1024 * 128)
            if not block:
                break
            total += len(block)
            if total > 10 * 1024 * 1024:
                raise ValueError("UCI Statlog archive exceeded the 10 MB safety limit")
            chunks.append(block)
    archive_bytes = b"".join(chunks)

    try:
        with zipfile.ZipFile(io.BytesIO(archive_bytes)) as archive:
            candidates = [item for item in archive.infolist() if Path(item.filename).name == "german.data"]
            if len(candidates) != 1:
                raise ValueError("UCI archive did not contain german.data")
            data_bytes = archive.read(candidates[0])
    except zipfile.BadZipFile:
        raise ValueError("UCI returned an invalid ZIP archive")

    try:
        with data_path.open("xb") as data_file:
            data_file.write(data_bytes)
            data_file.flush()
            os.fsync(data_file.fileno())
        with attribution_path.open("x", encoding="utf-8") as attribution_file:
            attribution_file.write(ATTRIBUTION)
            attribution_file.flush()
            os.fsync(attribution_file.fileno())
    except Exception:
        for path in (data_path, attribution_path):
            try:
                path.unlink()
            except FileNotFoundError:
                pass
        raise

    return {
        "data_file": str(data_path),
        "attribution_file": str(attribution_path),
        "sha256": hashlib.sha256(data_bytes).hexdigest(),
        "rows": sum(1 for line in data_bytes.splitlines() if line.strip()),
        "license": "CC BY 4.0",
        "source": STATLOG_ARCHIVE_URL,
    }


def main():
    parser = argparse.ArgumentParser(description="Download the openly licensed UCI Statlog German Credit benchmark.")
    parser.add_argument("--output-dir", default="data/raw/statlog-german")
    args = parser.parse_args()
    print(json.dumps(download_statlog(args.output_dir), indent=2))


if __name__ == "__main__":
    main()
