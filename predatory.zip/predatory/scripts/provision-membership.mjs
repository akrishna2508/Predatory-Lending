import { randomBytes, randomUUID, scryptSync } from 'node:crypto';
import { Pool } from 'pg';

const [tenantId, emailArg, role = 'member'] = process.argv.slice(2);
const email = emailArg?.trim().toLowerCase();
const password = process.env.AEGIS_MEMBER_INITIAL_PASSWORD;
const operator = process.env.AEGIS_OPERATOR_PRINCIPAL?.trim();
const connectionString = process.env.AEGIS_PROVISIONING_DATABASE_URL;
const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const allowedRoles = new Set(['member', 'partner_admin', 'partner_analyst']);

if (!uuid.test(tenantId ?? '') || !email || email.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || !allowedRoles.has(role)) {
  console.error('Usage: AEGIS_MEMBER_INITIAL_PASSWORD="..." npm run provision:membership -- <organization-uuid> <email> [member|partner_admin|partner_analyst]');
  process.exit(2);
}
if (!password || password.length < 14 || password.length > 256 || /[\r\n]/.test(password)) {
  console.error('Set AEGIS_MEMBER_INITIAL_PASSWORD to a unique passphrase with at least 14 characters.');
  process.exit(2);
}
if (!connectionString || !operator || operator.length > 160) {
  console.error('AEGIS_PROVISIONING_DATABASE_URL and AEGIS_OPERATOR_PRINCIPAL are required.');
  process.exit(2);
}

const pool = new Pool({ connectionString, max: 1, connectionTimeoutMillis: 5000, ...(process.env.NODE_ENV === 'production' ? { ssl: { rejectUnauthorized: true } } : {}) });
let client;
try {
  client = await pool.connect();
  await client.query('BEGIN');
  await client.query('SET LOCAL ROLE aegis_provisioner');
  const organization = await client.query('SELECT status FROM organizations WHERE id = $1', [tenantId]);
  if (organization.rows[0]?.status !== 'active') throw new Error('An active organization is required.');

  const userId = randomUUID();
  await client.query(
    `INSERT INTO app_users (id, identity_issuer, identity_subject)
     VALUES ($1::uuid, 'aegis:local', $2::text) ON CONFLICT (identity_issuer, identity_subject) DO NOTHING`,
    [userId, userId],
  );
  const salt = randomBytes(16);
  const passwordHash = scryptSync(password, salt, 64, { N: 16384, r: 8, p: 1, maxmem: 64 * 1024 * 1024 });
  await client.query(
    'INSERT INTO local_credentials (user_id, email, password_salt, password_hash) VALUES ($1, $2, $3, $4)',
    [userId, email, salt, passwordHash],
  );
  await client.query(
    `INSERT INTO memberships (tenant_id, user_id, role, status) VALUES ($1, $2, $3, 'active')`,
    [tenantId, userId, role],
  );
  await client.query(
    `INSERT INTO audit_events (tenant_id, actor_user_id, action, entity_type, entity_id, request_id, metadata)
     VALUES ($1, NULL, 'membership.provisioned', 'membership', $2, $3, $4::jsonb)`,
    [tenantId, userId, randomUUID(), JSON.stringify({ role, operator_principal: operator })],
  );
  await client.query('COMMIT');
  console.log(`Active ${role} membership provisioned for ${email} in organization ${tenantId}. Share the initial passphrase through a private channel.`);
} catch (error) {
  if (client) { try { await client.query('ROLLBACK'); } catch { /* Keep the original failure. */ } }
  console.error(error instanceof Error ? error.message : 'Membership provisioning failed.');
  process.exitCode = 1;
} finally {
  client?.release();
  await pool.end();
}
