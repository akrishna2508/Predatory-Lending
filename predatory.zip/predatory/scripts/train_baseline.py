"""Train one labeled public-data benchmark and write aggregate metrics only."""

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from scripts.aegis_models.baseline import fit_logistic_baseline
from scripts.aegis_models.sources import FEATURE_NAMES, SOURCE_CATALOG, SourceDataError, iter_canonical_rows


def build_baseline_report(source, input_path, row_limit=20000, seed=42, confirm_source_terms=False):
    if source not in SOURCE_CATALOG:
        raise SourceDataError("unsupported source: {}".format(source))
    metadata = SOURCE_CATALOG[source]
    if metadata.get("requires_terms_confirmation") and not confirm_source_terms:
        raise SourceDataError("confirm the source's permitted use before training this dataset")
    rows = list(iter_canonical_rows(input_path, source, row_limit=row_limit))
    if not rows:
        raise SourceDataError("no usable labeled rows were found")
    feature_names = list(rows[0]["features"].keys()) if source == "fico" else FEATURE_NAMES[source]
    result = fit_logistic_baseline(rows, feature_names, seed=seed)
    result.update({
        "source": {key: metadata[key] for key in ("name", "url", "license", "use", "caveat", "label")},
        "trained_at": datetime.now(timezone.utc).isoformat(),
        "source_terms_confirmed": bool(confirm_source_terms),
        "raw_rows_saved": False,
    })
    return result


def _write_json(value, output):
    content = json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n"
    if output == "-":
        sys.stdout.write(content)
        return
    path = Path(output)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".tmp")
    temp.write_text(content, encoding="utf-8")
    temp.replace(path)


def main(argv=None):
    parser = argparse.ArgumentParser(description="Train a local Aegis baseline model from an eligible labeled dataset.")
    parser.add_argument("--source", choices=sorted(SOURCE_CATALOG), required=True)
    parser.add_argument("--input", required=True, help="Path to a local source file")
    parser.add_argument("--output", default="data/results/baseline-latest.json", help="JSON path or - for stdout")
    parser.add_argument("--row-limit", type=int, default=20000)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--confirm-source-terms", action="store_true", help="Confirm you have checked and will follow the source terms")
    args = parser.parse_args(argv)
    if args.row_limit < 10:
        parser.error("--row-limit must be at least 10")
    report = build_baseline_report(args.source, args.input, args.row_limit, args.seed, args.confirm_source_terms)
    _write_json(report, args.output)


if __name__ == "__main__":
    main()
