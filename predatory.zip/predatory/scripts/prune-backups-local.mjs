import { pruneBackups } from './backup-retention.mjs';

if (process.argv.length > 3) throw new Error('Usage: npm run db:prune-backups:local -- [backup-directory]');
const directory = process.argv[2] ?? process.env.AEGIS_BACKUP_DIRECTORY ?? 'backups';
const retentionDays = Number(process.env.AEGIS_BACKUP_RETENTION_DAYS ?? 35);
const removed = await pruneBackups(directory, retentionDays);
console.log(`Removed ${removed} encrypted backup(s) older than ${retentionDays} days.`);
