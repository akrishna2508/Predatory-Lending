"""Run an aggregate synthetic financial-behavior scenario."""

import argparse
import csv
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from scripts.aegis_models.generators import sample_diffusion, sample_gan, train_diffusion, train_gan
from scripts.aegis_models.simulation import PROFILE_TYPES, generate_training_rows, run_monte_carlo


SYNTHETIC_FEATURES = [
    "income_variability", "days_until_payday_ratio", "cash_shortfall_ratio",
    "synthetic_impulse", "synthetic_stress_sensitivity",
]
SYNTHETIC_PROVENANCE = "experimental_synthetic"


def _write_json(value, output):
    content = json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n"
    if output == "-":
        sys.stdout.write(content)
        return
    path = Path(output)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".tmp")
    temp.write_text(content, encoding="utf-8")
    temp.replace(path)


def _write_synthetic_csv(rows, output):
    path = Path(output)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".tmp")
    with temp.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow([*SYNTHETIC_FEATURES, "provenance"])
        writer.writerows([
            [*[round(float(value), 6) for value in row], SYNTHETIC_PROVENANCE]
            for row in rows
        ])
    temp.replace(path)
    return str(path)


def run(profile, trials, seed, engine="none", samples=500, synthetic_output=None):
    report = run_monte_carlo(profile, trials=trials, seed=seed)
    if engine == "none":
        return report
    if engine not in ("gan", "diffusion"):
        raise ValueError("unsupported generator engine")
    if synthetic_output is None:
        raise ValueError("synthetic_output is required when a generator engine is selected")
    training_rows = generate_training_rows(profile, count=max(300, samples), seed=seed + 1)
    if engine == "gan":
        model = train_gan(training_rows, seed=seed, steps=300)
        generated = sample_gan(model, count=samples, seed=seed + 2)
        engine_name = "NumPy MLP GAN (experimental)"
    else:
        model = train_diffusion(training_rows, seed=seed, steps=max(1000, samples), timesteps=16)
        generated = sample_diffusion(model, count=samples, seed=seed + 2)
        engine_name = "Linear denoising diffusion (experimental)"
    report["generator"] = {
        "engine": engine_name,
        "provenance": SYNTHETIC_PROVENANCE,
        "rows_generated": int(len(generated)),
        "features": SYNTHETIC_FEATURES,
        "artifact": _write_synthetic_csv(generated, synthetic_output),
        "caveat": "Generated only from fictional simulation rows; not a privacy guarantee or a real-person profile.",
    }
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description="Run a fictional Aegis cash-flow and loan-trigger simulation.")
    parser.add_argument("--profile", choices=PROFILE_TYPES, required=True)
    parser.add_argument("--trials", type=int, default=1000)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--engine", choices=("none", "gan", "diffusion"), default="none")
    parser.add_argument("--samples", type=int, default=500)
    parser.add_argument("--synthetic-output", help="CSV path for generated numeric rows")
    parser.add_argument("--output", default="data/results/simulation-latest.json", help="JSON path or - for stdout")
    args = parser.parse_args(argv)
    if args.trials < 1 or args.trials > 100000:
        parser.error("--trials must be between 1 and 100000")
    if args.samples < 1 or args.samples > 100000:
        parser.error("--samples must be between 1 and 100000")
    _write_json(run(args.profile, args.trials, args.seed, args.engine, args.samples, args.synthetic_output), args.output)


if __name__ == "__main__":
    main()
