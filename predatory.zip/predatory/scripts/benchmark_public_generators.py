"""Evaluate experimental GAN and diffusion samplers on an open credit matrix.

Only aggregate holdout comparisons are written. Generated borrower-level rows
are discarded and are never used by the member offer check.
"""

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import sys

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from scripts.aegis_models.generators import sample_diffusion, sample_gan, train_diffusion, train_gan
from scripts.aegis_models.sources import FEATURE_NAMES, SOURCE_CATALOG, iter_canonical_rows


OPEN_SOURCES = ("statlog-german", "lendingclub")


def _correlation(values):
    centered = values - np.mean(values, axis=0)
    scale = np.std(values, axis=0)
    standardized = centered / np.where(scale < 1e-12, 1.0, scale)
    return np.clip(standardized.T @ standardized / len(values), -1.0, 1.0)


def _holdout_distances(generated, holdout, training):
    span = np.max(training, axis=0) - np.min(training, axis=0)
    span = np.where(span < 1e-12, 1.0, span)
    mean_distance = np.mean(np.abs(np.mean(generated, axis=0) - np.mean(holdout, axis=0)) / span)
    spread_distance = np.mean(np.abs(np.std(generated, axis=0) - np.std(holdout, axis=0)) / span)
    upper = np.triu_indices(training.shape[1], k=1)
    correlation_distance = np.mean(np.abs(_correlation(generated)[upper] - _correlation(holdout)[upper]))
    return {
        "mean_distance_scaled": round(float(mean_distance), 6),
        "spread_distance_scaled": round(float(spread_distance), 6),
        "correlation_distance": round(float(correlation_distance), 6),
    }


def benchmark_public_generators(source, input_path, row_limit=1000, samples=500, seed=42):
    if source not in OPEN_SOURCES:
        raise ValueError("generator benchmark only accepts openly available Statlog or LendingClub data")
    if row_limit < 100 or row_limit > 50000 or samples < 20 or samples > 5000:
        raise ValueError("row_limit must be 100–50000 and samples must be 20–5000")
    if seed < 0 or seed > 2147483647:
        raise ValueError("seed must be between 0 and 2147483647")

    features = FEATURE_NAMES[source]
    records = list(iter_canonical_rows(input_path, source, row_limit=row_limit))
    if len(records) < 100:
        raise ValueError("at least 100 usable public records are required")
    matrix = np.asarray([[record["features"][name] for name in features] for record in records], dtype=float)
    rng = np.random.default_rng(seed)
    indices = rng.permutation(len(matrix))
    test_count = max(20, round(len(matrix) * 0.2))
    training, holdout = matrix[indices[test_count:]], matrix[indices[:test_count]]

    gan = train_gan(training, seed=seed, steps=300)
    diffusion = train_diffusion(training, seed=seed, steps=1000, timesteps=16)
    generated = {
        "gan": sample_gan(gan, count=samples, seed=seed + 1),
        "diffusion": sample_diffusion(diffusion, count=samples, seed=seed + 2),
    }
    return {
        "source": {key: SOURCE_CATALOG[source][key] for key in ("name", "url", "license", "caveat")},
        "source_id": source,
        "trained_at": datetime.now(timezone.utc).isoformat(),
        "seed": seed,
        "feature_names": features,
        "rows_used": len(matrix),
        "train_rows": len(training),
        "holdout_rows": len(holdout),
        "generated_rows_per_engine": samples,
        "engines": {
            engine: {
                "name": "NumPy MLP GAN (experimental)" if engine == "gan" else "Linear denoising diffusion (experimental)",
                "holdout_distances": _holdout_distances(values, holdout, training),
            }
            for engine, values in generated.items()
        },
        "generated_rows_saved": False,
        "caveat": "Aggregate distribution checks only. No privacy or predictive validity claim; these samplers do not detect predatory lending or infer personal traits.",
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description="Benchmark experimental generators on an open public credit matrix.")
    parser.add_argument("--source", choices=OPEN_SOURCES, required=True)
    parser.add_argument("--input", required=True)
    parser.add_argument("--row-limit", type=int, default=1000)
    parser.add_argument("--samples", type=int, default=500)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--output", default="data/results/generator-benchmark-latest.json")
    args = parser.parse_args(argv)
    report = benchmark_public_generators(args.source, args.input, args.row_limit, args.samples, args.seed)
    content = json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + "\n"
    if args.output == "-":
        sys.stdout.write(content)
        return
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_name(output.name + ".tmp")
    temporary.write_text(content, encoding="utf-8")
    temporary.replace(output)


if __name__ == "__main__":
    main()
