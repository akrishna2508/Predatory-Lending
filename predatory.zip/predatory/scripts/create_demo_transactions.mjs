import { writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const today = new Date();
const dateAt = days => new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), today.getUTCDate() + days)).toISOString().slice(0, 10);
const rows = [
  ['Date', 'Description', 'Amount'],
  [dateAt(-35), 'Payday loan payment', '-88.00'],
  [dateAt(-21), 'Payday loan payment', '-88.00'],
  [dateAt(-7), 'Payday loan payment', '-88.00'],
  [dateAt(-30), 'Overdraft fee', '-34.00'],
  [dateAt(-14), 'Overdraft fee', '-34.00'],
  [dateAt(-28), 'Gig income', '500.00'],
  [dateAt(-14), 'Gig income', '190.00'],
  [dateAt(0), 'Gig income', '440.00'],
];
const output = path.join(root, 'examples', 'shield-demo-transactions.csv');
await writeFile(output, rows.map(row => row.join(',')).join('\n') + '\n');
process.stdout.write(`Updated ${output} with fictional transactions dated relative to ${dateAt(0)}.\n`);
