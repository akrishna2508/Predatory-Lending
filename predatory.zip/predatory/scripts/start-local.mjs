import { spawn } from 'node:child_process';
import { existsSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

export function buildLocalServerEnv(env = process.env, projectRoot = process.cwd()) {
  return { ...env, AEGIS_PROJECT_ROOT: path.resolve(projectRoot), HOSTNAME: '127.0.0.1' };
}

export function startStandaloneServer(root = process.cwd(), args = process.argv.slice(2)) {
  const envFile = path.join(root, '.env.local');
  if (existsSync(envFile)) process.loadEnvFile(envFile);
  const serverPath = path.join(root, '.next', 'standalone', 'server.js');
  const child = spawn(process.execPath, [serverPath, ...args], {
    cwd: root,
    env: buildLocalServerEnv(process.env, root),
    stdio: 'inherit',
  });
  process.once('SIGINT', () => child.kill('SIGINT'));
  process.once('SIGTERM', () => child.kill('SIGTERM'));
  child.once('error', (error) => {
    console.error('Could not start the local Aegis server.', error);
    process.exitCode = 1;
  });
  child.once('exit', (code, signal) => {
    process.exitCode = code ?? (signal === 'SIGINT' ? 0 : 1);
  });
}

const invokedPath = process.argv[1] ? path.resolve(process.argv[1]) : '';
if (invokedPath && invokedPath === fileURLToPath(import.meta.url)) {
  startStandaloneServer();
}
