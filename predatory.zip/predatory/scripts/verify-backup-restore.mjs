import { copyFile, mkdtemp, open, rm, stat } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { randomBytes } from 'node:crypto';
import { spawn } from 'node:child_process';
import { assertRestoreConfirmation, parseLocalDatabaseUrl } from './local-database-url.mjs';
import { BACKUP_HEADER_BYTES, loadBackupKey } from './backup-envelope.mjs';

const source = parseLocalDatabaseUrl(process.env.AEGIS_BACKUP_DATABASE_URL, 'AEGIS_BACKUP_DATABASE_URL');
assertRestoreConfirmation(source.databaseName, process.env.AEGIS_VERIFY_BACKUP_CONFIRM_SOURCE);
await loadBackupKey();
const suffix = randomBytes(5).toString('hex');
const restoreDatabase = `aegis_restore_verify_${suffix}`;
const corruptDatabase = `aegis_corrupt_verify_${suffix}`;
const restoreUrl = withDatabaseName(source.connectionString, restoreDatabase);
const corruptUrl = withDatabaseName(source.connectionString, corruptDatabase);
const scratch = await mkdtemp(join(tmpdir(), 'aegis-backup-verify-'));
const backupPath = join(scratch, 'source.aegisbackup');
const corruptPath = join(scratch, 'corrupt.aegisbackup');

try {
  await run('psql', ['--no-psqlrc', '--set=ON_ERROR_STOP=1', `--dbname=${source.connectionString}`, `--command=CREATE DATABASE ${restoreDatabase}`]);
  await run('psql', ['--no-psqlrc', '--set=ON_ERROR_STOP=1', `--dbname=${source.connectionString}`, `--command=CREATE DATABASE ${corruptDatabase}`]);
  await run(process.execPath, [new URL('./backup-local.mjs', import.meta.url).pathname, backupPath], {
    AEGIS_BACKUP_DATABASE_URL: source.connectionString,
    AEGIS_BACKUP_KEY: process.env.AEGIS_BACKUP_KEY,
  });
  const backupBeforeCollision = await stat(backupPath);
  const collision = await run(process.execPath, [new URL('./backup-local.mjs', import.meta.url).pathname, backupPath], {
    AEGIS_BACKUP_DATABASE_URL: source.connectionString,
    AEGIS_BACKUP_KEY: process.env.AEGIS_BACKUP_KEY,
  }, { allowFailure: true });
  const backupAfterCollision = await stat(backupPath);
  if (collision.code === 0 || backupBeforeCollision.ino !== backupAfterCollision.ino || backupBeforeCollision.size !== backupAfterCollision.size) {
    throw new Error('Backup output collision unexpectedly overwrote an existing backup.');
  }
  await run(process.execPath, [new URL('./restore-local.mjs', import.meta.url).pathname, backupPath], {
    AEGIS_RESTORE_DATABASE_URL: restoreUrl,
    AEGIS_RESTORE_CONFIRM_DATABASE: restoreDatabase,
    AEGIS_BACKUP_KEY: process.env.AEGIS_BACKUP_KEY,
  });

  const sourceState = await querySchemaState(source.connectionString);
  const restoredState = await querySchemaState(restoreUrl);
  if (JSON.stringify(sourceState) !== JSON.stringify(restoredState)) {
    throw new Error('Restored database schema inventory does not match the source.');
  }

  await copyFile(backupPath, corruptPath);
  const corruptFile = await open(corruptPath, 'r+');
  try {
    const byte = Buffer.alloc(1);
    await corruptFile.read(byte, 0, 1, BACKUP_HEADER_BYTES);
    byte[0] ^= 1;
    await corruptFile.write(byte, 0, 1, BACKUP_HEADER_BYTES);
  } finally {
    await corruptFile.close();
  }
  const corruptRestore = await run(process.execPath, [new URL('./restore-local.mjs', import.meta.url).pathname, corruptPath], {
    AEGIS_RESTORE_DATABASE_URL: corruptUrl,
    AEGIS_RESTORE_CONFIRM_DATABASE: corruptDatabase,
    AEGIS_BACKUP_KEY: process.env.AEGIS_BACKUP_KEY,
  }, { allowFailure: true });
  if (corruptRestore.code === 0) throw new Error('A corrupted backup unexpectedly restored.');
  const remainingObjects = Number(await run('psql', [
    '--no-psqlrc', '--quiet', '--tuples-only', '--no-align', '--set=ON_ERROR_STOP=1',
    `--dbname=${corruptUrl}`, "--command=SELECT count(*) FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace WHERE n.nspname = 'public' AND c.relkind IN ('r', 'p', 'v', 'm', 'S', 'f', 'c')",
  ]));
  if (remainingObjects !== 0) throw new Error('Corrupted restore left database objects behind.');
  console.log('Encrypted backup/restore drill passed; tampered backup was rejected and rolled back.');
} finally {
  await dropDatabase(source.connectionString, corruptDatabase).catch(() => {});
  await dropDatabase(source.connectionString, restoreDatabase).catch(() => {});
  await rm(scratch, { recursive: true, force: true });
}

async function querySchemaState(connectionString) {
  const result = await run('psql', [
    '--no-psqlrc', '--quiet', '--tuples-only', '--no-align', '--set=ON_ERROR_STOP=1',
    `--dbname=${connectionString}`,
  `--command=SELECT json_build_object(
      'tables', (SELECT coalesce(json_agg(tablename ORDER BY tablename), '[]'::json) FROM pg_tables WHERE schemaname = 'public'),
      'forcedRlsTables', (SELECT count(*) FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace WHERE n.nspname = 'public' AND c.relkind IN ('r', 'p') AND c.relrowsecurity AND c.relforcerowsecurity)
    )::text`,
  ]);
  try { return JSON.parse(result); }
  catch { throw new Error('Backup drill could not inspect the restored database schema.'); }
}

async function dropDatabase(connectionString, databaseName) {
  await run('psql', ['--no-psqlrc', '--set=ON_ERROR_STOP=1', `--dbname=${connectionString}`, `--command=DROP DATABASE IF EXISTS ${databaseName} WITH (FORCE)`]);
}

function withDatabaseName(connectionString, databaseName) {
  const url = new URL(connectionString);
  url.pathname = `/${databaseName}`;
  url.searchParams.delete('dbname');
  return url.toString();
}

function run(command, args, overrides = {}, { allowFailure = false } = {}) {
  const env = { ...process.env, ...overrides };
  if (command !== process.execPath) {
    delete env.AEGIS_BACKUP_KEY;
    delete env.AEGIS_BACKUP_KEY_FILE;
    delete env.AEGIS_BACKUP_DATABASE_URL;
    delete env.AEGIS_RESTORE_DATABASE_URL;
    delete env.AEGIS_RESTORE_CONFIRM_DATABASE;
    delete env.AEGIS_VERIFY_BACKUP_CONFIRM_SOURCE;
  }

  const child = spawn(command, args, { stdio: ['ignore', 'pipe', 'ignore'], env });
  const chunks = [];
  child.stdout.on('data', chunk => chunks.push(chunk));
  return new Promise((resolveRun, reject) => {
    child.once('error', () => reject(new Error(`${command} could not be started.`)));
    child.once('close', code => {
      const output = Buffer.concat(chunks).toString('utf8').trim();
      if (code !== 0 && !allowFailure) reject(new Error(`${command} failed with exit code ${code ?? 'unknown'}.`));
      else resolveRun(allowFailure ? { code, output } : output);
    });
  });
}
