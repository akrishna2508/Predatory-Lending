"""Keep a minimal metadata-only slice from a CFPB complaint CSV export."""

import argparse
import csv
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import tempfile


MAX_SOURCE_ROWS = 100_000
OUTPUT_COLUMNS = ["Date received", "Product", "Issue", "Company"]


def minimize_payday_complaints(input_path, output_dir, source_url):
    input_path = Path(input_path)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = output_dir / "payday-complaints.csv"
    metadata_path = output_dir / "metadata.json"
    temp_path = None

    try:
        with input_path.open("r", encoding="utf-8-sig", errors="replace", newline="") as source_file:
            reader = csv.DictReader(source_file)
            if not reader.fieldnames:
                raise RuntimeError("CFPB export has no CSV header.")
            missing = [column for column in OUTPUT_COLUMNS if column not in reader.fieldnames]
            if missing:
                raise RuntimeError("CFPB export is missing columns: {}.".format(", ".join(missing)))

            with tempfile.NamedTemporaryFile("w", encoding="utf-8", newline="", dir=output_dir, delete=False) as output_file:
                temp_path = Path(output_file.name)
                writer = csv.DictWriter(output_file, fieldnames=OUTPUT_COLUMNS)
                writer.writeheader()
                source_rows = 0
                kept_rows = 0
                digest = hashlib.sha256()
                for row in reader:
                    source_rows += 1
                    if source_rows > MAX_SOURCE_ROWS:
                        raise RuntimeError("CFPB filtered export exceeded the documented 100,000-row limit.")
                    projected = {column: (row.get(column) or "").strip() for column in OUTPUT_COLUMNS}
                    if "payday" not in projected["Product"].casefold():
                        continue
                    writer.writerow(projected)
                    digest.update(("\x1f".join(projected[column] for column in OUTPUT_COLUMNS) + "\n").encode("utf-8"))
                    kept_rows += 1

        if kept_rows == 0:
            raise RuntimeError("CFPB export contained no payday-product complaint rows.")
        os.replace(temp_path, output_path)
        temp_path = None
        metadata = {
            "source": "CFPB Consumer Complaint Database",
            "source_url": "https://www.consumerfinance.gov/data-research/consumer-complaints/",
            "retrieval_api_url": source_url,
            "query": {"search_term": "payday", "field": "all"},
            "retrieved_at_utc": datetime.now(timezone.utc).isoformat(),
            "source_rows_examined": source_rows,
            "payday_product_rows_kept": kept_rows,
            "columns_kept": OUTPUT_COLUMNS,
            "sha256_minimized_rows": digest.hexdigest(),
            "notes": [
                "Public complaints are not verified findings and are not representative of all consumers.",
                "Current CFPB exports are metadata-only; this file is market context, not default labels.",
                "Only payday-product rows and date, product, issue, and company columns are retained.",
                "Location, complaint identifiers, and narrative text are not retained.",
            ],
        }
        metadata_path.write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")
        return metadata
    finally:
        if temp_path is not None:
            temp_path.unlink(missing_ok=True)


def main():
    parser = argparse.ArgumentParser(description="Minimize a CFPB export to payday complaint metadata.")
    parser.add_argument("--input", required=True, help="CSV export downloaded from the CFPB public API")
    parser.add_argument("--output-dir", default="data/raw/cfpb")
    parser.add_argument("--source-url", required=True, help="Full CFPB API query URL")
    args = parser.parse_args()
    print(json.dumps(minimize_payday_complaints(args.input, args.output_dir, args.source_url), indent=2))


if __name__ == "__main__":
    main()
