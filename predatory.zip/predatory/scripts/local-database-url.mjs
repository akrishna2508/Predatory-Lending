const LOOPBACK_HOSTS = new Set(['localhost', '127.0.0.1', '::1']);

export function parseLocalDatabaseUrl(value, variableName) {
  if (typeof value !== 'string' || value.trim() === '') {
    throw new Error(`${variableName} is required.`);
  }

  let url;
  try {
    url = new URL(value);
  } catch {
    throw new Error(`${variableName} must be a valid PostgreSQL URL.`);
  }
  if (!['postgres:', 'postgresql:'].includes(url.protocol)) {
    throw new Error(`${variableName} must use PostgreSQL.`);
  }
  if (url.password) {
    throw new Error(`${variableName} must not contain a password; use PostgreSQL peer auth or PGPASSFILE.`);
  }
  if ([...url.searchParams.keys()].some(key => ['password', 'sslpassword'].includes(key.toLowerCase()))) {
    throw new Error(`${variableName} must not contain a password; use PostgreSQL peer auth or PGPASSFILE.`);
  }

  const urlHost = normalizeHost(url.hostname);
  const queryHost = url.searchParams.get('host');
  const effectiveHost = queryHost ?? urlHost;
  if (queryHost && urlHost && normalizeHost(queryHost) !== urlHost) {
    throw new Error(`${variableName} has conflicting host settings.`);
  }
  if (effectiveHost && !isLocalHost(effectiveHost)) {
    throw new Error(`${variableName} must use loopback or a Unix-domain socket.`);
  }

  const hostAddress = url.searchParams.get('hostaddr');
  if (hostAddress && !isLocalHost(hostAddress)) {
    throw new Error(`${variableName} must use a loopback host address.`);
  }

  const pathDatabase = decodeURIComponent(url.pathname.replace(/^\/+/, ''));
  const queryDatabase = url.searchParams.get('dbname');
  if (pathDatabase && queryDatabase && pathDatabase !== queryDatabase) {
    throw new Error(`${variableName} has conflicting database names.`);
  }
  const databaseName = queryDatabase ?? pathDatabase;
  if (!databaseName || databaseName.includes('/') || databaseName.includes('\0')) {
    throw new Error(`${variableName} must name a PostgreSQL database.`);
  }
  return { connectionString: value, databaseName };
}

export function assertRestoreConfirmation(databaseName, confirmation) {
  if (typeof confirmation !== 'string' || confirmation !== databaseName) {
    throw new Error('Set AEGIS_RESTORE_CONFIRM_DATABASE to the exact target database name.');
  }
}

function normalizeHost(host) {
  return host.toLowerCase().replace(/^\[|\]$/g, '');
}

function isLocalHost(host) {
  const normalized = normalizeHost(host);
  return normalized.startsWith('/') || normalized === '' || LOOPBACK_HOSTS.has(normalized);
}
