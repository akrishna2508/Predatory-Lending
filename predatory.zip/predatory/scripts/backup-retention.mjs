import { lstat, readdir, unlink } from 'node:fs/promises';
import { join, resolve } from 'node:path';

export async function pruneBackups(directory, retentionDays = 35, now = Date.now()) {
  if (!Number.isSafeInteger(retentionDays) || retentionDays < 1 || retentionDays > 365) {
    throw new Error('Backup retention must be a whole number from 1 to 365 days.');
  }
  const resolved = resolve(directory);
  const directoryInfo = await lstat(resolved);
  if (!directoryInfo.isDirectory() || directoryInfo.isSymbolicLink()) {
    throw new Error('Backup retention path must be a real directory, not a symbolic link.');
  }
  const cutoff = now - retentionDays * 24 * 60 * 60 * 1_000;
  const entries = await readdir(resolved, { withFileTypes: true });
  let removed = 0;
  for (const entry of entries) {
    if (!entry.isFile() || !entry.name.endsWith('.aegisbackup')) continue;
    const filePath = join(resolved, entry.name);
    const fileInfo = await lstat(filePath);
    if (fileInfo.isFile() && !fileInfo.isSymbolicLink() && fileInfo.mtimeMs < cutoff) {
      await unlink(filePath);
      removed++;
    }
  }
  return removed;
}
