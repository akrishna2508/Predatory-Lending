"""Seeded, synthetic-only cash-flow and short-term-loan agent simulations."""

import math
import random


PROFILE_TYPES = ("gig-worker", "student", "low-income-family")
SCENARIO_CAVEAT = "scenario_only: generated assumptions are fictional and are not predictions about people."

_CONFIGS = {
    "gig-worker": {
        "opening": (250.0, 850.0),
        "paydays": (2, 9, 16, 23, 30),
        "income": (260.0, 480.0),
        "rent": 680.0,
        "bills": ((4, 105.0), (11, 125.0), (18, 105.0), (25, 135.0)),
        "impulse": (0.25, 0.85),
        "stress": (0.20, 0.90),
    },
    "student": {
        "opening": (180.0, 650.0),
        "paydays": (5, 19),
        "income": (420.0, 820.0),
        "rent": 720.0,
        "bills": ((3, 95.0), (10, 150.0), (17, 110.0), (24, 145.0)),
        "impulse": (0.20, 0.80),
        "stress": (0.25, 0.90),
    },
    "low-income-family": {
        "opening": (300.0, 1000.0),
        "paydays": (6, 20),
        "income": (820.0, 1250.0),
        "rent": 900.0,
        "bills": ((4, 140.0), (8, 130.0), (15, 170.0), (22, 135.0), (28, 115.0)),
        "impulse": (0.10, 0.70),
        "stress": (0.25, 0.95),
    },
}


def _clamp(value, low=0.0, high=1.0):
    return max(low, min(high, value))


def _event(day, kind, amount, label):
    return {"day": int(day), "kind": kind, "amount": round(float(amount), 2), "label": label, "provenance": "synthetic"}


def generate_profile(profile_type, rng):
    """Generate one fictional 30-day profile. Latent traits are random simulation knobs only."""
    if profile_type not in _CONFIGS:
        raise ValueError("unsupported profile: {}".format(profile_type))
    config = _CONFIGS[profile_type]
    events = [_event(1, "bill", -config["rent"], "housing")]
    payday_days = []
    for day in config["paydays"]:
        amount = rng.uniform(*config["income"])
        events.append(_event(day, "income", amount, "synthetic income"))
        payday_days.append(day)
    for day, amount in config["bills"]:
        events.append(_event(day, "bill", -amount, "essential bill"))
    if rng.random() < 0.4:
        stress_day = rng.randint(2, 28)
        stress_cost = rng.uniform(90.0, 420.0)
        events.append(_event(stress_day, "stress-expense", -stress_cost, "synthetic stress event"))
    events.sort(key=lambda item: (item["day"], 0 if item["kind"] == "income" else 1, item["kind"]))
    return {
        "profile_type": profile_type,
        "starting_balance": round(rng.uniform(*config["opening"]), 2),
        "events": events,
        "payday_days": payday_days,
        "decision_day": rng.randint(3, 25),
        "offer_principal": round(rng.uniform(300.0, 800.0), 2),
        "fee_ratio": round(rng.uniform(0.20, 0.55), 3),
        "synthetic_impulse": round(rng.uniform(*config["impulse"]), 4),
        "synthetic_stress_sensitivity": round(rng.uniform(*config["stress"]), 4),
        "provenance": "synthetic",
    }


def loan_temptation(shortfall, days_until_payday, fee_ratio, impulse, stress):
    """Return a bounded synthetic trigger propensity, not a psychological assessment."""
    shortfall_pressure = _clamp(max(0.0, shortfall) / 900.0)
    payday_wait = _clamp(max(0.0, days_until_payday) / 14.0)
    fee_pressure = _clamp(max(0.0, fee_ratio) / 0.65)
    return round(_clamp(
        0.30 * shortfall_pressure
        + 0.22 * payday_wait
        + 0.18 * fee_pressure
        + 0.16 * _clamp(impulse)
        + 0.14 * _clamp(stress)
    ), 6)


def _min_balance(profile, extra_events=()):
    balance = float(profile["starting_balance"])
    minimum = balance
    entries = sorted(list(profile["events"]) + list(extra_events), key=lambda item: (item["day"], 0 if item["kind"] == "income" else 1))
    for item in entries:
        balance += item["amount"]
        minimum = min(minimum, balance)
    return minimum


def simulate_agent(profile, rng):
    """Run one generated profile through a fictional loan offer and return internal metrics."""
    decision_day = profile["decision_day"]
    future_paydays = [day for day in profile["payday_days"] if day > decision_day]
    next_payday = future_paydays[0] if future_paydays else min(profile["payday_days"]) + 30
    days_until_payday = max(0, next_payday - decision_day)
    balance_at_decision = profile["starting_balance"] + sum(
        event["amount"] for event in profile["events"] if event["day"] <= decision_day
    )
    projected_pre_payday = balance_at_decision + sum(
        event["amount"] for event in profile["events"] if decision_day < event["day"] <= next_payday
    )
    shortfall_need = max(0.0, -projected_pre_payday)
    temptation = loan_temptation(
        shortfall_need,
        days_until_payday,
        profile["fee_ratio"],
        profile["synthetic_impulse"],
        profile["synthetic_stress_sensitivity"],
    )
    accept_probability = 1.0 / (1.0 + math.exp(-8.0 * (temptation - 0.48)))
    accepted = rng.random() < accept_probability
    principal = profile["offer_principal"]
    fee = principal * profile["fee_ratio"]
    loan_events = []
    if accepted:
        loan_events.append(_event(decision_day, "income", principal, "simulated loan proceeds"))
        loan_events.append(_event(min(30, next_payday), "bill", -(principal + fee), "simulated loan repayment"))
    baseline_min = _min_balance(profile)
    with_offer_min = _min_balance(profile, loan_events)
    repeated = False
    if accepted and with_offer_min < 0:
        repeat_probability = _clamp(0.20 * profile["synthetic_impulse"] + 0.25 * profile["synthetic_stress_sensitivity"] + 0.35 * shortfall_need / 900.0)
        repeated = rng.random() < repeat_probability
    return {
        "accepted": bool(accepted),
        "baseline_shortfall": baseline_min < 0,
        "with_offer_shortfall": with_offer_min < 0,
        "repeat_borrowing": bool(repeated),
        "payday_captured": bool(accepted and next_payday <= 30),
        "temptation": temptation,
        "accepted_fee": fee if accepted else 0.0,
        "decision_shortfall": shortfall_need,
        "income_wait_days": days_until_payday,
        "income_variability": _income_variability(profile),
        "synthetic_impulse": profile["synthetic_impulse"],
        "synthetic_stress": profile["synthetic_stress_sensitivity"],
    }


def _income_variability(profile):
    amounts = [event["amount"] for event in profile["events"] if event["kind"] == "income"]
    if len(amounts) < 2:
        return 0.0
    mean = sum(amounts) / len(amounts)
    if mean <= 0:
        return 0.0
    variance = sum((amount - mean) ** 2 for amount in amounts) / len(amounts)
    return min(1.0, math.sqrt(variance) / mean)


def _aggregate(records, profile_type, trials, seed):
    def rate(name):
        return round(sum(bool(row[name]) for row in records) / len(records), 6)

    def mean(name):
        return round(sum(float(row[name]) for row in records) / len(records), 6)

    fees = sorted(float(row["accepted_fee"]) for row in records)
    return {
        "profile_type": profile_type,
        "trials": trials,
        "seed": seed,
        "metrics": {
            "acceptance_rate": rate("accepted"),
            "baseline_shortfall_rate": rate("baseline_shortfall"),
            "with_offer_shortfall_rate": rate("with_offer_shortfall"),
            "repeat_borrowing_rate": rate("repeat_borrowing"),
            "payday_capture_rate": rate("payday_captured"),
            "mean_temptation_trigger": mean("temptation"),
            "mean_shortfall_pressure": mean("decision_shortfall"),
            "mean_days_to_payday": mean("income_wait_days"),
            "income_variability_mean": mean("income_variability"),
            "simulated_fees_p50": round(fees[int((len(fees) - 1) * 0.50)], 2),
            "simulated_fees_p90": round(fees[int((len(fees) - 1) * 0.90)], 2),
        },
        "caveat": SCENARIO_CAVEAT,
    }


def run_monte_carlo(profile_type, trials=1000, seed=42):
    if profile_type not in _CONFIGS:
        raise ValueError("unsupported profile: {}".format(profile_type))
    if not isinstance(trials, int) or trials < 1 or trials > 100000:
        raise ValueError("trials must be between 1 and 100000")
    rng = random.Random(int(seed))
    records = [simulate_agent(generate_profile(profile_type, rng), rng) for _ in range(trials)]
    return _aggregate(records, profile_type, trials, int(seed))


def generate_training_rows(profile_type, count=1000, seed=42):
    """Create numeric synthetic-only rows for experimental tabular generators."""
    if profile_type not in _CONFIGS:
        raise ValueError("unsupported profile: {}".format(profile_type))
    if not isinstance(count, int) or count < 2 or count > 100000:
        raise ValueError("count must be between 2 and 100000")
    rng = random.Random(int(seed))
    output = []
    for _ in range(count):
        record = simulate_agent(generate_profile(profile_type, rng), rng)
        output.append([
            float(record["income_variability"]),
            min(1.0, float(record["income_wait_days"]) / 30.0),
            min(1.0, float(record["decision_shortfall"]) / 1200.0),
            float(record["synthetic_impulse"]),
            float(record["synthetic_stress"]),
        ])
    return output
