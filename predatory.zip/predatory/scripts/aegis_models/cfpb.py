"""Streaming descriptive summaries for CFPB Consumer Complaint data."""

import csv
from datetime import date, datetime
from pathlib import Path
from collections import Counter
from contextlib import contextmanager
from io import TextIOWrapper
import re
import zipfile


CFPB_CAVEAT = (
    "CFPB complaints are not a statistical sample and are not representative of all consumers' experiences. "
    "Complaint counts are not a lender safety score; consider company size and market share."
)

_NARRATIVE_PHRASES = {
    "income_disruption": (
        "lost my job", "lost my income", "laid off", "unemployed", "income stopped",
        "reduced hours", "hours were reduced", "cut my hours",
    ),
    "payment_difficulty": (
        "could not pay", "couldn't pay", "unable to pay", "cannot pay", "can't pay",
        "missed payment", "late payment", "behind on", "past due", "could not afford",
    ),
    "cash_shortfall": (
        "overdraft", "insufficient funds", "short on money", "not enough money",
        "payday loan", "cash advance", "borrowed to pay",
    ),
    "fee_pressure": ("fee", "fees", "interest rate", "finance charge", "annual percentage rate", "apr"),
}
_NARRATIVE_PATTERNS = {
    category: re.compile(r"\b(?:{})\b".format("|".join(re.escape(phrase) for phrase in phrases)))
    for category, phrases in _NARRATIVE_PHRASES.items()
}


class CFPBDataError(ValueError):
    pass


@contextmanager
def _text_inputs(path):
    path = Path(path)
    if path.suffix.lower() != ".zip":
        with path.open("r", newline="", encoding="utf-8-sig", errors="replace") as stream:
            yield [stream]
        return
    with zipfile.ZipFile(path) as archive:
        members = [name for name in archive.namelist() if name.lower().endswith(".csv") and not name.endswith("/")]
        if not members:
            raise CFPBDataError("ZIP archive does not contain a CSV file")
        streams = []
        try:
            for name in members:
                streams.append(TextIOWrapper(archive.open(name, "r"), encoding="utf-8-sig", errors="replace", newline=""))
            yield streams
        finally:
            for stream in streams:
                stream.close()


def _date_month(value):
    value = (value or "").strip()
    if not value:
        return None
    for candidate in (value[:10], value):
        try:
            return date.fromisoformat(candidate).strftime("%Y-%m")
        except ValueError:
            pass
    for fmt in ("%m/%d/%Y", "%m/%d/%y"):
        try:
            return datetime.strptime(value, fmt).date().strftime("%Y-%m")
        except ValueError:
            pass
    return None


def _top(counter, limit=20):
    return [{"name": name, "count": count} for name, count in sorted(counter.items(), key=lambda item: (-item[1], item[0]))[:limit]]


def _narrative_flags(value):
    """Count transparent phrase flags; never return or retain the narrative text."""
    normalized = " ".join((value or "").casefold().split())
    return {
        category: pattern.search(normalized) is not None
        for category, pattern in _NARRATIVE_PATTERNS.items()
    }


def summarize_complaints(path, row_limit=None, product_contains=None):
    """Aggregate complaint metadata and optional local phrase counts from archived narratives."""
    if row_limit is not None and row_limit < 1:
        raise CFPBDataError("row_limit must be a positive integer")
    product_contains = (product_contains or "").strip()
    if len(product_contains) > 120:
        raise CFPBDataError("product filter must be at most 120 characters")
    months = Counter()
    products = Counter()
    issues = Counter()
    companies = Counter()
    narrative_signals = Counter({name: 0 for name in _NARRATIVE_PHRASES})
    rows_used = 0
    rows_scanned = 0
    valid_dates = 0
    narrative_rows = 0
    narrative_signal_rows = 0
    date_values = []

    try:
        with _text_inputs(path) as streams:
            for stream in streams:
                reader = csv.DictReader(stream)
                if not reader.fieldnames:
                    continue
                field_map = {name.strip().casefold(): name for name in reader.fieldnames if name}
                narrative_field = field_map.get("consumer complaint narrative") or field_map.get("complaint narrative")
                required = ("date received", "product", "issue", "company")
                missing = [name for name in required if name not in field_map]
                if missing:
                    raise CFPBDataError("CFPB input is missing required columns: {}".format(", ".join(missing)))
                for row in reader:
                    if row_limit is not None and rows_used >= row_limit:
                        break
                    rows_scanned += 1
                    product = (row.get(field_map["product"]) or "").strip() or "(not specified)"
                    if product_contains and product_contains.casefold() not in product.casefold():
                        continue
                    rows_used += 1
                    issue = (row.get(field_map["issue"]) or "").strip() or "(not specified)"
                    company = (row.get(field_map["company"]) or "").strip() or "(not specified)"
                    products[product] += 1
                    issues[issue] += 1
                    companies[company] += 1
                    if narrative_field:
                        narrative = row.get(narrative_field) or ""
                        if narrative.strip():
                            narrative_rows += 1
                            flags = _narrative_flags(narrative)
                            if any(flags.values()):
                                narrative_signal_rows += 1
                            for category, matched in flags.items():
                                if matched:
                                    narrative_signals[category] += 1
                    month = _date_month(row.get(field_map["date received"]))
                    if month:
                        months[month] += 1
                        valid_dates += 1
                        date_values.append(month)
                if row_limit is not None and rows_used >= row_limit:
                    break
    except FileNotFoundError:
        raise CFPBDataError("CFPB input file was not found: {}".format(path))
    except zipfile.BadZipFile:
        raise CFPBDataError("CFPB ZIP input is invalid")

    if rows_used == 0:
        raise CFPBDataError(
            "CFPB input contains no data rows matching the product filter"
            if product_contains else "CFPB input contains no data rows"
        )

    return {
        "source": "CFPB Consumer Complaint Database",
        "rows_used": rows_used,
        "rows_scanned": rows_scanned,
        "product_filter": product_contains or None,
        "rows_with_valid_dates": valid_dates,
        "date_coverage": {"from": min(date_values) if date_values else None, "to": max(date_values) if date_values else None},
        "by_month": dict(sorted(months.items())),
        "top_products": _top(products),
        "top_issues": _top(issues),
        "top_companies": _top(companies),
        "narrative_text_included": False,
        "narrative_analysis": {
            "rows_with_text": narrative_rows,
            "rows_with_any_signal": narrative_signal_rows,
            "signals": dict(narrative_signals),
            "method": "Transparent phrase flags returned as aggregate counts only; not an individual profile or population estimate.",
            "privacy_note": "Narrative text is processed locally and is not included in this report.",
        },
        "caveat": CFPB_CAVEAT,
        "source_url": "https://www.consumerfinance.gov/data-research/consumer-complaints/",
    }
