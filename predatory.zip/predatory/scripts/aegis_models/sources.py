"""Local dataset provenance and source-specific tabular adapters."""

import csv
import math
from pathlib import Path
from typing import Iterator, Optional


class SourceDataError(ValueError):
    """Raised when an input file does not match the selected dataset schema."""


SOURCE_CATALOG = {
    "statlog-german": {
        "name": "Statlog German Credit",
        "url": "https://archive.ics.uci.edu/dataset/144/statlog+german+credit+data",
        "license": "CC BY 4.0",
        "use": "Open benchmark; attribution required.",
        "caveat": "1,000 historical German records; not representative of U.S. consumers.",
        "label": "Good/Bad credit class; bad is encoded as 1.",
    },
    "lendingclub": {
        "name": "LendingClub loan records",
        "url": "https://www.kaggle.com/datasets/wordsforthewise/lending-club",
        "license": "CC0 1.0 Universal (archive metadata)",
        "use": "Open historical benchmark; preserve source attribution and verify the downloaded archive metadata.",
        "caveat": "Historical U.S. personal loans from 2007–2018; not payday-specific or representative of Aegis members.",
        "label": "In the CC0 adaptation, loan_status 0 = default; 1 = paid/OK. Canonical model label 1 = adverse.",
    },
    "home-credit": {
        "name": "Home Credit Default Risk",
        "url": "https://www.kaggle.com/c/home-credit-default-risk/rules",
        "license": "Subject to the relevant Kaggle competition rules; not an open-data license",
        "use": "Confirm that the rules permit the intended research use; do not redistribute the data.",
        "caveat": "Competition records are not general-use production training data.",
        "label": "TARGET; 1 is a payment difficulty outcome.",
        "requires_terms_confirmation": True,
    },
    "fico": {
        "name": "FICO Explainable ML Challenge / HELOC",
        "url": "https://investors.fico.com/news-releases/news-release-details/fico-announces-xml-challenge/",
        "license": "Challenge terms must be checked by the data recipient",
        "use": "Use only after confirming the applicable challenge terms.",
        "caveat": "A benchmark outcome is not an Aegis consumer-protection signal.",
        "label": "RiskPerformance Good/Bad; Bad is encoded as 1.",
        "requires_terms_confirmation": True,
    },
}


FEATURE_NAMES = {
    "statlog-german": [
        "duration_months", "credit_amount", "installment_rate", "age_years", "existing_credits"
    ],
    "lendingclub": [
        "loan_amount", "annual_income", "debt_to_income", "installment",
        "revolving_balance", "revolving_utilization"
    ],
    "home-credit": [
        "annual_income", "loan_amount", "installment", "goods_price", "employment_days"
    ],
}

_LENDINGCLUB_STATUS = {
    # The CC0 adaptation encodes 0 as default and 1 as paid/OK.
    # Canonical model labels use 1 for the adverse outcome.
    "0": 1,
    "0.0": 1,
    "1": 0,
    "1.0": 0,
    "fully paid": 0,
    "does not meet the credit policy. status:fully paid": 0,
    "charged off": 1,
    "default": 1,
    "does not meet the credit policy. status:charged off": 1,
}


def _required(header, columns, source):
    missing = [column for column in columns if column not in header]
    if missing:
        raise SourceDataError(
            "{} input is missing required columns: {}".format(source, ", ".join(missing))
        )


def _number(value, source, field):
    try:
        number = float(value)
    except (TypeError, ValueError):
        raise SourceDataError("{} has a non-numeric value in {}".format(source, field))
    if not math.isfinite(number):
        raise SourceDataError("{} has a non-finite value in {}".format(source, field))
    return number


def _statlog(path, row_limit):
    emitted = 0
    with Path(path).open("r", encoding="utf-8", errors="replace") as source_file:
        for line_number, line in enumerate(source_file, 1):
            if not line.strip():
                continue
            cells = line.split()
            if len(cells) != 21:
                raise SourceDataError("statlog-german row {} must contain 21 fields".format(line_number))
            try:
                label_value = int(cells[20])
            except ValueError:
                raise SourceDataError("statlog-german row {} has an invalid class".format(line_number))
            if label_value not in (1, 2):
                raise SourceDataError("statlog-german row {} has an unsupported class".format(line_number))
            features = {
                "duration_months": _number(cells[1], "statlog-german", "duration"),
                "credit_amount": _number(cells[4], "statlog-german", "credit amount"),
                "installment_rate": _number(cells[7], "statlog-german", "installment rate"),
                "age_years": _number(cells[12], "statlog-german", "age"),
                "existing_credits": _number(cells[15], "statlog-german", "existing credits"),
            }
            yield {"source": "statlog-german", "features": features, "label": 1 if label_value == 2 else 0}
            emitted += 1
            if row_limit is not None and emitted >= row_limit:
                break


def _csv_rows(path):
    try:
        return Path(path).open("r", newline="", encoding="utf-8-sig", errors="replace")
    except OSError as error:
        raise SourceDataError("could not open dataset: {}".format(error))


def iter_canonical_rows(path, source, row_limit=None):
    """Yield normalized labeled records while keeping only the current row in memory."""
    if source not in SOURCE_CATALOG:
        raise SourceDataError("unsupported source: {}".format(source))
    if row_limit is not None and row_limit < 1:
        raise SourceDataError("row_limit must be a positive integer")
    if source == "statlog-german":
        for row in _statlog(path, row_limit):
            yield row
        return

    with _csv_rows(path) as input_file:
        reader = csv.DictReader(input_file)
        header = set(reader.fieldnames or [])
        if source == "lendingclub":
            required = ["loan_amnt", "annual_inc", "dti", "installment", "revol_bal", "revol_util", "loan_status"]
            _required(header, required, source)
            emitted = 0
            for row in reader:
                status = (row.get("loan_status") or "").strip().lower()
                if status not in _LENDINGCLUB_STATUS:
                    continue
                try:
                    features = {
                        "loan_amount": _number(row["loan_amnt"], source, "loan_amnt"),
                        "annual_income": _number(row["annual_inc"], source, "annual_inc"),
                        "debt_to_income": _number(row["dti"], source, "dti"),
                        "installment": _number(row["installment"], source, "installment"),
                        "revolving_balance": _number(row["revol_bal"], source, "revol_bal"),
                        "revolving_utilization": _number((row.get("revol_util") or "").replace("%", ""), source, "revol_util"),
                    }
                except SourceDataError:
                    continue
                yield {"source": source, "features": features, "label": _LENDINGCLUB_STATUS[status]}
                emitted += 1
                if row_limit is not None and emitted >= row_limit:
                    break
            return

        if source == "home-credit":
            required = ["AMT_INCOME_TOTAL", "AMT_CREDIT", "AMT_ANNUITY", "AMT_GOODS_PRICE", "DAYS_EMPLOYED", "TARGET"]
            _required(header, required, source)
            emitted = 0
            for row in reader:
                try:
                    label = int(row["TARGET"])
                except (TypeError, ValueError):
                    continue
                if label not in (0, 1):
                    continue
                try:
                    employed_days = _number(row["DAYS_EMPLOYED"], source, "DAYS_EMPLOYED")
                    if employed_days == -365243 or employed_days == 365243:
                        continue
                    features = {
                        "annual_income": _number(row["AMT_INCOME_TOTAL"], source, "AMT_INCOME_TOTAL"),
                        "loan_amount": _number(row["AMT_CREDIT"], source, "AMT_CREDIT"),
                        "installment": _number(row["AMT_ANNUITY"], source, "AMT_ANNUITY"),
                        "goods_price": _number(row["AMT_GOODS_PRICE"], source, "AMT_GOODS_PRICE"),
                        "employment_days": abs(employed_days),
                    }
                except SourceDataError:
                    continue
                yield {"source": source, "features": features, "label": label}
                emitted += 1
                if row_limit is not None and emitted >= row_limit:
                    break
            return

        required = ["RiskPerformance"]
        _required(header, required, source)
        id_columns = {"UNIQUEID", "UniqueID", "uniqueid", "id", "ID"}
        feature_columns = [column for column in (reader.fieldnames or []) if column not in id_columns | {"RiskPerformance"}]
        if len(feature_columns) < 2:
            raise SourceDataError("fico input needs at least two numeric feature columns")
        emitted = 0
        for row in reader:
            outcome = (row.get("RiskPerformance") or "").strip().lower()
            if outcome not in ("good", "bad"):
                continue
            try:
                features = {column: _number(row[column], source, column) for column in feature_columns}
            except SourceDataError:
                continue
            yield {"source": source, "features": features, "label": 1 if outcome == "bad" else 0}
            emitted += 1
            if row_limit is not None and emitted >= row_limit:
                break
