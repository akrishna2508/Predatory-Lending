"""Local research modules for the Aegis modeling workbench."""

