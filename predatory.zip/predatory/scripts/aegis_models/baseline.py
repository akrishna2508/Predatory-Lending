"""Small, deterministic NumPy logistic-regression benchmark."""

import math
from typing import Dict, List

import numpy as np


class ModelTrainingError(ValueError):
    """Raised when a benchmark cannot be evaluated without misleading results."""


def _sigmoid(values):
    clipped = np.clip(values, -35.0, 35.0)
    return 1.0 / (1.0 + np.exp(-clipped))


def _auc(labels, probabilities):
    positives = int(np.sum(labels == 1))
    negatives = int(np.sum(labels == 0))
    if positives == 0 or negatives == 0:
        raise ModelTrainingError("holdout split must contain both outcome classes")
    order = np.argsort(probabilities, kind="mergesort")
    ordered = probabilities[order]
    ranks = np.empty(len(labels), dtype=float)
    start = 0
    while start < len(order):
        end = start + 1
        while end < len(order) and ordered[end] == ordered[start]:
            end += 1
        ranks[order[start:end]] = (start + 1 + end) / 2.0
        start = end
    positive_rank_sum = float(np.sum(ranks[labels == 1]))
    return (positive_rank_sum - positives * (positives + 1) / 2.0) / (positives * negatives)


def _round(value):
    number = float(value)
    if not math.isfinite(number):
        raise ModelTrainingError("model produced a non-finite result")
    return round(number, 6)


def _stratified_indices(labels, seed):
    rng = np.random.default_rng(seed)
    train = []
    test = []
    for label in (0, 1):
        indices = np.flatnonzero(labels == label)
        if len(indices) < 2:
            raise ModelTrainingError("training and holdout data must contain both outcome classes")
        rng.shuffle(indices)
        test_count = max(1, int(round(len(indices) * 0.2)))
        test_count = min(test_count, len(indices) - 1)
        test.extend(indices[:test_count].tolist())
        train.extend(indices[test_count:].tolist())
    rng.shuffle(train)
    rng.shuffle(test)
    return np.asarray(train, dtype=int), np.asarray(test, dtype=int)


def fit_logistic_baseline(rows, feature_names, seed=42, steps=600, learning_rate=0.05):
    """Fit an interpretable benchmark and return aggregate holdout metrics only."""
    feature_names = list(feature_names)
    if not feature_names or len(set(feature_names)) != len(feature_names):
        raise ModelTrainingError("feature_names must be a non-empty list without duplicates")
    if steps < 1 or learning_rate <= 0 or not math.isfinite(learning_rate):
        raise ModelTrainingError("steps and learning_rate must be positive")

    selected = []
    for row in rows:
        try:
            label = int(row["label"])
            vector = [float(row["features"][name]) for name in feature_names]
        except (KeyError, TypeError, ValueError):
            raise ModelTrainingError("each row must contain the requested features and a binary label")
        if label not in (0, 1):
            raise ModelTrainingError("outcome labels must be 0 or 1")
        if not all(math.isfinite(value) for value in vector):
            raise ModelTrainingError("all model features must be finite")
        selected.append((vector, label))
    if len(selected) < 10:
        raise ModelTrainingError("at least 10 usable labeled rows are required")

    features = np.asarray([row[0] for row in selected], dtype=float)
    labels = np.asarray([row[1] for row in selected], dtype=int)
    train_indices, test_indices = _stratified_indices(labels, seed)

    train_x = features[train_indices]
    train_y = labels[train_indices].astype(float)
    test_x = features[test_indices]
    test_y = labels[test_indices].astype(float)
    means = np.mean(train_x, axis=0)
    scales = np.std(train_x, axis=0)
    scales[scales < 1e-9] = 1.0
    train_z = (train_x - means) / scales
    test_z = (test_x - means) / scales
    train_design = np.column_stack([np.ones(len(train_z)), train_z])
    test_design = np.column_stack([np.ones(len(test_z)), test_z])

    weights = np.zeros(train_design.shape[1], dtype=float)
    for _ in range(int(steps)):
        probabilities = _sigmoid(train_design @ weights)
        gradient = (train_design.T @ (probabilities - train_y)) / len(train_y)
        gradient[1:] += 1e-4 * weights[1:]
        weights -= learning_rate * gradient

    probabilities = _sigmoid(test_design @ weights)
    predicted = (probabilities >= 0.5).astype(int)
    metrics = {
        "roc_auc": _round(_auc(test_y.astype(int), probabilities)),
        "brier_score": _round(np.mean(np.square(probabilities - test_y))),
        "accuracy_at_0_5": _round(np.mean(predicted == test_y)),
        "holdout_adverse_rate": _round(np.mean(test_y)),
    }
    coefficients = {name: _round(value) for name, value in zip(feature_names, weights[1:])}
    return {
        "model": "standardized_logistic_regression",
        "seed": int(seed),
        "feature_names": feature_names,
        "metrics": metrics,
        "coefficients": coefficients,
        "intercept": _round(weights[0]),
        "train_rows": int(len(train_indices)),
        "test_rows": int(len(test_indices)),
        "total_rows": int(len(selected)),
        "positive_label": "adverse repayment outcome",
        "caveat": "Research benchmark only; not an individual credit decision or consumer risk score.",
    }
