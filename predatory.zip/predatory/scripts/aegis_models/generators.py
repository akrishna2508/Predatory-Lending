"""Experimental NumPy tabular GAN and linear-denoiser diffusion sampler.

These small local prototypes are intended for generated simulation rows only.
They are not privacy guarantees, and their outputs are not consumer records.
"""

import math

import numpy as np


def _prepare(rows):
    data = np.asarray(rows, dtype=float)
    if data.ndim != 2 or data.shape[0] < 2 or data.shape[1] < 1:
        raise ValueError("at least two numeric rows and one feature are required")
    if not np.isfinite(data).all():
        raise ValueError("generator input values must be finite")
    lower = np.min(data, axis=0)
    upper = np.max(data, axis=0)
    span = upper - lower
    safe_span = np.where(span < 1e-12, 1.0, span)
    normalized = ((data - lower) / safe_span) * 2.0 - 1.0
    normalized[:, span < 1e-12] = 0.0
    return data, lower, upper, span, normalized


def _sigmoid(value):
    return 1.0 / (1.0 + np.exp(-np.clip(value, -30.0, 30.0)))


def _apply_update(weights, gradients, rate):
    for key in weights:
        weights[key] -= rate * np.clip(gradients[key], -5.0, 5.0)


def train_gan(rows, seed=42, steps=300, batch_size=32, learning_rate=0.01):
    """Train a compact two-layer MLP GAN on numeric synthetic rows."""
    _, lower, upper, span, real = _prepare(rows)
    if steps < 1 or batch_size < 2:
        raise ValueError("steps must be positive and batch_size must be at least 2")
    rng = np.random.default_rng(seed)
    dimensions = real.shape[1]
    latent_dimensions = max(3, min(8, dimensions + 2))
    hidden = max(8, min(24, dimensions * 2 + 4))
    scale_g1 = math.sqrt(2.0 / (latent_dimensions + hidden))
    scale_g2 = math.sqrt(2.0 / (hidden + dimensions))
    scale_d1 = math.sqrt(2.0 / (dimensions + hidden))
    generator = {
        "w1": rng.normal(0.0, scale_g1, (latent_dimensions, hidden)),
        "b1": np.zeros(hidden),
        "w2": rng.normal(0.0, scale_g2, (hidden, dimensions)),
        "b2": np.zeros(dimensions),
    }
    discriminator = {
        "w1": rng.normal(0.0, scale_d1, (dimensions, hidden)),
        "b1": np.zeros(hidden),
        "w2": rng.normal(0.0, math.sqrt(2.0 / (hidden + 1)), (hidden, 1)),
        "b2": np.zeros(1),
    }

    def generate(noise):
        hidden_values = np.tanh(noise @ generator["w1"] + generator["b1"])
        output = np.tanh(hidden_values @ generator["w2"] + generator["b2"])
        return output, hidden_values

    def discriminate(values):
        hidden_values = np.tanh(values @ discriminator["w1"] + discriminator["b1"])
        logits = hidden_values @ discriminator["w2"] + discriminator["b2"]
        return _sigmoid(logits), hidden_values

    count = min(int(batch_size), len(real))
    for _ in range(int(steps)):
        real_batch = real[rng.integers(0, len(real), size=count)]
        noise = rng.normal(size=(count, latent_dimensions))
        fake_batch, _ = generate(noise)
        real_probability, real_hidden = discriminate(real_batch)
        fake_probability, fake_hidden = discriminate(fake_batch)
        real_grad = (real_probability - 1.0) / count
        fake_grad = fake_probability / count
        d_w2 = real_hidden.T @ real_grad + fake_hidden.T @ fake_grad
        d_b2 = np.sum(real_grad + fake_grad, axis=0)
        d_real_hidden = (real_grad @ discriminator["w2"].T) * (1.0 - real_hidden ** 2)
        d_fake_hidden = (fake_grad @ discriminator["w2"].T) * (1.0 - fake_hidden ** 2)
        d_w1 = real_batch.T @ d_real_hidden + fake_batch.T @ d_fake_hidden
        d_b1 = np.sum(d_real_hidden + d_fake_hidden, axis=0)
        _apply_update(discriminator, {"w1": d_w1, "b1": d_b1, "w2": d_w2, "b2": d_b2}, learning_rate)

        noise = rng.normal(size=(count, latent_dimensions))
        fake_batch, generator_hidden = generate(noise)
        fake_probability, discriminator_hidden = discriminate(fake_batch)
        generator_grad = (fake_probability - 1.0) / count
        grad_fake = (generator_grad @ discriminator["w2"].T) * (1.0 - discriminator_hidden ** 2)
        grad_fake = grad_fake @ discriminator["w1"].T
        grad_fake_logits = grad_fake * (1.0 - fake_batch ** 2)
        g_w2 = generator_hidden.T @ grad_fake_logits
        g_b2 = np.sum(grad_fake_logits, axis=0)
        grad_generator_hidden = (grad_fake_logits @ generator["w2"].T) * (1.0 - generator_hidden ** 2)
        g_w1 = noise.T @ grad_generator_hidden
        g_b1 = np.sum(grad_generator_hidden, axis=0)
        _apply_update(generator, {"w1": g_w1, "b1": g_b1, "w2": g_w2, "b2": g_b2}, learning_rate)

    return {
        "engine": "numpy_mlp_gan_experimental",
        "generator": generator,
        "lower": lower,
        "upper": upper,
        "span": span,
        "latent_dimensions": latent_dimensions,
        "feature_count": dimensions,
        "provenance": "experimental_synthetic",
    }


def sample_gan(model, count, seed=42):
    if not isinstance(count, int) or count < 1 or count > 100000:
        raise ValueError("count must be between 1 and 100000")
    rng = np.random.default_rng(seed)
    generator = model["generator"]
    noise = rng.normal(size=(count, model["latent_dimensions"]))
    normalized = np.tanh(np.tanh(noise @ generator["w1"] + generator["b1"]) @ generator["w2"] + generator["b2"])
    result = (normalized + 1.0) / 2.0 * np.where(model["span"] < 1e-12, 0.0, model["span"]) + model["lower"]
    result = np.minimum(np.maximum(result, model["lower"]), model["upper"])
    if not np.isfinite(result).all():
        raise ValueError("GAN generated non-finite values")
    return result


def train_diffusion(rows, seed=42, steps=1000, timesteps=16, ridge=1e-3):
    """Fit a linear noise predictor for a compact DDPM-style numeric sampler."""
    _, lower, upper, span, normalized = _prepare(rows)
    if steps < 20 or timesteps < 2 or timesteps > 64:
        raise ValueError("diffusion requires at least 20 steps and 2 to 64 timesteps")
    rng = np.random.default_rng(seed)
    betas = np.linspace(1e-4, 0.02, int(timesteps))
    alphas = 1.0 - betas
    alpha_bar = np.cumprod(alphas)
    selected = rng.integers(0, len(normalized), size=int(steps))
    time_indices = rng.integers(0, int(timesteps), size=int(steps))
    noise = rng.normal(size=(int(steps), normalized.shape[1]))
    noisy = (
        np.sqrt(alpha_bar[time_indices, None]) * normalized[selected]
        + np.sqrt(1.0 - alpha_bar[time_indices, None]) * noise
    )
    time_feature = (time_indices.astype(float) / max(1, timesteps - 1))[:, None]
    design = np.column_stack([np.ones(int(steps)), noisy, time_feature])
    penalty = np.eye(design.shape[1]) * float(ridge)
    penalty[0, 0] = 0.0
    coefficients = np.linalg.solve(design.T @ design + penalty, design.T @ noise)
    return {
        "engine": "linear_denoising_diffusion_experimental",
        "coefficients": coefficients,
        "betas": betas,
        "alphas": alphas,
        "alpha_bar": alpha_bar,
        "lower": lower,
        "upper": upper,
        "span": span,
        "feature_count": normalized.shape[1],
        "provenance": "experimental_synthetic",
    }


def sample_diffusion(model, count, seed=42):
    if not isinstance(count, int) or count < 1 or count > 100000:
        raise ValueError("count must be between 1 and 100000")
    rng = np.random.default_rng(seed)
    dimensions = model["feature_count"]
    values = rng.normal(size=(count, dimensions))
    betas = model["betas"]
    alphas = model["alphas"]
    alpha_bar = model["alpha_bar"]
    for index in range(len(betas) - 1, -1, -1):
        time_column = np.full((count, 1), index / max(1, len(betas) - 1))
        design = np.column_stack([np.ones(count), values, time_column])
        predicted_noise = design @ model["coefficients"]
        values = (values - (betas[index] / math.sqrt(max(1e-12, 1.0 - alpha_bar[index]))) * predicted_noise) / math.sqrt(alphas[index])
        if index > 0:
            values += math.sqrt(betas[index]) * rng.normal(size=values.shape)
        values = np.clip(values, -3.0, 3.0)
    normalized = np.clip(values, -1.0, 1.0)
    result = (normalized + 1.0) / 2.0 * np.where(model["span"] < 1e-12, 0.0, model["span"]) + model["lower"]
    result = np.minimum(np.maximum(result, model["lower"]), model["upper"])
    if not np.isfinite(result).all():
        raise ValueError("diffusion sampler generated non-finite values")
    return result
