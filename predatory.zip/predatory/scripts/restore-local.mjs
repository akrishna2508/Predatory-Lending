import { createReadStream } from 'node:fs';
import { open, stat } from 'node:fs/promises';
import { spawn } from 'node:child_process';
import { pipeline } from 'node:stream/promises';
import { assertRestoreConfirmation, parseLocalDatabaseUrl } from './local-database-url.mjs';
import { BACKUP_HEADER_BYTES, BACKUP_MIN_BYTES, createBackupDecryption, loadBackupKey } from './backup-envelope.mjs';

const [backupPath] = process.argv.slice(2);
if (!backupPath || process.argv.length !== 3) {
  throw new Error('Usage: npm run db:restore:local -- <encrypted-backup-file>');
}
const target = parseLocalDatabaseUrl(process.env.AEGIS_RESTORE_DATABASE_URL, 'AEGIS_RESTORE_DATABASE_URL');
assertRestoreConfirmation(target.databaseName, process.env.AEGIS_RESTORE_CONFIRM_DATABASE);
const key = await loadBackupKey();
const backup = await stat(backupPath);
if (!backup.isFile() || backup.size < BACKUP_MIN_BYTES) throw new Error('Backup file is invalid or truncated.');

const header = Buffer.alloc(BACKUP_HEADER_BYTES);
const file = await open(backupPath, 'r');
try {
  const { bytesRead } = await file.read(header, 0, header.byteLength, 0);
  if (bytesRead !== header.byteLength) throw new Error('Backup file is invalid or truncated.');
} finally {
  await file.close();
}
const decryption = createBackupDecryption(header, key);

const targetCheck = await runPsqlQuery(target.connectionString, `
  SELECT json_build_object(
    'isSuperuser', (SELECT rolsuper FROM pg_roles WHERE rolname = current_user),
    'hasObjects',
      EXISTS (
        SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
        WHERE n.nspname NOT IN ('pg_catalog', 'information_schema')
          AND n.nspname NOT LIKE 'pg_toast%'
          AND c.relkind IN ('r', 'p', 'v', 'm', 'S', 'f', 'c')
      ) OR EXISTS (
        SELECT 1 FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace
        WHERE n.nspname = 'public'
      ) OR EXISTS (
        SELECT 1 FROM pg_type t JOIN pg_namespace n ON n.oid = t.typnamespace
        WHERE n.nspname = 'public' AND t.typtype <> 'p' AND t.typcategory <> 'A'
      ) OR EXISTS (
        SELECT 1 FROM pg_namespace
        WHERE nspname NOT IN ('public', 'pg_catalog', 'information_schema') AND nspname NOT LIKE 'pg_%'
      )
  )::text;
`);
let targetState;
try { targetState = JSON.parse(targetCheck); }
catch { throw new Error('Could not validate the local restore target.'); }
if (targetState.isSuperuser !== true) throw new Error('Restore requires a PostgreSQL administrator to preserve database ownership and grants.');
if (targetState.hasObjects !== false) throw new Error('Restore target must be an empty database.');

const child = spawn('pg_restore', [
  '--single-transaction',
  '--exit-on-error',
  `--dbname=${target.connectionString}`,
], { stdio: ['pipe', 'ignore', 'ignore'], env: childEnvironment() });
const exited = waitForSuccess(child);
try {
  await pipeline(
    createReadStream(backupPath, { start: BACKUP_HEADER_BYTES, end: backup.size - 1 }),
    decryption.tagStripper,
    decryption.transform,
    child.stdin,
  );
  await exited;
  console.log(`Encrypted backup restored into empty database: ${target.databaseName}`);
} catch {
  child.kill('SIGTERM');
  await exited.catch(() => {});
  throw new Error('Restore failed. The target was not committed; verify the key, backup integrity, and PostgreSQL tool versions.');
}

async function runPsqlQuery(connectionString, query) {
  const childProcess = spawn('psql', [
    '--no-psqlrc', '--quiet', '--tuples-only', '--no-align',
    '--set=ON_ERROR_STOP=1', `--dbname=${connectionString}`, `--command=${query}`,
  ], { stdio: ['ignore', 'pipe', 'ignore'], env: childEnvironment() });
  const exit = waitForSuccess(childProcess, 'psql');
  const chunks = [];
  for await (const chunk of childProcess.stdout) chunks.push(chunk);
  try { await exit; }
  catch { throw new Error('Could not validate the local restore target with psql.'); }
  return Buffer.concat(chunks).toString('utf8').trim();
}

function childEnvironment() {
  const env = { ...process.env };
  delete env.AEGIS_BACKUP_KEY;
  delete env.AEGIS_BACKUP_KEY_FILE;
  delete env.AEGIS_BACKUP_DATABASE_URL;
  delete env.AEGIS_RESTORE_DATABASE_URL;
  delete env.AEGIS_RESTORE_CONFIRM_DATABASE;
  return env;
}

function waitForSuccess(childProcess, toolName = 'pg_restore') {
  return new Promise((resolveExit, reject) => {
    childProcess.once('error', () => reject(new Error(`${toolName} could not be started.`)));
    childProcess.once('close', code => code === 0
      ? resolveExit()
      : reject(new Error(`${toolName} failed with exit code ${code ?? 'unknown'}.`)));
  });
}
