import { randomBytes } from 'node:crypto';
import { createWriteStream } from 'node:fs';
import { link, mkdir, open, unlink } from 'node:fs/promises';
import { basename, dirname, resolve } from 'node:path';
import { spawn } from 'node:child_process';
import { pipeline } from 'node:stream/promises';
import { createBackupEncryption, loadBackupKey } from './backup-envelope.mjs';
import { parseLocalDatabaseUrl } from './local-database-url.mjs';

const database = parseLocalDatabaseUrl(process.env.AEGIS_BACKUP_DATABASE_URL, 'AEGIS_BACKUP_DATABASE_URL');
const key = await loadBackupKey();
const defaultName = `aegis-${new Date().toISOString().replaceAll(':', '').replaceAll('.', '')}.aegisbackup`;
const destination = resolve(process.argv[2] ?? `backups/${defaultName}`);
if (basename(destination).length < 8) throw new Error('Choose a descriptive backup file name.');

await mkdir(dirname(destination), { recursive: true, mode: 0o700 });
const temporary = `${destination}.partial-${process.pid}-${randomBytes(6).toString('hex')}`;
const encryption = createBackupEncryption(key);
const child = spawn('pg_dump', ['--format=custom', `--dbname=${database.connectionString}`], {
  stdio: ['ignore', 'pipe', 'ignore'],
  env: childEnvironment(),
});
const exited = waitForSuccess(child, 'pg_dump');
let output;
try {
  output = createWriteStream(temporary, { flags: 'wx', mode: 0o600 });
  await waitForOpen(output);
  output.write(encryption.header);
  await pipeline(child.stdout, encryption.transform, output);
  await exited;
  const file = await open(temporary, 'r');
  try { await file.sync(); } finally { await file.close(); }
  await link(temporary, destination);
  await unlink(temporary);
  console.log(`Encrypted PostgreSQL backup created: ${destination}`);
} catch (error) {
  child.kill('SIGTERM');
  await exited.catch(() => {});
  output?.destroy();
  await unlink(temporary).catch(() => {});
  throw new Error(error instanceof Error ? error.message : 'Local database backup failed.');
}

function childEnvironment() {
  const env = { ...process.env };
  delete env.AEGIS_BACKUP_KEY;
  delete env.AEGIS_BACKUP_KEY_FILE;
  delete env.AEGIS_BACKUP_DATABASE_URL;
  return env;
}

function waitForOpen(stream) {
  return new Promise((resolveOpen, reject) => {
    stream.once('open', resolveOpen);
    stream.once('error', reject);
  });
}

function waitForSuccess(childProcess, toolName) {
  return new Promise((resolveExit, reject) => {
    childProcess.once('error', () => reject(new Error(`${toolName} could not be started.`)));
    childProcess.once('close', code => code === 0
      ? resolveExit()
      : reject(new Error(`${toolName} failed with exit code ${code ?? 'unknown'}.`)));
  });
}
