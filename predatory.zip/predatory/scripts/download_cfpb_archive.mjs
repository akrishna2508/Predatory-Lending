import { createReadStream, createWriteStream } from 'node:fs';
import { mkdir, mkdtemp, open, rename, rm, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { Transform, Readable } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

// Pinned to an official pre-cessation CFPB export containing public narratives.
const archiveUrl = 'https://files.consumerfinance.gov/f/documents/CCDB_Export_20_July_2026.zip';
const archivePage = 'https://www.consumerfinance.gov/foia-requests/foia-electronic-reading-room/cfpb-consumer-complaint-database-narratives-archive/';
const maxBytes = 64 * 1024 * 1024;
const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const outputDir = path.join(projectRoot, 'data', 'raw', 'cfpb');
const outputPath = path.join(outputDir, 'historical-jul-2026.zip');
const metadataPath = path.join(outputDir, 'historical-jul-2026.metadata.json');

await mkdir(outputDir, { recursive: true });
const temporaryDir = await mkdtemp(path.join(outputDir, '.cfpb-archive-'));
const temporaryPath = path.join(temporaryDir, 'archive.zip');

try {
  const response = await fetch(archiveUrl);
  if (!response.ok || !response.body) throw new Error(`CFPB archive download failed (HTTP ${response.status}).`);
  const expectedBytes = Number(response.headers.get('content-length'));
  if (Number.isFinite(expectedBytes) && expectedBytes > maxBytes) throw new Error('CFPB archive exceeded the 64 MB download limit.');

  let bytes = 0;
  const limiter = new Transform({
    transform(chunk, _encoding, callback) {
      bytes += chunk.length;
      callback(bytes > maxBytes ? new Error('CFPB archive exceeded the 64 MB download limit.') : null, chunk);
    },
  });
  await pipeline(Readable.fromWeb(response.body), limiter, createWriteStream(temporaryPath, { flags: 'wx', mode: 0o600 }));
  if (Number.isFinite(expectedBytes) && expectedBytes > 0 && bytes !== expectedBytes) throw new Error('CFPB archive download was incomplete.');
  const handle = await open(temporaryPath, 'r');
  const signature = Buffer.alloc(4);
  try { await handle.read(signature, 0, 4, 0); } finally { await handle.close(); }
  if (!signature.equals(Buffer.from([0x50, 0x4b, 0x03, 0x04]))) throw new Error('CFPB archive is not a ZIP file.');

  const digest = createHash('sha256');
  for await (const chunk of createReadStream(temporaryPath)) digest.update(chunk);
  const sha256 = digest.digest('hex');
  await rename(temporaryPath, outputPath);
  const metadata = {
    source: 'CFPB Consumer Complaint Database Narratives Archive',
    source_page: archivePage,
    archive_url: archiveUrl,
    coverage: 'July 2026',
    downloaded_at_utc: new Date().toISOString(),
    bytes,
    sha256,
    note: 'Previously published public complaints. Narratives are processed locally into aggregate counts; they are not returned by the website.',
  };
  await writeFile(metadataPath, `${JSON.stringify(metadata, null, 2)}\n`, { mode: 0o600 });
  process.stdout.write(`${JSON.stringify(metadata, null, 2)}\n`);
} finally {
  await rm(temporaryDir, { recursive: true, force: true });
}
