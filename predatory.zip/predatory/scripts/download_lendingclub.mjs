import { createReadStream, createWriteStream } from 'node:fs';
import { mkdir, mkdtemp, rename, rm, stat, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { Readable } from 'node:stream';
import { pipeline } from 'node:stream/promises';

const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const outputDir = path.join(projectRoot, 'data', 'raw', 'lendingclub');
const outputPath = path.join(outputDir, 'loans.csv');
const metadataPath = path.join(outputDir, 'metadata.json');
const articleUrl = 'https://api.figshare.com/v2/articles/22121477';

await mkdir(outputDir, { recursive: true });
const tempDir = await mkdtemp(path.join(outputDir, '.lendingclub-download-'));
const temporaryCsv = path.join(tempDir, 'loans.csv');

try {
  const metadataResponse = await fetch(articleUrl);
  if (!metadataResponse.ok) throw new Error(`LendingClub dataset metadata request failed (HTTP ${metadataResponse.status}).`);
  const article = await metadataResponse.json();
  const license = (article.license?.name || '').toLowerCase();
  if (license !== 'cc0') throw new Error(`Expected the archived dataset to declare CC0; received ${article.license?.name || 'no license'}.`);
  const sourceFile = (article.files || []).find(file => file.name === 'train_lending_club.csv');
  if (!sourceFile?.download_url || !Number.isFinite(sourceFile.size)) throw new Error('CC0 LendingClub training file was not listed in the archive metadata.');

  const response = await fetch(sourceFile.download_url);
  if (!response.ok || !response.body) throw new Error(`LendingClub file download failed (HTTP ${response.status}).`);
  await pipeline(Readable.fromWeb(response.body), createWriteStream(temporaryCsv, { flags: 'wx', mode: 0o600 }));
  const fileSize = (await stat(temporaryCsv)).size;
  if (fileSize !== sourceFile.size) throw new Error(`Downloaded file size mismatch (${fileSize} vs ${sourceFile.size} bytes).`);

  const digest = createHash('sha256');
  for await (const chunk of createReadStream(temporaryCsv)) digest.update(chunk);
  await rename(temporaryCsv, outputPath);
  const record = {
    source: 'LendingClub historical loan records, 2007–2018',
    source_url: 'https://www.kaggle.com/datasets/wordsforthewise/lending-club',
    archive_url: article.url || 'https://figshare.com/articles/dataset/Lending_Club/22121477',
    archive_file: sourceFile.name,
    archive_license: article.license.name,
    archive_license_url: article.license.url,
    downloaded_at_utc: new Date().toISOString(),
    bytes: fileSize,
    sha256: digest.digest('hex'),
    note: 'Historical U.S. personal-loan data; not payday-specific and not representative of Aegis members or current lending.',
  };
  await writeFile(metadataPath, `${JSON.stringify(record, null, 2)}\n`, { mode: 0o600 });
  process.stdout.write(`${JSON.stringify(record, null, 2)}\n`);
} finally {
  await rm(tempDir, { recursive: true, force: true });
}
