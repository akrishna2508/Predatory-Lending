import { Pool } from 'pg';
import { randomUUID } from 'node:crypto';

const [tenantId, userId, role, status = 'active'] = process.argv.slice(2);
const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const allowedRoles = new Set(['member', 'partner_admin', 'partner_analyst']);
const allowedStatuses = new Set(['active', 'revoked']);
const connectionString = process.env.AEGIS_PROVISIONING_DATABASE_URL;

if (!uuid.test(tenantId ?? '') || !uuid.test(userId ?? '') || !allowedRoles.has(role) || !allowedStatuses.has(status)) {
  console.error('Usage: npm run membership:update -- <organization-uuid> <local-user-uuid> <member|partner_admin|partner_analyst> [active|revoked]');
  process.exit(2);
}
const operator = process.env.AEGIS_OPERATOR_PRINCIPAL?.trim();
if (!connectionString || !operator || operator.length > 160) {
  console.error('AEGIS_PROVISIONING_DATABASE_URL and AEGIS_OPERATOR_PRINCIPAL are required.');
  process.exit(2);
}

const pool = new Pool({
  connectionString,
  max: 1,
  connectionTimeoutMillis: 5000,
  ...(process.env.NODE_ENV === 'production' ? { ssl: { rejectUnauthorized: true } } : {}),
});
let client;
let transactionStarted = false;

try {
  client = await pool.connect();
  await client.query('BEGIN');
  transactionStarted = true;
  await client.query('SET LOCAL ROLE aegis_provisioner');
  const result = await client.query(
    `SELECT o.status AS organization_status, u.status AS user_status, m.role, m.status
     FROM memberships m
     JOIN organizations o ON o.id = m.tenant_id
     JOIN app_users u ON u.id = m.user_id
     WHERE m.tenant_id = $1 AND m.user_id = $2
     FOR UPDATE OF m`,
    [tenantId, userId],
  );
  const current = result.rows[0];
  if (!current || current.organization_status !== 'active' || current.user_status !== 'active') {
    throw new Error('An active organization, identity, and existing membership are required.');
  }

  if (current.role !== role || current.status !== status) {
    await client.query(
      'UPDATE memberships SET role = $3, status = $4 WHERE tenant_id = $1 AND user_id = $2',
      [tenantId, userId, role, status],
    );
    await client.query(
      `INSERT INTO audit_events (tenant_id, actor_user_id, action, entity_type, entity_id, request_id, metadata)
       VALUES ($1, NULL, 'membership.permissions_changed', 'membership', $2, $3, $4::jsonb)`,
      [tenantId, userId, randomUUID(), JSON.stringify({
        old_role: current.role,
        new_role: role,
        old_status: current.status,
        new_status: status,
        operator_principal: operator,
      })],
    );
    await client.query('COMMIT');
    transactionStarted = false;
    console.log('Membership permissions updated and the change was audited.');
  } else {
    await client.query('COMMIT');
    transactionStarted = false;
    console.log('Membership already has the requested role and status; no change was made.');
  }
} catch (error) {
  if (client && transactionStarted) {
    try { await client.query('ROLLBACK'); } catch { /* Keep the original operation failure. */ }
  }
  console.error(error instanceof Error ? error.message : 'Membership update failed.');
  process.exitCode = 1;
} finally {
  client?.release();
  await pool.end();
}
