"""Create an aggregate CFPB metadata and optional narrative-phrase summary."""

import argparse
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from scripts.aegis_models.cfpb import summarize_complaints


def build_complaint_report(input_path, row_limit=None, product_contains=None):
    return summarize_complaints(input_path, row_limit=row_limit, product_contains=product_contains)


def _write_json(value, output):
    content = json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n"
    if output == "-":
        sys.stdout.write(content)
        return
    path = Path(output)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".tmp")
    temp.write_text(content, encoding="utf-8")
    temp.replace(path)


def main(argv=None):
    parser = argparse.ArgumentParser(description="Summarize CFPB metadata and optional archived-narrative phrase signals locally; raw text is discarded.")
    parser.add_argument("--input", required=True, help="Local CFPB CSV or ZIP file")
    parser.add_argument("--output", default="data/results/cfpb-latest.json", help="JSON path or - for stdout")
    parser.add_argument("--row-limit", type=int)
    parser.add_argument("--product-contains", help="Keep only products containing this phrase, case insensitive")
    parser.add_argument("--source-url", help="Exact public source or archive page for the input file")
    args = parser.parse_args(argv)
    if args.row_limit is not None and args.row_limit < 1:
        parser.error("--row-limit must be positive")
    report = build_complaint_report(args.input, args.row_limit, args.product_contains)
    if args.source_url:
        report["source_url"] = args.source_url
    _write_json(report, args.output)


if __name__ == "__main__":
    main()
