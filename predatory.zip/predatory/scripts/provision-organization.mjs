import { Pool } from 'pg';

const [name, slug] = process.argv.slice(2);
const connectionString = process.env.AEGIS_PROVISIONING_DATABASE_URL;
if (!name || name.trim().length < 1 || name.trim().length > 120 || !/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(slug ?? '')) {
  console.error('Usage: npm run provision:organization -- "Credit Union Name" <lowercase-slug>');
  process.exit(2);
}
if (!connectionString) {
  console.error('AEGIS_PROVISIONING_DATABASE_URL is required.');
  process.exit(2);
}

const pool = new Pool({ connectionString, max: 1, connectionTimeoutMillis: 5000, ...(process.env.NODE_ENV === 'production' ? { ssl: { rejectUnauthorized: true } } : {}) });
let client;
try {
  client = await pool.connect();
  await client.query('BEGIN');
  await client.query('SET LOCAL ROLE aegis_provisioner');
  await client.query('INSERT INTO organizations (name, slug) VALUES ($1, $2) ON CONFLICT (slug) DO NOTHING', [name.trim(), slug]);
  const organization = await client.query('SELECT id, name, status FROM organizations WHERE slug = $1', [slug]);
  if (organization.rows[0]?.status !== 'active' || organization.rows[0]?.name !== name.trim()) {
    throw new Error('Organization slug is already in use or the organization is inactive.');
  }
  await client.query('COMMIT');
  console.log(`Active organization provisioned: ${organization.rows[0].id} (${slug}).`);
} catch (error) {
  if (client) {
    try { await client.query('ROLLBACK'); } catch { /* Preserve the provisioning failure. */ }
  }
  console.error(error instanceof Error ? error.message : 'Organization provisioning failed.');
  process.exitCode = 1;
} finally {
  client?.release();
  await pool.end();
}
