BEGIN;

ALTER TABLE consent_events DROP CONSTRAINT consent_events_purpose_check;
ALTER TABLE consent_events ADD CONSTRAINT consent_events_purpose_check
  CHECK (purpose IN (
    'manual_financial_profile', 'read_only_bank_connection', 'transaction_history_upload',
    'cashflow_profile_storage', 'offer_check_storage', 'offer_outcome_reporting', 'research',
    'transaction_pattern_analysis'
  ));

COMMIT;
