BEGIN;

ALTER TABLE consent_events DROP CONSTRAINT consent_events_purpose_check;
ALTER TABLE consent_events ADD CONSTRAINT consent_events_purpose_check
  CHECK (purpose IN ('manual_financial_profile', 'read_only_bank_connection', 'transaction_history_upload', 'offer_check_storage', 'offer_outcome_reporting', 'research'));

CREATE TABLE transaction_imports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  member_user_id uuid NOT NULL REFERENCES app_users(id) ON DELETE CASCADE,
  source_hash bytea NOT NULL CHECK (octet_length(source_hash) = 32),
  transaction_count integer NOT NULL CHECK (transaction_count BETWEEN 1 AND 5000),
  created_at timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY (tenant_id, member_user_id) REFERENCES memberships(tenant_id, user_id) ON DELETE CASCADE,
  UNIQUE (tenant_id, member_user_id, id),
  UNIQUE (tenant_id, member_user_id, source_hash)
);
CREATE INDEX transaction_imports_member_created_idx ON transaction_imports(tenant_id, member_user_id, created_at DESC);

CREATE TABLE imported_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  member_user_id uuid NOT NULL REFERENCES app_users(id) ON DELETE CASCADE,
  import_id uuid NOT NULL,
  row_number integer NOT NULL CHECK (row_number BETWEEN 1 AND 5000),
  amount numeric(13, 2) NOT NULL CHECK (amount <> 0 AND amount BETWEEN -1000000000 AND 1000000000),
  transaction_date date NOT NULL,
  description text NOT NULL CHECK (length(description) BETWEEN 1 AND 200),
  created_at timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY (tenant_id, member_user_id, import_id)
    REFERENCES transaction_imports(tenant_id, member_user_id, id) ON DELETE CASCADE,
  UNIQUE (import_id, row_number)
);
CREATE INDEX imported_transactions_member_date_idx ON imported_transactions(tenant_id, member_user_id, transaction_date DESC, id DESC);

ALTER TABLE transaction_imports ENABLE ROW LEVEL SECURITY;
ALTER TABLE transaction_imports FORCE ROW LEVEL SECURITY;
ALTER TABLE imported_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE imported_transactions FORCE ROW LEVEL SECURITY;

CREATE POLICY transaction_imports_member_read ON transaction_imports
  FOR SELECT TO aegis_runtime
  USING (tenant_id = aegis_context_tenant_id() AND member_user_id = aegis_context_user_id());
CREATE POLICY transaction_imports_member_insert ON transaction_imports
  FOR INSERT TO aegis_runtime
  WITH CHECK (
    tenant_id = aegis_context_tenant_id()
    AND member_user_id = aegis_context_user_id()
    AND EXISTS (
      SELECT 1 FROM consent_events c
      WHERE c.tenant_id = aegis_context_tenant_id()
        AND c.member_user_id = aegis_context_user_id()
        AND c.purpose = 'transaction_history_upload'
        AND c.action = 'granted'
        AND c.event_seq = (
          SELECT max(latest.event_seq) FROM consent_events latest
          WHERE latest.tenant_id = c.tenant_id
            AND latest.member_user_id = c.member_user_id
            AND latest.purpose = 'transaction_history_upload'
        )
    )
  );
CREATE POLICY transaction_imports_member_delete ON transaction_imports
  FOR DELETE TO aegis_runtime
  USING (tenant_id = aegis_context_tenant_id() AND member_user_id = aegis_context_user_id());

CREATE POLICY imported_transactions_member_read ON imported_transactions
  FOR SELECT TO aegis_runtime
  USING (tenant_id = aegis_context_tenant_id() AND member_user_id = aegis_context_user_id());
CREATE POLICY imported_transactions_member_insert ON imported_transactions
  FOR INSERT TO aegis_runtime
  WITH CHECK (
    tenant_id = aegis_context_tenant_id()
    AND member_user_id = aegis_context_user_id()
    AND EXISTS (
      SELECT 1 FROM transaction_imports i
      WHERE i.id = import_id AND i.tenant_id = imported_transactions.tenant_id
        AND i.member_user_id = imported_transactions.member_user_id
    )
    AND EXISTS (
      SELECT 1 FROM consent_events c
      WHERE c.tenant_id = aegis_context_tenant_id()
        AND c.member_user_id = aegis_context_user_id()
        AND c.purpose = 'transaction_history_upload'
        AND c.action = 'granted'
        AND c.event_seq = (
          SELECT max(latest.event_seq) FROM consent_events latest
          WHERE latest.tenant_id = c.tenant_id
            AND latest.member_user_id = c.member_user_id
            AND latest.purpose = 'transaction_history_upload'
        )
    )
  );
CREATE POLICY imported_transactions_member_delete ON imported_transactions
  FOR DELETE TO aegis_runtime
  USING (tenant_id = aegis_context_tenant_id() AND member_user_id = aegis_context_user_id());

GRANT SELECT, INSERT, DELETE ON transaction_imports, imported_transactions TO aegis_runtime;
GRANT SELECT, DELETE ON transaction_imports, imported_transactions TO aegis_privacy_owner;

CREATE FUNCTION aegis_purge_expired_imported_transactions()
RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public
AS $$
DECLARE deleted_count integer;
BEGIN
  DELETE FROM public.transaction_imports WHERE created_at < now() - interval '13 months';
  GET DIAGNOSTICS deleted_count = ROW_COUNT;
  RETURN deleted_count;
END
$$;
ALTER FUNCTION aegis_purge_expired_imported_transactions() OWNER TO aegis_privacy_owner;
REVOKE ALL ON FUNCTION aegis_purge_expired_imported_transactions() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION aegis_purge_expired_imported_transactions() TO aegis_runtime;

COMMIT;
