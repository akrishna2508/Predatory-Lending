BEGIN;

CREATE FUNCTION aegis_purge_expired_bank_transactions()
RETURNS bigint
LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  deleted_count bigint;
BEGIN
  DELETE FROM public.bank_transactions
  WHERE transaction_date < ((now() AT TIME ZONE 'UTC')::date - interval '13 months')::date;
  GET DIAGNOSTICS deleted_count = ROW_COUNT;
  RETURN deleted_count;
END
$$;
ALTER FUNCTION aegis_purge_expired_bank_transactions() OWNER TO aegis_bank_worker_owner;
REVOKE ALL ON FUNCTION aegis_purge_expired_bank_transactions() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION aegis_purge_expired_bank_transactions() TO aegis_bank_worker;

COMMIT;
