BEGIN;

ALTER TABLE consent_events DROP CONSTRAINT consent_events_purpose_check;
ALTER TABLE consent_events ADD CONSTRAINT consent_events_purpose_check
  CHECK (purpose IN (
    'manual_financial_profile', 'read_only_bank_connection', 'transaction_history_upload',
    'cashflow_profile_storage', 'offer_check_storage', 'offer_outcome_reporting', 'research'
  ));

CREATE TABLE member_cashflow_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  member_user_id uuid NOT NULL REFERENCES app_users(id) ON DELETE CASCADE,
  as_of_date date NOT NULL,
  starting_balance numeric(12, 2) NOT NULL CHECK (starting_balance BETWEEN 0 AND 1000000),
  events jsonb NOT NULL CHECK (jsonb_typeof(events) = 'array' AND jsonb_array_length(events) <= 60),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz NOT NULL,
  FOREIGN KEY (tenant_id, member_user_id) REFERENCES memberships(tenant_id, user_id) ON DELETE CASCADE,
  UNIQUE (tenant_id, member_user_id),
  CHECK (expires_at > updated_at)
);
CREATE INDEX member_cashflow_profiles_expiry_idx ON member_cashflow_profiles(expires_at);

ALTER TABLE member_cashflow_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE member_cashflow_profiles FORCE ROW LEVEL SECURITY;

CREATE POLICY member_cashflow_profiles_member_read ON member_cashflow_profiles
  FOR SELECT TO aegis_runtime
  USING (
    tenant_id = aegis_context_tenant_id()
    AND member_user_id = aegis_context_user_id()
    AND (SELECT c.action FROM consent_events c
      WHERE c.tenant_id = aegis_context_tenant_id()
        AND c.member_user_id = aegis_context_user_id()
        AND c.purpose = 'manual_financial_profile'
      ORDER BY c.event_seq DESC LIMIT 1) = 'granted'
    AND (SELECT c.action FROM consent_events c
      WHERE c.tenant_id = aegis_context_tenant_id()
        AND c.member_user_id = aegis_context_user_id()
        AND c.purpose = 'cashflow_profile_storage'
      ORDER BY c.event_seq DESC LIMIT 1) = 'granted'
  );

CREATE POLICY member_cashflow_profiles_member_insert ON member_cashflow_profiles
  FOR INSERT TO aegis_runtime
  WITH CHECK (
    tenant_id = aegis_context_tenant_id()
    AND member_user_id = aegis_context_user_id()
    AND (SELECT c.action FROM consent_events c
      WHERE c.tenant_id = aegis_context_tenant_id()
        AND c.member_user_id = aegis_context_user_id()
        AND c.purpose = 'manual_financial_profile'
      ORDER BY c.event_seq DESC LIMIT 1) = 'granted'
    AND (SELECT c.action FROM consent_events c
      WHERE c.tenant_id = aegis_context_tenant_id()
        AND c.member_user_id = aegis_context_user_id()
        AND c.purpose = 'cashflow_profile_storage'
      ORDER BY c.event_seq DESC LIMIT 1) = 'granted'
  );

CREATE POLICY member_cashflow_profiles_member_update ON member_cashflow_profiles
  FOR UPDATE TO aegis_runtime
  USING (
    tenant_id = aegis_context_tenant_id()
    AND member_user_id = aegis_context_user_id()
    AND (SELECT c.action FROM consent_events c
      WHERE c.tenant_id = aegis_context_tenant_id()
        AND c.member_user_id = aegis_context_user_id()
        AND c.purpose = 'manual_financial_profile'
      ORDER BY c.event_seq DESC LIMIT 1) = 'granted'
    AND (SELECT c.action FROM consent_events c
      WHERE c.tenant_id = aegis_context_tenant_id()
        AND c.member_user_id = aegis_context_user_id()
        AND c.purpose = 'cashflow_profile_storage'
      ORDER BY c.event_seq DESC LIMIT 1) = 'granted'
  )
  WITH CHECK (
    tenant_id = aegis_context_tenant_id()
    AND member_user_id = aegis_context_user_id()
    AND (SELECT c.action FROM consent_events c
      WHERE c.tenant_id = aegis_context_tenant_id()
        AND c.member_user_id = aegis_context_user_id()
        AND c.purpose = 'manual_financial_profile'
      ORDER BY c.event_seq DESC LIMIT 1) = 'granted'
    AND (SELECT c.action FROM consent_events c
      WHERE c.tenant_id = aegis_context_tenant_id()
        AND c.member_user_id = aegis_context_user_id()
        AND c.purpose = 'cashflow_profile_storage'
      ORDER BY c.event_seq DESC LIMIT 1) = 'granted'
  );

CREATE POLICY member_cashflow_profiles_member_delete ON member_cashflow_profiles
  FOR DELETE TO aegis_runtime
  USING (tenant_id = aegis_context_tenant_id() AND member_user_id = aegis_context_user_id());

GRANT SELECT, INSERT, UPDATE, DELETE ON member_cashflow_profiles TO aegis_runtime;
GRANT SELECT, DELETE ON member_cashflow_profiles TO aegis_privacy_owner;

CREATE FUNCTION aegis_purge_expired_member_cashflow_profiles()
RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public
AS $$
DECLARE deleted_count integer;
BEGIN
  DELETE FROM public.member_cashflow_profiles WHERE expires_at <= now();
  GET DIAGNOSTICS deleted_count = ROW_COUNT;
  RETURN deleted_count;
END
$$;
ALTER FUNCTION aegis_purge_expired_member_cashflow_profiles() OWNER TO aegis_privacy_owner;
REVOKE ALL ON FUNCTION aegis_purge_expired_member_cashflow_profiles() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION aegis_purge_expired_member_cashflow_profiles() TO aegis_runtime;

CREATE OR REPLACE FUNCTION aegis_begin_member_account_deletion()
RETURNS text LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public
AS $$
DECLARE
  member_id uuid := public.aegis_context_user_id();
  member_status text;
  current_status text;
BEGIN
  IF member_id IS NULL THEN RAISE EXCEPTION 'Authenticated member context required'; END IF;
  SELECT status INTO member_status FROM public.app_users WHERE id = member_id;
  IF member_status = 'deletion_pending' THEN
    SELECT provider_status INTO current_status FROM public.account_deletion_jobs WHERE user_id = member_id;
    IF current_status IS NOT NULL THEN RETURN current_status; END IF;
  END IF;
  IF member_status IS DISTINCT FROM 'active' THEN RAISE EXCEPTION 'Active member account required'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.memberships WHERE user_id = member_id AND role = 'member' AND status = 'active') THEN
    RAISE EXCEPTION 'Active member access required';
  END IF;
  IF EXISTS (SELECT 1 FROM public.memberships WHERE user_id = member_id AND role <> 'member') THEN
    RAISE EXCEPTION 'Mixed-role account deletion requires support';
  END IF;

  INSERT INTO public.audit_events (tenant_id, actor_user_id, action, entity_type, metadata)
  SELECT DISTINCT tenant_id, NULL::uuid, 'member.data_deleted', 'member_account', '{}'::jsonb
  FROM public.memberships WHERE user_id = member_id AND role = 'member';
  UPDATE public.audit_events SET entity_id = NULL
  WHERE entity_type = 'offer_check' AND entity_id IN (SELECT id FROM public.offer_checks WHERE member_user_id = member_id);
  DELETE FROM public.offer_checks WHERE member_user_id = member_id;
  DELETE FROM public.member_cashflow_profiles WHERE member_user_id = member_id;
  DELETE FROM public.transaction_imports WHERE member_user_id = member_id;
  DELETE FROM public.consent_events WHERE member_user_id = member_id;
  UPDATE public.audit_events SET actor_user_id = NULL,
    entity_id = CASE WHEN entity_id = member_id THEN NULL ELSE entity_id END
  WHERE actor_user_id = member_id OR entity_id = member_id;
  UPDATE public.app_users SET status = 'deletion_pending' WHERE id = member_id;
  UPDATE public.memberships SET status = 'revoked' WHERE user_id = member_id;
  INSERT INTO public.account_deletion_jobs (user_id) VALUES (member_id);
  RETURN 'provider_pending';
END
$$;
ALTER FUNCTION aegis_begin_member_account_deletion() OWNER TO aegis_privacy_owner;

COMMIT;
