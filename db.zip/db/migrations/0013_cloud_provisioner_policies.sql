BEGIN;

-- Allow aegis_provisioner to insert/select organizations, users, memberships, credentials, and audit events
-- in managed cloud environments (Render, AWS RDS, etc.) where BYPASSRLS is restricted to database superusers.

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE policyname = 'organizations_provisioner_all' AND tablename = 'organizations'
  ) THEN
    CREATE POLICY organizations_provisioner_all ON organizations
      FOR ALL TO aegis_provisioner
      USING (true)
      WITH CHECK (true);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE policyname = 'app_users_provisioner_all' AND tablename = 'app_users'
  ) THEN
    CREATE POLICY app_users_provisioner_all ON app_users
      FOR ALL TO aegis_provisioner
      USING (true)
      WITH CHECK (true);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE policyname = 'memberships_provisioner_all' AND tablename = 'memberships'
  ) THEN
    CREATE POLICY memberships_provisioner_all ON memberships
      FOR ALL TO aegis_provisioner
      USING (true)
      WITH CHECK (true);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE policyname = 'audit_events_provisioner_all' AND tablename = 'audit_events'
  ) THEN
    CREATE POLICY audit_events_provisioner_all ON audit_events
      FOR ALL TO aegis_provisioner
      USING (true)
      WITH CHECK (true);
  END IF;
END
$$;

COMMIT;
