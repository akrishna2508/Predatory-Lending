BEGIN;

CREATE TABLE member_reminders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  member_user_id uuid NOT NULL,
  offer_check_id uuid NOT NULL,
  reminder_at timestamptz NOT NULL,
  status text NOT NULL DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'cancelled')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY (tenant_id, member_user_id, offer_check_id)
    REFERENCES offer_checks(tenant_id, member_user_id, id) ON DELETE CASCADE
);
CREATE UNIQUE INDEX member_reminders_one_scheduled_per_check_idx
  ON member_reminders(tenant_id, member_user_id, offer_check_id) WHERE status = 'scheduled';
CREATE INDEX member_reminders_member_time_idx
  ON member_reminders(tenant_id, member_user_id, reminder_at) WHERE status = 'scheduled';

ALTER TABLE member_reminders ENABLE ROW LEVEL SECURITY;
ALTER TABLE member_reminders FORCE ROW LEVEL SECURITY;

CREATE POLICY member_reminders_member_read ON member_reminders
  FOR SELECT TO aegis_runtime
  USING (tenant_id = aegis_context_tenant_id() AND member_user_id = aegis_context_user_id());
CREATE POLICY member_reminders_member_insert ON member_reminders
  FOR INSERT TO aegis_runtime
  WITH CHECK (
    tenant_id = aegis_context_tenant_id()
    AND member_user_id = aegis_context_user_id()
    AND EXISTS (
      SELECT 1 FROM (
        SELECT c.action FROM consent_events c
        WHERE c.tenant_id = aegis_context_tenant_id()
          AND c.member_user_id = aegis_context_user_id()
          AND c.purpose = 'offer_check_storage'
        ORDER BY c.event_seq DESC LIMIT 1
      ) latest_consent WHERE latest_consent.action = 'granted'
    )
  );
CREATE POLICY member_reminders_member_update ON member_reminders
  FOR UPDATE TO aegis_runtime
  USING (tenant_id = aegis_context_tenant_id() AND member_user_id = aegis_context_user_id())
  WITH CHECK (
    tenant_id = aegis_context_tenant_id()
    AND member_user_id = aegis_context_user_id()
    AND (
      status = 'cancelled'
      OR EXISTS (
        SELECT 1 FROM (
          SELECT c.action FROM consent_events c
          WHERE c.tenant_id = aegis_context_tenant_id()
            AND c.member_user_id = aegis_context_user_id()
            AND c.purpose = 'offer_check_storage'
          ORDER BY c.event_seq DESC LIMIT 1
        ) latest_consent WHERE latest_consent.action = 'granted'
      )
    )
  );
CREATE POLICY member_reminders_member_delete ON member_reminders
  FOR DELETE TO aegis_runtime
  USING (tenant_id = aegis_context_tenant_id() AND member_user_id = aegis_context_user_id());

GRANT SELECT, INSERT, UPDATE, DELETE ON member_reminders TO aegis_runtime;
REVOKE ALL ON member_reminders FROM PUBLIC, aegis_reporting_owner, aegis_privacy_owner, aegis_provisioner, aegis_bank_worker, aegis_bank_worker_owner;

COMMIT;
