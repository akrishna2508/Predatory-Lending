BEGIN;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'aegis_bank_worker_owner') THEN
    CREATE ROLE aegis_bank_worker_owner NOLOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT NOBYPASSRLS;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'aegis_bank_worker') THEN
    CREATE ROLE aegis_bank_worker NOLOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT NOBYPASSRLS;
  END IF;
  BEGIN
    EXECUTE 'ALTER ROLE aegis_bank_worker_owner BYPASSRLS';
  EXCEPTION WHEN insufficient_privilege THEN
    NULL;
  END;
END
$$;

GRANT USAGE, CREATE ON SCHEMA public TO aegis_bank_worker_owner, aegis_bank_worker;

ALTER TABLE consent_events ADD COLUMN event_seq bigint GENERATED ALWAYS AS IDENTITY;
CREATE INDEX consent_events_member_purpose_sequence_idx ON consent_events(tenant_id, member_user_id, purpose, event_seq DESC);

CREATE TABLE bank_connections (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  member_user_id uuid NOT NULL REFERENCES app_users(id) ON DELETE CASCADE,
  provider text NOT NULL DEFAULT 'plaid' CHECK (provider = 'plaid'),
  provider_item_id text NOT NULL CHECK (length(provider_item_id) BETWEEN 1 AND 200),
  access_token_ciphertext bytea NOT NULL CHECK (octet_length(access_token_ciphertext) BETWEEN 1 AND 8192),
  institution_id text CHECK (institution_id IS NULL OR length(institution_id) <= 120),
  institution_name text CHECK (institution_name IS NULL OR length(institution_name) <= 200),
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'disconnect_pending', 'reauth_required', 'sync_error')),
  provider_cursor text,
  last_sync_started_at timestamptz,
  last_sync_completed_at timestamptz,
  last_provider_error text CHECK (last_provider_error IS NULL OR length(last_provider_error) <= 80),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY (tenant_id, member_user_id) REFERENCES memberships(tenant_id, user_id) ON DELETE CASCADE,
  UNIQUE (tenant_id, member_user_id, id),
  UNIQUE (provider, provider_item_id)
);
CREATE INDEX bank_connections_member_idx ON bank_connections(tenant_id, member_user_id, created_at DESC);

CREATE TABLE bank_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  member_user_id uuid NOT NULL REFERENCES app_users(id) ON DELETE CASCADE,
  connection_id uuid NOT NULL,
  provider_transaction_id text NOT NULL CHECK (length(provider_transaction_id) BETWEEN 1 AND 200),
  provider_account_id text NOT NULL CHECK (length(provider_account_id) BETWEEN 1 AND 200),
  amount numeric(13, 2) NOT NULL CHECK (amount BETWEEN -1000000000 AND 1000000000),
  transaction_date date NOT NULL,
  authorized_date date,
  name text NOT NULL CHECK (length(name) BETWEEN 1 AND 200),
  merchant_name text CHECK (merchant_name IS NULL OR length(merchant_name) <= 200),
  pending boolean NOT NULL,
  pending_transaction_id text CHECK (pending_transaction_id IS NULL OR length(pending_transaction_id) <= 200),
  categories text[] NOT NULL DEFAULT ARRAY[]::text[] CHECK (cardinality(categories) <= 10),
  provider_updated_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY (tenant_id, member_user_id, connection_id)
    REFERENCES bank_connections(tenant_id, member_user_id, id) ON DELETE CASCADE,
  UNIQUE (connection_id, provider_transaction_id)
);
CREATE INDEX bank_transactions_member_date_idx ON bank_transactions(tenant_id, member_user_id, transaction_date DESC, id DESC);
CREATE INDEX bank_transactions_pending_link_idx ON bank_transactions(connection_id, pending_transaction_id) WHERE pending_transaction_id IS NOT NULL;

CREATE TABLE bank_sync_jobs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  connection_id uuid NOT NULL REFERENCES bank_connections(id) ON DELETE CASCADE,
  job_kind text NOT NULL CHECK (job_kind IN ('sync', 'disconnect')),
  status text NOT NULL DEFAULT 'queued' CHECK (status IN ('queued', 'processing', 'retry', 'completed', 'dead')),
  attempts integer NOT NULL DEFAULT 0 CHECK (attempts >= 0),
  available_at timestamptz NOT NULL DEFAULT now(),
  locked_at timestamptz,
  completed_at timestamptz,
  last_error_code text CHECK (last_error_code IS NULL OR length(last_error_code) <= 80),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX bank_sync_jobs_one_open_per_connection_idx
  ON bank_sync_jobs(connection_id) WHERE status IN ('queued', 'processing', 'retry');
CREATE INDEX bank_sync_jobs_claim_idx ON bank_sync_jobs(available_at, created_at) WHERE status IN ('queued', 'retry');

ALTER TABLE bank_connections ENABLE ROW LEVEL SECURITY;
ALTER TABLE bank_connections FORCE ROW LEVEL SECURITY;
ALTER TABLE bank_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE bank_transactions FORCE ROW LEVEL SECURITY;
ALTER TABLE bank_sync_jobs ENABLE ROW LEVEL SECURITY;
ALTER TABLE bank_sync_jobs FORCE ROW LEVEL SECURITY;

CREATE POLICY bank_connections_member_read ON bank_connections
  FOR SELECT TO aegis_runtime
  USING (tenant_id = aegis_context_tenant_id() AND member_user_id = aegis_context_user_id());
CREATE POLICY bank_connections_member_insert ON bank_connections
  FOR INSERT TO aegis_runtime
  WITH CHECK (
    tenant_id = aegis_context_tenant_id()
    AND member_user_id = aegis_context_user_id()
    AND status = 'active'
    AND EXISTS (
      SELECT 1 FROM (
        SELECT c.action FROM consent_events c
        WHERE c.tenant_id = aegis_context_tenant_id()
          AND c.member_user_id = aegis_context_user_id()
          AND c.purpose = 'read_only_bank_connection'
        ORDER BY c.event_seq DESC LIMIT 1
      ) latest_consent WHERE latest_consent.action = 'granted'
    )
  );
CREATE POLICY bank_connections_member_update ON bank_connections
  FOR UPDATE TO aegis_runtime
  USING (tenant_id = aegis_context_tenant_id() AND member_user_id = aegis_context_user_id())
  WITH CHECK (tenant_id = aegis_context_tenant_id() AND member_user_id = aegis_context_user_id());
CREATE POLICY bank_connections_member_delete ON bank_connections
  FOR DELETE TO aegis_runtime
  USING (tenant_id = aegis_context_tenant_id() AND member_user_id = aegis_context_user_id());

CREATE POLICY bank_transactions_member_read ON bank_transactions
  FOR SELECT TO aegis_runtime
  USING (tenant_id = aegis_context_tenant_id() AND member_user_id = aegis_context_user_id());
CREATE POLICY bank_transactions_member_insert ON bank_transactions
  FOR INSERT TO aegis_runtime
  WITH CHECK (
    tenant_id = aegis_context_tenant_id()
    AND member_user_id = aegis_context_user_id()
    AND EXISTS (
      SELECT 1 FROM bank_connections c
      WHERE c.id = connection_id AND c.tenant_id = bank_transactions.tenant_id AND c.member_user_id = bank_transactions.member_user_id AND c.status = 'active'
    )
    AND EXISTS (
      SELECT 1 FROM (
        SELECT c.action FROM consent_events c
        WHERE c.tenant_id = aegis_context_tenant_id()
          AND c.member_user_id = aegis_context_user_id()
          AND c.purpose = 'read_only_bank_connection'
        ORDER BY c.event_seq DESC LIMIT 1
      ) latest_consent WHERE latest_consent.action = 'granted'
    )
  );
CREATE POLICY bank_transactions_member_update ON bank_transactions
  FOR UPDATE TO aegis_runtime
  USING (tenant_id = aegis_context_tenant_id() AND member_user_id = aegis_context_user_id())
  WITH CHECK (tenant_id = aegis_context_tenant_id() AND member_user_id = aegis_context_user_id());
CREATE POLICY bank_transactions_member_delete ON bank_transactions
  FOR DELETE TO aegis_runtime
  USING (tenant_id = aegis_context_tenant_id() AND member_user_id = aegis_context_user_id());

-- The web process gets only scoped enqueue functions. Provider tokens and queue contents stay behind a separate owner role.
GRANT USAGE ON SCHEMA public TO aegis_bank_worker_owner;
GRANT SELECT (id, tenant_id, member_user_id, provider, provider_item_id, access_token_ciphertext, status, provider_cursor, created_at)
  ON bank_connections TO aegis_bank_worker_owner;
GRANT UPDATE (status, provider_cursor, last_sync_started_at, last_sync_completed_at, last_provider_error, updated_at), DELETE
  ON bank_connections TO aegis_bank_worker_owner;
GRANT SELECT (tenant_id, member_user_id, purpose, action, event_seq) ON consent_events TO aegis_bank_worker_owner;
GRANT SELECT (tenant_id, user_id, role, status) ON memberships TO aegis_bank_worker_owner;
GRANT SELECT (id, status) ON app_users TO aegis_bank_worker_owner;
GRANT SELECT (connection_id, provider_transaction_id, provider_account_id, amount, transaction_date, authorized_date,
  name, merchant_name, pending, pending_transaction_id, categories, provider_updated_at, updated_at),
  INSERT, UPDATE, DELETE ON bank_transactions TO aegis_bank_worker_owner;
GRANT SELECT, INSERT, UPDATE ON bank_sync_jobs TO aegis_bank_worker_owner;
GRANT SELECT (id, tenant_id, member_user_id, status) ON bank_connections TO aegis_privacy_owner;
GRANT UPDATE (status, institution_id, institution_name, provider_cursor, updated_at) ON bank_connections TO aegis_privacy_owner;
GRANT SELECT (member_user_id) ON bank_transactions TO aegis_privacy_owner;
GRANT DELETE ON bank_transactions TO aegis_privacy_owner;
GRANT SELECT (id, connection_id, job_kind, status, available_at) ON bank_sync_jobs TO aegis_privacy_owner;
GRANT INSERT (connection_id, job_kind), UPDATE (job_kind, status, available_at, updated_at)
  ON bank_sync_jobs TO aegis_privacy_owner;
GRANT SELECT (id, tenant_id, member_user_id, provider, provider_item_id, institution_id, institution_name, status, last_sync_started_at, last_sync_completed_at, last_provider_error, created_at, updated_at) ON bank_connections TO aegis_runtime;
GRANT SELECT ON bank_transactions TO aegis_runtime;
GRANT INSERT (id, tenant_id, member_user_id, provider, provider_item_id, access_token_ciphertext, institution_id, institution_name, status)
  ON bank_connections TO aegis_runtime;
REVOKE ALL ON bank_sync_jobs FROM PUBLIC, aegis_runtime, aegis_reporting_owner, aegis_provisioner;

CREATE FUNCTION aegis_enqueue_member_bank_sync(p_connection_id uuid, reason text)
RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  connection_status text;
  current_action text;
BEGIN
  IF reason NOT IN ('member_request', 'webhook', 'reconnect') THEN
    RETURN false;
  END IF;
  SELECT c.status INTO connection_status
  FROM public.bank_connections c
  JOIN public.memberships m ON m.tenant_id = c.tenant_id AND m.user_id = c.member_user_id
  JOIN public.app_users u ON u.id = c.member_user_id
  WHERE c.id = p_connection_id
    AND c.tenant_id = public.aegis_context_tenant_id()
    AND c.member_user_id = public.aegis_context_user_id()
    AND m.role = 'member' AND m.status = 'active' AND u.status = 'active';
  IF connection_status IS DISTINCT FROM 'active' THEN RETURN false; END IF;

  SELECT c.action INTO current_action
  FROM public.consent_events c
  WHERE c.tenant_id = public.aegis_context_tenant_id()
    AND c.member_user_id = public.aegis_context_user_id()
    AND c.purpose = 'read_only_bank_connection'
  ORDER BY c.event_seq DESC LIMIT 1;
  IF current_action IS DISTINCT FROM 'granted' THEN RETURN false; END IF;

  INSERT INTO public.bank_sync_jobs(connection_id, job_kind)
  VALUES (p_connection_id, 'sync')
  ON CONFLICT (connection_id) WHERE status IN ('queued', 'processing', 'retry')
  DO UPDATE SET job_kind = CASE WHEN public.bank_sync_jobs.job_kind = 'disconnect' THEN 'disconnect' ELSE 'sync' END,
                status = CASE WHEN public.bank_sync_jobs.status = 'processing' THEN 'processing' ELSE 'queued' END,
                available_at = LEAST(public.bank_sync_jobs.available_at, now()),
                updated_at = now();
  RETURN true;
END
$$;
ALTER FUNCTION aegis_enqueue_member_bank_sync(uuid, text) OWNER TO aegis_bank_worker_owner;
REVOKE ALL ON FUNCTION aegis_enqueue_member_bank_sync(uuid, text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION aegis_enqueue_member_bank_sync(uuid, text) TO aegis_runtime;

CREATE FUNCTION aegis_enqueue_plaid_item_sync(provider_item_id text)
RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  v_connection_id uuid;
  v_member_id uuid;
  v_tenant_id uuid;
  current_status text;
  current_action text;
BEGIN
  SELECT c.id, c.member_user_id, c.tenant_id, c.status
    INTO v_connection_id, v_member_id, v_tenant_id, current_status
  FROM public.bank_connections c
  WHERE c.provider = 'plaid' AND c.provider_item_id = aegis_enqueue_plaid_item_sync.provider_item_id;
  IF v_connection_id IS NULL OR current_status <> 'active' THEN RETURN false; END IF;
  SELECT c.action INTO current_action
  FROM public.consent_events c
  WHERE c.tenant_id = v_tenant_id AND c.member_user_id = v_member_id AND c.purpose = 'read_only_bank_connection'
  ORDER BY c.event_seq DESC LIMIT 1;
  IF current_action IS DISTINCT FROM 'granted' THEN RETURN false; END IF;

  INSERT INTO public.bank_sync_jobs(connection_id, job_kind)
  VALUES (v_connection_id, 'sync')
  ON CONFLICT (connection_id) WHERE status IN ('queued', 'processing', 'retry')
  DO UPDATE SET job_kind = CASE WHEN public.bank_sync_jobs.job_kind = 'disconnect' THEN 'disconnect' ELSE 'sync' END,
                status = CASE WHEN public.bank_sync_jobs.status = 'processing' THEN 'processing' ELSE 'queued' END,
                available_at = LEAST(public.bank_sync_jobs.available_at, now()),
                updated_at = now();
  RETURN true;
END
$$;
ALTER FUNCTION aegis_enqueue_plaid_item_sync(text) OWNER TO aegis_bank_worker_owner;
REVOKE ALL ON FUNCTION aegis_enqueue_plaid_item_sync(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION aegis_enqueue_plaid_item_sync(text) TO aegis_runtime;

CREATE FUNCTION aegis_claim_bank_sync_jobs(p_limit integer DEFAULT 5)
RETURNS TABLE(
  job_id uuid,
  connection_id uuid,
  tenant_id uuid,
  member_user_id uuid,
  provider_item_id text,
  access_token_ciphertext bytea,
  provider_cursor text,
  job_kind text,
  attempts integer
)
LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
BEGIN
  IF p_limit < 1 OR p_limit > 20 THEN RAISE EXCEPTION 'Claim size must be from 1 through 20'; END IF;
  RETURN QUERY
  WITH candidates AS (
    SELECT j.id FROM public.bank_sync_jobs j
    WHERE (j.status IN ('queued', 'retry') AND j.available_at <= now())
       OR (j.status = 'processing' AND j.locked_at < now() - interval '5 minutes')
    ORDER BY j.available_at, j.created_at
    FOR UPDATE SKIP LOCKED LIMIT p_limit
  ), claimed AS (
    UPDATE public.bank_sync_jobs j SET status = 'processing', locked_at = now(),
      attempts = j.attempts + 1, updated_at = now()
    FROM candidates c WHERE j.id = c.id
    RETURNING j.id, j.connection_id, j.job_kind, j.attempts
  )
  SELECT claimed.id, c.id, c.tenant_id, c.member_user_id, c.provider_item_id,
         c.access_token_ciphertext, c.provider_cursor, claimed.job_kind, claimed.attempts
  FROM claimed JOIN public.bank_connections c ON c.id = claimed.connection_id
  ORDER BY c.created_at;
END
$$;
ALTER FUNCTION aegis_claim_bank_sync_jobs(integer) OWNER TO aegis_bank_worker_owner;
REVOKE ALL ON FUNCTION aegis_claim_bank_sync_jobs(integer) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION aegis_claim_bank_sync_jobs(integer) TO aegis_bank_worker;

CREATE FUNCTION aegis_heartbeat_bank_sync_job(p_job_id uuid)
RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
BEGIN
  UPDATE public.bank_sync_jobs SET locked_at = now(), updated_at = now()
  WHERE id = p_job_id AND status = 'processing';
  RETURN FOUND;
END
$$;
ALTER FUNCTION aegis_heartbeat_bank_sync_job(uuid) OWNER TO aegis_bank_worker_owner;
REVOKE ALL ON FUNCTION aegis_heartbeat_bank_sync_job(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION aegis_heartbeat_bank_sync_job(uuid) TO aegis_bank_worker;

CREATE FUNCTION aegis_complete_bank_sync_job(p_job_id uuid, p_next_cursor text, p_changes jsonb)
RETURNS text
LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  v_job public.bank_sync_jobs%ROWTYPE;
  v_connection_id uuid;
  v_connection_tenant_id uuid;
  v_member_user_id uuid;
  v_connection_status text;
  v_latest_consent text;
  v_change jsonb;
  v_transaction jsonb;
  v_categories text[];
  v_kind text;
  v_provider_id text;
  v_affected integer := 0;
BEGIN
  IF p_next_cursor IS NULL OR length(p_next_cursor) > 10000 OR p_changes IS NULL OR jsonb_typeof(p_changes) <> 'array'
     OR jsonb_array_length(p_changes) > 50000 THEN RAISE EXCEPTION 'Sync result is invalid'; END IF;
  SELECT * INTO v_job FROM public.bank_sync_jobs WHERE id = p_job_id FOR UPDATE;
  IF NOT FOUND OR v_job.status <> 'processing' OR v_job.job_kind <> 'sync' THEN RAISE EXCEPTION 'Sync job is not active'; END IF;
  SELECT c.id, c.tenant_id, c.member_user_id, c.status
    INTO v_connection_id, v_connection_tenant_id, v_member_user_id, v_connection_status
  FROM public.bank_connections c WHERE c.id = v_job.connection_id FOR UPDATE;
  IF NOT FOUND OR v_connection_status <> 'active' THEN RAISE EXCEPTION 'Bank connection is not active'; END IF;
  SELECT c.action INTO v_latest_consent FROM public.consent_events c
  WHERE c.tenant_id = v_connection_tenant_id AND c.member_user_id = v_member_user_id
    AND c.purpose = 'read_only_bank_connection'
  ORDER BY c.event_seq DESC LIMIT 1;
  IF v_latest_consent IS DISTINCT FROM 'granted' THEN
    UPDATE public.bank_connections SET status = 'disconnect_pending', updated_at = now() WHERE id = v_connection_id;
    DELETE FROM public.bank_transactions WHERE connection_id = v_connection_id;
    UPDATE public.bank_sync_jobs SET job_kind = 'disconnect', status = 'queued', locked_at = NULL,
      available_at = now(), updated_at = now() WHERE id = p_job_id;
    RETURN 'disconnect_queued';
  END IF;

  FOR v_change IN SELECT value FROM jsonb_array_elements(p_changes) AS changes(value) LOOP
    v_kind := v_change->>'kind';
    IF v_kind = 'removed' THEN
      v_provider_id := v_change->>'transactionId';
      IF v_provider_id IS NULL OR length(v_provider_id) > 200 THEN RAISE EXCEPTION 'Removed transaction is invalid'; END IF;
      DELETE FROM public.bank_transactions WHERE connection_id = v_connection_id AND provider_transaction_id = v_provider_id;
    ELSIF v_kind IN ('added', 'modified') THEN
      v_transaction := v_change->'transaction';
      IF jsonb_typeof(v_transaction) <> 'object' THEN RAISE EXCEPTION 'Changed transaction is invalid'; END IF;
      IF jsonb_typeof(v_transaction->'categories') = 'array' THEN
        SELECT COALESCE(array_agg(value), ARRAY[]::text[]) INTO v_categories
        FROM jsonb_array_elements_text(v_transaction->'categories') AS categories(value);
      ELSE
        RAISE EXCEPTION 'Transaction categories are invalid';
      END IF;
      INSERT INTO public.bank_transactions(
        tenant_id, member_user_id, connection_id, provider_transaction_id, provider_account_id,
        amount, transaction_date, authorized_date, name, merchant_name, pending,
        pending_transaction_id, categories, provider_updated_at, updated_at
      ) VALUES (
        v_connection_tenant_id, v_member_user_id, v_connection_id,
        v_transaction->>'transactionId', v_transaction->>'accountId',
        (v_transaction->>'amount')::numeric, (v_transaction->>'date')::date,
        nullif(v_transaction->>'authorizedDate', '')::date, v_transaction->>'name',
        nullif(v_transaction->>'merchantName', ''), (v_transaction->>'pending')::boolean,
        nullif(v_transaction->>'pendingTransactionId', ''), v_categories, now(), now()
      )
      ON CONFLICT (connection_id, provider_transaction_id) DO UPDATE SET
        provider_account_id = EXCLUDED.provider_account_id, amount = EXCLUDED.amount,
        transaction_date = EXCLUDED.transaction_date, authorized_date = EXCLUDED.authorized_date,
        name = EXCLUDED.name, merchant_name = EXCLUDED.merchant_name, pending = EXCLUDED.pending,
        pending_transaction_id = EXCLUDED.pending_transaction_id, categories = EXCLUDED.categories,
        provider_updated_at = now(), updated_at = now();
    ELSE
      RAISE EXCEPTION 'Transaction change kind is invalid';
    END IF;
    v_affected := v_affected + 1;
  END LOOP;

  UPDATE public.bank_connections SET provider_cursor = p_next_cursor, last_sync_completed_at = now(),
    last_provider_error = NULL, status = 'active', updated_at = now() WHERE id = v_connection_id;
  UPDATE public.bank_sync_jobs SET status = 'completed', completed_at = now(), locked_at = NULL,
    last_error_code = NULL, updated_at = now() WHERE id = p_job_id;
  RETURN 'completed';
END
$$;
ALTER FUNCTION aegis_complete_bank_sync_job(uuid, text, jsonb) OWNER TO aegis_bank_worker_owner;
REVOKE ALL ON FUNCTION aegis_complete_bank_sync_job(uuid, text, jsonb) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION aegis_complete_bank_sync_job(uuid, text, jsonb) TO aegis_bank_worker;

CREATE FUNCTION aegis_complete_bank_disconnect_job(p_job_id uuid)
RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  v_connection_id uuid;
BEGIN
  SELECT j.connection_id INTO v_connection_id FROM public.bank_sync_jobs j
  WHERE j.id = p_job_id AND j.job_kind = 'disconnect' AND j.status = 'processing' FOR UPDATE;
  IF v_connection_id IS NULL THEN RETURN false; END IF;
  DELETE FROM public.bank_connections WHERE id = v_connection_id AND status = 'disconnect_pending';
  RETURN FOUND;
END
$$;
ALTER FUNCTION aegis_complete_bank_disconnect_job(uuid) OWNER TO aegis_bank_worker_owner;
REVOKE ALL ON FUNCTION aegis_complete_bank_disconnect_job(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION aegis_complete_bank_disconnect_job(uuid) TO aegis_bank_worker;

CREATE FUNCTION aegis_fail_bank_sync_job(p_job_id uuid, p_error_code text)
RETURNS text
LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  v_job public.bank_sync_jobs%ROWTYPE;
  v_status text;
BEGIN
  IF p_error_code NOT IN ('NETWORK', 'RATE_LIMIT', 'PROVIDER_ERROR', 'ITEM_LOGIN_REQUIRED', 'ITEM_NOT_FOUND', 'INVALID_RESPONSE', 'KMS_ERROR') THEN
    RAISE EXCEPTION 'Provider error code is invalid';
  END IF;
  SELECT * INTO v_job FROM public.bank_sync_jobs WHERE id = p_job_id FOR UPDATE;
  IF NOT FOUND OR v_job.status <> 'processing' THEN RAISE EXCEPTION 'Sync job is not active'; END IF;
  IF v_job.job_kind = 'disconnect' AND p_error_code = 'ITEM_NOT_FOUND' THEN
    DELETE FROM public.bank_connections WHERE id = v_job.connection_id;
    RETURN 'completed';
  END IF;
  IF v_job.attempts >= 8 OR p_error_code = 'ITEM_LOGIN_REQUIRED' THEN v_status := 'dead';
  ELSE v_status := 'retry'; END IF;
  UPDATE public.bank_sync_jobs SET status = v_status, locked_at = NULL,
    available_at = now() + make_interval(secs => LEAST(3600, 15 * (2 ^ LEAST(attempts, 7))::integer)),
    last_error_code = p_error_code, updated_at = now() WHERE id = p_job_id;
  IF v_job.job_kind = 'disconnect' AND v_status = 'dead' THEN
    UPDATE public.bank_connections SET last_provider_error = p_error_code, updated_at = now() WHERE id = v_job.connection_id;
  ELSIF v_job.job_kind = 'sync' AND v_status = 'dead' THEN
    UPDATE public.bank_connections SET status = CASE WHEN p_error_code = 'ITEM_LOGIN_REQUIRED' THEN 'reauth_required' ELSE 'sync_error' END,
      last_provider_error = p_error_code, updated_at = now() WHERE id = v_job.connection_id;
  END IF;
  RETURN v_status;
END
$$;
ALTER FUNCTION aegis_fail_bank_sync_job(uuid, text) OWNER TO aegis_bank_worker_owner;
REVOKE ALL ON FUNCTION aegis_fail_bank_sync_job(uuid, text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION aegis_fail_bank_sync_job(uuid, text) TO aegis_bank_worker;

CREATE FUNCTION aegis_disconnect_member_bank_connection(p_connection_id uuid)
RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  v_member_id uuid := public.aegis_context_user_id();
  v_tenant_id uuid := public.aegis_context_tenant_id();
  v_status text;
BEGIN
  SELECT c.status INTO v_status
  FROM public.bank_connections c
  JOIN public.memberships m ON m.tenant_id = c.tenant_id AND m.user_id = c.member_user_id
  JOIN public.app_users u ON u.id = c.member_user_id
  WHERE c.id = p_connection_id AND c.tenant_id = v_tenant_id AND c.member_user_id = v_member_id
    AND m.role = 'member' AND m.status = 'active' AND u.status = 'active';
  IF v_status IS NULL THEN RETURN false; END IF;

  UPDATE public.bank_connections SET status = 'disconnect_pending', updated_at = now()
  WHERE id = p_connection_id AND status <> 'disconnect_pending';
  DELETE FROM public.bank_transactions WHERE connection_id = p_connection_id;
  INSERT INTO public.bank_sync_jobs(connection_id, job_kind)
  VALUES (p_connection_id, 'disconnect')
  ON CONFLICT (connection_id) WHERE status IN ('queued', 'processing', 'retry')
  DO UPDATE SET job_kind = 'disconnect',
                status = CASE WHEN public.bank_sync_jobs.status = 'processing' THEN 'processing' ELSE 'queued' END,
                available_at = LEAST(public.bank_sync_jobs.available_at, now()),
                updated_at = now();
  RETURN true;
END
$$;
ALTER FUNCTION aegis_disconnect_member_bank_connection(uuid) OWNER TO aegis_bank_worker_owner;
REVOKE ALL ON FUNCTION aegis_disconnect_member_bank_connection(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION aegis_disconnect_member_bank_connection(uuid) TO aegis_runtime;

CREATE FUNCTION aegis_revoke_member_bank_consent()
RETURNS integer
LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  v_member_id uuid := public.aegis_context_user_id();
  v_tenant_id uuid := public.aegis_context_tenant_id();
  affected integer;
BEGIN
  IF v_member_id IS NULL OR v_tenant_id IS NULL THEN RAISE EXCEPTION 'Member context required'; END IF;
  IF NOT EXISTS (
    SELECT 1 FROM public.memberships m JOIN public.app_users u ON u.id = m.user_id
    WHERE m.tenant_id = v_tenant_id AND m.user_id = v_member_id AND m.role = 'member'
      AND m.status = 'active' AND u.status = 'active'
  ) THEN RAISE EXCEPTION 'Active member access required'; END IF;
  IF NOT EXISTS (
    SELECT 1 FROM public.consent_events c
    WHERE c.tenant_id = v_tenant_id AND c.member_user_id = v_member_id
      AND c.purpose = 'read_only_bank_connection'
    ORDER BY c.event_seq DESC LIMIT 1
  ) THEN RETURN 0; END IF;
  IF (SELECT c.action FROM public.consent_events c
      WHERE c.tenant_id = v_tenant_id AND c.member_user_id = v_member_id
        AND c.purpose = 'read_only_bank_connection'
      ORDER BY c.event_seq DESC LIMIT 1) <> 'revoked' THEN
    RAISE EXCEPTION 'Bank connection consent must be revoked first';
  END IF;

  UPDATE public.bank_connections c SET status = 'disconnect_pending', updated_at = now()
  WHERE c.tenant_id = v_tenant_id AND c.member_user_id = v_member_id AND c.status <> 'disconnect_pending';
  GET DIAGNOSTICS affected = ROW_COUNT;
  DELETE FROM public.bank_transactions t USING public.bank_connections c
  WHERE t.connection_id = c.id AND c.tenant_id = v_tenant_id AND c.member_user_id = v_member_id;
  INSERT INTO public.bank_sync_jobs(connection_id, job_kind)
  SELECT c.id, 'disconnect' FROM public.bank_connections c
  WHERE c.tenant_id = v_tenant_id AND c.member_user_id = v_member_id AND c.status = 'disconnect_pending'
  ON CONFLICT (connection_id) WHERE status IN ('queued', 'processing', 'retry')
  DO UPDATE SET job_kind = 'disconnect',
                status = CASE WHEN public.bank_sync_jobs.status = 'processing' THEN 'processing' ELSE 'queued' END,
                available_at = LEAST(public.bank_sync_jobs.available_at, now()),
                updated_at = now();
  RETURN affected;
END
$$;
ALTER FUNCTION aegis_revoke_member_bank_consent() OWNER TO aegis_bank_worker_owner;
REVOKE ALL ON FUNCTION aegis_revoke_member_bank_consent() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION aegis_revoke_member_bank_consent() TO aegis_runtime;

GRANT EXECUTE ON FUNCTION aegis_context_tenant_id(), aegis_context_user_id() TO aegis_bank_worker_owner;

CREATE OR REPLACE FUNCTION aegis_begin_member_account_deletion()
RETURNS text
LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  member_id uuid := public.aegis_context_user_id();
  member_status text;
  current_provider_status text;
BEGIN
  IF member_id IS NULL THEN RAISE EXCEPTION 'Authenticated member context required'; END IF;
  SELECT u.status INTO member_status FROM public.app_users u WHERE u.id = member_id;
  IF member_status = 'deletion_pending' THEN
    SELECT j.provider_status INTO current_provider_status FROM public.account_deletion_jobs j WHERE j.user_id = member_id;
    IF current_provider_status IS NOT NULL THEN RETURN current_provider_status; END IF;
  END IF;
  IF member_status IS DISTINCT FROM 'active' THEN RAISE EXCEPTION 'Active member account required'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.memberships m WHERE m.user_id = member_id AND m.role = 'member' AND m.status = 'active') THEN
    RAISE EXCEPTION 'Active member access required';
  END IF;
  IF EXISTS (SELECT 1 FROM public.memberships m WHERE m.user_id = member_id AND m.role <> 'member') THEN
    RAISE EXCEPTION 'Mixed-role account deletion requires support';
  END IF;

  -- Keep only the encrypted credential and provider Item reference until the worker confirms offboarding.
  UPDATE public.bank_connections SET status = 'disconnect_pending', institution_id = NULL,
    institution_name = NULL, provider_cursor = NULL, updated_at = now()
  WHERE member_user_id = member_id;
  DELETE FROM public.bank_transactions WHERE member_user_id = member_id;
  INSERT INTO public.bank_sync_jobs(connection_id, job_kind)
  SELECT id, 'disconnect' FROM public.bank_connections WHERE member_user_id = member_id
  ON CONFLICT (connection_id) WHERE status IN ('queued', 'processing', 'retry')
  DO UPDATE SET job_kind = 'disconnect',
                status = CASE WHEN public.bank_sync_jobs.status = 'processing' THEN 'processing' ELSE 'queued' END,
                available_at = LEAST(public.bank_sync_jobs.available_at, now()), updated_at = now();

  INSERT INTO public.audit_events (tenant_id, actor_user_id, action, entity_type, metadata)
  SELECT DISTINCT m.tenant_id, NULL::uuid, 'member.data_deleted', 'member_account', '{}'::jsonb
  FROM public.memberships m WHERE m.user_id = member_id AND m.role = 'member';
  UPDATE public.audit_events SET entity_id = NULL
  WHERE entity_type = 'offer_check' AND entity_id IN (SELECT oc.id FROM public.offer_checks oc WHERE oc.member_user_id = member_id);
  DELETE FROM public.offer_checks WHERE member_user_id = member_id;
  DELETE FROM public.consent_events WHERE member_user_id = member_id;
  UPDATE public.audit_events SET actor_user_id = NULL,
    entity_id = CASE WHEN entity_id = member_id THEN NULL ELSE entity_id END
  WHERE actor_user_id = member_id OR entity_id = member_id;
  UPDATE public.app_users SET status = 'deletion_pending' WHERE id = member_id;
  UPDATE public.memberships SET status = 'revoked' WHERE user_id = member_id;
  INSERT INTO public.account_deletion_jobs (user_id) VALUES (member_id);
  RETURN 'provider_pending';
END
$$;
ALTER FUNCTION aegis_begin_member_account_deletion() OWNER TO aegis_privacy_owner;

CREATE OR REPLACE FUNCTION aegis_finalize_member_account_deletion()
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  member_id uuid := public.aegis_context_user_id();
BEGIN
  IF member_id IS NULL THEN RAISE EXCEPTION 'Authenticated member context required'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.account_deletion_jobs j WHERE j.user_id = member_id AND j.provider_status = 'identity_deleted') THEN
    RAISE EXCEPTION 'Identity-provider deletion must complete first';
  END IF;
  IF EXISTS (SELECT 1 FROM public.bank_connections c WHERE c.member_user_id = member_id) THEN
    RAISE EXCEPTION 'Bank provider disconnection must complete first';
  END IF;
  DELETE FROM public.app_users WHERE id = member_id AND status = 'deletion_pending';
  IF NOT FOUND THEN RAISE EXCEPTION 'Pending account deletion not found'; END IF;
END
$$;
ALTER FUNCTION aegis_finalize_member_account_deletion() OWNER TO aegis_privacy_owner;

COMMIT;
