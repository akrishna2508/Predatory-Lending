BEGIN;

-- This self-hosted release replaces bank linking with member-controlled CSV upload.
-- Remove provider credentials, tokens, snapshots, queues, and provider worker APIs.
DROP FUNCTION IF EXISTS aegis_enqueue_member_bank_sync(uuid, text) CASCADE;
DROP FUNCTION IF EXISTS aegis_enqueue_plaid_item_sync(text) CASCADE;
DROP FUNCTION IF EXISTS aegis_claim_bank_sync_jobs(integer) CASCADE;
DROP FUNCTION IF EXISTS aegis_heartbeat_bank_sync_job(uuid) CASCADE;
DROP FUNCTION IF EXISTS aegis_complete_bank_sync_job(uuid, text, jsonb) CASCADE;
DROP FUNCTION IF EXISTS aegis_complete_bank_disconnect_job(uuid) CASCADE;
DROP FUNCTION IF EXISTS aegis_fail_bank_sync_job(uuid, text) CASCADE;
DROP FUNCTION IF EXISTS aegis_disconnect_member_bank_connection(uuid) CASCADE;
DROP FUNCTION IF EXISTS aegis_revoke_member_bank_consent() CASCADE;
DROP FUNCTION IF EXISTS aegis_replace_bank_account_balances(uuid, jsonb) CASCADE;
DROP FUNCTION IF EXISTS aegis_clear_disconnected_bank_balances() CASCADE;
DROP FUNCTION IF EXISTS aegis_purge_expired_bank_transactions() CASCADE;
DROP TABLE IF EXISTS bank_account_balances, bank_transactions, bank_sync_jobs, bank_connections CASCADE;

COMMIT;
