BEGIN;

CREATE OR REPLACE FUNCTION aegis_begin_member_account_deletion()
RETURNS text LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public
AS $$
DECLARE
  member_id uuid := public.aegis_context_user_id();
  member_status text;
  current_status text;
BEGIN
  IF member_id IS NULL THEN RAISE EXCEPTION 'Authenticated member context required'; END IF;
  SELECT status INTO member_status FROM public.app_users WHERE id = member_id;
  IF member_status = 'deletion_pending' THEN
    SELECT provider_status INTO current_status FROM public.account_deletion_jobs WHERE user_id = member_id;
    IF current_status IS NOT NULL THEN RETURN current_status; END IF;
  END IF;
  IF member_status IS DISTINCT FROM 'active' THEN RAISE EXCEPTION 'Active member account required'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.memberships WHERE user_id = member_id AND role = 'member' AND status = 'active') THEN
    RAISE EXCEPTION 'Active member access required';
  END IF;
  IF EXISTS (SELECT 1 FROM public.memberships WHERE user_id = member_id AND role <> 'member') THEN
    RAISE EXCEPTION 'Mixed-role account deletion requires support';
  END IF;

  INSERT INTO public.audit_events (tenant_id, actor_user_id, action, entity_type, metadata)
  SELECT DISTINCT tenant_id, NULL::uuid, 'member.data_deleted', 'member_account', '{}'::jsonb
  FROM public.memberships WHERE user_id = member_id AND role = 'member';
  UPDATE public.audit_events SET entity_id = NULL
  WHERE entity_type = 'offer_check' AND entity_id IN (SELECT id FROM public.offer_checks WHERE member_user_id = member_id);
  DELETE FROM public.offer_checks WHERE member_user_id = member_id;
  DELETE FROM public.transaction_imports WHERE member_user_id = member_id;
  DELETE FROM public.consent_events WHERE member_user_id = member_id;
  UPDATE public.audit_events SET actor_user_id = NULL,
    entity_id = CASE WHEN entity_id = member_id THEN NULL ELSE entity_id END
  WHERE actor_user_id = member_id OR entity_id = member_id;
  UPDATE public.app_users SET status = 'deletion_pending' WHERE id = member_id;
  UPDATE public.memberships SET status = 'revoked' WHERE user_id = member_id;
  INSERT INTO public.account_deletion_jobs (user_id) VALUES (member_id);
  RETURN 'provider_pending';
END
$$;
ALTER FUNCTION aegis_begin_member_account_deletion() OWNER TO aegis_privacy_owner;

CREATE OR REPLACE FUNCTION aegis_finalize_member_account_deletion()
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public
AS $$
DECLARE member_id uuid := public.aegis_context_user_id();
BEGIN
  IF member_id IS NULL THEN RAISE EXCEPTION 'Authenticated member context required'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.account_deletion_jobs WHERE user_id = member_id AND provider_status = 'identity_deleted') THEN
    RAISE EXCEPTION 'Local identity deletion must be recorded first';
  END IF;
  DELETE FROM public.app_users WHERE id = member_id AND status = 'deletion_pending';
  IF NOT FOUND THEN RAISE EXCEPTION 'Pending account deletion not found'; END IF;
END
$$;
ALTER FUNCTION aegis_finalize_member_account_deletion() OWNER TO aegis_privacy_owner;

CREATE OR REPLACE FUNCTION aegis_resolve_member_session(p_token_hash bytea)
RETURNS uuid LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public
AS $$
  SELECT s.user_id FROM public.member_sessions s
  JOIN public.app_users u ON u.id = s.user_id
  WHERE s.token_hash = p_token_hash AND s.revoked_at IS NULL AND s.expires_at > now()
    AND u.status IN ('active', 'deletion_pending')
  LIMIT 1
$$;
ALTER FUNCTION aegis_resolve_member_session(bytea) OWNER TO aegis_privacy_owner;

COMMIT;
