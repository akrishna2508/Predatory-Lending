BEGIN;

-- Keep tenant context empty for suspended organizations or inactive memberships.
-- A BYPASSRLS owner is required because this function is called from row policies
-- on organizations, memberships, and every tenant-owned data table.
CREATE OR REPLACE FUNCTION aegis_context_tenant_id()
RETURNS uuid
LANGUAGE sql STABLE SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
  SELECT context.tenant_id
  FROM (
    SELECT nullif(current_setting('aegis.tenant_id', true), '')::uuid AS tenant_id,
           nullif(current_setting('aegis.user_id', true), '')::uuid AS user_id
  ) AS context
  WHERE EXISTS (
    SELECT 1
    FROM public.organizations o
    JOIN public.memberships m ON m.tenant_id = o.id
    JOIN public.app_users u ON u.id = m.user_id
    WHERE o.id = context.tenant_id
      AND m.user_id = context.user_id
      AND o.status = 'active'
      AND m.status = 'active'
      AND u.status = 'active'
      AND m.role IN ('member', 'partner_admin', 'partner_analyst')
  )
$$;
ALTER FUNCTION aegis_context_tenant_id() OWNER TO aegis_reporting_owner;
REVOKE ALL ON FUNCTION aegis_context_tenant_id() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION aegis_context_tenant_id() TO aegis_runtime, aegis_reporting_owner, aegis_privacy_owner;

-- Return only the latest consent decision for the identity set on this transaction.
-- The function exposes a boolean for the current member and no consent rows.
GRANT SELECT (tenant_id, member_user_id, purpose, action, event_seq)
  ON consent_events TO aegis_privacy_owner;
CREATE FUNCTION aegis_member_has_consent(required_purpose text)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
  SELECT coalesce((
    SELECT c.action = 'granted'
    FROM public.consent_events c
    WHERE c.tenant_id = nullif(current_setting('aegis.tenant_id', true), '')::uuid
      AND c.member_user_id = nullif(current_setting('aegis.user_id', true), '')::uuid
      AND c.purpose = required_purpose
    ORDER BY c.event_seq DESC
    LIMIT 1
  ), false)
$$;
ALTER FUNCTION aegis_member_has_consent(text) OWNER TO aegis_privacy_owner;
REVOKE ALL ON FUNCTION aegis_member_has_consent(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION aegis_member_has_consent(text) TO aegis_runtime;

-- Use a narrowly scoped definer purge because the consent-revoked SELECT policy
-- intentionally hides a saved profile before the ordinary DELETE can find it.
CREATE FUNCTION aegis_purge_member_cashflow_profile()
RETURNS integer
LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  current_tenant uuid := nullif(current_setting('aegis.tenant_id', true), '')::uuid;
  current_member uuid := nullif(current_setting('aegis.user_id', true), '')::uuid;
  deleted_count integer;
BEGIN
  IF current_tenant IS NULL OR current_member IS NULL THEN
    RAISE EXCEPTION 'Authenticated member context required';
  END IF;
  DELETE FROM public.member_cashflow_profiles
  WHERE tenant_id = current_tenant AND member_user_id = current_member;
  GET DIAGNOSTICS deleted_count = ROW_COUNT;
  RETURN deleted_count;
END
$$;
ALTER FUNCTION aegis_purge_member_cashflow_profile() OWNER TO aegis_privacy_owner;
REVOKE ALL ON FUNCTION aegis_purge_member_cashflow_profile() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION aegis_purge_member_cashflow_profile() TO aegis_runtime;

DROP POLICY offer_checks_member_insert ON offer_checks;
CREATE POLICY offer_checks_member_insert ON offer_checks
  FOR INSERT TO aegis_runtime
  WITH CHECK (
    tenant_id = aegis_context_tenant_id()
    AND member_user_id = aegis_context_user_id()
    AND aegis_member_has_consent('manual_financial_profile')
    AND aegis_member_has_consent('offer_check_storage')
  );

DROP POLICY offer_checks_member_update ON offer_checks;
CREATE POLICY offer_checks_member_update ON offer_checks
  FOR UPDATE TO aegis_runtime
  USING (
    tenant_id = aegis_context_tenant_id()
    AND member_user_id = aegis_context_user_id()
    AND aegis_member_has_consent('manual_financial_profile')
    AND aegis_member_has_consent('offer_check_storage')
  )
  WITH CHECK (
    tenant_id = aegis_context_tenant_id()
    AND member_user_id = aegis_context_user_id()
    AND aegis_member_has_consent('manual_financial_profile')
    AND aegis_member_has_consent('offer_check_storage')
  );

DROP POLICY offer_outcomes_member_append ON offer_outcomes;
CREATE POLICY offer_outcomes_member_append ON offer_outcomes
  FOR INSERT TO aegis_runtime
  WITH CHECK (
    tenant_id = aegis_context_tenant_id()
    AND member_user_id = aegis_context_user_id()
    AND aegis_member_has_consent('offer_check_storage')
    AND aegis_member_has_consent('offer_outcome_reporting')
  );

COMMIT;
