BEGIN;

CREATE TABLE local_credentials (
  user_id uuid PRIMARY KEY REFERENCES app_users(id) ON DELETE CASCADE,
  email text NOT NULL CHECK (length(email) BETWEEN 3 AND 254 AND email = lower(email)),
  password_salt bytea NOT NULL CHECK (octet_length(password_salt) = 16),
  password_hash bytea NOT NULL CHECK (octet_length(password_hash) = 64),
  failed_attempts integer NOT NULL DEFAULT 0 CHECK (failed_attempts BETWEEN 0 AND 8),
  locked_until timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX local_credentials_email_idx ON local_credentials(email);
ALTER TABLE local_credentials ENABLE ROW LEVEL SECURITY;
ALTER TABLE local_credentials FORCE ROW LEVEL SECURITY;

CREATE TABLE member_sessions (
  token_hash bytea PRIMARY KEY CHECK (octet_length(token_hash) = 32),
  user_id uuid NOT NULL REFERENCES app_users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz NOT NULL,
  revoked_at timestamptz,
  CHECK (expires_at > created_at)
);
CREATE INDEX member_sessions_user_expiry_idx ON member_sessions(user_id, expires_at);
ALTER TABLE member_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE member_sessions FORCE ROW LEVEL SECURITY;

CREATE POLICY local_credentials_provisioner_insert ON local_credentials
  FOR INSERT TO aegis_provisioner WITH CHECK (true);
CREATE POLICY local_credentials_privacy_access ON local_credentials
  FOR ALL TO aegis_privacy_owner USING (true) WITH CHECK (true);
CREATE POLICY member_sessions_privacy_access ON member_sessions
  FOR ALL TO aegis_privacy_owner USING (true) WITH CHECK (true);
GRANT INSERT ON local_credentials TO aegis_provisioner;
GRANT SELECT, UPDATE, DELETE ON local_credentials TO aegis_privacy_owner;
GRANT SELECT, INSERT, UPDATE, DELETE ON member_sessions TO aegis_privacy_owner;
GRANT USAGE ON SCHEMA public TO aegis_runtime;

CREATE FUNCTION aegis_lookup_local_credential(p_email text)
RETURNS TABLE(user_id uuid, password_salt bytea, password_hash bytea, is_locked boolean)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public
AS $$
  SELECT c.user_id, c.password_salt, c.password_hash,
         (c.locked_until IS NOT NULL AND c.locked_until > now())
  FROM public.local_credentials c
  JOIN public.app_users u ON u.id = c.user_id
  WHERE c.email = lower(trim(p_email)) AND u.status = 'active'
  LIMIT 1
$$;
ALTER FUNCTION aegis_lookup_local_credential(text) OWNER TO aegis_privacy_owner;

CREATE FUNCTION aegis_record_local_login_failure(p_email text)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public
AS $$
BEGIN
  UPDATE public.local_credentials
  SET failed_attempts = CASE WHEN locked_until IS NOT NULL AND locked_until <= now() THEN 1 ELSE least(failed_attempts + 1, 8) END,
      locked_until = CASE WHEN (CASE WHEN locked_until IS NOT NULL AND locked_until <= now() THEN 1 ELSE failed_attempts + 1 END) >= 8 THEN now() + interval '15 minutes' ELSE NULL END,
      updated_at = now()
  WHERE email = lower(trim(p_email));
END
$$;
ALTER FUNCTION aegis_record_local_login_failure(text) OWNER TO aegis_privacy_owner;

CREATE FUNCTION aegis_create_member_session(p_user_id uuid, p_token_hash bytea, p_expires_at timestamptz)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public
AS $$
BEGIN
  IF octet_length(p_token_hash) <> 32 OR p_expires_at <= now() OR p_expires_at > now() + interval '13 hours' THEN
    RETURN false;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM public.app_users WHERE id = p_user_id AND status = 'active') THEN
    RETURN false;
  END IF;
  INSERT INTO public.member_sessions(token_hash, user_id, expires_at) VALUES (p_token_hash, p_user_id, p_expires_at);
  UPDATE public.local_credentials SET failed_attempts = 0, locked_until = NULL, updated_at = now() WHERE user_id = p_user_id;
  RETURN true;
END
$$;
ALTER FUNCTION aegis_create_member_session(uuid, bytea, timestamptz) OWNER TO aegis_privacy_owner;

CREATE FUNCTION aegis_resolve_member_session(p_token_hash bytea)
RETURNS uuid LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public
AS $$
  SELECT s.user_id FROM public.member_sessions s
  JOIN public.app_users u ON u.id = s.user_id
  WHERE s.token_hash = p_token_hash AND s.revoked_at IS NULL AND s.expires_at > now() AND u.status = 'active'
  LIMIT 1
$$;
ALTER FUNCTION aegis_resolve_member_session(bytea) OWNER TO aegis_privacy_owner;

CREATE FUNCTION aegis_revoke_member_session(p_token_hash bytea)
RETURNS void LANGUAGE sql SECURITY DEFINER SET search_path = pg_catalog, public
AS $$ UPDATE public.member_sessions SET revoked_at = now() WHERE token_hash = p_token_hash AND revoked_at IS NULL $$;
ALTER FUNCTION aegis_revoke_member_session(bytea) OWNER TO aegis_privacy_owner;

CREATE FUNCTION aegis_purge_expired_local_sessions()
RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public
AS $$
DECLARE deleted_count integer;
BEGIN
  DELETE FROM public.member_sessions WHERE expires_at < now() OR revoked_at < now() - interval '30 days';
  GET DIAGNOSTICS deleted_count = ROW_COUNT;
  RETURN deleted_count;
END
$$;
ALTER FUNCTION aegis_purge_expired_local_sessions() OWNER TO aegis_privacy_owner;

REVOKE ALL ON FUNCTION aegis_lookup_local_credential(text), aegis_record_local_login_failure(text),
  aegis_create_member_session(uuid, bytea, timestamptz), aegis_resolve_member_session(bytea),
  aegis_revoke_member_session(bytea), aegis_purge_expired_local_sessions() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION aegis_lookup_local_credential(text), aegis_record_local_login_failure(text),
  aegis_create_member_session(uuid, bytea, timestamptz), aegis_resolve_member_session(bytea),
  aegis_revoke_member_session(bytea), aegis_purge_expired_local_sessions() TO aegis_runtime;

COMMIT;
