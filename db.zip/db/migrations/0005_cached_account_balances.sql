BEGIN;

CREATE TABLE bank_account_balances (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  member_user_id uuid NOT NULL REFERENCES app_users(id) ON DELETE CASCADE,
  connection_id uuid NOT NULL,
  provider_account_id text NOT NULL CHECK (length(provider_account_id) BETWEEN 1 AND 200),
  account_name text NOT NULL CHECK (length(account_name) BETWEEN 1 AND 200),
  official_name text CHECK (official_name IS NULL OR length(official_name) <= 200),
  account_subtype text NOT NULL CHECK (account_subtype IN ('checking', 'savings')),
  current_balance numeric(13, 2) CHECK (current_balance IS NULL OR current_balance BETWEEN -1000000000 AND 1000000000),
  available_balance numeric(13, 2) CHECK (available_balance IS NULL OR available_balance BETWEEN -1000000000 AND 1000000000),
  currency_code text NOT NULL CHECK (currency_code = 'USD'),
  institution_updated_at timestamptz,
  retrieved_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (current_balance IS NOT NULL OR available_balance IS NOT NULL),
  FOREIGN KEY (tenant_id, member_user_id, connection_id)
    REFERENCES bank_connections(tenant_id, member_user_id, id) ON DELETE CASCADE,
  UNIQUE (connection_id, provider_account_id)
);
CREATE INDEX bank_account_balances_member_idx ON bank_account_balances(tenant_id, member_user_id, retrieved_at DESC);

ALTER TABLE bank_account_balances ENABLE ROW LEVEL SECURITY;
ALTER TABLE bank_account_balances FORCE ROW LEVEL SECURITY;
CREATE POLICY bank_account_balances_member_read ON bank_account_balances
  FOR SELECT TO aegis_runtime
  USING (
    tenant_id = aegis_context_tenant_id()
    AND member_user_id = aegis_context_user_id()
    AND EXISTS (
      SELECT 1 FROM bank_connections c
      WHERE c.id = connection_id AND c.tenant_id = bank_account_balances.tenant_id
        AND c.member_user_id = bank_account_balances.member_user_id AND c.status = 'active'
    )
    AND EXISTS (
      SELECT 1 FROM (
        SELECT c.action FROM consent_events c
        WHERE c.tenant_id = aegis_context_tenant_id()
          AND c.member_user_id = aegis_context_user_id()
          AND c.purpose = 'read_only_bank_connection'
        ORDER BY c.event_seq DESC LIMIT 1
      ) latest_consent WHERE latest_consent.action = 'granted'
    )
  );

GRANT SELECT (connection_id) ON bank_account_balances TO aegis_bank_worker_owner;
GRANT SELECT (retrieved_at) ON bank_account_balances TO aegis_bank_worker_owner;
GRANT INSERT (tenant_id, member_user_id, connection_id, provider_account_id, account_name, official_name,
  account_subtype, current_balance, available_balance, currency_code, institution_updated_at)
  ON bank_account_balances TO aegis_bank_worker_owner;
GRANT DELETE ON bank_account_balances TO aegis_bank_worker_owner;
GRANT SELECT (connection_id) ON bank_account_balances TO aegis_privacy_owner;
GRANT DELETE ON bank_account_balances TO aegis_privacy_owner;
GRANT SELECT ON bank_account_balances TO aegis_runtime;
REVOKE INSERT, UPDATE, DELETE ON bank_account_balances FROM PUBLIC, aegis_runtime, aegis_reporting_owner, aegis_provisioner;

CREATE FUNCTION aegis_replace_bank_account_balances(p_job_id uuid, p_balances jsonb)
RETURNS integer
LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  v_connection_id uuid;
  v_tenant_id uuid;
  v_member_id uuid;
  v_account jsonb;
  v_current numeric;
  v_available numeric;
  v_updated_at timestamptz;
  v_saved integer := 0;
  v_latest_consent text;
BEGIN
  IF p_balances IS NULL OR jsonb_typeof(p_balances) <> 'array' OR jsonb_array_length(p_balances) > 100 THEN
    RAISE EXCEPTION 'Cached account balance result is invalid';
  END IF;
  IF EXISTS (
    SELECT 1 FROM jsonb_array_elements(p_balances) AS items(value)
    GROUP BY value->>'providerAccountId' HAVING count(*) > 1
  ) THEN RAISE EXCEPTION 'Cached account balance identifiers must be unique'; END IF;

  SELECT c.id, c.tenant_id, c.member_user_id INTO v_connection_id, v_tenant_id, v_member_id
  FROM public.bank_sync_jobs j JOIN public.bank_connections c ON c.id = j.connection_id
  WHERE j.id = p_job_id AND j.job_kind = 'sync' AND j.status = 'completed' AND c.status = 'active'
  FOR UPDATE OF c;
  IF NOT FOUND THEN RETURN 0; END IF;
  SELECT c.action INTO v_latest_consent FROM public.consent_events c
  WHERE c.tenant_id = v_tenant_id AND c.member_user_id = v_member_id AND c.purpose = 'read_only_bank_connection'
  ORDER BY c.event_seq DESC LIMIT 1;
  IF v_latest_consent IS DISTINCT FROM 'granted' THEN RETURN 0; END IF;

  FOR v_account IN SELECT value FROM jsonb_array_elements(p_balances) AS accounts(value) LOOP
    IF jsonb_typeof(v_account) IS DISTINCT FROM 'object'
      OR jsonb_typeof(v_account->'providerAccountId') IS DISTINCT FROM 'string'
      OR length(btrim(v_account->>'providerAccountId')) NOT BETWEEN 1 AND 200
      OR jsonb_typeof(v_account->'name') IS DISTINCT FROM 'string'
      OR length(btrim(v_account->>'name')) NOT BETWEEN 1 AND 200
      OR (jsonb_typeof(v_account->'officialName') IS DISTINCT FROM 'string' AND jsonb_typeof(v_account->'officialName') IS DISTINCT FROM 'null')
      OR (jsonb_typeof(v_account->'officialName') = 'string' AND length(v_account->>'officialName') > 200)
      OR jsonb_typeof(v_account->'subtype') IS DISTINCT FROM 'string'
      OR v_account->>'subtype' NOT IN ('checking', 'savings')
      OR jsonb_typeof(v_account->'currencyCode') IS DISTINCT FROM 'string'
      OR v_account->>'currencyCode' <> 'USD'
      OR coalesce(jsonb_typeof(v_account->'currentBalance'), '') NOT IN ('number', 'null')
      OR coalesce(jsonb_typeof(v_account->'availableBalance'), '') NOT IN ('number', 'null')
      OR (v_account ? 'institutionUpdatedAt' AND coalesce(jsonb_typeof(v_account->'institutionUpdatedAt'), '') NOT IN ('string', 'null')) THEN
      RAISE EXCEPTION 'Cached account balance row is invalid';
    END IF;
    v_current := CASE WHEN jsonb_typeof(v_account->'currentBalance') = 'null' THEN NULL ELSE (v_account->>'currentBalance')::numeric END;
    v_available := CASE WHEN jsonb_typeof(v_account->'availableBalance') = 'null' THEN NULL ELSE (v_account->>'availableBalance')::numeric END;
    IF (v_current IS NOT NULL AND abs(v_current) > 1000000000)
      OR (v_available IS NOT NULL AND abs(v_available) > 1000000000)
      OR (v_current IS NULL AND v_available IS NULL) THEN
      RAISE EXCEPTION 'Cached account balance value is invalid';
    END IF;
    v_updated_at := CASE
      WHEN jsonb_typeof(v_account->'institutionUpdatedAt') = 'string' THEN (v_account->>'institutionUpdatedAt')::timestamptz
      ELSE NULL
    END;
    v_saved := v_saved + 1;
  END LOOP;

  DELETE FROM public.bank_account_balances WHERE connection_id = v_connection_id;
  -- The table is replaced only after every provider row has been validated. Reinsert the validated snapshot atomically.
  FOR v_account IN SELECT value FROM jsonb_array_elements(p_balances) AS accounts(value) LOOP
    v_current := CASE WHEN jsonb_typeof(v_account->'currentBalance') = 'null' THEN NULL ELSE (v_account->>'currentBalance')::numeric END;
    v_available := CASE WHEN jsonb_typeof(v_account->'availableBalance') = 'null' THEN NULL ELSE (v_account->>'availableBalance')::numeric END;
    v_updated_at := CASE
      WHEN jsonb_typeof(v_account->'institutionUpdatedAt') = 'string' THEN (v_account->>'institutionUpdatedAt')::timestamptz
      ELSE NULL
    END;
    INSERT INTO public.bank_account_balances(
      tenant_id, member_user_id, connection_id, provider_account_id, account_name, official_name,
      account_subtype, current_balance, available_balance, currency_code, institution_updated_at
    ) VALUES (
      v_tenant_id, v_member_id, v_connection_id, btrim(v_account->>'providerAccountId'), btrim(v_account->>'name'),
      CASE WHEN jsonb_typeof(v_account->'officialName') = 'null' THEN NULL ELSE nullif(btrim(v_account->>'officialName'), '') END,
      v_account->>'subtype', v_current, v_available, 'USD', v_updated_at
    );
  END LOOP;
  RETURN v_saved;
END
$$;
ALTER FUNCTION aegis_replace_bank_account_balances(uuid, jsonb) OWNER TO aegis_bank_worker_owner;
REVOKE ALL ON FUNCTION aegis_replace_bank_account_balances(uuid, jsonb) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION aegis_replace_bank_account_balances(uuid, jsonb) TO aegis_bank_worker;

CREATE FUNCTION aegis_clear_disconnected_bank_balances()
RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
BEGIN
  DELETE FROM public.bank_account_balances WHERE connection_id = NEW.id;
  RETURN NEW;
END
$$;
ALTER FUNCTION aegis_clear_disconnected_bank_balances() OWNER TO aegis_privacy_owner;
REVOKE ALL ON FUNCTION aegis_clear_disconnected_bank_balances() FROM PUBLIC;
CREATE TRIGGER bank_connections_clear_balances_on_disconnect
  AFTER UPDATE OF status ON bank_connections
  FOR EACH ROW WHEN (OLD.status IS DISTINCT FROM NEW.status AND NEW.status = 'disconnect_pending')
  EXECUTE FUNCTION aegis_clear_disconnected_bank_balances();

CREATE OR REPLACE FUNCTION aegis_purge_expired_bank_transactions()
RETURNS bigint
LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  deleted_count bigint;
  v_balance_rows_deleted bigint;
BEGIN
  DELETE FROM public.bank_transactions
  WHERE transaction_date < ((now() AT TIME ZONE 'UTC')::date - interval '13 months')::date;
  GET DIAGNOSTICS deleted_count = ROW_COUNT;
  DELETE FROM public.bank_account_balances
  WHERE retrieved_at < now() - interval '13 months';
  GET DIAGNOSTICS v_balance_rows_deleted = ROW_COUNT;
  deleted_count := deleted_count + v_balance_rows_deleted;
  RETURN deleted_count;
END
$$;
ALTER FUNCTION aegis_purge_expired_bank_transactions() OWNER TO aegis_bank_worker_owner;

COMMIT;
