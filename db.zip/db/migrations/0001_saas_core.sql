BEGIN;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'aegis_runtime') THEN
    CREATE ROLE aegis_runtime NOLOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT NOBYPASSRLS;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'aegis_reporting_owner') THEN
    CREATE ROLE aegis_reporting_owner NOLOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT NOBYPASSRLS;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'aegis_privacy_owner') THEN
    CREATE ROLE aegis_privacy_owner NOLOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT NOBYPASSRLS;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'aegis_provisioner') THEN
    CREATE ROLE aegis_provisioner NOLOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT NOBYPASSRLS;
  END IF;
  BEGIN
    EXECUTE 'ALTER ROLE aegis_reporting_owner BYPASSRLS';
    EXECUTE 'ALTER ROLE aegis_privacy_owner BYPASSRLS';
    EXECUTE 'ALTER ROLE aegis_provisioner BYPASSRLS';
  EXCEPTION WHEN insufficient_privilege THEN
    NULL;
  END;
END
$$;

GRANT USAGE, CREATE ON SCHEMA public TO aegis_runtime, aegis_reporting_owner, aegis_privacy_owner, aegis_provisioner;

CREATE TABLE organizations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL CHECK (length(trim(name)) BETWEEN 1 AND 120),
  slug text NOT NULL UNIQUE CHECK (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'),
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'suspended', 'closed')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE app_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  identity_issuer text NOT NULL,
  identity_subject text NOT NULL,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'disabled', 'deletion_pending')),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (identity_issuer, identity_subject)
);

CREATE TABLE memberships (
  tenant_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES app_users(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN ('member', 'partner_admin', 'partner_analyst')),
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'revoked')),
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, user_id)
);
CREATE INDEX memberships_user_idx ON memberships(user_id, status);

CREATE TABLE consent_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  member_user_id uuid NOT NULL REFERENCES app_users(id) ON DELETE CASCADE,
  purpose text NOT NULL CHECK (purpose IN ('manual_financial_profile', 'read_only_bank_connection', 'offer_check_storage', 'offer_outcome_reporting', 'research')),
  action text NOT NULL CHECK (action IN ('granted', 'revoked')),
  policy_version text NOT NULL CHECK (length(trim(policy_version)) BETWEEN 1 AND 40),
  occurred_at timestamptz NOT NULL DEFAULT now(),
  request_id uuid,
  FOREIGN KEY (tenant_id, member_user_id) REFERENCES memberships(tenant_id, user_id)
);
CREATE INDEX consent_events_member_purpose_idx ON consent_events(tenant_id, member_user_id, purpose, occurred_at DESC);

CREATE TABLE offer_checks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  member_user_id uuid NOT NULL REFERENCES app_users(id) ON DELETE CASCADE,
  title text CHECK (title IS NULL OR length(title) <= 120),
  input_payload jsonb NOT NULL,
  result_payload jsonb NOT NULL,
  calculation_version text NOT NULL,
  data_as_of timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY (tenant_id, member_user_id) REFERENCES memberships(tenant_id, user_id),
  UNIQUE (tenant_id, member_user_id, id)
);
CREATE INDEX offer_checks_member_created_idx ON offer_checks(tenant_id, member_user_id, created_at DESC);

-- These are member self-reports, never inferred or partner-visible outcomes.
-- They cascade with the associated saved offer check on consent revocation/deletion.
CREATE TABLE offer_outcomes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  member_user_id uuid NOT NULL REFERENCES app_users(id) ON DELETE CASCADE,
  offer_check_id uuid NOT NULL,
  outcome text NOT NULL CHECK (outcome IN ('accepted', 'declined', 'changed_terms', 'still_deciding')),
  source text NOT NULL DEFAULT 'member_self_report' CHECK (source = 'member_self_report'),
  reported_at timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY (tenant_id, member_user_id, offer_check_id)
    REFERENCES offer_checks(tenant_id, member_user_id, id) ON DELETE CASCADE
);
CREATE INDEX offer_outcomes_check_reported_idx ON offer_outcomes(offer_check_id, reported_at DESC, id DESC);

CREATE TABLE audit_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  actor_user_id uuid REFERENCES app_users(id) ON DELETE SET NULL,
  action text NOT NULL CHECK (length(trim(action)) BETWEEN 1 AND 80),
  entity_type text NOT NULL CHECK (length(trim(entity_type)) BETWEEN 1 AND 60),
  entity_id uuid,
  request_id uuid,
  occurred_at timestamptz NOT NULL DEFAULT now(),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  FOREIGN KEY (actor_user_id) REFERENCES app_users(id) ON DELETE SET NULL
);
CREATE INDEX audit_events_tenant_time_idx ON audit_events(tenant_id, occurred_at DESC);

-- Minimal retry state remains after member financial data has been erased, until Cognito confirms deletion.
CREATE TABLE account_deletion_jobs (
  user_id uuid PRIMARY KEY REFERENCES app_users(id) ON DELETE CASCADE,
  provider_status text NOT NULL DEFAULT 'provider_pending' CHECK (provider_status IN ('provider_pending', 'identity_deleted')),
  requested_at timestamptz NOT NULL DEFAULT now(),
  identity_deleted_at timestamptz
);

CREATE FUNCTION aegis_context_tenant_id() RETURNS uuid
LANGUAGE sql STABLE PARALLEL SAFE
AS $$ SELECT nullif(current_setting('aegis.tenant_id', true), '')::uuid $$;

CREATE FUNCTION aegis_context_user_id() RETURNS uuid
LANGUAGE sql STABLE PARALLEL SAFE
AS $$ SELECT nullif(current_setting('aegis.user_id', true), '')::uuid $$;

CREATE FUNCTION aegis_partner_usage_summary()
RETURNS TABLE(report_month date, participating_members bigint, saved_checks bigint)
LANGUAGE sql STABLE SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
  SELECT date_trunc('month', oc.created_at AT TIME ZONE 'UTC')::date,
         count(DISTINCT oc.member_user_id),
         count(*)
  FROM public.offer_checks oc
  WHERE oc.tenant_id = public.aegis_context_tenant_id()
    AND EXISTS (
      SELECT 1
      FROM public.memberships m
      JOIN public.app_users u ON u.id = m.user_id
      JOIN public.organizations org ON org.id = m.tenant_id
      WHERE m.tenant_id = public.aegis_context_tenant_id()
        AND m.user_id = public.aegis_context_user_id()
        AND m.role IN ('partner_admin', 'partner_analyst')
        AND m.status = 'active'
        AND u.status = 'active'
        AND org.status = 'active'
    )
  GROUP BY 1
  HAVING count(DISTINCT oc.member_user_id) >= 20
  ORDER BY 1 DESC
$$;
ALTER FUNCTION aegis_partner_usage_summary() OWNER TO aegis_reporting_owner;

CREATE FUNCTION aegis_begin_member_account_deletion()
RETURNS text
LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  member_id uuid := public.aegis_context_user_id();
  member_status text;
  current_provider_status text;
BEGIN
  IF member_id IS NULL THEN
    RAISE EXCEPTION 'Authenticated member context required';
  END IF;
  SELECT u.status INTO member_status FROM public.app_users u WHERE u.id = member_id;
  IF member_status = 'deletion_pending' THEN
    SELECT j.provider_status INTO current_provider_status
    FROM public.account_deletion_jobs j WHERE j.user_id = member_id;
    IF current_provider_status IS NOT NULL THEN
      RETURN current_provider_status;
    END IF;
  END IF;
  IF member_status IS DISTINCT FROM 'active' THEN
    RAISE EXCEPTION 'Active member account required';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM public.memberships m WHERE m.user_id = member_id AND m.role = 'member' AND m.status = 'active') THEN
    RAISE EXCEPTION 'Active member access required';
  END IF;
  IF EXISTS (SELECT 1 FROM public.memberships m WHERE m.user_id = member_id AND m.role <> 'member') THEN
    RAISE EXCEPTION 'Mixed-role account deletion requires support';
  END IF;

  INSERT INTO public.audit_events (tenant_id, actor_user_id, action, entity_type, metadata)
  SELECT DISTINCT m.tenant_id, NULL::uuid, 'member.data_deleted', 'member_account', '{}'::jsonb
  FROM public.memberships m
  WHERE m.user_id = member_id AND m.role = 'member';

  UPDATE public.audit_events
  SET entity_id = NULL
  WHERE entity_type = 'offer_check'
    AND entity_id IN (SELECT oc.id FROM public.offer_checks oc WHERE oc.member_user_id = member_id);
  DELETE FROM public.offer_checks WHERE member_user_id = member_id;
  DELETE FROM public.consent_events WHERE member_user_id = member_id;
  UPDATE public.audit_events
  SET actor_user_id = NULL,
      entity_id = CASE WHEN entity_id = member_id THEN NULL ELSE entity_id END
  WHERE actor_user_id = member_id OR entity_id = member_id;
  UPDATE public.app_users SET status = 'deletion_pending' WHERE id = member_id;
  UPDATE public.memberships SET status = 'revoked' WHERE user_id = member_id;
  INSERT INTO public.account_deletion_jobs (user_id) VALUES (member_id);
  RETURN 'provider_pending';
END
$$;
ALTER FUNCTION aegis_begin_member_account_deletion() OWNER TO aegis_privacy_owner;

CREATE FUNCTION aegis_mark_member_identity_deleted()
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  member_id uuid := public.aegis_context_user_id();
BEGIN
  IF member_id IS NULL THEN
    RAISE EXCEPTION 'Authenticated member context required';
  END IF;
  UPDATE public.account_deletion_jobs
  SET provider_status = 'identity_deleted', identity_deleted_at = COALESCE(identity_deleted_at, now())
  WHERE user_id = member_id AND provider_status IN ('provider_pending', 'identity_deleted');
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Account deletion request not found';
  END IF;
END
$$;
ALTER FUNCTION aegis_mark_member_identity_deleted() OWNER TO aegis_privacy_owner;

CREATE FUNCTION aegis_finalize_member_account_deletion()
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  member_id uuid := public.aegis_context_user_id();
BEGIN
  IF member_id IS NULL THEN
    RAISE EXCEPTION 'Authenticated member context required';
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM public.account_deletion_jobs j
    WHERE j.user_id = member_id AND j.provider_status = 'identity_deleted'
  ) THEN
    RAISE EXCEPTION 'Identity-provider deletion must complete first';
  END IF;
  DELETE FROM public.app_users WHERE id = member_id AND status = 'deletion_pending';
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Pending account deletion not found';
  END IF;
END
$$;
ALTER FUNCTION aegis_finalize_member_account_deletion() OWNER TO aegis_privacy_owner;

ALTER TABLE organizations ENABLE ROW LEVEL SECURITY;
ALTER TABLE organizations FORCE ROW LEVEL SECURITY;
ALTER TABLE app_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE app_users FORCE ROW LEVEL SECURITY;
ALTER TABLE memberships ENABLE ROW LEVEL SECURITY;
ALTER TABLE memberships FORCE ROW LEVEL SECURITY;
ALTER TABLE consent_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE consent_events FORCE ROW LEVEL SECURITY;
ALTER TABLE offer_checks ENABLE ROW LEVEL SECURITY;
ALTER TABLE offer_checks FORCE ROW LEVEL SECURITY;
ALTER TABLE offer_outcomes ENABLE ROW LEVEL SECURITY;
ALTER TABLE offer_outcomes FORCE ROW LEVEL SECURITY;
ALTER TABLE audit_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_events FORCE ROW LEVEL SECURITY;
ALTER TABLE account_deletion_jobs ENABLE ROW LEVEL SECURITY;
ALTER TABLE account_deletion_jobs FORCE ROW LEVEL SECURITY;

CREATE POLICY organizations_member_tenants ON organizations
  FOR SELECT TO aegis_runtime
  USING (
    id = aegis_context_tenant_id()
    OR EXISTS (
      SELECT 1 FROM memberships m
      WHERE m.tenant_id = organizations.id
        AND m.user_id = aegis_context_user_id()
        AND m.status = 'active'
    )
  );

CREATE POLICY app_users_self ON app_users
  FOR SELECT TO aegis_runtime
  USING (id = aegis_context_user_id());

CREATE POLICY memberships_self ON memberships
  FOR SELECT TO aegis_runtime
  USING (user_id = aegis_context_user_id() AND status = 'active');

CREATE POLICY consent_events_member_read ON consent_events
  FOR SELECT TO aegis_runtime
  USING (tenant_id = aegis_context_tenant_id() AND member_user_id = aegis_context_user_id());
CREATE POLICY consent_events_member_append ON consent_events
  FOR INSERT TO aegis_runtime
  WITH CHECK (tenant_id = aegis_context_tenant_id() AND member_user_id = aegis_context_user_id());

CREATE POLICY offer_checks_member_read ON offer_checks
  FOR SELECT TO aegis_runtime
  USING (tenant_id = aegis_context_tenant_id() AND member_user_id = aegis_context_user_id());
CREATE POLICY offer_checks_member_insert ON offer_checks
  FOR INSERT TO aegis_runtime
  WITH CHECK (tenant_id = aegis_context_tenant_id() AND member_user_id = aegis_context_user_id());
CREATE POLICY offer_checks_member_update ON offer_checks
  FOR UPDATE TO aegis_runtime
  USING (tenant_id = aegis_context_tenant_id() AND member_user_id = aegis_context_user_id())
  WITH CHECK (tenant_id = aegis_context_tenant_id() AND member_user_id = aegis_context_user_id());
CREATE POLICY offer_checks_member_delete ON offer_checks
  FOR DELETE TO aegis_runtime
  USING (tenant_id = aegis_context_tenant_id() AND member_user_id = aegis_context_user_id());

CREATE POLICY offer_outcomes_member_read ON offer_outcomes
  FOR SELECT TO aegis_runtime
  USING (tenant_id = aegis_context_tenant_id() AND member_user_id = aegis_context_user_id());
CREATE POLICY offer_outcomes_member_append ON offer_outcomes
  FOR INSERT TO aegis_runtime
  WITH CHECK (tenant_id = aegis_context_tenant_id() AND member_user_id = aegis_context_user_id());
CREATE POLICY offer_outcomes_member_delete ON offer_outcomes
  FOR DELETE TO aegis_runtime
  USING (tenant_id = aegis_context_tenant_id() AND member_user_id = aegis_context_user_id());

CREATE POLICY audit_events_actor_read ON audit_events
  FOR SELECT TO aegis_runtime
  USING (tenant_id = aegis_context_tenant_id() AND actor_user_id = aegis_context_user_id());
CREATE POLICY audit_events_actor_append ON audit_events
  FOR INSERT TO aegis_runtime
  WITH CHECK (tenant_id = aegis_context_tenant_id() AND actor_user_id = aegis_context_user_id());

GRANT USAGE ON SCHEMA public TO aegis_runtime;
GRANT USAGE ON SCHEMA public TO aegis_reporting_owner;
GRANT USAGE ON SCHEMA public TO aegis_privacy_owner;
GRANT USAGE ON SCHEMA public TO aegis_provisioner;
GRANT SELECT ON organizations, app_users, memberships, offer_checks TO aegis_reporting_owner;
GRANT SELECT ON organizations, app_users, memberships TO aegis_privacy_owner;
GRANT SELECT ON account_deletion_jobs TO aegis_privacy_owner;
GRANT SELECT (member_user_id) ON consent_events, offer_checks TO aegis_privacy_owner;
GRANT SELECT (id) ON offer_checks TO aegis_privacy_owner;
GRANT DELETE ON app_users, consent_events, offer_checks TO aegis_privacy_owner;
GRANT UPDATE (status) ON app_users, memberships TO aegis_privacy_owner;
GRANT INSERT, UPDATE ON account_deletion_jobs TO aegis_privacy_owner;
GRANT SELECT, INSERT ON audit_events TO aegis_privacy_owner;
GRANT UPDATE (actor_user_id, entity_id) ON audit_events TO aegis_privacy_owner;
GRANT SELECT, INSERT ON organizations, app_users, memberships TO aegis_provisioner;
GRANT UPDATE (role, status) ON memberships TO aegis_provisioner;
GRANT INSERT ON audit_events TO aegis_provisioner;
GRANT SELECT ON organizations, app_users, memberships, consent_events, offer_checks, offer_outcomes, audit_events TO aegis_runtime;
GRANT INSERT ON consent_events, offer_checks, offer_outcomes, audit_events TO aegis_runtime;
GRANT UPDATE, DELETE ON offer_checks TO aegis_runtime;
GRANT DELETE ON offer_outcomes TO aegis_runtime;
GRANT EXECUTE ON FUNCTION aegis_context_tenant_id(), aegis_context_user_id() TO aegis_runtime;
GRANT EXECUTE ON FUNCTION aegis_context_tenant_id(), aegis_context_user_id() TO aegis_reporting_owner;
GRANT EXECUTE ON FUNCTION aegis_context_tenant_id(), aegis_context_user_id() TO aegis_privacy_owner;
REVOKE ALL ON FUNCTION aegis_partner_usage_summary() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION aegis_partner_usage_summary() TO aegis_runtime;
REVOKE ALL ON FUNCTION aegis_begin_member_account_deletion() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION aegis_begin_member_account_deletion() TO aegis_runtime;
REVOKE ALL ON FUNCTION aegis_mark_member_identity_deleted() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION aegis_mark_member_identity_deleted() TO aegis_runtime;
REVOKE ALL ON FUNCTION aegis_finalize_member_account_deletion() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION aegis_finalize_member_account_deletion() TO aegis_runtime;

COMMIT;
