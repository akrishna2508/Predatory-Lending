BEGIN;

-- Allow aegis_privacy_owner and aegis_reporting_owner to execute their SECURITY DEFINER functions
-- in managed cloud environments (Render, AWS RDS, etc.) where BYPASSRLS is restricted to database superusers.

DO $$
BEGIN
  -- app_users policies
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'app_users_privacy_owner_all' AND tablename = 'app_users') THEN
    CREATE POLICY app_users_privacy_owner_all ON app_users FOR ALL TO aegis_privacy_owner USING (true) WITH CHECK (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'app_users_reporting_owner_all' AND tablename = 'app_users') THEN
    CREATE POLICY app_users_reporting_owner_all ON app_users FOR ALL TO aegis_reporting_owner USING (true) WITH CHECK (true);
  END IF;

  -- organizations policies
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'organizations_privacy_owner_all' AND tablename = 'organizations') THEN
    CREATE POLICY organizations_privacy_owner_all ON organizations FOR ALL TO aegis_privacy_owner USING (true) WITH CHECK (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'organizations_reporting_owner_all' AND tablename = 'organizations') THEN
    CREATE POLICY organizations_reporting_owner_all ON organizations FOR ALL TO aegis_reporting_owner USING (true) WITH CHECK (true);
  END IF;

  -- memberships policies
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'memberships_privacy_owner_all' AND tablename = 'memberships') THEN
    CREATE POLICY memberships_privacy_owner_all ON memberships FOR ALL TO aegis_privacy_owner USING (true) WITH CHECK (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'memberships_reporting_owner_all' AND tablename = 'memberships') THEN
    CREATE POLICY memberships_reporting_owner_all ON memberships FOR ALL TO aegis_reporting_owner USING (true) WITH CHECK (true);
  END IF;

  -- offer_checks policies
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'offer_checks_privacy_owner_all' AND tablename = 'offer_checks') THEN
    CREATE POLICY offer_checks_privacy_owner_all ON offer_checks FOR ALL TO aegis_privacy_owner USING (true) WITH CHECK (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'offer_checks_reporting_owner_all' AND tablename = 'offer_checks') THEN
    CREATE POLICY offer_checks_reporting_owner_all ON offer_checks FOR ALL TO aegis_reporting_owner USING (true) WITH CHECK (true);
  END IF;

  -- consent_events policies
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'consent_events_privacy_owner_all' AND tablename = 'consent_events') THEN
    CREATE POLICY consent_events_privacy_owner_all ON consent_events FOR ALL TO aegis_privacy_owner USING (true) WITH CHECK (true);
  END IF;

  -- imported_transactions & transaction_imports policies
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'imported_transactions_privacy_owner_all' AND tablename = 'imported_transactions') THEN
    CREATE POLICY imported_transactions_privacy_owner_all ON imported_transactions FOR ALL TO aegis_privacy_owner USING (true) WITH CHECK (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'transaction_imports_privacy_owner_all' AND tablename = 'transaction_imports') THEN
    CREATE POLICY transaction_imports_privacy_owner_all ON transaction_imports FOR ALL TO aegis_privacy_owner USING (true) WITH CHECK (true);
  END IF;

  -- member_cashflow_profiles policies
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'member_cashflow_profiles_privacy_owner_all' AND tablename = 'member_cashflow_profiles') THEN
    CREATE POLICY member_cashflow_profiles_privacy_owner_all ON member_cashflow_profiles FOR ALL TO aegis_privacy_owner USING (true) WITH CHECK (true);
  END IF;
END
$$;

COMMIT;
