BEGIN;

INSERT INTO organizations(id, name, slug) VALUES ('00000000-0000-4000-8000-000000000031', 'Reminder Test CU', 'reminder-test-cu');
INSERT INTO app_users(id, identity_issuer, identity_subject) VALUES
  ('00000000-0000-4000-8000-000000000032', 'https://identity.example', 'reminder-member'),
  ('00000000-0000-4000-8000-000000000033', 'https://identity.example', 'reminder-partner');
INSERT INTO memberships(tenant_id, user_id, role) VALUES
  ('00000000-0000-4000-8000-000000000031', '00000000-0000-4000-8000-000000000032', 'member'),
  ('00000000-0000-4000-8000-000000000031', '00000000-0000-4000-8000-000000000033', 'partner_admin');
INSERT INTO consent_events(tenant_id, member_user_id, purpose, action, policy_version) VALUES
  ('00000000-0000-4000-8000-000000000031', '00000000-0000-4000-8000-000000000032', 'manual_financial_profile', 'granted', 'test-v1'),
  ('00000000-0000-4000-8000-000000000031', '00000000-0000-4000-8000-000000000032', 'offer_check_storage', 'granted', 'test-v1');
INSERT INTO offer_checks(id, tenant_id, member_user_id, input_payload, result_payload, calculation_version)
VALUES ('00000000-0000-4000-8000-000000000034', '00000000-0000-4000-8000-000000000031', '00000000-0000-4000-8000-000000000032', '{}'::jsonb, '{}'::jsonb, 'test-v1');

DO $$
BEGIN
  IF has_table_privilege('aegis_runtime', 'member_reminders', 'SELECT') IS NOT TRUE
     OR has_table_privilege('aegis_reporting_owner', 'member_reminders', 'SELECT') THEN
    RAISE EXCEPTION 'member reminder access must be runtime-only';
  END IF;
END
$$;

SET LOCAL ROLE aegis_runtime;
SELECT set_config('aegis.tenant_id', '00000000-0000-4000-8000-000000000031', true);
SELECT set_config('aegis.user_id', '00000000-0000-4000-8000-000000000032', true);
INSERT INTO member_reminders(id, tenant_id, member_user_id, offer_check_id, reminder_at)
VALUES ('00000000-0000-4000-8000-000000000035', '00000000-0000-4000-8000-000000000031', '00000000-0000-4000-8000-000000000032', '00000000-0000-4000-8000-000000000034', now() + interval '1 day');
INSERT INTO member_reminders(tenant_id, member_user_id, offer_check_id, reminder_at)
VALUES ('00000000-0000-4000-8000-000000000031', '00000000-0000-4000-8000-000000000032', '00000000-0000-4000-8000-000000000034', now() + interval '2 days')
ON CONFLICT (tenant_id, member_user_id, offer_check_id) WHERE status = 'scheduled'
DO UPDATE SET reminder_at = EXCLUDED.reminder_at, updated_at = now();
DO $$
BEGIN
  IF (SELECT count(*) FROM member_reminders WHERE status = 'scheduled') <> 1
     OR (SELECT reminder_at FROM member_reminders WHERE status = 'scheduled') < now() + interval '1 day 23 hours' THEN
    RAISE EXCEPTION 'a member should have one reschedulable reminder per saved offer';
  END IF;
END
$$;

SELECT set_config('aegis.user_id', '00000000-0000-4000-8000-000000000033', true);
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM member_reminders) THEN RAISE EXCEPTION 'partner must not read member reminders'; END IF;
END
$$;

SELECT set_config('aegis.user_id', '00000000-0000-4000-8000-000000000032', true);
INSERT INTO consent_events(tenant_id, member_user_id, purpose, action, policy_version)
VALUES ('00000000-0000-4000-8000-000000000031', '00000000-0000-4000-8000-000000000032', 'offer_check_storage', 'revoked', 'test-v1');
DO $$
BEGIN
  BEGIN
    INSERT INTO member_reminders(tenant_id, member_user_id, offer_check_id, reminder_at)
    VALUES ('00000000-0000-4000-8000-000000000031', '00000000-0000-4000-8000-000000000032', '00000000-0000-4000-8000-000000000034', now() + interval '3 days');
    RAISE EXCEPTION 'revoked offer storage consent must block new reminders';
  EXCEPTION WHEN insufficient_privilege THEN NULL;
  END;
END
$$;
DELETE FROM offer_checks WHERE id = '00000000-0000-4000-8000-000000000034';
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM member_reminders) THEN
    RAISE EXCEPTION 'deleting an offer comparison must delete its reminder';
  END IF;
END
$$;
RESET ROLE;

ROLLBACK;
