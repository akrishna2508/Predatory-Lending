BEGIN;

INSERT INTO organizations(id, name, slug) VALUES
  ('00000000-0000-4000-8000-000000000001', 'Test Credit Union A', 'test-cu-a'),
  ('00000000-0000-4000-8000-000000000002', 'Test Credit Union B', 'test-cu-b');

INSERT INTO app_users(id, identity_issuer, identity_subject) VALUES
  ('00000000-0000-4000-8000-000000000011', 'https://identity.example', 'member-a'),
  ('00000000-0000-4000-8000-000000000012', 'https://identity.example', 'member-b'),
  ('00000000-0000-4000-8000-000000000013', 'https://identity.example', 'member-c'),
  ('00000000-0000-4000-8000-000000000014', 'https://identity.example', 'partner-admin');

INSERT INTO memberships(tenant_id, user_id, role) VALUES
  ('00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000011', 'member'),
  ('00000000-0000-4000-8000-000000000002', '00000000-0000-4000-8000-000000000011', 'member'),
  ('00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000012', 'member'),
  ('00000000-0000-4000-8000-000000000002', '00000000-0000-4000-8000-000000000013', 'member'),
  ('00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000014', 'partner_admin');

INSERT INTO app_users(id, identity_issuer, identity_subject)
SELECT ('10000000-0000-4000-8000-' || lpad(g.i::text, 12, '0'))::uuid,
       'https://identity.example', 'aggregate-member-' || g.i
FROM generate_series(1, 20) AS g(i);
INSERT INTO memberships(tenant_id, user_id, role)
SELECT '00000000-0000-4000-8000-000000000001',
       ('10000000-0000-4000-8000-' || lpad(g.i::text, 12, '0'))::uuid,
       'member'
FROM generate_series(1, 20) AS g(i);

INSERT INTO offer_checks(id, tenant_id, member_user_id, input_payload, result_payload, calculation_version) VALUES
  ('20000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000011', '{"synthetic":true}', '{"synthetic":true}', 'test-v1'),
  ('20000000-0000-4000-8000-000000000002', '00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000012', '{"synthetic":true}', '{"synthetic":true}', 'test-v1'),
  ('20000000-0000-4000-8000-000000000003', '00000000-0000-4000-8000-000000000002', '00000000-0000-4000-8000-000000000013', '{"synthetic":true}', '{"synthetic":true}', 'test-v1');
INSERT INTO offer_checks(tenant_id, member_user_id, input_payload, result_payload, calculation_version, created_at)
SELECT '00000000-0000-4000-8000-000000000001',
       ('10000000-0000-4000-8000-' || lpad(g.i::text, 12, '0'))::uuid,
       '{"synthetic":true}', '{"synthetic":true}', 'test-v1', '2026-10-01 12:00:00+00'::timestamptz
FROM generate_series(1, 20) AS g(i);
INSERT INTO offer_checks(tenant_id, member_user_id, input_payload, result_payload, calculation_version, created_at)
SELECT '00000000-0000-4000-8000-000000000001',
       ('10000000-0000-4000-8000-' || lpad(g.i::text, 12, '0'))::uuid,
       '{"synthetic":true}', '{"synthetic":true}', 'test-v1', '2026-09-01 12:00:00+00'::timestamptz
FROM generate_series(1, 17) AS g(i);

INSERT INTO consent_events(tenant_id, member_user_id, purpose, action, policy_version)
VALUES
  ('00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000011', 'manual_financial_profile', 'granted', 'test-v1'),
  ('00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000011', 'offer_check_storage', 'granted', 'test-v1');
INSERT INTO audit_events(tenant_id, actor_user_id, action, entity_type, entity_id)
VALUES ('00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000011', 'offer_check.created', 'offer_check', '20000000-0000-4000-8000-000000000001');
INSERT INTO audit_events(tenant_id, action, entity_type, entity_id, metadata)
VALUES (
  '00000000-0000-4000-8000-000000000001', 'membership.permissions_changed', 'membership',
  '00000000-0000-4000-8000-000000000011', '{"new_role":"partner_analyst"}'::jsonb
);

DO $$
BEGIN
  IF has_table_privilege('aegis_runtime', 'account_deletion_jobs', 'SELECT') THEN
    RAISE EXCEPTION 'runtime must not read the temporary account deletion job table directly';
  END IF;
  IF has_table_privilege('aegis_runtime', 'offer_outcomes', 'UPDATE') THEN
    RAISE EXCEPTION 'self-reported offer outcomes must not be editable in place';
  END IF;
  IF has_table_privilege('aegis_provisioner', 'offer_checks', 'SELECT') THEN
    RAISE EXCEPTION 'operator provisioning role must not read member offer records';
  END IF;
END
$$;

SET LOCAL ROLE aegis_provisioner;
UPDATE memberships SET role = 'partner_analyst'
WHERE tenant_id = '00000000-0000-4000-8000-000000000001'
  AND user_id = '00000000-0000-4000-8000-000000000012';
INSERT INTO audit_events (tenant_id, actor_user_id, action, entity_type, entity_id, metadata)
VALUES (
  '00000000-0000-4000-8000-000000000001', NULL, 'membership.permissions_changed', 'membership',
  '00000000-0000-4000-8000-000000000012',
  '{"old_role":"member","new_role":"partner_analyst","operator_principal":"test-operator"}'::jsonb
);
INSERT INTO memberships (tenant_id, user_id, role)
VALUES ('00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000013', 'member');
INSERT INTO audit_events (tenant_id, actor_user_id, action, entity_type, entity_id, metadata)
VALUES (
  '00000000-0000-4000-8000-000000000001', NULL, 'membership.provisioned', 'membership',
  '00000000-0000-4000-8000-000000000013',
  '{"role":"member","operator_principal":"test-operator"}'::jsonb
);
RESET ROLE;
DO $$
BEGIN
  IF (SELECT role FROM memberships WHERE tenant_id = '00000000-0000-4000-8000-000000000001' AND user_id = '00000000-0000-4000-8000-000000000012') <> 'partner_analyst' THEN
    RAISE EXCEPTION 'operator role change must take effect';
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM audit_events
    WHERE action = 'membership.permissions_changed'
      AND entity_id = '00000000-0000-4000-8000-000000000012'
      AND metadata @> '{"old_role":"member","new_role":"partner_analyst","operator_principal":"test-operator"}'::jsonb
  ) THEN
    RAISE EXCEPTION 'operator role change must be auditable';
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM audit_events
    WHERE action = 'membership.provisioned'
      AND entity_id = '00000000-0000-4000-8000-000000000013'
      AND metadata @> '{"role":"member","operator_principal":"test-operator"}'::jsonb
  ) THEN
    RAISE EXCEPTION 'operator membership provisioning must be auditable';
  END IF;
END
$$;

SET LOCAL ROLE aegis_runtime;

SELECT set_config('aegis.tenant_id', '00000000-0000-4000-8000-000000000001', true);
SELECT set_config('aegis.user_id', '00000000-0000-4000-8000-000000000011', true);
INSERT INTO offer_outcomes (tenant_id, member_user_id, offer_check_id, outcome)
SELECT '00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000011', id, 'declined'
FROM offer_checks
WHERE tenant_id = '00000000-0000-4000-8000-000000000001'
  AND member_user_id = '00000000-0000-4000-8000-000000000011';
DO $$
BEGIN
  IF (SELECT count(*) FROM offer_checks) <> 1 THEN
    RAISE EXCEPTION 'member must see exactly their own offer check';
  END IF;
  IF EXISTS (SELECT 1 FROM offer_checks WHERE member_user_id <> '00000000-0000-4000-8000-000000000011') THEN
    RAISE EXCEPTION 'member can see another member offer check';
  END IF;
  IF (SELECT count(*) FROM offer_outcomes) <> 1 OR EXISTS (SELECT 1 FROM offer_outcomes WHERE member_user_id <> '00000000-0000-4000-8000-000000000011') THEN
    RAISE EXCEPTION 'member must see only their own self-reported outcomes';
  END IF;
  BEGIN
    INSERT INTO offer_outcomes (tenant_id, member_user_id, offer_check_id, outcome)
    VALUES ('00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000012', '20000000-0000-4000-8000-000000000002', 'accepted');
    RAISE EXCEPTION 'member must not write a self-reported outcome for another member';
  EXCEPTION WHEN insufficient_privilege THEN
    NULL;
  END;
END
$$;

SELECT set_config('aegis.user_id', '00000000-0000-4000-8000-000000000014', true);
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM offer_checks) THEN
    RAISE EXCEPTION 'partner role must not read member offer checks';
  END IF;
  IF EXISTS (SELECT 1 FROM offer_outcomes) THEN
    RAISE EXCEPTION 'partner role must not read member self-reported outcomes';
  END IF;
  IF (SELECT count(*) FROM aegis_partner_usage_summary()) <> 1 THEN
    RAISE EXCEPTION 'partner report must suppress a monthly cohort below 20';
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM aegis_partner_usage_summary()
    WHERE report_month = '2026-10-01'::date AND participating_members = 20 AND saved_checks = 20
  ) THEN
    RAISE EXCEPTION 'partner report must return only a sufficiently large aggregate';
  END IF;
END
$$;

SELECT set_config('aegis.tenant_id', '00000000-0000-4000-8000-000000000002', true);
SELECT set_config('aegis.user_id', '00000000-0000-4000-8000-000000000011', true);
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM offer_checks) THEN
    RAISE EXCEPTION 'member must not cross tenant boundary';
  END IF;
  IF EXISTS (SELECT 1 FROM aegis_partner_usage_summary()) THEN
    RAISE EXCEPTION 'member cannot invoke partner aggregates';
  END IF;
END
$$;

SELECT set_config('aegis.user_id', '00000000-0000-4000-8000-000000000014', true);
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM aegis_partner_usage_summary()) THEN
    RAISE EXCEPTION 'partner cannot query another organization aggregate';
  END IF;
END
$$;

SELECT set_config('aegis.tenant_id', '', true);
SELECT set_config('aegis.user_id', '00000000-0000-4000-8000-000000000011', true);
DO $$
BEGIN
  IF (SELECT count(*) FROM memberships) <> 2 THEN
    RAISE EXCEPTION 'member can discover only their own active memberships';
  END IF;
  IF (SELECT count(*) FROM organizations) <> 2 THEN
    RAISE EXCEPTION 'member can discover only organizations where they are an active member';
  END IF;
  IF EXISTS (SELECT 1 FROM offer_checks) THEN
    RAISE EXCEPTION 'tenant discovery context must not reveal offer checks';
  END IF;
END
$$;

SELECT set_config('aegis.tenant_id', '00000000-0000-4000-8000-000000000001', true);
DELETE FROM offer_outcomes WHERE offer_check_id = '20000000-0000-4000-8000-000000000001';
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM offer_outcomes WHERE member_user_id = '00000000-0000-4000-8000-000000000011') THEN
    RAISE EXCEPTION 'member must be able to erase their self-reported outcomes after revocation';
  END IF;
END
$$;
INSERT INTO offer_outcomes (tenant_id, member_user_id, offer_check_id, outcome)
SELECT '00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000011', id, 'declined'
FROM offer_checks
WHERE id = '20000000-0000-4000-8000-000000000001';
SELECT set_config('aegis.tenant_id', '', true);
SELECT set_config('aegis.user_id', '00000000-0000-4000-8000-000000000011', true);
SELECT aegis_begin_member_account_deletion();
RESET ROLE;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM app_users WHERE id = '00000000-0000-4000-8000-000000000011' AND status = 'deletion_pending') THEN
    RAISE EXCEPTION 'deletion request must disable the member identity before provider deletion';
  END IF;
  IF EXISTS (SELECT 1 FROM memberships WHERE user_id = '00000000-0000-4000-8000-000000000011' AND status = 'active') THEN
    RAISE EXCEPTION 'deletion request must revoke every member membership';
  END IF;
  IF EXISTS (SELECT 1 FROM offer_checks WHERE member_user_id = '00000000-0000-4000-8000-000000000011') THEN
    RAISE EXCEPTION 'financial offer data must be deleted before external identity deletion';
  END IF;
  IF EXISTS (SELECT 1 FROM audit_events WHERE entity_id = '20000000-0000-4000-8000-000000000001') THEN
    RAISE EXCEPTION 'account deletion must remove retained audit references to saved offer data';
  END IF;
  IF EXISTS (SELECT 1 FROM offer_outcomes WHERE member_user_id = '00000000-0000-4000-8000-000000000011') THEN
    RAISE EXCEPTION 'self-reported outcomes must be deleted with their offer checks';
  END IF;
  IF EXISTS (SELECT 1 FROM consent_events WHERE member_user_id = '00000000-0000-4000-8000-000000000011') THEN
    RAISE EXCEPTION 'consent history must be deleted before external identity deletion';
  END IF;
  IF (SELECT provider_status FROM account_deletion_jobs WHERE user_id = '00000000-0000-4000-8000-000000000011') <> 'provider_pending' THEN
    RAISE EXCEPTION 'deletion must retain a minimal retry marker until Cognito confirms deletion';
  END IF;
END
$$;
SET LOCAL ROLE aegis_runtime;
SELECT aegis_begin_member_account_deletion();
RESET ROLE;
DO $$
BEGIN
  IF (SELECT count(*) FROM audit_events WHERE action = 'member.data_deleted' AND actor_user_id IS NULL) <> 2 THEN
    RAISE EXCEPTION 'retries must not duplicate de-identified deletion audit events';
  END IF;
END
$$;
SET LOCAL ROLE aegis_runtime;
SELECT aegis_mark_member_identity_deleted();
SELECT aegis_finalize_member_account_deletion();
RESET ROLE;
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM app_users WHERE id = '00000000-0000-4000-8000-000000000011') THEN
    RAISE EXCEPTION 'account deletion must remove the member identity record';
  END IF;
  IF EXISTS (SELECT 1 FROM memberships WHERE user_id = '00000000-0000-4000-8000-000000000011') THEN
    RAISE EXCEPTION 'account deletion must remove the member memberships';
  END IF;
  IF EXISTS (SELECT 1 FROM offer_checks WHERE member_user_id = '00000000-0000-4000-8000-000000000011') THEN
    RAISE EXCEPTION 'account deletion must remove the member offer checks';
  END IF;
  IF EXISTS (SELECT 1 FROM offer_outcomes WHERE member_user_id = '00000000-0000-4000-8000-000000000011') THEN
    RAISE EXCEPTION 'account deletion must remove self-reported outcomes';
  END IF;
  IF EXISTS (SELECT 1 FROM consent_events WHERE member_user_id = '00000000-0000-4000-8000-000000000011') THEN
    RAISE EXCEPTION 'account deletion must remove the member consent events';
  END IF;
  IF EXISTS (SELECT 1 FROM audit_events WHERE actor_user_id = '00000000-0000-4000-8000-000000000011') THEN
    RAISE EXCEPTION 'account deletion must de-identify audit actors';
  END IF;
  IF EXISTS (SELECT 1 FROM audit_events WHERE entity_id = '00000000-0000-4000-8000-000000000011') THEN
    RAISE EXCEPTION 'account deletion must remove the member identity from retained audit targets';
  END IF;
  IF EXISTS (SELECT 1 FROM account_deletion_jobs WHERE user_id = '00000000-0000-4000-8000-000000000011') THEN
    RAISE EXCEPTION 'completed deletion must remove its temporary retry marker';
  END IF;
  IF (SELECT count(*) FROM audit_events WHERE action = 'member.data_deleted' AND actor_user_id IS NULL) <> 2 THEN
    RAISE EXCEPTION 'account deletion must leave one de-identified audit event per organization';
  END IF;
END
$$;

ROLLBACK;
