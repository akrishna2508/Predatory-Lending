BEGIN;

INSERT INTO organizations(id, name, slug) VALUES
  ('00000000-0000-4000-8000-000000000101', 'Cashflow Test CU', 'cashflow-test-cu'),
  ('00000000-0000-4000-8000-000000000104', 'Other Cashflow Test CU', 'other-cashflow-test-cu');
INSERT INTO app_users(id, identity_issuer, identity_subject) VALUES
  ('00000000-0000-4000-8000-000000000102', 'https://identity.example', 'cashflow-member-one'),
  ('00000000-0000-4000-8000-000000000105', 'https://identity.example', 'cashflow-member-two');
INSERT INTO memberships(tenant_id, user_id, role) VALUES
  ('00000000-0000-4000-8000-000000000101', '00000000-0000-4000-8000-000000000102', 'member'),
  ('00000000-0000-4000-8000-000000000104', '00000000-0000-4000-8000-000000000105', 'member');
INSERT INTO consent_events(tenant_id, member_user_id, purpose, action, policy_version) VALUES
  ('00000000-0000-4000-8000-000000000101', '00000000-0000-4000-8000-000000000102', 'manual_financial_profile', 'granted', 'test'),
  ('00000000-0000-4000-8000-000000000101', '00000000-0000-4000-8000-000000000102', 'cashflow_profile_storage', 'granted', 'test');

SET LOCAL ROLE aegis_runtime;
SELECT set_config('aegis.tenant_id', '00000000-0000-4000-8000-000000000101', true),
       set_config('aegis.user_id', '00000000-0000-4000-8000-000000000102', true);
INSERT INTO member_cashflow_profiles(tenant_id, member_user_id, as_of_date, starting_balance, events, expires_at)
VALUES (
  '00000000-0000-4000-8000-000000000101',
  '00000000-0000-4000-8000-000000000102',
  current_date,
  840,
  '[{"id":"rent","date":"2026-09-29","label":"Rent","amount":760,"kind":"bill","source":"member_entered"}]'::jsonb,
  now() + interval '30 days'
);
DO $$
BEGIN
  IF (SELECT count(*) FROM member_cashflow_profiles) <> 1 THEN
    RAISE EXCEPTION 'member must read their own confirmed profile';
  END IF;
  IF (SELECT count(*) FROM member_cashflow_profiles WHERE tenant_id = '00000000-0000-4000-8000-000000000104') <> 0 THEN
    RAISE EXCEPTION 'member must not read another tenant profile';
  END IF;
END
$$;

INSERT INTO consent_events(tenant_id, member_user_id, purpose, action, policy_version)
VALUES ('00000000-0000-4000-8000-000000000101', '00000000-0000-4000-8000-000000000102', 'cashflow_profile_storage', 'revoked', 'test');
SELECT aegis_purge_member_cashflow_profile();
DO $$
BEGIN
  IF (SELECT count(*) FROM member_cashflow_profiles) <> 0 THEN
    RAISE EXCEPTION 'revoked storage consent must hide the profile';
  END IF;
  BEGIN
    INSERT INTO member_cashflow_profiles(tenant_id, member_user_id, as_of_date, starting_balance, events, expires_at)
    VALUES ('00000000-0000-4000-8000-000000000101', '00000000-0000-4000-8000-000000000102', current_date, 10, '[]'::jsonb, now() + interval '30 days');
    RAISE EXCEPTION 'revoked storage consent must reject new profiles';
  EXCEPTION WHEN insufficient_privilege THEN NULL;
  END;
  DELETE FROM member_cashflow_profiles
  WHERE tenant_id = '00000000-0000-4000-8000-000000000101'
    AND member_user_id = '00000000-0000-4000-8000-000000000102';
END
$$;
RESET ROLE;
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM member_cashflow_profiles
    WHERE tenant_id = '00000000-0000-4000-8000-000000000101'
      AND member_user_id = '00000000-0000-4000-8000-000000000102'
  ) THEN
    RAISE EXCEPTION 'revocation must physically delete the saved profile, not only hide it through row security';
  END IF;
END
$$;
SET LOCAL ROLE aegis_runtime;

RESET ROLE;
INSERT INTO member_cashflow_profiles(tenant_id, member_user_id, as_of_date, starting_balance, events, updated_at, expires_at)
VALUES (
  '00000000-0000-4000-8000-000000000101',
  '00000000-0000-4000-8000-000000000102',
  current_date,
  10,
  '[]'::jsonb,
  now() - interval '60 days',
  now() - interval '30 days'
);
SET LOCAL ROLE aegis_runtime;
SELECT aegis_purge_expired_member_cashflow_profiles();
RESET ROLE;
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM member_cashflow_profiles WHERE member_user_id = '00000000-0000-4000-8000-000000000102') THEN
    RAISE EXCEPTION 'retention sweep must remove expired profiles';
  END IF;
END
$$;

INSERT INTO consent_events(tenant_id, member_user_id, purpose, action, policy_version) VALUES
  ('00000000-0000-4000-8000-000000000104', '00000000-0000-4000-8000-000000000105', 'manual_financial_profile', 'granted', 'test'),
  ('00000000-0000-4000-8000-000000000104', '00000000-0000-4000-8000-000000000105', 'cashflow_profile_storage', 'granted', 'test');
INSERT INTO member_cashflow_profiles(tenant_id, member_user_id, as_of_date, starting_balance, events, expires_at)
VALUES ('00000000-0000-4000-8000-000000000104', '00000000-0000-4000-8000-000000000105', current_date, 25, '[]'::jsonb, now() + interval '30 days');
SET LOCAL ROLE aegis_runtime;
SELECT set_config('aegis.tenant_id', '00000000-0000-4000-8000-000000000104', true),
       set_config('aegis.user_id', '00000000-0000-4000-8000-000000000105', true);
SELECT aegis_begin_member_account_deletion();
RESET ROLE;
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM member_cashflow_profiles WHERE member_user_id = '00000000-0000-4000-8000-000000000105') THEN
    RAISE EXCEPTION 'account deletion must immediately remove the saved profile';
  END IF;
END
$$;

ROLLBACK;
