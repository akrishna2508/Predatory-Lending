BEGIN;

INSERT INTO organizations(id, name, slug) VALUES ('00000000-0000-4000-8000-000000000071', 'Auth Test CU', 'auth-test-cu');
INSERT INTO app_users(id, identity_issuer, identity_subject) VALUES ('00000000-0000-4000-8000-000000000072', 'aegis:local', '00000000-0000-4000-8000-000000000072');
INSERT INTO memberships(tenant_id, user_id, role) VALUES ('00000000-0000-4000-8000-000000000071', '00000000-0000-4000-8000-000000000072', 'member');
INSERT INTO local_credentials(user_id, email, password_salt, password_hash)
VALUES ('00000000-0000-4000-8000-000000000072', 'member@example.test', decode(repeat('a1', 16), 'hex'), decode(repeat('b2', 64), 'hex'));

SET LOCAL ROLE aegis_runtime;
SELECT set_config('aegis.tenant_id', '00000000-0000-4000-8000-000000000071', true),
       set_config('aegis.user_id', '00000000-0000-4000-8000-000000000072', true);
DO $$
DECLARE
  resolved uuid;
  created boolean;
  credential_count integer;
BEGIN
  SELECT count(*) INTO credential_count FROM aegis_lookup_local_credential('MEMBER@example.test');
  IF credential_count <> 1 THEN RAISE EXCEPTION 'local login must resolve case-insensitive email'; END IF;
  IF has_table_privilege(current_user, 'local_credentials', 'SELECT') THEN
    RAISE EXCEPTION 'runtime must not read the credential table directly';
  END IF;
  SELECT aegis_create_member_session(
    '00000000-0000-4000-8000-000000000072', decode(repeat('c3', 32), 'hex'), now() + interval '12 hours'
  ) INTO created;
  IF NOT created THEN RAISE EXCEPTION 'active member session should be created'; END IF;
  SELECT aegis_resolve_member_session(decode(repeat('c3', 32), 'hex')) INTO resolved;
  IF resolved <> '00000000-0000-4000-8000-000000000072' THEN RAISE EXCEPTION 'valid session should resolve to its member'; END IF;
  PERFORM aegis_revoke_member_session(decode(repeat('c3', 32), 'hex'));
  SELECT aegis_resolve_member_session(decode(repeat('c3', 32), 'hex')) INTO resolved;
  IF resolved IS NOT NULL THEN RAISE EXCEPTION 'revoked session must not authenticate'; END IF;
END
$$;

SELECT aegis_create_member_session(
  '00000000-0000-4000-8000-000000000072', decode(repeat('d4', 32), 'hex'), now() + interval '12 hours'
);
DO $$
BEGIN
  IF aegis_context_user_id() <> '00000000-0000-4000-8000-000000000072' THEN RAISE EXCEPTION 'member context must persist through local authentication'; END IF;
END
$$;
SELECT aegis_begin_member_account_deletion();
DO $$
BEGIN
  IF aegis_resolve_member_session(decode(repeat('d4', 32), 'hex')) <> '00000000-0000-4000-8000-000000000072' THEN
    RAISE EXCEPTION 'pending deletion session must allow a safe retry';
  END IF;
END
$$;
SELECT aegis_mark_member_identity_deleted();
SELECT aegis_finalize_member_account_deletion();
DO $$
BEGIN
  IF aegis_resolve_member_session(decode(repeat('d4', 32), 'hex')) IS NOT NULL THEN
    RAISE EXCEPTION 'completed deletion must remove active sessions';
  END IF;
END
$$;

ROLLBACK;
