BEGIN;

INSERT INTO organizations(id, name, slug) VALUES ('00000000-0000-4000-8000-000000000041', 'Retention Test CU', 'retention-test-cu');
INSERT INTO app_users(id, identity_issuer, identity_subject) VALUES ('00000000-0000-4000-8000-000000000042', 'https://identity.example', 'retention-member');
INSERT INTO memberships(tenant_id, user_id, role) VALUES ('00000000-0000-4000-8000-000000000041', '00000000-0000-4000-8000-000000000042', 'member');
INSERT INTO bank_connections(id, tenant_id, member_user_id, provider_item_id, access_token_ciphertext)
VALUES ('00000000-0000-4000-8000-000000000043', '00000000-0000-4000-8000-000000000041', '00000000-0000-4000-8000-000000000042', 'retention-test-item', decode('aabbcc', 'hex'));
INSERT INTO bank_transactions(
  tenant_id, member_user_id, connection_id, provider_transaction_id, provider_account_id,
  amount, transaction_date, name, pending, categories
) VALUES
  ('00000000-0000-4000-8000-000000000041', '00000000-0000-4000-8000-000000000042', '00000000-0000-4000-8000-000000000043', 'expired-tx', 'retention-account', -10, ((now() AT TIME ZONE 'UTC')::date - interval '14 months')::date, 'Old transaction', false, ARRAY[]::text[]),
  ('00000000-0000-4000-8000-000000000041', '00000000-0000-4000-8000-000000000042', '00000000-0000-4000-8000-000000000043', 'recent-tx', 'retention-account', -20, ((now() AT TIME ZONE 'UTC')::date - interval '1 month')::date, 'Recent transaction', false, ARRAY[]::text[]);

DO $$
BEGIN
  IF has_table_privilege('aegis_bank_worker', 'bank_transactions', 'DELETE') THEN
    RAISE EXCEPTION 'worker must not directly delete transaction rows';
  END IF;
  IF NOT has_function_privilege('aegis_bank_worker', 'aegis_purge_expired_bank_transactions()', 'EXECUTE') THEN
    RAISE EXCEPTION 'worker must execute the retention function';
  END IF;
END
$$;

SET LOCAL ROLE aegis_bank_worker;
DO $$
DECLARE
  deleted_count bigint;
BEGIN
  SELECT aegis_purge_expired_bank_transactions() INTO deleted_count;
  IF deleted_count <> 1 THEN RAISE EXCEPTION 'retention must purge only rows older than thirteen months'; END IF;
END
$$;
RESET ROLE;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM bank_transactions WHERE provider_transaction_id = 'expired-tx')
     OR NOT EXISTS (SELECT 1 FROM bank_transactions WHERE provider_transaction_id = 'recent-tx') THEN
    RAISE EXCEPTION 'retention must preserve in-window transaction history';
  END IF;
END
$$;

ROLLBACK;
