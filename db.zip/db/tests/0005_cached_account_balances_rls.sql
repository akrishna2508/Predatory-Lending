BEGIN;

INSERT INTO organizations(id, name, slug) VALUES ('00000000-0000-4000-8000-000000000051', 'Balance Test CU', 'balance-test-cu');
INSERT INTO app_users(id, identity_issuer, identity_subject) VALUES
  ('00000000-0000-4000-8000-000000000052', 'https://identity.example', 'balance-member'),
  ('00000000-0000-4000-8000-000000000053', 'https://identity.example', 'balance-partner');
INSERT INTO memberships(tenant_id, user_id, role) VALUES
  ('00000000-0000-4000-8000-000000000051', '00000000-0000-4000-8000-000000000052', 'member'),
  ('00000000-0000-4000-8000-000000000051', '00000000-0000-4000-8000-000000000053', 'partner_admin');
INSERT INTO consent_events(tenant_id, member_user_id, purpose, action, policy_version)
VALUES ('00000000-0000-4000-8000-000000000051', '00000000-0000-4000-8000-000000000052', 'read_only_bank_connection', 'granted', 'test-v1');
INSERT INTO bank_connections(id, tenant_id, member_user_id, provider_item_id, access_token_ciphertext)
VALUES ('00000000-0000-4000-8000-000000000054', '00000000-0000-4000-8000-000000000051', '00000000-0000-4000-8000-000000000052', 'balance-test-item', decode('aabbcc', 'hex'));
INSERT INTO bank_sync_jobs(id, connection_id, job_kind, status, attempts)
VALUES ('00000000-0000-4000-8000-000000000055', '00000000-0000-4000-8000-000000000054', 'sync', 'queued', 0);

DO $$
BEGIN
  IF has_table_privilege('aegis_bank_worker', 'bank_account_balances', 'SELECT') THEN
    RAISE EXCEPTION 'worker must not read stored balance rows directly';
  END IF;
  IF has_column_privilege('aegis_bank_worker_owner', 'bank_account_balances', 'current_balance', 'SELECT') THEN
    RAISE EXCEPTION 'worker function owner must not read stored balance values';
  END IF;
  IF has_table_privilege('aegis_reporting_owner', 'bank_account_balances', 'SELECT') THEN
    RAISE EXCEPTION 'partner reporting owner must not read individual account balances';
  END IF;
END
$$;

SET LOCAL ROLE aegis_bank_worker;
DO $$
DECLARE
  claimed record;
BEGIN
  SELECT * INTO claimed FROM aegis_claim_bank_sync_jobs(1);
  IF aegis_complete_bank_sync_job(claimed.job_id, 'balance-cursor-v1', '[]'::jsonb) <> 'completed' THEN
    RAISE EXCEPTION 'transaction cursor must complete before storing its balance snapshot';
  END IF;
  IF aegis_replace_bank_account_balances(claimed.job_id, '[{"providerAccountId":"checking-1","name":"Everyday Checking","officialName":null,"subtype":"checking","currentBalance":512.34,"availableBalance":498.12,"currencyCode":"USD"}]'::jsonb) <> 1 THEN
    RAISE EXCEPTION 'worker must store the validated checking balance snapshot';
  END IF;
END
$$;
RESET ROLE;

SET LOCAL ROLE aegis_runtime;
SELECT set_config('aegis.tenant_id', '00000000-0000-4000-8000-000000000051', true);
SELECT set_config('aegis.user_id', '00000000-0000-4000-8000-000000000052', true);
DO $$
BEGIN
  IF (SELECT count(*) FROM bank_account_balances) <> 1
    OR NOT EXISTS (SELECT 1 FROM bank_account_balances WHERE current_balance = 512.34 AND available_balance = 498.12 AND currency_code = 'USD') THEN
    RAISE EXCEPTION 'member must see their own cached balance with its source fields';
  END IF;
END
$$;
SELECT set_config('aegis.user_id', '00000000-0000-4000-8000-000000000053', true);
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM bank_account_balances) THEN
    RAISE EXCEPTION 'partner must not see member account balances';
  END IF;
END
$$;

SELECT set_config('aegis.user_id', '00000000-0000-4000-8000-000000000052', true);
INSERT INTO consent_events(tenant_id, member_user_id, purpose, action, policy_version)
VALUES ('00000000-0000-4000-8000-000000000051', '00000000-0000-4000-8000-000000000052', 'read_only_bank_connection', 'revoked', 'test-v1');
DO $$
BEGIN
  PERFORM aegis_revoke_member_bank_consent();
  IF EXISTS (SELECT 1 FROM bank_account_balances) THEN
    RAISE EXCEPTION 'bank consent revocation must immediately erase cached balances';
  END IF;
END
$$;
RESET ROLE;

ROLLBACK;
