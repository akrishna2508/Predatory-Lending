BEGIN;

INSERT INTO organizations(id, name, slug) VALUES ('00000000-0000-4000-8000-000000000021', 'Bank Data Test CU', 'bank-data-test-cu');
INSERT INTO app_users(id, identity_issuer, identity_subject) VALUES
  ('00000000-0000-4000-8000-000000000022', 'https://identity.example', 'bank-member'),
  ('00000000-0000-4000-8000-000000000023', 'https://identity.example', 'bank-partner');
INSERT INTO memberships(tenant_id, user_id, role) VALUES
  ('00000000-0000-4000-8000-000000000021', '00000000-0000-4000-8000-000000000022', 'member'),
  ('00000000-0000-4000-8000-000000000021', '00000000-0000-4000-8000-000000000023', 'partner_admin');
INSERT INTO consent_events(tenant_id, member_user_id, purpose, action, policy_version)
VALUES ('00000000-0000-4000-8000-000000000021', '00000000-0000-4000-8000-000000000022', 'read_only_bank_connection', 'granted', 'test-v1');
INSERT INTO bank_connections(
  id, tenant_id, member_user_id, provider_item_id, access_token_ciphertext, institution_id, institution_name
) VALUES (
  '00000000-0000-4000-8000-000000000024',
  '00000000-0000-4000-8000-000000000021',
  '00000000-0000-4000-8000-000000000022',
  'plaid-item-synthetic', decode('aabbcc', 'hex'), 'ins_synthetic', 'Synthetic Community Bank'
);
INSERT INTO bank_transactions(
  tenant_id, member_user_id, connection_id, provider_transaction_id, provider_account_id,
  amount, transaction_date, name, pending, categories
) VALUES (
  '00000000-0000-4000-8000-000000000021',
  '00000000-0000-4000-8000-000000000022',
  '00000000-0000-4000-8000-000000000024',
  'pending-tx-1', 'synthetic-account-1', 1250.00, '2026-09-24', 'Synthetic payroll', true, ARRAY['INCOME', 'INCOME_WAGES']
);

DO $$
BEGIN
  IF has_column_privilege('aegis_runtime', 'bank_connections', 'access_token_ciphertext', 'SELECT') THEN
    RAISE EXCEPTION 'web runtime must not read encrypted bank tokens directly';
  END IF;
  IF has_table_privilege('aegis_runtime', 'bank_sync_jobs', 'SELECT') THEN
    RAISE EXCEPTION 'web runtime must not read internal bank sync jobs';
  END IF;
  IF NOT has_function_privilege('aegis_runtime', 'aegis_enqueue_member_bank_sync(uuid, text)', 'EXECUTE') THEN
    RAISE EXCEPTION 'member runtime needs the guarded sync enqueue function';
  END IF;
  IF has_function_privilege('aegis_runtime', 'aegis_claim_bank_sync_jobs(integer)', 'EXECUTE') THEN
    RAISE EXCEPTION 'member web runtime must not claim background bank jobs';
  END IF;
  IF has_function_privilege('aegis_runtime', 'aegis_heartbeat_bank_sync_job(uuid)', 'EXECUTE')
     OR NOT has_function_privilege('aegis_bank_worker', 'aegis_heartbeat_bank_sync_job(uuid)', 'EXECUTE') THEN
    RAISE EXCEPTION 'only the bank worker may extend a processing job lease';
  END IF;
  IF has_table_privilege('aegis_bank_worker', 'bank_transactions', 'SELECT') OR has_column_privilege('aegis_bank_worker', 'bank_connections', 'access_token_ciphertext', 'SELECT') THEN
    RAISE EXCEPTION 'worker credentials must use scoped functions instead of direct table access';
  END IF;
  IF has_table_privilege('aegis_bank_worker_owner', 'bank_transactions', 'SELECT')
     OR has_column_privilege('aegis_bank_worker_owner', 'bank_transactions', 'member_user_id', 'SELECT') THEN
    RAISE EXCEPTION 'worker function owner must not have broad member-level access to normalized financial records';
  END IF;
  IF has_table_privilege('aegis_privacy_owner', 'bank_transactions', 'SELECT')
     OR has_table_privilege('aegis_privacy_owner', 'bank_connections', 'DELETE') THEN
    RAISE EXCEPTION 'privacy function owner should erase data without reading or removing provider links';
  END IF;
END
$$;

SET LOCAL ROLE aegis_runtime;
SELECT set_config('aegis.tenant_id', '00000000-0000-4000-8000-000000000021', true);
SELECT set_config('aegis.user_id', '00000000-0000-4000-8000-000000000022', true);
DO $$
BEGIN
  IF (SELECT count(*) FROM bank_connections) <> 1 THEN
    RAISE EXCEPTION 'member must see their own bank connection';
  END IF;
  IF (SELECT count(*) FROM bank_transactions) <> 1 THEN
    RAISE EXCEPTION 'member must see their own normalized transactions';
  END IF;
  IF (SELECT aegis_enqueue_member_bank_sync('00000000-0000-4000-8000-000000000024', 'member_request')) IS NOT TRUE THEN
    RAISE EXCEPTION 'member must enqueue a sync for their own active connection';
  END IF;
  IF aegis_enqueue_plaid_item_sync('plaid-item-synthetic') IS NOT TRUE THEN
    RAISE EXCEPTION 'verified Plaid item webhook must enqueue a sync for an active consented connection';
  END IF;
  BEGIN
    INSERT INTO bank_transactions(
      tenant_id, member_user_id, connection_id, provider_transaction_id, provider_account_id,
      amount, transaction_date, name, pending, categories
    ) VALUES (
      '00000000-0000-4000-8000-000000000021',
      '00000000-0000-4000-8000-000000000023',
      '00000000-0000-4000-8000-000000000024',
      'other-member-tx', 'synthetic-account-1', 1, '2026-09-24', 'Invalid cross-member row', false, ARRAY[]::text[]
    );
    RAISE EXCEPTION 'member must not write a transaction for another member';
  EXCEPTION WHEN insufficient_privilege THEN
    NULL;
  END;
END
$$;

RESET ROLE;
SET LOCAL ROLE aegis_bank_worker;
DO $$
DECLARE
  claimed record;
  result_status text;
BEGIN
  SELECT * INTO claimed FROM aegis_claim_bank_sync_jobs(5);
  IF claimed.job_id IS NULL OR claimed.job_kind <> 'sync' OR claimed.access_token_ciphertext IS NULL THEN
    RAISE EXCEPTION 'worker must claim an encrypted-token sync job';
  END IF;
  IF aegis_heartbeat_bank_sync_job(claimed.job_id) IS NOT TRUE THEN
    RAISE EXCEPTION 'active sync job lease must be extendable while provider pagination runs';
  END IF;
  result_status := aegis_complete_bank_sync_job(claimed.job_id, 'cursor-v1',
    '[{"kind":"added","transaction":{"transactionId":"posted-tx-1","accountId":"synthetic-account-1","amount":1250,"date":"2026-09-24","authorizedDate":"2026-09-24","name":"Synthetic payroll","merchantName":"Synthetic CU","pending":false,"pendingTransactionId":"pending-tx-1","categories":["INCOME"]}},{"kind":"removed","transactionId":"pending-tx-1"}]'::jsonb);
  IF result_status <> 'completed' THEN RAISE EXCEPTION 'worker sync result must complete atomically'; END IF;
END
$$;
RESET ROLE;
DO $$
BEGIN
  IF (SELECT provider_cursor FROM bank_connections WHERE id = '00000000-0000-4000-8000-000000000024') <> 'cursor-v1' THEN
    RAISE EXCEPTION 'worker must commit provider cursor with its transaction batch';
  END IF;
  IF (SELECT count(*) FROM bank_transactions WHERE connection_id = '00000000-0000-4000-8000-000000000024') <> 1
     OR NOT EXISTS (SELECT 1 FROM bank_transactions WHERE provider_transaction_id = 'posted-tx-1' AND pending = false) THEN
    RAISE EXCEPTION 'worker must apply posted transactions and remove their pending predecessors';
  END IF;
END
$$;

SET LOCAL ROLE aegis_runtime;
SELECT set_config('aegis.tenant_id', '00000000-0000-4000-8000-000000000021', true);
SELECT set_config('aegis.user_id', '00000000-0000-4000-8000-000000000022', true);
SELECT aegis_enqueue_member_bank_sync('00000000-0000-4000-8000-000000000024', 'member_request');
RESET ROLE;
SET LOCAL ROLE aegis_bank_worker;
DO $$
DECLARE
  claimed record;
  result_status text;
BEGIN
  SELECT * INTO claimed FROM aegis_claim_bank_sync_jobs(5);
  result_status := aegis_fail_bank_sync_job(claimed.job_id, 'RATE_LIMIT');
  IF result_status <> 'retry' THEN RAISE EXCEPTION 'temporary provider failures must retry'; END IF;
END
$$;
RESET ROLE;
DO $$
BEGIN
  IF (SELECT status FROM bank_sync_jobs WHERE connection_id = '00000000-0000-4000-8000-000000000024' AND status = 'retry') <> 'retry'
     OR (SELECT last_error_code FROM bank_sync_jobs WHERE connection_id = '00000000-0000-4000-8000-000000000024' AND status = 'retry') <> 'RATE_LIMIT'
     OR (SELECT available_at FROM bank_sync_jobs WHERE connection_id = '00000000-0000-4000-8000-000000000024' AND status = 'retry') <= now() THEN
    RAISE EXCEPTION 'provider retry state must retain a safe error code and exponential backoff';
  END IF;
END
$$;

SET LOCAL ROLE aegis_runtime;
SELECT set_config('aegis.tenant_id', '00000000-0000-4000-8000-000000000021', true);
SELECT set_config('aegis.user_id', '00000000-0000-4000-8000-000000000023', true);
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM bank_connections) OR EXISTS (SELECT 1 FROM bank_transactions) THEN
    RAISE EXCEPTION 'partner must not read individual member bank data';
  END IF;
END
$$;

SELECT set_config('aegis.user_id', '00000000-0000-4000-8000-000000000022', true);
INSERT INTO consent_events(tenant_id, member_user_id, purpose, action, policy_version)
VALUES ('00000000-0000-4000-8000-000000000021', '00000000-0000-4000-8000-000000000022', 'read_only_bank_connection', 'revoked', 'test-v1');
DO $$
BEGIN
  IF aegis_enqueue_member_bank_sync('00000000-0000-4000-8000-000000000024', 'member_request') IS TRUE THEN
    RAISE EXCEPTION 'a prior grant must not allow sync after the latest consent is revoked';
  END IF;
  IF aegis_revoke_member_bank_consent() <> 1 THEN
    RAISE EXCEPTION 'consent revocation must mark an active connection for provider offboarding';
  END IF;
  IF EXISTS (SELECT 1 FROM bank_transactions) THEN
    RAISE EXCEPTION 'consent revocation must immediately delete imported transactions';
  END IF;
END
$$;

RESET ROLE;
DO $$
BEGIN
  IF (SELECT count(*) FROM bank_sync_jobs WHERE connection_id = '00000000-0000-4000-8000-000000000024' AND status IN ('queued', 'processing', 'retry')) <> 1 THEN
    RAISE EXCEPTION 'only one sync or disconnect job may remain open';
  END IF;
  IF (SELECT job_kind FROM bank_sync_jobs WHERE connection_id = '00000000-0000-4000-8000-000000000024' AND status IN ('queued', 'processing', 'retry')) <> 'disconnect' THEN
    RAISE EXCEPTION 'provider disconnect must take priority over pending sync';
  END IF;
  IF (SELECT status FROM bank_connections WHERE id = '00000000-0000-4000-8000-000000000024') <> 'disconnect_pending' THEN
    RAISE EXCEPTION 'revoked connection must be labeled pending provider offboarding';
  END IF;
END
$$;

SET LOCAL ROLE aegis_runtime;
SELECT set_config('aegis.tenant_id', '', true);
SELECT set_config('aegis.user_id', '00000000-0000-4000-8000-000000000022', true);
SELECT aegis_begin_member_account_deletion();
SELECT aegis_mark_member_identity_deleted();
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM bank_transactions WHERE member_user_id = '00000000-0000-4000-8000-000000000022') THEN
    RAISE EXCEPTION 'account deletion must immediately erase imported transactions';
  END IF;
  BEGIN
    PERFORM aegis_finalize_member_account_deletion();
    RAISE EXCEPTION 'account deletion must wait for provider Item removal';
  EXCEPTION WHEN raise_exception THEN
    IF SQLERRM = 'account deletion must wait for provider Item removal' THEN RAISE; END IF;
  END;
END
$$;
RESET ROLE;
SET LOCAL ROLE aegis_bank_worker;
DO $$
DECLARE
  claimed record;
BEGIN
  SELECT * INTO claimed FROM aegis_claim_bank_sync_jobs(5);
  IF claimed.job_id IS NULL OR claimed.job_kind <> 'disconnect' THEN
    RAISE EXCEPTION 'worker must receive the queued provider disconnect before account deletion finalizes';
  END IF;
  IF aegis_complete_bank_disconnect_job(claimed.job_id) IS NOT TRUE THEN
    RAISE EXCEPTION 'confirmed provider offboarding must remove the bank connection';
  END IF;
END
$$;
RESET ROLE;
SET LOCAL ROLE aegis_runtime;
SELECT set_config('aegis.tenant_id', '', true);
SELECT set_config('aegis.user_id', '00000000-0000-4000-8000-000000000022', true);
SELECT aegis_finalize_member_account_deletion();
RESET ROLE;
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM app_users WHERE id = '00000000-0000-4000-8000-000000000022') THEN
    RAISE EXCEPTION 'account deletion must finish after provider disconnection';
  END IF;
END
$$;

ROLLBACK;
