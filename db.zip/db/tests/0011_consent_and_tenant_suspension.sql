BEGIN;

INSERT INTO organizations(id, name, slug) VALUES
  ('00000000-0000-4000-8000-000000000201', 'Consent Test CU', 'consent-test-cu');
INSERT INTO app_users(id, identity_issuer, identity_subject) VALUES
  ('00000000-0000-4000-8000-000000000202', 'https://identity.example', 'consent-member');
INSERT INTO memberships(tenant_id, user_id, role) VALUES
  ('00000000-0000-4000-8000-000000000201', '00000000-0000-4000-8000-000000000202', 'member');

SET LOCAL ROLE aegis_runtime;
SELECT set_config('aegis.tenant_id', '00000000-0000-4000-8000-000000000201', true),
       set_config('aegis.user_id', '00000000-0000-4000-8000-000000000202', true);

DO $$
BEGIN
  BEGIN
    INSERT INTO offer_checks(tenant_id, member_user_id, input_payload, result_payload, calculation_version)
    VALUES ('00000000-0000-4000-8000-000000000201', '00000000-0000-4000-8000-000000000202', '{}'::jsonb, '{}'::jsonb, 'test');
    RAISE EXCEPTION 'offer checks must require active calculation and storage consent';
  EXCEPTION WHEN insufficient_privilege THEN NULL;
  END;
END
$$;

INSERT INTO consent_events(tenant_id, member_user_id, purpose, action, policy_version) VALUES
  ('00000000-0000-4000-8000-000000000201', '00000000-0000-4000-8000-000000000202', 'manual_financial_profile', 'granted', 'test'),
  ('00000000-0000-4000-8000-000000000201', '00000000-0000-4000-8000-000000000202', 'offer_check_storage', 'granted', 'test'),
  ('00000000-0000-4000-8000-000000000201', '00000000-0000-4000-8000-000000000202', 'offer_outcome_reporting', 'granted', 'test');

INSERT INTO offer_checks(id, tenant_id, member_user_id, input_payload, result_payload, calculation_version)
VALUES ('20000000-0000-4000-8000-000000000201', '00000000-0000-4000-8000-000000000201', '00000000-0000-4000-8000-000000000202', '{}'::jsonb, '{}'::jsonb, 'test');
INSERT INTO offer_outcomes(tenant_id, member_user_id, offer_check_id, outcome)
VALUES ('00000000-0000-4000-8000-000000000201', '00000000-0000-4000-8000-000000000202', '20000000-0000-4000-8000-000000000201', 'declined');

INSERT INTO consent_events(tenant_id, member_user_id, purpose, action, policy_version)
VALUES ('00000000-0000-4000-8000-000000000201', '00000000-0000-4000-8000-000000000202', 'offer_outcome_reporting', 'revoked', 'test');
DO $$
BEGIN
  BEGIN
    INSERT INTO offer_outcomes(tenant_id, member_user_id, offer_check_id, outcome)
    VALUES ('00000000-0000-4000-8000-000000000201', '00000000-0000-4000-8000-000000000202', '20000000-0000-4000-8000-000000000201', 'accepted');
    RAISE EXCEPTION 'revoked outcome consent must reject new self-reports';
  EXCEPTION WHEN insufficient_privilege THEN NULL;
  END;
END
$$;

INSERT INTO consent_events(tenant_id, member_user_id, purpose, action, policy_version)
VALUES ('00000000-0000-4000-8000-000000000201', '00000000-0000-4000-8000-000000000202', 'offer_check_storage', 'revoked', 'test');
DO $$
BEGIN
  BEGIN
    INSERT INTO offer_checks(tenant_id, member_user_id, input_payload, result_payload, calculation_version)
    VALUES ('00000000-0000-4000-8000-000000000201', '00000000-0000-4000-8000-000000000202', '{}'::jsonb, '{}'::jsonb, 'test');
    RAISE EXCEPTION 'revoked offer-check consent must reject new saved checks';
  EXCEPTION WHEN insufficient_privilege THEN NULL;
  END;
END
$$;

RESET ROLE;
UPDATE organizations SET status = 'suspended' WHERE id = '00000000-0000-4000-8000-000000000201';
SET LOCAL ROLE aegis_runtime;
SELECT set_config('aegis.tenant_id', '00000000-0000-4000-8000-000000000201', true),
       set_config('aegis.user_id', '00000000-0000-4000-8000-000000000202', true);
DO $$
BEGIN
  IF aegis_context_tenant_id() IS NOT NULL THEN
    RAISE EXCEPTION 'suspended organizations must not produce an active tenant context';
  END IF;
  IF EXISTS (SELECT 1 FROM offer_checks) THEN
    RAISE EXCEPTION 'suspended members must not retain access to financial records';
  END IF;
END
$$;

ROLLBACK;
