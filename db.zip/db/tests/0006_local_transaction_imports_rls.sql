BEGIN;

INSERT INTO organizations(id, name, slug) VALUES
  ('00000000-0000-4000-8000-000000000061', 'CSV Test CU', 'csv-test-cu'),
  ('00000000-0000-4000-8000-000000000064', 'Other CSV Test CU', 'other-csv-test-cu');
INSERT INTO app_users(id, identity_issuer, identity_subject) VALUES
  ('00000000-0000-4000-8000-000000000062', 'https://identity.example', 'csv-member');
INSERT INTO memberships(tenant_id, user_id, role) VALUES
  ('00000000-0000-4000-8000-000000000061', '00000000-0000-4000-8000-000000000062', 'member');
INSERT INTO consent_events(tenant_id, member_user_id, purpose, action, policy_version)
VALUES ('00000000-0000-4000-8000-000000000061', '00000000-0000-4000-8000-000000000062', 'transaction_history_upload', 'granted', 'test');
INSERT INTO transaction_imports(id, tenant_id, member_user_id, source_hash, transaction_count)
VALUES ('00000000-0000-4000-8000-000000000063', '00000000-0000-4000-8000-000000000061', '00000000-0000-4000-8000-000000000062', decode(repeat('a1', 32), 'hex'), 1);
INSERT INTO imported_transactions(tenant_id, member_user_id, import_id, row_number, amount, transaction_date, description)
VALUES ('00000000-0000-4000-8000-000000000061', '00000000-0000-4000-8000-000000000062', '00000000-0000-4000-8000-000000000063', 1, -22.50, current_date, 'Test grocery');

SET LOCAL ROLE aegis_runtime;
SELECT set_config('aegis.tenant_id', '00000000-0000-4000-8000-000000000061', true),
       set_config('aegis.user_id', '00000000-0000-4000-8000-000000000062', true);
DO $$
BEGIN
  IF (SELECT count(*) FROM imported_transactions) <> 1 THEN
    RAISE EXCEPTION 'member must read their imported transaction';
  END IF;
  IF (SELECT count(*) FROM transaction_imports WHERE tenant_id = '00000000-0000-4000-8000-000000000064') <> 0 THEN
    RAISE EXCEPTION 'member must not read another tenant import';
  END IF;
  INSERT INTO transaction_imports(tenant_id, member_user_id, source_hash, transaction_count)
  VALUES ('00000000-0000-4000-8000-000000000061', '00000000-0000-4000-8000-000000000062', decode(repeat('c3', 32), 'hex'), 1);
  INSERT INTO imported_transactions(tenant_id, member_user_id, import_id, row_number, amount, transaction_date, description)
  SELECT '00000000-0000-4000-8000-000000000061', '00000000-0000-4000-8000-000000000062', id, 1, 10, current_date, 'Allowed income'
  FROM transaction_imports WHERE source_hash = decode(repeat('c3', 32), 'hex');
END
$$;

RESET ROLE;
INSERT INTO consent_events(tenant_id, member_user_id, purpose, action, policy_version)
VALUES ('00000000-0000-4000-8000-000000000061', '00000000-0000-4000-8000-000000000062', 'transaction_history_upload', 'revoked', 'test');
SET LOCAL ROLE aegis_runtime;
SELECT set_config('aegis.tenant_id', '00000000-0000-4000-8000-000000000061', true),
       set_config('aegis.user_id', '00000000-0000-4000-8000-000000000062', true);
DO $$
BEGIN
  BEGIN
    INSERT INTO transaction_imports(tenant_id, member_user_id, source_hash, transaction_count)
    VALUES ('00000000-0000-4000-8000-000000000061', '00000000-0000-4000-8000-000000000062', decode(repeat('b2', 32), 'hex'), 1);
    RAISE EXCEPTION 'revoked consent must reject new import';
  EXCEPTION WHEN insufficient_privilege THEN NULL;
  END;
END
$$;

ROLLBACK;
