# Local PostgreSQL setup

PostgreSQL is the only stateful service required by the app. The Compose database bootstrap creates separate `aegis_app` and `aegis_operator` logins. The web login inherits only `aegis_runtime`; operator scripts use `aegis_provisioner`; migrations use the local database administrator. Never put operator or migration credentials in the web container.

For a fresh local database, copy `.env.example` to `.env`, load it into the shell, start PostgreSQL, and apply migrations:

```sh
set -a
. ./.env
set +a
docker compose up -d db
npm run db:migrate:local
```

The migration runner takes a PostgreSQL advisory lock and records completed filenames in `aegis_schema_migrations`. Its migrations run in order. It is for a fresh local install; do not point it at a database with existing data but no matching migration history.

## Roles and row-level security

`aegis_runtime` is a `NOLOGIN`, `NOBYPASSRLS` role. Member API transactions explicitly assume it and set tenant and member IDs as transaction-local PostgreSQL settings. Member-owned tables use forced row-level security. Partner access is limited to an aggregate function that suppresses cohorts smaller than 20. `aegis_privacy_owner` owns narrowly scoped account deletion, session, retention, and aggregate functions; it is not a login. `aegis_provisioner` can create organizations, local credentials, memberships, and audit events, but it cannot read member offer or transaction records.

CSV upload and member transactions exist in `transaction_imports` and `imported_transactions`. The exact CSV hash prevents an identical file being uploaded twice for the same member in the same credit union. The app discards the file name and stores only the transaction date, description, and amount. Upload insert policies require the latest `transaction_history_upload` consent to be granted. Revocation deletes all imports for that member and tenant. A daily in-process maintenance task removes imported transactions after 13 months and expired local sessions.

## Local identity

Passwords are hashed with Node's built-in scrypt and a per-account random salt. The credential table is not directly readable by the web role; a narrowly scoped database function returns one credential record for login. Failed attempts are counted and an account is locked for 15 minutes after eight failures. Successful sign-in generates a random opaque session token, stores only its SHA-256 hash in PostgreSQL, and sends the token in an HttpOnly, SameSite=Lax cookie. Logout revokes the server-side session. Public self-registration is disabled; an operator provisions each member and partner user.

Create an organization and provision a login using `.env` values:

```sh
npm run provision:organization -- "Community Credit Union" community-cu
AEGIS_MEMBER_INITIAL_PASSWORD="use-a-unique-passphrase-at-least-14-chars" npm run provision:membership -- <organization-uuid> member@example.org member
```

Set `AEGIS_OPERATOR_PRINCIPAL` to the person or procedure performing provisioning. Membership role changes use `npm run membership:update`; they lock the existing membership row and append an audit event. Provisioning and membership tools use `AEGIS_PROVISIONING_DATABASE_URL` and never use web-runtime credentials.

Account deletion disables the local identity immediately, removes offers and consent, retires sessions and credentials, deletes member transactions, removes memberships, and de-identifies retained audit events. Mixed member/partner accounts remain a support workflow.

## Encrypted backups and restore

Install `pg_dump`, `pg_restore`, and `psql` from the same PostgreSQL major release as the server. `npm run db:backup:local -- [output-path]` creates a streaming AES-256-GCM encrypted custom-format dump. The output file is created with mode `0600` under a mode-`0700` newly created directory; an existing output is never overwritten. `AEGIS_BACKUP_DATABASE_URL` must point to loopback or a Unix socket and must not contain a password. Use `PGPASSFILE` or local peer authentication. Set `AEGIS_BACKUP_KEY_FILE` to a mode-`0600` base64 file containing exactly 32 random bytes; the backup key is not passed to the web container or database client process.

Run `npm run db:restore:local -- <backup-file>` with `AEGIS_RESTORE_DATABASE_URL`, `AEGIS_RESTORE_CONFIRM_DATABASE`, and the same key file configured. Restore is limited to a local, empty database and requires a PostgreSQL superuser so object owners and grants are restored. The restore runs in one transaction; it refuses a nonempty target and does not drop existing objects.

`npm run db:prune-backups:local` removes only regular `.aegisbackup` files older than 35 days from `backups/` (or `AEGIS_BACKUP_DIRECTORY`). Operators should schedule a backup every 30 minutes to support the product plan's one-hour recovery-point objective, run pruning daily, store a recovery copy of the key separately from encrypted backup files, and perform a restore drill quarterly. Schedule execution and off-host storage are operator responsibilities in this local release.

Historical dumps can contain records already deleted from the live database. A restore may reintroduce those records; the current alpha does not replay an external erasure ledger. Do not restore production member data and reopen service until deletion events newer than the selected backup have been reconciled. Legal/privacy review must disclose backup expiry behavior.

## SQL verification

Run each SQL test at its matching point in the migration history, as the CI workflow does. Tests `0001`–`0005` require the historical bank tables and run immediately after their matching migrations; test `0006` runs after migration `0006`; test `0007` runs after all migrations, including `0009`. Each test creates synthetic fixtures inside a transaction and rolls back. Never run database tests against member data.

## Schema history

Migrations `0001`–`0005` record the original AWS/Cognito/Plaid implementation. They remain in order so an existing local database can be upgraded. `0006` adds local transaction imports, `0007` adds local authentication, `0008` removes the paid bank provider tables, tokens, balances, and worker functions, and `0009` removes provider-dependent account-deletion behavior. Do not edit or delete already applied migrations; add a new numbered migration for future schema changes.
