import { describe, expect, it } from 'vitest';
import { analyzeOffer, type CashEvent, type OfferInput } from '../src/domain/finance';
import { exampleOffer } from '../src/domain/fixtures';

const asOfDate = '2026-09-25';
const base: CashEvent[] = [
  { id: 'bill', date: '2026-10-02', label: 'Rent', amount: -780, kind: 'bill' },
  { id: 'income', date: '2026-10-08', label: 'Paycheck', amount: 950, kind: 'income' },
];
const offer = (overrides: Partial<OfferInput> = {}): OfferInput => ({ asOfDate, startingBalance: 500, events: base, proceeds: 300, receivedOn: '2026-09-26', payments: [
  { date: '2026-10-01', amount: 190 }, { date: '2026-10-15', amount: 190 },
], ...overrides });

describe('analyzeOffer', () => {
  it('calculates repayment and dollar cost from every scheduled payment to cents', () => {
    const result = analyzeOffer(offer({ proceeds: 300.25, payments: [{ date: '2026-10-01', amount: 190.1 }, { date: '2026-10-15', amount: 190.15 }] }));
    expect(result.valid).toBe(true);
    if (result.valid) {
      expect(result.totalRepayment).toBe(380.25);
      expect(result.dollarCost).toBe(80);
    }
  });

  it('orders same-day flows deterministically and returns both minima', () => {
    const result = analyzeOffer(offer({ startingBalance: 200, events: [
      { id: 'income', date: '2026-10-01', label: 'Pay', amount: 100, kind: 'income' },
      { id: 'bill', date: '2026-10-01', label: 'Bill', amount: -50, kind: 'bill' },
    ], proceeds: 1, receivedOn: '2026-10-01', payments: [{ date: '2026-10-01', amount: 300 }] }));
    expect(result.valid).toBe(true);
    if (result.valid) {
      expect(result.baseline.lowestBalance).toBe(200);
      expect(result.baseline.lowestDate).toBe(asOfDate);
      expect(result.withOffer.lowestBalance).toBe(-49);
      expect(result.withOffer.lowestDate).toBe('2026-10-01');
      expect(result.withOffer.points.filter(point => point.date === '2026-10-01').map(point => point.kind)).toEqual(['income', 'proceeds', 'bill', 'payment']);
      expect(result.startingBalance).toBe(200);
    }
  });

  it('names the payment when a later bill creates a shortfall before income', () => {
    const result = analyzeOffer(offer({ startingBalance: 500, events: [
      { id: 'bill-1', date: '2026-09-30', label: 'Utility bill', amount: -300, kind: 'bill' },
      { id: 'bill-2', date: '2026-10-02', label: 'Rent', amount: -250, kind: 'bill' },
      { id: 'income', date: '2026-10-05', label: 'Paycheck', amount: 1000, kind: 'income' },
    ], proceeds: 100, receivedOn: asOfDate, payments: [{ date: '2026-09-29', amount: 200 }] }));
    expect(result.valid).toBe(true);
    if (result.valid) expect(result.warning).toMatchObject({ date: '2026-10-02', paymentDate: '2026-09-29', paymentAmount: 200, balanceAfter: -150, paymentIndex: 0 });
  });

  it('attributes the example shortfall to the payment date and amount', () => {
    const result = analyzeOffer(exampleOffer);
    expect(result.valid).toBe(true);
    if (result.valid) expect(result.warning).toMatchObject({ date: '2026-10-02', paymentDate: '2026-10-02', paymentAmount: 250, balanceAfter: -98 });
  });

  it('prompts when the member reports another short-term repayment in the prior 14 days', () => {
    const result = analyzeOffer(offer({ recentShortTermLoanRepaymentDate: '2026-09-18' }));
    expect(result.valid).toBe(true);
    if (result.valid) expect(result.repeatBorrowingPrompt).toEqual({ recentRepaymentDate: '2026-09-18', daysSinceRepayment: 7 });
  });

  it('does not prompt for older history and rejects a repayment date after the balance date', () => {
    const older = analyzeOffer(offer({ recentShortTermLoanRepaymentDate: '2026-09-01' }));
    expect(older.valid && older.repeatBorrowingPrompt).toBeNull();
    expect(analyzeOffer(offer({ recentShortTermLoanRepaymentDate: '2026-09-26' }))).toMatchObject({ valid: false });
  });

  it('rejects impossible calendar dates', () => {
    expect(analyzeOffer(offer({ receivedOn: '2026-02-31' }))).toMatchObject({ valid: false });
  });

  it('keeps receipt and payments inside the as-of 30-day window and after receipt', () => {
    expect(analyzeOffer(offer({ receivedOn: '2026-10-25' }))).toMatchObject({ valid: false, reason: expect.stringContaining('30-day') });
    expect(analyzeOffer(offer({ receivedOn: '2026-09-28', payments: [{ date: '2026-09-27', amount: 100 }] }))).toMatchObject({ valid: false, reason: expect.stringContaining('on or after') });
    expect(analyzeOffer(offer({ payments: [{ date: '2026-10-25', amount: 100 }] }))).toMatchObject({ valid: false, reason: expect.stringContaining('30-day') });
  });

  it('rejects missing or nonpositive offer terms without a numeric result', () => {
    const result = analyzeOffer(offer({ proceeds: 0, receivedOn: '', payments: [{ date: '', amount: -20 }] }));
    expect(result).toMatchObject({ valid: false });
  });
});
