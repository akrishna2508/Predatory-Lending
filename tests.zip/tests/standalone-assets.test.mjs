import { mkdtemp, mkdir, readFile, rm, writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { afterEach, expect, it } from 'vitest';
import { copyStandaloneAssets } from '../scripts/prepare-standalone.mjs';

let tempRoot;

afterEach(async () => {
  if (tempRoot) await rm(tempRoot, { recursive: true, force: true });
  tempRoot = undefined;
});

it('copies Next static and public assets into standalone output', async () => {
  tempRoot = await mkdtemp(path.join(os.tmpdir(), 'aegis-standalone-'));
  const cssPath = path.join(tempRoot, '.next', 'static', 'css', 'app.css');
  const publicPath = path.join(tempRoot, 'public', 'mark.svg');
  await mkdir(path.dirname(cssPath), { recursive: true });
  await mkdir(path.dirname(publicPath), { recursive: true });
  await writeFile(cssPath, 'body { color: black; }');
  await writeFile(publicPath, '<svg/>');

  await copyStandaloneAssets(tempRoot);

  expect(await readFile(path.join(tempRoot, '.next', 'standalone', '.next', 'static', 'css', 'app.css'), 'utf8'))
    .toBe('body { color: black; }');
  expect(await readFile(path.join(tempRoot, '.next', 'standalone', 'public', 'mark.svg'), 'utf8'))
    .toBe('<svg/>');
});
