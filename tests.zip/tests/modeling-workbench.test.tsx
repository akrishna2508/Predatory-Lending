import { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { describe, expect, it } from 'vitest';
import Home from '@/app/lab/page';

describe('Aegis modeling workbench', () => {
  it('shows only the public-data and synthetic-simulation phases', () => {
    const page = renderToStaticMarkup(createElement(Home));

    expect(page).toContain('Phase 1');
    expect(page).toContain('Baseline macro models');
    expect(page).toContain('CFPB complaint context');
    expect(page).toContain('Official historical narrative archive');
    expect(page).toContain('aggregate phrase counts only');
    expect(page).toContain('LendingClub');
    expect(page).toContain('Home Credit');
    expect(page).toContain('FICO');
    expect(page).toContain('Statlog German Credit');
    expect(page).toContain('Phase 2');
    expect(page).toContain('Synthetic ecosystem');
    expect(page).toContain('Gig worker');
    expect(page).toContain('Student');
    expect(page).toContain('Low-income family');
    expect(page).toContain('GAN');
    expect(page).toContain('diffusion');
    expect(page).toContain('public data + fictional scenarios');
    expect(page).toContain('Run public data benchmark');
    expect(page).not.toContain('Check an offer');
  });
});
