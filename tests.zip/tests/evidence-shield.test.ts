import { describe, expect, it } from 'vitest';
import { assessEvidenceShield, type ShieldResearch } from '../src/domain/evidence-shield';

const research: ShieldResearch = {
  baseline: { totalRows: 100_000, coefficients: { debtToIncome: 0.35 } },
  complaints: { rowsUsed: 74_525, topIssues: [
    { name: "Charged fees or interest you didn't expect", count: 16_545 },
    { name: 'Problem when making payments', count: 9_309 },
  ] },
  archivedLoanComplaints: { rowsUsed: 1_793, narrativesWithText: 410,
    signals: { feePressure: 120, paymentDifficulty: 21, cashShortfall: 20 },
    sourceUrl: 'https://www.consumerfinance.gov/foia-requests/foia-electronic-reading-room/cfpb-consumer-complaint-database-narratives-archive/',
  },
};

describe('evidence-linked shield', () => {
  it('uses public aggregates to explain a personal fee review without labeling the lender', () => {
    const alerts = assessEvidenceShield({ dollarCost: 75, shortfall: false, offerText: '', hasDebtBills: true }, research);
    expect(alerts).toContainEqual(expect.objectContaining({
      id: 'fee-review', pause: false,
      detail: expect.stringContaining('120 of 410'),
    }));
    expect(alerts.some(alert => /scam|predatory lender/i.test(alert.title))).toBe(false);
  });

  it('pauses for a cash shortfall or concerning text, while allowing an ordinary cost review', () => {
    const ordinary = assessEvidenceShield({ dollarCost: 75, shortfall: false, offerText: '', hasDebtBills: true }, research);
    expect(ordinary.some(alert => alert.pause)).toBe(false);
    const shortfall = assessEvidenceShield({ dollarCost: 75, shortfall: true, offerText: '', hasDebtBills: true }, research);
    expect(shortfall.find(alert => alert.id === 'payment-shortfall')).toMatchObject({ pause: true });
    const upfront = assessEvidenceShield({ dollarCost: 75, shortfall: false,
      offerText: 'Pay an upfront fee before funds are released.', hasDebtBills: true }, research);
    expect(upfront.find(alert => alert.id === 'upfront-payment')).toMatchObject({ pause: true });
  });

  it('uses a model association only to request missing debt bills, never to score the member', () => {
    const alerts = assessEvidenceShield({ dollarCost: 0, shortfall: false, offerText: '', hasDebtBills: false }, research);
    expect(alerts).toEqual([expect.objectContaining({ id: 'debt-bills', pause: false })]);
    expect(assessEvidenceShield({ dollarCost: 0, shortfall: false, offerText: '', hasDebtBills: false }, null)).toEqual([]);
  });

  it('keeps a missing-repayment pause when public reports are temporarily unavailable', () => {
    const alerts = assessEvidenceShield({ dollarCost: 75, shortfall: false,
      offerText: 'Apply now for a cash advance.', hasDebtBills: true }, null);
    expect(alerts).toContainEqual(expect.objectContaining({ id: 'missing-terms', pause: true }));
  });
});
