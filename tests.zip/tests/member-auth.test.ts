import { describe, expect, it } from 'vitest';

const auth = await import('../src/server/member-auth').catch(() => undefined);

const validRequest = (headers: Record<string, string> = {}) => new Request('https://aegis.test/api/member', {
  headers: { authorization: 'Bearer signed-access-token', 'x-aegis-tenant-id': '00000000-0000-4000-8000-000000000001', ...headers },
});

describe('member request identity', () => {
  it('requires a bearer access token and tenant identifier', async () => {
    expect(auth, 'member auth module should exist').toBeDefined();
    const verify = async () => ({ sub: '00000000-0000-4000-8000-000000000011' });
    await expect(auth!.resolveMemberIdentity(new Request('https://aegis.test'), verify)).rejects.toThrow('Authentication required');
    await expect(auth!.resolveMemberIdentity(validRequest({ 'x-aegis-tenant-id': '' }), verify)).rejects.toThrow('Tenant identifier required');
  });

  it('uses verified subject and requested tenant as database identity', async () => {
    expect(auth, 'member auth module should exist').toBeDefined();
    const identity = await auth!.resolveMemberIdentity(validRequest(), async token => {
      expect(token).toBe('signed-access-token');
      return { sub: '00000000-0000-4000-8000-000000000011' };
    });
    expect(identity).toEqual({ tenantId: '00000000-0000-4000-8000-000000000001', userId: '00000000-0000-4000-8000-000000000011' });
  });

  it('supports HttpOnly cookie sessions and requires same-origin writes for those sessions', async () => {
    expect(auth, 'member auth module should exist').toBeDefined();
    const request = new Request('https://aegis.test/api/member', {
      headers: { cookie: 'aegis_session=signed-access-token', 'x-aegis-tenant-id': '00000000-0000-4000-8000-000000000001' },
    });
    await expect(auth!.resolveMemberIdentity(request, async token => {
      expect(token).toBe('signed-access-token');
      return { sub: '00000000-0000-4000-8000-000000000011' };
    })).resolves.toMatchObject({ userId: '00000000-0000-4000-8000-000000000011' });
    expect(auth!.hasSafeMutationOrigin(new Request('https://aegis.test/api/member', { method: 'POST', headers: { cookie: 'aegis_session=token', origin: 'https://aegis.test' } }))).toBe(true);
    expect(auth!.hasSafeMutationOrigin(new Request('https://aegis.test/api/member', { method: 'POST', headers: { cookie: 'aegis_session=token', origin: 'https://evil.test' } }))).toBe(false);
  });

  it('accepts the public host when Next is bound to 0.0.0.0', () => {
    const request = new Request('http://0.0.0.0:3000/api/auth/login', {
      method: 'POST',
      headers: { host: 'localhost:3000', origin: 'http://localhost:3000', 'content-type': 'application/json' },
    });
    expect(auth!.hasSameOriginRequest(request)).toBe(true);
    expect(auth!.hasSameOriginRequest(new Request('http://0.0.0.0:3000/api/auth/login', {
      method: 'POST', headers: { host: 'localhost:3000', origin: 'http://attacker.test' },
    }))).toBe(false);
  });

  it('rejects invalid signatures, non-UUID subjects, and malformed tenant identifiers', async () => {
    expect(auth, 'member auth module should exist').toBeDefined();
    await expect(auth!.resolveMemberIdentity(validRequest(), async () => { throw new Error('signature invalid'); })).rejects.toThrow('Authentication failed');
    await expect(auth!.resolveMemberIdentity(validRequest(), async () => ({ sub: 'not-a-uuid' }))).rejects.toThrow('Authentication failed');
    await expect(auth!.resolveMemberIdentity(validRequest({ 'x-aegis-tenant-id': 'not-a-uuid' }), async () => ({ sub: '00000000-0000-4000-8000-000000000011' }))).rejects.toThrow('Tenant identifier required');
  });
});
