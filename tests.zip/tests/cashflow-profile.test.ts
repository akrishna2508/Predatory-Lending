import { describe, expect, it } from 'vitest';
import { hasCashflowProfileStorageConsent, validateCashflowProfile } from '@/server/cashflow-profile';

const validProfile = {
  asOfDate: '2026-09-26',
  startingBalance: 840,
  events: [
    { id: 'event-1', date: '2026-09-28', label: 'Electric bill', amount: 128, kind: 'bill' as const, source: 'member_entered' as const },
    { id: 'event-2', date: '2026-10-03', label: 'Paycheck', amount: 1240, kind: 'income' as const, source: 'transaction_suggestion' as const },
  ],
};

describe('cash-flow profile validation', () => {
  it('accepts a member-reviewed profile and preserves the source of each item', () => {
    expect(validateCashflowProfile(validProfile, '2026-09-26')).toEqual({ valid: true, profile: validProfile });
  });

  it('rejects future or impossible balance dates', () => {
    expect(validateCashflowProfile({ ...validProfile, asOfDate: '2026-09-27' }, '2026-09-26')).toMatchObject({ valid: false });
    expect(validateCashflowProfile({ ...validProfile, asOfDate: '2026-02-30' }, '2026-09-26')).toMatchObject({ valid: false });
  });

  it('rejects events outside the 30-day window and invalid amounts', () => {
    expect(validateCashflowProfile({ ...validProfile, events: [{ ...validProfile.events[0], date: '2026-10-26' }] }, '2026-09-26')).toMatchObject({ valid: false });
    expect(validateCashflowProfile({ ...validProfile, events: [{ ...validProfile.events[0], amount: -1 }] }, '2026-09-26')).toMatchObject({ valid: false });
  });

  it('requires both calculation-use and profile-storage consent to be active', () => {
    expect(hasCashflowProfileStorageConsent([
      { purpose: 'manual_financial_profile', action: 'granted' },
      { purpose: 'cashflow_profile_storage', action: 'granted' },
    ])).toBe(true);
    expect(hasCashflowProfileStorageConsent([{ purpose: 'cashflow_profile_storage', action: 'granted' }])).toBe(false);
    expect(hasCashflowProfileStorageConsent([
      { purpose: 'manual_financial_profile', action: 'granted' },
      { purpose: 'cashflow_profile_storage', action: 'revoked' },
    ])).toBe(false);
  });
});
