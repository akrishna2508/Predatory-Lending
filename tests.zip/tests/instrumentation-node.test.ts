import { afterEach, expect, it, vi } from 'vitest';

const scheduler = vi.hoisted(() => ({ startRetentionScheduler: vi.fn() }));
vi.mock('../src/server/retention-scheduler', () => scheduler);

import { startNodeRuntime } from '../src/instrumentation.node';

const previousDatabaseUrl = process.env.DATABASE_URL;

afterEach(() => {
  if (previousDatabaseUrl === undefined) delete process.env.DATABASE_URL;
  else process.env.DATABASE_URL = previousDatabaseUrl;
  scheduler.startRetentionScheduler.mockClear();
});

it('starts the retention scheduler when the Node runtime has a database', () => {
  process.env.DATABASE_URL = 'postgresql://aegis_runtime@localhost/aegis';
  startNodeRuntime();
  expect(scheduler.startRetentionScheduler).toHaveBeenCalledTimes(1);
});

it('skips database maintenance when no database is configured', () => {
  delete process.env.DATABASE_URL;
  startNodeRuntime();
  expect(scheduler.startRetentionScheduler).not.toHaveBeenCalled();
});
