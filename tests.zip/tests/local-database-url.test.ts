import { describe, expect, it } from 'vitest';

const databaseUrl = await import('../scripts/local-database-url.mjs').catch(() => undefined);

describe('local PostgreSQL maintenance URL guard', () => {
  it('accepts loopback and Unix-socket database URLs and reports the database name', () => {
    expect(databaseUrl).toBeDefined();
    expect(databaseUrl!.parseLocalDatabaseUrl('postgresql://admin@localhost:5432/aegis', 'AEGIS_BACKUP_DATABASE_URL'))
      .toMatchObject({ databaseName: 'aegis' });
    expect(databaseUrl!.parseLocalDatabaseUrl('postgresql:///aegis_restore?host=%2Ftmp', 'AEGIS_RESTORE_DATABASE_URL'))
      .toMatchObject({ databaseName: 'aegis_restore' });
  });

  it('rejects remote hosts, credentials embedded in the URL, and conflicting host overrides', () => {
    expect(databaseUrl).toBeDefined();
    for (const value of [
      'postgresql://admin@db.example.org:5432/aegis',
      'postgresql://admin:secret@localhost:5432/aegis',
      'postgresql://admin@localhost:5432/aegis?password=secret',
      'postgresql://admin@localhost:5432/aegis?host=db.example.org',
    ]) {
      expect(() => databaseUrl!.parseLocalDatabaseUrl(value, 'AEGIS_BACKUP_DATABASE_URL')).toThrow();
    }
  });

  it('requires an exact target database confirmation', () => {
    expect(databaseUrl).toBeDefined();
    expect(() => databaseUrl!.assertRestoreConfirmation('aegis_restore', 'aegis')).toThrow();
    expect(() => databaseUrl!.assertRestoreConfirmation('aegis_restore', 'aegis_restore')).not.toThrow();
  });
});
