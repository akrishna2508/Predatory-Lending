import { describe, expect, it } from 'vitest';
import { findShieldSignals } from '@/domain/transaction-shield';

describe('opted-in transaction shield', () => {
  it('flags variable income-like deposits while keeping the evidence descriptive', () => {
    const signals = findShieldSignals([
      { date: '2026-09-01', description: 'Gig income', amount: 500 },
      { date: '2026-09-15', description: 'Gig income', amount: 190 },
      { date: '2026-09-29', description: 'Gig income', amount: 440 },
    ], '2026-09-29');
    expect(signals).toContainEqual(expect.objectContaining({
      id: 'variable_income', evidenceCount: 3, mostRecentDate: '2026-09-29',
    }));
    expect(signals[0].summary).toContain('transaction labels may be incomplete');
  });

  it('does not treat arbitrary incoming transfers or one-day duplicates as income instability', () => {
    const signals = findShieldSignals([
      { date: '2026-09-01', description: 'Transfer from savings', amount: 500 },
      { date: '2026-09-15', description: 'Transfer from savings', amount: 190 },
      { date: '2026-09-29', description: 'Transfer from savings', amount: 440 },
      { date: '2026-09-29', description: 'Payroll', amount: 500 },
      { date: '2026-09-29', description: 'Payroll', amount: 190 },
      { date: '2026-09-29', description: 'Payroll', amount: 440 },
    ], '2026-09-29');
    expect(signals.some(signal => signal.id === 'variable_income')).toBe(false);
  });
});
