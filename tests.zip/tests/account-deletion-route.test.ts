import { beforeEach, describe, expect, it, vi } from 'vitest';

const testState = vi.hoisted(() => ({
  events: [] as string[],
  providerStatus: 'provider_pending',
  accountStatus: 'active',
}));

vi.mock('@/server/member-auth', () => ({
  MemberAuthError: class MemberAuthError extends Error {},
  resolveMemberSubject: async () => '00000000-0000-4000-8000-000000000011',
  hasSafeMutationOrigin: () => true,
}));

vi.mock('@/server/database', () => ({
  getDatabasePool: () => ({}),
  withIdentityTransaction: async (_pool: unknown, _userId: string, operation: (client: unknown) => Promise<unknown>) =>
    operation({
      query: async (sql: string) => {
        if (sql.includes('aegis_begin_member_account_deletion')) {
          testState.events.push('begin');
          return { rows: [{ provider_status: testState.providerStatus }] };
        }
        if (sql.includes('aegis_mark_member_identity_deleted')) {
          testState.events.push('mark-provider-deleted');
          return { rows: [] };
        }
        if (sql.includes('aegis_finalize_member_account_deletion')) {
          testState.events.push('finalize');
          return { rows: [] };
        }
        if (sql.includes('SELECT status FROM app_users')) {
          return { rows: [{ status: testState.accountStatus }] };
        }
        throw new Error(`Unexpected SQL: ${sql}`);
      },
    }),
}));

const accountRoute = await import('../src/app/api/member/account/route');

describe('member account deletion workflow', () => {
  beforeEach(() => {
    testState.events = [];
    testState.providerStatus = 'provider_pending';
    testState.accountStatus = 'active';
  });

  it('erases member data, retires local credentials, then finalizes the local identity', async () => {
    const response = await accountRoute.DELETE(new Request('https://aegis.test/api/member/account', { method: 'DELETE' }));

    expect(response.status).toBe(200);
    expect(testState.events).toEqual(['begin', 'mark-provider-deleted', 'finalize']);
  });

  it('finalizes a retry after local sign-in deletion was recorded', async () => {
    testState.providerStatus = 'identity_deleted';
    const response = await accountRoute.DELETE(new Request('https://aegis.test/api/member/account', { method: 'DELETE' }));

    expect(response.status).toBe(200);
    expect(testState.events).toEqual(['begin', 'finalize']);
  });

  it('reports pending deletion for the member recovery screen', async () => {
    testState.accountStatus = 'deletion_pending';
    const response = await accountRoute.GET(new Request('https://aegis.test/api/member/account'));

    expect(response.status).toBe(200);
    expect(await response.json()).toEqual({ deletionPending: true });
  });
});
