import { beforeEach, describe, expect, it, vi } from 'vitest';

const mocks = vi.hoisted(() => ({
  identity: { tenantId: '00000000-0000-4000-8000-000000000001', userId: '00000000-0000-4000-8000-000000000011' },
  consents: [] as Array<{ purpose: string; action: string }>,
  query: vi.fn(),
  resolveIdentity: vi.fn(),
  safeOrigin: vi.fn(),
}));

vi.mock('@/server/member-auth', () => ({
  MemberAuthError: class MemberAuthError extends Error {},
  resolveMemberIdentity: mocks.resolveIdentity,
  hasSafeMutationOrigin: mocks.safeOrigin,
}));

vi.mock('@/server/database', () => ({
  getDatabasePool: () => ({}),
  withMemberTransaction: async (_pool: unknown, _identity: unknown, operation: (client: { query: typeof mocks.query }) => Promise<unknown>) => operation({ query: mocks.query }),
}));

const route = await import('@/app/api/member/cashflow-profile/route');

function dateOffset(offset: number) {
  const date = new Date();
  date.setUTCDate(date.getUTCDate() + offset);
  return date.toISOString().slice(0, 10);
}

const profileInput = {
  asOfDate: dateOffset(0),
  startingBalance: 840,
  events: [{ id: 'bill-1', date: dateOffset(2), label: 'Electric bill', amount: 128, kind: 'bill', source: 'member_entered' }],
};

function request(method: string, body?: unknown, origin = 'https://aegis.test') {
  return new Request('https://aegis.test/api/member/cashflow-profile', {
    method,
    headers: {
      'x-aegis-tenant-id': mocks.identity.tenantId,
      ...(body === undefined ? {} : { 'content-type': 'application/json' }),
      ...(origin ? { origin } : {}),
    },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
  });
}

describe('member cash-flow profile API', () => {
  beforeEach(() => {
    mocks.consents = [];
    mocks.resolveIdentity.mockReset().mockResolvedValue(mocks.identity);
    mocks.safeOrigin.mockReset().mockReturnValue(true);
    mocks.query.mockReset().mockImplementation(async (sql: string) => {
      if (sql.includes('SELECT DISTINCT ON (purpose)')) return { rows: mocks.consents };
      if (sql.includes('INSERT INTO member_cashflow_profiles')) return { rows: [{
        id: '00000000-0000-4000-8000-000000000019',
        as_of_date: profileInput.asOfDate,
        starting_balance: '840.00',
        events: profileInput.events,
        created_at: '2026-09-26T00:00:00.000Z',
        updated_at: '2026-09-26T00:00:00.000Z',
        expires_at: '2026-10-26T00:00:00.000Z',
      }] };
      if (sql.includes('DELETE FROM member_cashflow_profiles')) return { rows: [{ id: '00000000-0000-4000-8000-000000000019' }] };
      return { rows: [] };
    });
  });

  it('requires both grants before reading or storing the profile', async () => {
    const getResponse = await route.GET(request('GET'));
    const putResponse = await route.PUT(request('PUT', profileInput));

    expect(getResponse.status).toBe(403);
    expect(putResponse.status).toBe(403);
    expect(mocks.query.mock.calls.some(([sql]) => String(sql).includes('INSERT INTO member_cashflow_profiles'))).toBe(false);
  });

  it('stores only a validated member-confirmed picture and returns its expiry', async () => {
    mocks.consents = [
      { purpose: 'manual_financial_profile', action: 'granted' },
      { purpose: 'cashflow_profile_storage', action: 'granted' },
    ];
    const response = await route.PUT(request('PUT', profileInput));
    const body = await response.json();

    expect(response.status).toBe(200);
    expect(response.headers.get('cache-control')).toContain('no-store');
    expect(body.profile).toMatchObject({ as_of_date: profileInput.asOfDate, starting_balance: 840, events: profileInput.events });
    const insert = mocks.query.mock.calls.find(([sql]) => String(sql).includes('INSERT INTO member_cashflow_profiles'));
    expect(insert?.[1]).toContain(mocks.identity.tenantId);
    expect(insert?.[1]).toContain(mocks.identity.userId);
    expect(JSON.parse(String(insert?.[1]?.[4]))).toEqual(profileInput.events);
    expect(mocks.query.mock.calls.some(([sql]) => String(sql).includes('member.cashflow_profile_saved'))).toBe(true);
  });

  it('rejects cross-origin writes before checking identity or reading the body', async () => {
    mocks.safeOrigin.mockReturnValue(false);
    const response = await route.PUT(request('PUT', profileInput, 'https://attacker.test'));

    expect(response.status).toBe(403);
    expect(mocks.resolveIdentity).not.toHaveBeenCalled();
    expect(mocks.query).not.toHaveBeenCalled();
  });

  it('allows an authenticated member to delete the saved profile without storage consent', async () => {
    const response = await route.DELETE(request('DELETE'));

    expect(response.status).toBe(200);
    expect(await response.json()).toEqual({ deleted: true });
    expect(mocks.query.mock.calls.some(([sql]) => String(sql).includes('DELETE FROM member_cashflow_profiles'))).toBe(true);
  });
});
