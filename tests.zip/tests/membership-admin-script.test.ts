import { spawnSync } from 'node:child_process';
import { describe, expect, it } from 'vitest';
import { fileURLToPath } from 'node:url';

const script = fileURLToPath(new URL('../scripts/change-membership.mjs', import.meta.url));

describe('operator membership administration command', () => {
  it('rejects missing identifiers without contacting AWS or PostgreSQL', () => {
    const result = spawnSync(process.execPath, [script], { encoding: 'utf8' });
    expect(result.status).toBe(2);
    expect(result.stderr).toContain('Usage: npm run membership:update');
  });

  it('rejects roles outside the supported member and partner access model', () => {
    const result = spawnSync(process.execPath, [
      script,
      '00000000-0000-4000-8000-000000000001',
      '00000000-0000-4000-8000-000000000011',
      'underwriter',
      'active',
    ], { encoding: 'utf8' });
    expect(result.status).toBe(2);
    expect(result.stderr).toContain('Usage: npm run membership:update');
  });
});
