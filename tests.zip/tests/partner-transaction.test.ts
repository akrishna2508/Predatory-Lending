import { describe, expect, it } from 'vitest';

const database = await import('../src/server/database').catch(() => undefined);

function fakePool(membershipRows: Array<{ role: string }> = [{ role: 'partner_analyst' }]) {
  const statements: Array<{ sql: string; values?: unknown[] }> = [];
  let released = false;
  const pool = { async connect() { return {
    async query(sql: string, values?: unknown[]) {
      statements.push({ sql, values });
      if (sql.includes('FROM memberships')) {
        const partnerRows = membershipRows.filter(row => ['partner_admin', 'partner_analyst'].includes(row.role));
        return { rows: sql.includes("m.role IN ('partner_admin', 'partner_analyst')") ? partnerRows : membershipRows };
      }
      if (sql.includes('aegis_partner_usage_summary')) return { rows: [{ month: '2026-09-01', participating_members: 20, saved_checks: 23 }] };
      return { rows: [] };
    }, release() { released = true; },
  }; } };
  return { pool, statements, released: () => released };
}

const identity = { tenantId: '00000000-0000-4000-8000-000000000001', userId: '00000000-0000-4000-8000-000000000014' };

describe('partner reporting transaction boundary', () => {
  it('allows an active partner analyst to read aggregate function output only', async () => {
    expect(database, 'database module should exist').toBeDefined();
    const { pool, statements, released } = fakePool();
    const result = await database!.withPartnerTransaction(pool, identity, async client => {
      return client.query('SELECT * FROM aegis_partner_usage_summary()');
    });
    expect(result.rows).toEqual([{ month: '2026-09-01', participating_members: 20, saved_checks: 23 }]);
    expect(statements.map(item => item.sql)).toContain('SET LOCAL ROLE aegis_runtime');
    expect(statements.at(-1)?.sql).toBe('COMMIT');
    expect(released()).toBe(true);
  });

  it('rejects a member before the reporting operation runs', async () => {
    expect(database, 'database module should exist').toBeDefined();
    const { pool, statements, released } = fakePool([{ role: 'member' }]);
    let ran = false;
    await expect(database!.withPartnerTransaction(pool, identity, async () => { ran = true; })).rejects.toThrow('Partner membership required');
    expect(ran).toBe(false);
    expect(statements.at(-1)?.sql).toBe('ROLLBACK');
    expect(released()).toBe(true);
  });
});
