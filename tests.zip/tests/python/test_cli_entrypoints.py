import subprocess
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]


class PythonCliEntrypointTests(unittest.TestCase):
    def test_local_python_commands_start_when_invoked_by_file_path(self):
        for relative_path in (
            "scripts/train_baseline.py",
            "scripts/analyze_cfpb.py",
            "scripts/run_simulation.py",
        ):
            with self.subTest(command=relative_path):
                result = subprocess.run(
                    [sys.executable, relative_path, "--help"],
                    cwd=str(ROOT),
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    universal_newlines=True,
                    timeout=10,
                )
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertIn("usage:", result.stdout.lower())


if __name__ == "__main__":
    unittest.main()
