import csv
import tempfile
import unittest
from pathlib import Path

from scripts.run_simulation import run


class SimulationCommandTests(unittest.TestCase):
    def test_generator_command_writes_only_bounded_synthetic_rows(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            output_path = Path(temp_dir) / "synthetic.csv"
            result = run("student", trials=40, seed=22, engine="diffusion", samples=12, synthetic_output=output_path)
            with output_path.open("r", newline="", encoding="utf-8") as stream:
                rows = list(csv.DictReader(stream))

        self.assertEqual(len(rows), 12)
        self.assertEqual(result["generator"]["rows_generated"], 12)
        self.assertEqual(result["generator"]["provenance"], "experimental_synthetic")
        self.assertTrue(all(row["provenance"] == "experimental_synthetic" for row in rows))
        self.assertNotIn("synthetic_impulse", result)
        self.assertIn("scenario_only", result["caveat"])


if __name__ == "__main__":
    unittest.main()
