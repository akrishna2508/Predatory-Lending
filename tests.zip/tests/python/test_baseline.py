import unittest

from scripts.aegis_models.baseline import ModelTrainingError, fit_logistic_baseline


def separable_rows(count=120):
    rows = []
    for index in range(count):
        label = index % 2
        rows.append({
            "features": {
                "debt_to_income": (24.0 if label else 3.0) + (index % 5) / 20,
                "annual_income": (28000.0 if label else 64000.0) + index * 3,
            },
            "label": label,
        })
    return rows


class BaselineModelTests(unittest.TestCase):
    def test_fit_is_deterministic_and_reports_holdout_metrics_and_named_coefficients(self):
        first = fit_logistic_baseline(separable_rows(), ["debt_to_income", "annual_income"], seed=17, steps=300)
        second = fit_logistic_baseline(separable_rows(), ["debt_to_income", "annual_income"], seed=17, steps=300)

        self.assertEqual(first, second)
        self.assertEqual(first["train_rows"], 96)
        self.assertEqual(first["test_rows"], 24)
        self.assertGreater(first["metrics"]["roc_auc"], 0.95)
        self.assertLess(first["metrics"]["brier_score"], 0.15)
        self.assertEqual(set(first["coefficients"]), {"debt_to_income", "annual_income"})

    def test_training_refuses_data_without_both_outcome_classes(self):
        rows = [{"features": {"debt_to_income": float(index)}, "label": 0} for index in range(20)]

        with self.assertRaisesRegex(ModelTrainingError, "both outcome classes"):
            fit_logistic_baseline(rows, ["debt_to_income"])

    def test_training_rejects_non_finite_features(self):
        rows = separable_rows()
        rows[0]["features"]["debt_to_income"] = float("nan")

        with self.assertRaisesRegex(ModelTrainingError, "finite"):
            fit_logistic_baseline(rows, ["debt_to_income", "annual_income"])


if __name__ == "__main__":
    unittest.main()
