import csv
import tempfile
import unittest
from pathlib import Path

from scripts.analyze_cfpb import build_complaint_report


class CFPBCommandTests(unittest.TestCase):
    def test_build_complaint_report_returns_aggregate_only(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "complaints.csv"
            with path.open("w", newline="", encoding="utf-8") as stream:
                writer = csv.DictWriter(stream, fieldnames=["Date received", "Product", "Issue", "Company", "Consumer complaint narrative"])
                writer.writeheader()
                writer.writerow({"Date received": "2026-02-01", "Product": "Payday loan", "Issue": "Fees", "Company": "Lender", "Consumer complaint narrative": "secret narrative"})
            result = build_complaint_report(path)

        self.assertEqual(result["rows_used"], 1)
        self.assertNotIn("secret narrative", str(result))
        self.assertFalse(result["narrative_text_included"])


if __name__ == "__main__":
    unittest.main()
