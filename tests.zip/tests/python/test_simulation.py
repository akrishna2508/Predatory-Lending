import unittest

from scripts.aegis_models.simulation import (
    PROFILE_TYPES,
    generate_profile,
    generate_training_rows,
    loan_temptation,
    run_monte_carlo,
    simulate_agent,
)


class SyntheticSimulationTests(unittest.TestCase):
    def test_supported_profiles_have_bounded_synthetic_traits_and_ordered_cash_events(self):
        import random

        for profile_type in PROFILE_TYPES:
            profile = generate_profile(profile_type, random.Random(9))
            self.assertTrue(0 <= profile["synthetic_impulse"] <= 1)
            self.assertTrue(0 <= profile["synthetic_stress_sensitivity"] <= 1)
            self.assertEqual(profile["provenance"], "synthetic")
            event_days = [event["day"] for event in profile["events"]]
            self.assertEqual(event_days, sorted(event_days))

    def test_temptation_increases_with_cash_pressure_and_synthetic_traits(self):
        low = loan_temptation(shortfall=0, days_until_payday=1, fee_ratio=0.1, impulse=0.1, stress=0.1)
        high = loan_temptation(shortfall=700, days_until_payday=12, fee_ratio=0.5, impulse=0.9, stress=0.9)

        self.assertGreater(high, low)
        self.assertGreaterEqual(low, 0)
        self.assertLessEqual(high, 1)

    def test_payday_trigger_uses_the_actual_schedule_instead_of_day_30_fallback(self):
        class AcceptFirstOffer:
            @staticmethod
            def random():
                return 0.0

        student = {
            "profile_type": "student",
            "starting_balance": 1000.0,
            "events": [],
            "payday_days": [5, 19],
            "decision_day": 20,
            "offer_principal": 300.0,
            "fee_ratio": 0.2,
            "synthetic_impulse": 0.5,
            "synthetic_stress_sensitivity": 0.5,
        }
        gig_worker = {
            **student,
            "profile_type": "gig-worker",
            "payday_days": [2, 9, 16, 23, 30],
            "decision_day": 25,
        }

        after_last_student_payday = simulate_agent(student, AcceptFirstOffer())
        before_gig_worker_payday = simulate_agent(gig_worker, AcceptFirstOffer())

        self.assertEqual(after_last_student_payday["income_wait_days"], 15)
        self.assertFalse(after_last_student_payday["payday_captured"])
        self.assertEqual(before_gig_worker_payday["income_wait_days"], 5)
        self.assertTrue(before_gig_worker_payday["payday_captured"])

    def test_monte_carlo_is_reproducible_and_reports_aggregates_only(self):
        first = run_monte_carlo("gig-worker", trials=150, seed=81)
        second = run_monte_carlo("gig-worker", trials=150, seed=81)

        self.assertEqual(first, second)
        self.assertEqual(first["trials"], 150)
        self.assertGreaterEqual(first["metrics"]["acceptance_rate"], 0)
        self.assertLessEqual(first["metrics"]["acceptance_rate"], 1)
        self.assertIn("scenario_only", first["caveat"])
        self.assertNotIn("synthetic_impulse", first)
        self.assertNotIn("records", first)

    def test_training_rows_are_finite_numeric_and_reproducible(self):
        first = generate_training_rows("student", count=20, seed=4)
        second = generate_training_rows("student", count=20, seed=4)

        self.assertEqual(first, second)
        self.assertEqual(len(first), 20)
        self.assertEqual(len(first[0]), 5)
        self.assertTrue(all(isinstance(value, (float, int)) for row in first for value in row))

    def test_unknown_profile_and_invalid_trial_counts_fail_clearly(self):
        with self.assertRaisesRegex(ValueError, "unsupported profile"):
            run_monte_carlo("underwriter", trials=10, seed=1)
        with self.assertRaisesRegex(ValueError, "trials must be"):
            run_monte_carlo("student", trials=0, seed=1)


if __name__ == "__main__":
    unittest.main()
