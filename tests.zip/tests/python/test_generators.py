import unittest

import numpy as np

from scripts.aegis_models.generators import (
    sample_diffusion,
    sample_gan,
    train_diffusion,
    train_gan,
)


def synthetic_rows(seed=8, count=120):
    rng = np.random.default_rng(seed)
    pressure = rng.random(count)
    return np.column_stack([
        rng.uniform(0, 1, count),
        rng.uniform(0, 1, count),
        pressure,
        np.clip(0.2 + pressure * 0.7 + rng.normal(0, 0.08, count), 0, 1),
        np.clip(0.1 + pressure * 0.8 + rng.normal(0, 0.1, count), 0, 1),
    ])


class SyntheticTabularGeneratorTests(unittest.TestCase):
    def test_gan_samples_are_repeatable_finite_and_bounded(self):
        data = synthetic_rows()
        first_model = train_gan(data, seed=2, steps=60)
        second_model = train_gan(data, seed=2, steps=60)
        first = sample_gan(first_model, count=24, seed=3)
        second = sample_gan(second_model, count=24, seed=3)

        np.testing.assert_array_equal(first, second)
        self.assertEqual(first.shape, (24, 5))
        self.assertTrue(np.isfinite(first).all())
        self.assertTrue(np.all(first >= data.min(axis=0) - 1e-9))
        self.assertTrue(np.all(first <= data.max(axis=0) + 1e-9))

    def test_diffusion_samples_are_repeatable_finite_and_bounded(self):
        data = synthetic_rows()
        first_model = train_diffusion(data, seed=5, steps=120, timesteps=8)
        second_model = train_diffusion(data, seed=5, steps=120, timesteps=8)
        first = sample_diffusion(first_model, count=24, seed=6)
        second = sample_diffusion(second_model, count=24, seed=6)

        np.testing.assert_array_equal(first, second)
        self.assertEqual(first.shape, (24, 5))
        self.assertTrue(np.isfinite(first).all())
        self.assertTrue(np.all(first >= data.min(axis=0) - 1e-9))
        self.assertTrue(np.all(first <= data.max(axis=0) + 1e-9))

    def test_generators_reject_bad_shapes_and_non_finite_values(self):
        with self.assertRaisesRegex(ValueError, "at least two numeric rows"):
            train_gan([[1.0, 2.0]])
        bad = synthetic_rows()
        bad[0, 0] = np.nan
        with self.assertRaisesRegex(ValueError, "finite"):
            train_diffusion(bad)


if __name__ == "__main__":
    unittest.main()
