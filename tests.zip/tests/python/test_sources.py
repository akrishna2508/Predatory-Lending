import csv
import tempfile
import unittest
from pathlib import Path

from scripts.aegis_models.sources import SOURCE_CATALOG, SourceDataError, iter_canonical_rows


class SourceAdapterTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)

    def write_csv(self, name, fieldnames, rows):
        path = self.root / name
        with path.open("w", newline="", encoding="utf-8") as output:
            writer = csv.DictWriter(output, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(rows)
        return path

    def test_statlog_maps_numeric_fields_and_marks_bad_credit_positive(self):
        path = self.root / "german.data"
        path.write_text(
            "A11 6 A34 A43 1169 A65 A75 4 A93 A101 4 A121 67 A143 A152 2 A173 1 A191 A201 1\n"
            "A12 12 A32 A46 5951 A61 A73 2 A92 A101 3 A123 22 A143 A152 1 A173 1 A191 A201 2\n",
            encoding="utf-8",
        )

        rows = list(iter_canonical_rows(path, "statlog-german"))

        self.assertEqual(rows[0]["features"], {
            "duration_months": 6.0,
            "credit_amount": 1169.0,
            "installment_rate": 4.0,
            "age_years": 67.0,
            "existing_credits": 2.0,
        })
        self.assertEqual([row["label"] for row in rows], [0, 1])

    def test_lendingclub_normalizes_known_columns_and_skips_unresolved_status(self):
        path = self.write_csv("lc.csv", ["loan_amnt", "annual_inc", "dti", "installment", "revol_bal", "revol_util", "loan_status"], [
            {"loan_amnt": "1000", "annual_inc": "24000", "dti": "12.5", "installment": "88", "revol_bal": "200", "revol_util": "40", "loan_status": "Charged Off"},
            {"loan_amnt": "500", "annual_inc": "30000", "dti": "4", "installment": "40", "revol_bal": "0", "revol_util": "0", "loan_status": "Current"},
        ])

        rows = list(iter_canonical_rows(path, "lendingclub"))

        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["label"], 1)
        self.assertEqual(rows[0]["features"]["debt_to_income"], 12.5)
        self.assertEqual(rows[0]["features"]["annual_income"], 24000.0)

    def test_lendingclub_numeric_adaptation_maps_default_to_adverse_label(self):
        path = self.write_csv("lc_numeric.csv", ["loan_amnt", "annual_inc", "dti", "installment", "revol_bal", "revol_util", "loan_status"], [
            {"loan_amnt": "1000", "annual_inc": "24000", "dti": "12.5", "installment": "88", "revol_bal": "200", "revol_util": "40", "loan_status": "0"},
            {"loan_amnt": "500", "annual_inc": "30000", "dti": "4", "installment": "40", "revol_bal": "0", "revol_util": "0", "loan_status": "1"},
        ])

        rows = list(iter_canonical_rows(path, "lendingclub"))

        self.assertEqual([row["label"] for row in rows], [1, 0])

    def test_lendingclub_skips_rows_with_missing_numeric_features(self):
        path = self.write_csv("lc.csv", ["loan_amnt", "annual_inc", "dti", "installment", "revol_bal", "revol_util", "loan_status"], [
            {"loan_amnt": "1000", "annual_inc": "24000", "dti": "12", "installment": "88", "revol_bal": "200", "revol_util": "40%", "loan_status": "Charged Off"},
            {"loan_amnt": "900", "annual_inc": "", "dti": "10", "installment": "78", "revol_bal": "100", "revol_util": "20%", "loan_status": "Fully Paid"},
        ])

        rows = list(iter_canonical_rows(path, "lendingclub"))

        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["label"], 1)

    def test_home_credit_maps_target_and_financial_columns(self):
        path = self.write_csv("home.csv", ["AMT_INCOME_TOTAL", "AMT_CREDIT", "AMT_ANNUITY", "AMT_GOODS_PRICE", "DAYS_EMPLOYED", "TARGET"], [
            {"AMT_INCOME_TOTAL": "36000", "AMT_CREDIT": "12000", "AMT_ANNUITY": "500", "AMT_GOODS_PRICE": "10000", "DAYS_EMPLOYED": "-3650", "TARGET": "1"},
        ])

        rows = list(iter_canonical_rows(path, "home-credit"))

        self.assertEqual(rows[0]["label"], 1)
        self.assertEqual(rows[0]["features"]["annual_income"], 36000.0)
        self.assertEqual(rows[0]["features"]["employment_days"], 3650.0)

    def test_home_credit_catalog_links_to_the_matching_default_risk_competition(self):
        self.assertEqual(
            SOURCE_CATALOG["home-credit"]["url"],
            "https://www.kaggle.com/c/home-credit-default-risk/rules",
        )

    def test_fico_catalog_links_to_the_original_xml_challenge_announcement(self):
        self.assertEqual(
            SOURCE_CATALOG["fico"]["url"],
            "https://investors.fico.com/news-releases/news-release-details/fico-announces-xml-challenge/",
        )

    def test_fico_maps_good_bad_and_ignores_identifier(self):
        path = self.write_csv("heloc.csv", ["UNIQUEID", "ExternalRiskEstimate", "NumSatisfactoryTrades", "NetFractionRevolvingBurden", "RiskPerformance"], [
            {"UNIQUEID": "abc", "ExternalRiskEstimate": "612", "NumSatisfactoryTrades": "14", "NetFractionRevolvingBurden": "30", "RiskPerformance": "Bad"},
            {"UNIQUEID": "def", "ExternalRiskEstimate": "710", "NumSatisfactoryTrades": "22", "NetFractionRevolvingBurden": "9", "RiskPerformance": "Good"},
        ])

        rows = list(iter_canonical_rows(path, "fico"))

        self.assertEqual([row["label"] for row in rows], [1, 0])
        self.assertNotIn("UNIQUEID", rows[0]["features"])
        self.assertEqual(rows[0]["features"]["ExternalRiskEstimate"], 612.0)

    def test_row_limit_counts_valid_labeled_rows(self):
        path = self.write_csv("lc.csv", ["loan_amnt", "annual_inc", "dti", "installment", "revol_bal", "revol_util", "loan_status"], [
            {"loan_amnt": "1000", "annual_inc": "24000", "dti": "12", "installment": "88", "revol_bal": "200", "revol_util": "40", "loan_status": "Charged Off"},
            {"loan_amnt": "900", "annual_inc": "25000", "dti": "10", "installment": "78", "revol_bal": "100", "revol_util": "20", "loan_status": "Fully Paid"},
        ])

        self.assertEqual(len(list(iter_canonical_rows(path, "lendingclub", row_limit=1))), 1)

    def test_missing_required_columns_raise_source_specific_error(self):
        path = self.write_csv("bad.csv", ["loan_amnt", "loan_status"], [{"loan_amnt": "100", "loan_status": "Charged Off"}])

        with self.assertRaisesRegex(SourceDataError, "missing required columns"):
            list(iter_canonical_rows(path, "lendingclub"))


if __name__ == "__main__":
    unittest.main()
