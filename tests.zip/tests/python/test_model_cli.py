import csv
import tempfile
import unittest
from pathlib import Path

from scripts.train_baseline import build_baseline_report
from scripts.aegis_models.sources import SourceDataError


GOOD = "A11 6 A34 A43 1169 A65 A75 4 A93 A101 4 A121 67 A143 A152 2 A173 1 A191 A201 1"
BAD = "A12 36 A31 A49 8900 A61 A72 3 A92 A101 2 A121 25 A143 A151 1 A173 1 A191 A201 2"


class ModelCommandTests(unittest.TestCase):
    def test_statlog_report_contains_metrics_and_no_raw_rows(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "german.data"
            path.write_text("\n".join([GOOD, BAD] * 30), encoding="utf-8")
            result = build_baseline_report("statlog-german", path, row_limit=50, seed=4)
            rendered = str(result)

        self.assertIn("roc_auc", result["metrics"])
        self.assertEqual(result["total_rows"], 50)
        self.assertFalse(result["raw_rows_saved"])
        self.assertNotIn("A11", rendered)
        self.assertNotIn("1169", rendered)
        self.assertIn("CC BY 4.0", result["source"]["license"])

    def test_terms_gated_source_requires_explicit_confirmation(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "fico.csv"
            with path.open("w", newline="", encoding="utf-8") as stream:
                writer = csv.DictWriter(stream, fieldnames=["ExternalRiskEstimate", "NumSatisfactoryTrades", "RiskPerformance"])
                writer.writeheader()
                writer.writerows([
                    {"ExternalRiskEstimate": "610", "NumSatisfactoryTrades": "8", "RiskPerformance": "Bad"},
                    {"ExternalRiskEstimate": "720", "NumSatisfactoryTrades": "22", "RiskPerformance": "Good"},
                ] * 10)
            with self.assertRaisesRegex(SourceDataError, "confirm the source's permitted use"):
                build_baseline_report("fico", path)


if __name__ == "__main__":
    unittest.main()
