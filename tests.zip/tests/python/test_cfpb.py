import csv
import io
import tempfile
import unittest
import zipfile
from pathlib import Path

from scripts.aegis_models.cfpb import CFPB_CAVEAT, CFPBDataError, summarize_complaints


def write_csv(path, rows):
    columns = ["Date received", "Product", "Issue", "Company", "Consumer complaint narrative"]
    with path.open("w", newline="", encoding="utf-8") as output:
        writer = csv.DictWriter(output, fieldnames=columns)
        writer.writeheader()
        writer.writerows(rows)


class CFPBSummaryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)

    def test_stream_summary_groups_metadata_without_returning_raw_narratives(self):
        path = self.root / "complaints.csv"
        write_csv(path, [
            {"Date received": "2026-02-01", "Product": "Payday loan", "Issue": "Fees", "Company": "Lender A", "Consumer complaint narrative": "PRIVATE TEXT MUST NOT APPEAR"},
            {"Date received": "2026-02-18", "Product": "Payday loan", "Issue": "Fees", "Company": "Lender A", "Consumer complaint narrative": "another narrative"},
            {"Date received": "2026-03-02", "Product": "Personal loan", "Issue": "Payments", "Company": "Lender B", "Consumer complaint narrative": "third narrative"},
        ])

        result = summarize_complaints(path)

        self.assertEqual(result["rows_used"], 3)
        self.assertEqual(result["by_month"]["2026-02"], 2)
        self.assertEqual(result["top_products"][0], {"name": "Payday loan", "count": 2})
        self.assertEqual(result["top_issues"][0], {"name": "Fees", "count": 2})
        self.assertEqual(result["top_companies"][0], {"name": "Lender A", "count": 2})
        self.assertNotIn("PRIVATE TEXT", str(result))
        self.assertIn(CFPB_CAVEAT, result["caveat"])

    def test_missing_dates_do_not_break_aggregate_counts(self):
        path = self.root / "complaints.csv"
        write_csv(path, [
            {"Date received": "", "Product": "Payday loan", "Issue": "Fees", "Company": "Lender A", "Consumer complaint narrative": ""},
            {"Date received": "not-a-date", "Product": "Payday loan", "Issue": "Fees", "Company": "Lender A", "Consumer complaint narrative": ""},
        ])

        result = summarize_complaints(path)

        self.assertEqual(result["rows_used"], 2)
        self.assertEqual(result["rows_with_valid_dates"], 0)
        self.assertEqual(result["top_products"][0]["count"], 2)

    def test_archived_narratives_produce_only_aggregate_financial_pressure_flags(self):
        path = self.root / "complaints.csv"
        write_csv(path, [
            {
                "Date received": "2026-02-01",
                "Product": "Payday loan",
                "Issue": "Fees",
                "Company": "Lender A",
                "Consumer complaint narrative": "I lost my job and could not pay rent. I used a payday loan and was charged a late fee.",
            },
            {
                "Date received": "2026-02-02",
                "Product": "Credit card",
                "Issue": "Billing",
                "Company": "Bank B",
                "Consumer complaint narrative": "The replacement card took too long to arrive; the message also mentions coffee.",
            },
        ])

        result = summarize_complaints(path)
        narrative = result["narrative_analysis"]

        self.assertEqual(narrative["rows_with_text"], 2)
        self.assertEqual(narrative["rows_with_any_signal"], 1)
        self.assertEqual(narrative["signals"]["income_disruption"], 1)
        self.assertEqual(narrative["signals"]["payment_difficulty"], 1)
        self.assertEqual(narrative["signals"]["cash_shortfall"], 1)
        self.assertEqual(narrative["signals"]["fee_pressure"], 1)
        self.assertNotIn("I lost my job", str(result))
        self.assertIn("aggregate", narrative["method"])

    def test_product_filter_scans_archive_but_counts_only_matching_loans(self):
        path = self.root / "complaints.csv"
        write_csv(path, [
            {"Date received": "2026-07-01", "Product": "Credit card", "Issue": "Fees", "Company": "Bank", "Consumer complaint narrative": "I could not pay"},
            {"Date received": "2026-07-02", "Product": "Payday loan, title loan, personal loan, or advance loan", "Issue": "Repaying", "Company": "Lender", "Consumer complaint narrative": "I lost my job and could not pay the fee"},
        ])
        result = summarize_complaints(path, product_contains="PAYDAY LOAN")

        self.assertEqual(result["rows_scanned"], 2)
        self.assertEqual(result["rows_used"], 1)
        self.assertEqual(result["product_filter"], "PAYDAY LOAN")
        self.assertEqual(result["narrative_analysis"]["rows_with_text"], 1)
        self.assertEqual(result["narrative_analysis"]["signals"]["income_disruption"], 1)
        self.assertEqual(result["top_companies"], [{"name": "Lender", "count": 1}])

    def test_row_limit_caps_rows_read(self):
        path = self.root / "complaints.csv"
        write_csv(path, [
            {"Date received": "2026-02-01", "Product": "A", "Issue": "X", "Company": "One", "Consumer complaint narrative": ""},
            {"Date received": "2026-02-02", "Product": "B", "Issue": "Y", "Company": "Two", "Consumer complaint narrative": ""},
        ])

        self.assertEqual(summarize_complaints(path, row_limit=1)["rows_used"], 1)

    def test_zip_input_reads_csv_member(self):
        member = io.StringIO()
        writer = csv.DictWriter(member, fieldnames=["Date received", "Product", "Issue", "Company"])
        writer.writeheader()
        writer.writerow({"Date received": "2026-04-05", "Product": "Credit card", "Issue": "Billing", "Company": "Bank"})
        archive_path = self.root / "complaints.zip"
        with zipfile.ZipFile(archive_path, "w") as archive:
            archive.writestr("data/complaints.csv", member.getvalue())

        result = summarize_complaints(archive_path)

        self.assertEqual(result["rows_used"], 1)
        self.assertEqual(result["by_month"], {"2026-04": 1})

    def test_month_day_year_dates_are_included_in_date_coverage(self):
        path = self.root / "complaints.csv"
        write_csv(path, [
            {"Date received": "04/05/2026", "Product": "Credit card", "Issue": "Billing", "Company": "Bank", "Consumer complaint narrative": ""},
        ])

        result = summarize_complaints(path)

        self.assertEqual(result["by_month"], {"2026-04": 1})

    def test_empty_cfpb_file_is_rejected(self):
        path = self.root / "empty.csv"
        path.write_text("Date received,Product,Issue,Company\n", encoding="utf-8")

        with self.assertRaisesRegex(CFPBDataError, "no data rows"):
            summarize_complaints(path)


if __name__ == "__main__":
    unittest.main()
