import io
import tempfile
import unittest
import zipfile
from pathlib import Path

from scripts.download_dataset import download_statlog


def zip_bytes(entries):
    output = io.BytesIO()
    with zipfile.ZipFile(output, "w") as archive:
        for name, content in entries.items():
            archive.writestr(name, content)
    return output.getvalue()


class DatasetDownloadTests(unittest.TestCase):
    def test_download_extracts_only_the_expected_data_and_writes_attribution(self):
        payload = zip_bytes({
            "statlog/german.data": "A11 6 A34 A43 1169 A65 A75 4 A93 A101 4 A121 67 A143 A152 2 A173 1 A191 A201 1\n",
            "unexpected.txt": "ignore me",
        })
        with tempfile.TemporaryDirectory() as temp_dir:
            output = Path(temp_dir) / "data" / "raw"
            result = download_statlog(output, opener=lambda _url, timeout: io.BytesIO(payload))

            self.assertEqual(Path(result["data_file"]).read_text(encoding="utf-8").split()[4], "1169")
            self.assertTrue(Path(result["attribution_file"]).exists())
            self.assertNotIn("unexpected.txt", [path.name for path in output.iterdir()])
            self.assertEqual(len(result["sha256"]), 64)

    def test_download_rejects_archive_without_expected_dataset(self):
        payload = zip_bytes({"unexpected.txt": "not the dataset"})
        with tempfile.TemporaryDirectory() as temp_dir:
            with self.assertRaisesRegex(ValueError, "did not contain german.data"):
                download_statlog(Path(temp_dir), opener=lambda _url, timeout: io.BytesIO(payload))

    def test_download_does_not_overwrite_a_previous_dataset(self):
        payload = zip_bytes({"german.data": "unused"})
        with tempfile.TemporaryDirectory() as temp_dir:
            output = Path(temp_dir)
            (output / "german.data").write_text("keep", encoding="utf-8")
            with self.assertRaisesRegex(FileExistsError, "already exists"):
                download_statlog(output, opener=lambda _url, timeout: io.BytesIO(payload))
            self.assertEqual((output / "german.data").read_text(encoding="utf-8"), "keep")


if __name__ == "__main__":
    unittest.main()
