import { Readable, Transform, Writable } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { mkdtemp, chmod, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';

const envelope = await import('../scripts/backup-envelope.mjs').catch(() => undefined);

async function transformBuffer(input: Buffer, transforms: Transform[]): Promise<Buffer> {
  const chunks: Buffer[] = [];
  const output = new Writable({ write(chunk, _encoding, callback) { chunks.push(Buffer.from(chunk)); callback(); } });
  await pipeline(Readable.from([input]), ...transforms, output);
  return Buffer.concat(chunks);
}

describe('encrypted PostgreSQL backup envelope', () => {
  it('round-trips backup data through the streaming cipher', async () => {
    expect(envelope).toBeDefined();
    const key = Buffer.alloc(32, 7);
    const input = Buffer.from('synthetic PostgreSQL archive contents');
    const encrypted = envelope!.createBackupEncryption(key, Buffer.alloc(12, 3));
    const ciphertext = await transformBuffer(input, [encrypted.transform]);
    const decrypted = envelope!.createBackupDecryption(encrypted.header, key);

    await expect(transformBuffer(ciphertext, [decrypted.tagStripper, decrypted.transform])).resolves.toEqual(input);
  });

  it('rejects a modified encrypted backup during authentication', async () => {
    expect(envelope).toBeDefined();
    const key = Buffer.alloc(32, 7);
    const encrypted = envelope!.createBackupEncryption(key, Buffer.alloc(12, 3));
    const ciphertext = await transformBuffer(Buffer.from('synthetic database archive'), [encrypted.transform]);
    ciphertext[0] ^= 1;
    const decrypted = envelope!.createBackupDecryption(encrypted.header, key);

    await expect(transformBuffer(ciphertext, [decrypted.tagStripper, decrypted.transform])).rejects.toThrow();
  });

  it('accepts exactly a 32-byte base64 key', () => {
    expect(envelope).toBeDefined();
    expect(envelope!.parseBackupKey(Buffer.alloc(32, 9).toString('base64'))).toHaveLength(32);
    expect(() => envelope!.parseBackupKey(Buffer.alloc(31, 9).toString('base64'))).toThrow();
    expect(() => envelope!.parseBackupKey('not-base64')).toThrow();
  });

  it('rejects an unknown envelope header', () => {
    expect(envelope).toBeDefined();
    expect(() => envelope!.createBackupDecryption(Buffer.alloc(20), Buffer.alloc(32))).toThrow();
  });

  it('loads a key file only when it is private to the current operator', async () => {
    expect(envelope).toBeDefined();
    const directory = await mkdtemp(join(tmpdir(), 'aegis-backup-key-test-'));
    const keyPath = join(directory, 'backup.key');
    try {
      const key = Buffer.alloc(32, 4);
      await writeFile(keyPath, `${key.toString('base64')}\n`, { mode: 0o600 });
      await chmod(keyPath, 0o600);
      await expect(envelope!.loadBackupKey({ keyFile: keyPath, envKey: undefined })).resolves.toEqual(key);
      await chmod(keyPath, 0o644);
      await expect(envelope!.loadBackupKey({ keyFile: keyPath, envKey: undefined })).rejects.toThrow();
    } finally {
      await rm(directory, { recursive: true, force: true });
    }
  });
});
