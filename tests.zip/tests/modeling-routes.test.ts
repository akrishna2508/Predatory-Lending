import { afterEach, describe, expect, it, vi } from 'vitest';
import { mkdir, mkdtemp, rm, symlink, writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { POST as trainBaseline } from '@/app/api/lab/baseline/route';
import { POST as analyzeComplaints } from '@/app/api/lab/complaints/route';
import { GET as getLatest } from '@/app/api/lab/latest/route';
import { POST as runSimulation } from '@/app/api/lab/simulation/route';
import { POST as benchmarkGenerators } from '@/app/api/lab/generator-benchmark/route';
import { GET as getSynthetic } from '@/app/api/lab/synthetic/route';

const fixturePaths: string[] = [];
const fixtureRoots: string[] = [];
afterEach(async () => {
  vi.unstubAllEnvs();
  await Promise.all([
    ...fixturePaths.splice(0).map(file => rm(file, { force: true })),
    ...fixtureRoots.splice(0).map(root => rm(root, { recursive: true, force: true })),
  ]);
});

async function temporaryProjectRoot() {
  const root = await mkdtemp(path.join(os.tmpdir(), 'aegis-model-root-'));
  fixtureRoots.push(root);
  await symlink(path.join(process.cwd(), 'scripts'), path.join(root, 'scripts'), 'dir');
  await mkdir(path.join(root, 'data', 'raw'), { recursive: true });
  await mkdir(path.join(root, 'data', 'results'), { recursive: true });
  return root;
}

function localRequest(route: string, body: unknown, host = 'localhost:3000') {
  return new Request(`http://${host}/api/lab/${route}`, {
    method: 'POST',
    headers: { host, origin: `http://${host}`, 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
}

describe('local modeling routes', () => {
  it('uses the configured project root for source files in a standalone runtime', async () => {
    const root = await temporaryProjectRoot();
    const filename = 'standalone-fixture.data';
    const good = 'A11 6 A34 A43 1169 A65 A75 4 A93 A101 4 A121 67 A143 A152 2 A173 1 A191 A201 1';
    const bad = 'A12 36 A31 A49 8900 A61 A72 3 A92 A101 2 A121 25 A143 A151 1 A173 1 A191 A201 2';
    await writeFile(path.join(root, 'data', 'raw', filename), `${Array.from({ length: 20 }, (_, index) => index % 2 ? bad : good).join('\n')}\n`);
    vi.stubEnv('AEGIS_PROJECT_ROOT', root);

    const response = await trainBaseline(localRequest('baseline', {
      source: 'statlog-german', filename, rowLimit: 100, seed: 7,
    }));
    const report = await response.json();

    expect(response.status).toBe(200);
    expect(report.total_rows).toBe(20);
  });

  it('reads saved reports and generated tables from the configured project root', async () => {
    const root = await temporaryProjectRoot();
    await writeFile(path.join(root, 'data', 'results', 'baseline-latest.json'), '{"total_rows":77}');
    await writeFile(path.join(root, 'data', 'results', 'cfpb-loan-narratives-latest.json'), '{"rows_used":1793}');
    await writeFile(path.join(root, 'data', 'results', 'generator-benchmark-statlog.json'), '{"source_id":"statlog-german"}');
    await writeFile(path.join(root, 'data', 'results', 'synthetic-latest.csv'), 'provenance,value\nexperimental_synthetic,0.5\n');
    vi.stubEnv('AEGIS_PROJECT_ROOT', root);

    const latest = await getLatest(new Request('http://localhost:3000/api/lab/latest', { headers: { host: 'localhost:3000' } }));
    const latestReport = await latest.json();
    const synthetic = await getSynthetic(new Request('http://localhost:3000/api/lab/synthetic', { headers: { host: 'localhost:3000' } }));
    const syntheticCsv = await synthetic.text();

    expect(latestReport.baseline.total_rows).toBe(77);
    expect(latestReport.archivedLoanComplaints.rows_used).toBe(1793);
    expect(latestReport.generatorBenchmarks).toEqual([{ source_id: 'statlog-german' }]);
    expect(synthetic.status).toBe(200);
    expect(syntheticCsv).toContain('experimental_synthetic');
  });

  it('runs public-data generator benchmarks through the local website without returning records', async () => {
    const root = await temporaryProjectRoot();
    const filename = 'generator-fixture.data';
    const good = 'A11 6 A34 A43 1169 A65 A75 4 A93 A101 4 A121 67 A143 A152 2 A173 1 A191 A201 1';
    const bad = 'A12 36 A31 A49 8900 A61 A72 3 A92 A101 2 A121 25 A143 A151 1 A173 1 A191 A201 2';
    await writeFile(path.join(root, 'data', 'raw', filename), `${Array.from({ length: 120 }, (_, index) => index % 2 ? bad : good).join('\n')}\n`);
    vi.stubEnv('AEGIS_PROJECT_ROOT', root);

    const response = await benchmarkGenerators(localRequest('generator-benchmark', {
      source: 'statlog-german', filename, rowLimit: 120, samples: 24, seed: 7,
    }));
    const report = await response.json();

    expect(response.status).toBe(200);
    expect(report.rows_used).toBe(120);
    expect(report.generated_rows_saved).toBe(false);
    expect(report.engines.gan.holdout_distances.correlation_distance).toEqual(expect.any(Number));
    expect(report.engines.diffusion.holdout_distances.mean_distance_scaled).toEqual(expect.any(Number));
    expect(JSON.stringify(report)).not.toContain('A11 6');
  }, 20_000);

  it('trains from a local dataset and returns aggregate metrics', async () => {
    const rawDirectory = path.join(process.cwd(), 'data', 'raw');
    await mkdir(rawDirectory, { recursive: true });
    const filename = `route-fixture-${randomUUID()}.data`;
    const good = 'A11 6 A34 A43 1169 A65 A75 4 A93 A101 4 A121 67 A143 A152 2 A173 1 A191 A201 1';
    const bad = 'A12 36 A31 A49 8900 A61 A72 3 A92 A101 2 A121 25 A143 A151 1 A173 1 A191 A201 2';
    const filePath = path.join(rawDirectory, filename);
    fixturePaths.push(filePath);
    await writeFile(filePath, `${Array.from({ length: 20 }, (_, index) => index % 2 ? bad : good).join('\n')}\n`);

    const response = await trainBaseline(localRequest('baseline', {
      source: 'statlog-german', filename, rowLimit: 100, seed: 7,
    }));
    const report = await response.json();

    expect(response.status).toBe(200);
    expect(report.total_rows).toBe(20);
    expect(report.metrics.roc_auc).toBeGreaterThanOrEqual(0);
    expect(report.raw_rows_saved).toBe(false);
  });

  it('returns only aggregate phrase flags from a local historical complaint file', async () => {
    const rawDirectory = path.join(process.cwd(), 'data', 'raw');
    await mkdir(rawDirectory, { recursive: true });
    const filename = `cfpb-route-fixture-${randomUUID()}.csv`;
    const filePath = path.join(rawDirectory, filename);
    fixturePaths.push(filePath);
    await writeFile(filePath, [
      'Date received,Product,Issue,Company,Consumer complaint narrative',
      '2026-02-01,Payday loan,Fees,Lender,"I lost my job and could not pay rent. I used a payday loan and paid a late fee."',
      '',
    ].join('\n'));

    const response = await analyzeComplaints(localRequest('complaints', { filename, productContains: 'payday' }));
    const report = await response.json();

    expect(response.status).toBe(200);
    expect(report.narrative_analysis.signals.income_disruption).toBe(1);
    expect(report.narrative_analysis.signals.payment_difficulty).toBe(1);
    expect(report.product_filter).toBe('payday');
    expect(JSON.stringify(report)).not.toContain('I lost my job');
    expect(report.narrative_text_included).toBe(false);
  });

  it('rejects remote hosts and path traversal without running a model', async () => {
    const remote = await trainBaseline(localRequest('baseline', {
      source: 'statlog-german', filename: 'statlog-german/german.data',
    }, 'aegis.example'));
    const traversal = await trainBaseline(localRequest('baseline', {
      source: 'statlog-german', filename: '../outside.data',
    }));

    expect(remote.status).toBe(403);
    expect(traversal.status).toBe(400);
  });

  it('runs deterministic aggregate simulations without returning agent records', async () => {
    const first = await runSimulation(localRequest('simulation', { profile: 'student', trials: 30, seed: 14 }));
    const second = await runSimulation(localRequest('simulation', { profile: 'student', trials: 30, seed: 14 }));
    const firstReport = await first.json();
    const secondReport = await second.json();

    expect(first.status).toBe(200);
    expect(firstReport).toEqual(secondReport);
    expect(firstReport.metrics.acceptance_rate).toBeGreaterThanOrEqual(0);
    expect(firstReport.records).toBeUndefined();
    expect(firstReport.caveat).toContain('scenario_only');
  });
});
