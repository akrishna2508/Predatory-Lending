import { describe, expect, it } from 'vitest';

const database = await import('../src/server/database').catch(() => undefined);

describe('member tenant discovery', () => {
  it('sets the verified user identity and returns only active member organizations', async () => {
    expect(database, 'database module should exist').toBeDefined();
    const statements: Array<{ sql: string; values?: unknown[] }> = [];
    const pool = { async connect() { return {
      async query(sql: string, values?: unknown[]) {
        statements.push({ sql, values });
        if (sql.includes('FROM memberships m')) return { rows: [{ id: 'tenant-1', name: 'Community CU', slug: 'community-cu' }] };
        return { rows: [] };
      },
      release() {},
    }; } };
    const tenants = await database!.listMemberTenants(pool, '00000000-0000-4000-8000-000000000011');
    expect(tenants).toEqual([{ id: 'tenant-1', name: 'Community CU', slug: 'community-cu' }]);
    expect(statements.map(item => item.sql)).toEqual([
      'BEGIN',
      'SET LOCAL ROLE aegis_runtime',
      "SELECT set_config('aegis.tenant_id', '', true), set_config('aegis.user_id', $1, true)",
      "SELECT o.id, o.name, o.slug FROM memberships m JOIN organizations o ON o.id = m.tenant_id JOIN app_users u ON u.id = m.user_id WHERE m.role = 'member' AND m.status = 'active' AND o.status = 'active' AND u.status = 'active' ORDER BY o.name",
      'COMMIT',
    ]);
    expect(statements[2].values).toEqual(['00000000-0000-4000-8000-000000000011']);
  });

  it('rejects malformed user identifiers before borrowing a database connection', async () => {
    expect(database, 'database module should exist').toBeDefined();
    let connected = false;
    await expect(database!.listMemberTenants({ async connect() { connected = true; throw new Error('unexpected'); } }, 'member'))
      .rejects.toThrow('Valid user identifier is required');
    expect(connected).toBe(false);
  });
});
