import { describe, expect, it } from 'vitest';

const tenantsRoute = await import('../src/app/api/member/tenants/route');
const checksRoute = await import('../src/app/api/member/offer-checks/route');
const outcomeRoute = await import('../src/app/api/member/offer-checks/[id]/outcome/route');
const consentsRoute = await import('../src/app/api/member/consents/route');
const exportRoute = await import('../src/app/api/member/export/route');
const accountRoute = await import('../src/app/api/member/account/route');
const transactionsRoute = await import('../src/app/api/member/transactions/route');
const transactionImportRoute = await import('../src/app/api/member/transactions/import/route');
const reminderRoute = await import('../src/app/api/member/offer-checks/[id]/reminder/route');
const cashflowProfileRoute = await import('../src/app/api/member/cashflow-profile/route');

describe('member API authentication boundary', () => {
  it('rejects unauthenticated reads before attempting database access', async () => {
    const responses = await Promise.all([
      tenantsRoute.GET(new Request('https://aegis.test/api/member/tenants')),
      checksRoute.GET(new Request('https://aegis.test/api/member/offer-checks', { headers: { 'x-aegis-tenant-id': '00000000-0000-4000-8000-000000000001' } })),
      outcomeRoute.POST(new Request('https://aegis.test/api/member/offer-checks/00000000-0000-4000-8000-000000000099/outcome', { method: 'POST', headers: { 'content-type': 'application/json', origin: 'https://aegis.test' }, body: JSON.stringify({ outcome: 'declined' }) }), { params: Promise.resolve({ id: '00000000-0000-4000-8000-000000000099' }) }),
      consentsRoute.GET(new Request('https://aegis.test/api/member/consents', { headers: { 'x-aegis-tenant-id': '00000000-0000-4000-8000-000000000001' } })),
      exportRoute.GET(new Request('https://aegis.test/api/member/export')),
      accountRoute.GET(new Request('https://aegis.test/api/member/account')),
      accountRoute.DELETE(new Request('https://aegis.test/api/member/account', { method: 'DELETE' })),
      transactionsRoute.GET(new Request('https://aegis.test/api/member/transactions')),
      transactionImportRoute.POST(new Request('https://aegis.test/api/member/transactions/import', { method: 'POST', headers: { origin: 'https://aegis.test', 'content-type': 'text/csv' }, body: 'date,description,amount\n2026-01-01,Test,-1' })),
      reminderRoute.POST(new Request('https://aegis.test/api/member/offer-checks/00000000-0000-4000-8000-000000000099/reminder', { method: 'POST' }), { params: Promise.resolve({ id: '00000000-0000-4000-8000-000000000099' }) }),
      reminderRoute.DELETE(new Request('https://aegis.test/api/member/offer-checks/00000000-0000-4000-8000-000000000099/reminder', { method: 'DELETE' }), { params: Promise.resolve({ id: '00000000-0000-4000-8000-000000000099' }) }),
      cashflowProfileRoute.GET(new Request('https://aegis.test/api/member/cashflow-profile', { headers: { 'x-aegis-tenant-id': '00000000-0000-4000-8000-000000000001' } })),
      cashflowProfileRoute.PUT(new Request('https://aegis.test/api/member/cashflow-profile', { method: 'PUT', headers: { 'content-type': 'application/json', origin: 'https://aegis.test', 'x-aegis-tenant-id': '00000000-0000-4000-8000-000000000001' }, body: '{}' })),
      cashflowProfileRoute.DELETE(new Request('https://aegis.test/api/member/cashflow-profile', { method: 'DELETE', headers: { origin: 'https://aegis.test', 'x-aegis-tenant-id': '00000000-0000-4000-8000-000000000001' } })),
    ]);
    expect(responses.map(response => response.status)).toEqual(Array.from({ length: 14 }, () => 401));
    expect(await Promise.all(responses.map(response => response.json()))).toEqual(
      Array.from({ length: 14 }, () => ({ error: 'Authentication required' })),
    );
  });

  it('rejects cross-origin cookie mutations before reading or saving the submitted payload', async () => {
    const request = new Request('https://aegis.test/api/member/consents', {
      method: 'POST',
      headers: {
        cookie: 'aegis_session=unverified',
        origin: 'https://attacker.test',
        'x-aegis-tenant-id': '00000000-0000-4000-8000-000000000001',
      },
      body: '{"purpose":"research","action":"granted"}',
    });
    const response = await consentsRoute.POST(request);
    expect(response.status).toBe(403);
    expect(await response.json()).toEqual({ error: 'Cross-origin request rejected.' });
  });
});
