import { describe, expect, it } from 'vitest';
import { withMemberTransaction } from '@/server/database';

const identity = {
  tenantId: '00000000-0000-4000-8000-000000000001',
  userId: '00000000-0000-4000-8000-000000000011',
};

function fakePool(queryResult: (sql: string) => { rows: Array<Record<string, unknown>> }, calls: string[]) {
  return {
    async connect() {
      return {
        async query(sql: string) {
          calls.push(sql);
          return queryResult(sql);
        },
        release() {},
      };
    },
  };
}

describe('member database transactions', () => {
  it('serializes consent changes and member financial writes under one transaction lock', async () => {
    const calls: string[] = [];
    const pool = fakePool(sql => sql.includes('FROM memberships')
      ? { rows: [{ role: 'member' }] }
      : { rows: [] }, calls);

    await withMemberTransaction(pool, identity, async () => {
      calls.push('member-operation');
    });

    const lockIndex = calls.findIndex(sql => sql.includes('pg_advisory_xact_lock'));
    const operationIndex = calls.indexOf('member-operation');
    expect(lockIndex).toBeGreaterThan(-1);
    expect(lockIndex).toBeLessThan(operationIndex);
    expect(calls.at(-1)).toBe('COMMIT');
  });

  it('rejects member operations when the credit-union organization is suspended', async () => {
    const calls: string[] = [];
    let operationRan = false;
    const pool = fakePool(sql => {
      if (sql.includes('FROM memberships')) {
        return sql.includes('JOIN organizations') && sql.includes("'active'")
          ? { rows: [] }
          : { rows: [{ role: 'member' }] };
      }
      return { rows: [] };
    }, calls);

    await expect(withMemberTransaction(pool, identity, async () => {
      operationRan = true;
    })).rejects.toThrow('Active membership required');
    expect(operationRan).toBe(false);
    expect(calls.at(-1)).toBe('ROLLBACK');
  });
});
