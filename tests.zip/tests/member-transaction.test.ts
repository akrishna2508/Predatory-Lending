import { describe, expect, it } from 'vitest';

const database = await import('../src/server/database').catch(() => undefined);

type FakeClient = {
  statements: Array<{ sql: string; values?: unknown[] }>;
  released: boolean;
};

function fakePool(membershipRows: Array<{ role: string }> = [{ role: 'member' }]) {
  const client: FakeClient = { statements: [], released: false };
  const pool = {
    async connect() {
      return {
        async query(sql: string, values?: unknown[]) {
          client.statements.push({ sql, values });
          if (sql.includes('FROM memberships')) return { rows: membershipRows };
          return { rows: [] };
        },
        release() { client.released = true; },
      };
    },
  };
  return { pool, client };
}

const identity = {
  tenantId: '00000000-0000-4000-8000-000000000001',
  userId: '00000000-0000-4000-8000-000000000011',
};

describe('member database transaction', () => {
  it('sets tenant-local RLS context and checks membership before running queries', async () => {
    expect(database, 'server database module should exist').toBeDefined();
    const { pool, client } = fakePool();
    let callbackRan = false;

    const role = await database!.withMemberTransaction(pool, identity, async () => {
      callbackRan = true;
      return 'saved';
    });

    expect(role).toBe('saved');
    expect(callbackRan).toBe(true);
    expect(client.statements.map(statement => statement.sql)).toEqual([
      'BEGIN',
      'SET LOCAL ROLE aegis_runtime',
      "SELECT set_config('aegis.tenant_id', $1, true), set_config('aegis.user_id', $2, true)",
      "SELECT pg_advisory_xact_lock(hashtextextended($1::text, 0))",
      "SELECT m.role FROM memberships m JOIN app_users u ON u.id = m.user_id JOIN organizations o ON o.id = m.tenant_id WHERE m.tenant_id = $1 AND m.user_id = $2 AND m.status = 'active' AND u.status = 'active' AND o.status = 'active'",
      'COMMIT',
    ]);
    expect(client.statements[2].values).toEqual([identity.tenantId, identity.userId]);
    expect(client.released).toBe(true);
  });

  it('rejects a non-member before the supplied operation and rolls back', async () => {
    expect(database, 'server database module should exist').toBeDefined();
    const { pool, client } = fakePool([]);
    let callbackRan = false;

    await expect(database!.withMemberTransaction(pool, identity, async () => {
      callbackRan = true;
    })).rejects.toThrow('Active membership required');

    expect(callbackRan).toBe(false);
    expect(client.statements.map(statement => statement.sql).slice(-1)).toEqual(['ROLLBACK']);
    expect(client.released).toBe(true);
  });

  it('rolls back the transaction when a member operation fails', async () => {
    expect(database, 'server database module should exist').toBeDefined();
    const { pool, client } = fakePool();

    await expect(database!.withMemberTransaction(pool, identity, async () => {
      throw new Error('write failed');
    })).rejects.toThrow('write failed');

    expect(client.statements.map(statement => statement.sql).slice(-1)).toEqual(['ROLLBACK']);
    expect(client.released).toBe(true);
  });
});

describe('identity-only database transaction', () => {
  it('sets user context with no tenant for self-service account operations', async () => {
    expect(database, 'server database module should exist').toBeDefined();
    const { pool, client } = fakePool();
    const value = await database!.withIdentityTransaction(pool, identity.userId, async db => {
      await db.query('SELECT aegis_begin_member_account_deletion()');
      return 'done';
    });
    expect(value).toBe('done');
    expect(client.statements.map(statement => statement.sql)).toEqual([
      'BEGIN',
      'SET LOCAL ROLE aegis_runtime',
      "SELECT set_config('aegis.tenant_id', '', true), set_config('aegis.user_id', $1, true)",
      "SELECT pg_advisory_xact_lock(hashtextextended($1::text, 0))",
      'SELECT aegis_begin_member_account_deletion()',
      'COMMIT',
    ]);
    expect(client.statements[2].values).toEqual([identity.userId]);
    expect(client.released).toBe(true);
  });
});
