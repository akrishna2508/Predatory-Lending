import { existsSync, readFileSync, readdirSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { describe, expect, it } from 'vitest';
import Home from '@/app/page';

const root = fileURLToPath(new URL('..', import.meta.url));
const appDirectory = path.join(root, 'src', 'app');

describe('Aegis credit-union member platform', () => {
  it('presents the public service and links members, partners, and the research lab', () => {
    const page = renderToStaticMarkup(createElement(Home));

    expect(page).toContain('See the cost before you decide.');
    expect(page).toContain('href="/member"');
    expect(page).toContain('href="/partner"');
    expect(page).toContain('href="/lab"');
    expect(page).toContain('Illustrative example');
    expect(page).toContain('$500.00');
    expect(page).toContain('$575.00');
    expect(page).toContain('$75.00');
    expect(page).not.toContain('Safe loan');
    expect(page).not.toContain('Apply now');
  });

  it('serves separate member and partner routes alongside the research lab', () => {
    const pages = readdirSync(appDirectory, { withFileTypes: true })
      .filter(entry => entry.isDirectory() && entry.name !== 'api')
      .map(entry => entry.name)
      .sort();
    const apiRoots = readdirSync(path.join(appDirectory, 'api'), { withFileTypes: true })
      .filter(entry => entry.isDirectory())
      .map(entry => entry.name)
      .sort();

    expect(pages).toEqual(['check', 'lab', 'login', 'member', 'partner', 'shield-demo']);
    expect(apiRoots).toEqual(['auth', 'health', 'lab', 'member', 'partner', 'research']);
    expect(existsSync(path.join(appDirectory, 'api', 'member', 'offer-checks', 'route.ts'))).toBe(true);
    expect(existsSync(path.join(appDirectory, 'api', 'partner', 'reports', 'route.ts'))).toBe(true);
    expect(existsSync(path.join(appDirectory, 'api', 'lab', 'simulation', 'route.ts'))).toBe(true);
  });

  it('uses local persistence and manual or CSV financial input without cloud or aggregator dependencies', () => {
    const packageJson = JSON.parse(readFileSync(path.join(root, 'package.json'), 'utf8')) as {
      name: string;
      dependencies: Record<string, string>;
      scripts: Record<string, string>;
    };
    const compose = readFileSync(path.join(root, 'compose.yaml'), 'utf8');

    expect(packageJson.name).toBe('aegis-platform');
    expect(packageJson.dependencies).toHaveProperty('pg');
    expect(packageJson.scripts).toHaveProperty('db:migrate:local');
    expect(packageJson.scripts).toHaveProperty('provision:organization');
    expect(packageJson.scripts).toHaveProperty('models:simulate');
    expect(compose).toContain('127.0.0.1:5433:5432');
    expect(compose).not.toMatch(/plaid|aws/i);
    expect(existsSync(path.join(root, 'db', 'migrations', '0011_consent_and_tenant_guards.sql'))).toBe(true);
    expect(existsSync(path.join(root, 'src', 'domain', 'csv-transactions.ts'))).toBe(true);
  });
});
