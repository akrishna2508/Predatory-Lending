import { describe, expect, it } from 'vitest';

const service = await import('../src/server/offer-service').catch(() => undefined);

const validInput = {
  asOfDate: '2026-09-25',
  startingBalance: 840,
  events: [{ id: 'rent', date: '2026-10-01', label: 'Rent', amount: -760, kind: 'bill' as const }],
  proceeds: 200,
  receivedOn: '2026-09-25',
  payments: [{ date: '2026-10-02', amount: 250 }],
};

describe('offer check service', () => {
  it('validates bounded manual financial inputs and calculates a result', () => {
    expect(service, 'offer service should exist').toBeDefined();
    const result = service!.validateOfferCheck(validInput);
    expect(result.valid).toBe(true);
  });

  it('rejects oversized payloads, malformed entries, and invalid financial values', () => {
    expect(service, 'offer service should exist').toBeDefined();
    expect(service!.validateOfferCheck({ ...validInput, startingBalance: -1 }).valid).toBe(false);
    expect(service!.validateOfferCheck({ ...validInput, events: Array.from({ length: 61 }, (_, id) => ({ id: String(id), date: '2026-10-01', label: 'Bill', amount: -1, kind: 'bill' })) }).valid).toBe(false);
    expect(service!.validateOfferCheck({ ...validInput, payments: [{ date: '2026-10-02', amount: Number.POSITIVE_INFINITY }] }).valid).toBe(false);
  });

  it('requires every necessary purpose to have a latest granted consent', () => {
    expect(service, 'offer service should exist').toBeDefined();
    expect(service!.hasOfferCheckConsent([
      { purpose: 'manual_financial_profile', action: 'granted' },
      { purpose: 'offer_check_storage', action: 'granted' },
    ])).toBe(true);
    expect(service!.hasOfferCheckConsent([
      { purpose: 'manual_financial_profile', action: 'granted' },
      { purpose: 'offer_check_storage', action: 'revoked' },
    ])).toBe(false);
  });
});
