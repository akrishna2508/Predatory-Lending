import { describe, expect, it } from 'vitest';
import { analyzeLoanOfferText } from '../src/domain/loan-offer-signals';

describe('analyzeLoanOfferText', () => {
  it('flags a fee demanded to release a guaranteed loan and preserves the matched wording', () => {
    const signals = analyzeLoanOfferText('Your loan is guaranteed. Pay an upfront fee before funds are released.');
    expect(signals[0]).toMatchObject({
      id: 'pay_to_release',
      kind: 'high-concern',
      evidence: 'Pay an upfront fee before funds are released',
      source: { label: 'FTC loan scam guidance' },
    });
  });

  it('treats a fee mention without a pay-to-release condition as a review cue, not proof of fraud', () => {
    const signals = analyzeLoanOfferText('An application fee may apply. APR: 12%. Total repayment: $120.');
    expect(signals).toContainEqual(expect.objectContaining({ id: 'pay_to_release', kind: 'review' }));
    expect(signals.some(signal => signal.kind === 'high-concern')).toBe(false);
  });

  it('shows information checks when APR and total repayment are absent', () => {
    const signals = analyzeLoanOfferText('Act now. We connect you with participating lenders.');
    expect(signals.map(signal => signal.id)).toEqual(expect.arrayContaining([
      'time_pressure', 'lead_generation', 'missing_apr', 'missing_total_repayment',
    ]));
    expect(signals.every(signal => signal.kind !== 'high-concern')).toBe(true);
  });

  it('does nothing for blank text and limits analysis to 20,000 characters', () => {
    expect(analyzeLoanOfferText('  ')).toEqual([]);
    expect(analyzeLoanOfferText(`${'safe wording '.repeat(2_000)}guaranteed loan`))
      .not.toContainEqual(expect.objectContaining({ id: 'guaranteed_approval' }));
  });
});
