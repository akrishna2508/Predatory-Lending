import { expect, it } from 'vitest';
import { buildLocalServerEnv } from '../scripts/start-local.mjs';

it('pins the standalone listener to loopback even if the shell hostname is wildcard', () => {
  const env = buildLocalServerEnv({ HOSTNAME: '0.0.0.0', PORT: '3100' }, '/opt/aegis');
  expect(env).toEqual({ AEGIS_PROJECT_ROOT: '/opt/aegis', HOSTNAME: '127.0.0.1', PORT: '3100' });
});
