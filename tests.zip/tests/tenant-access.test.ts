import { describe, expect, it } from 'vitest';

const policy = await import('../src/server/tenant-access').catch(() => undefined);

function accessPolicy() {
  expect(policy, 'tenant access policy module should exist').toBeDefined();
  return policy!;
}

const member = { subject: 'member-a', tenantId: 'cu-a', role: 'member' as const };

describe('tenant data access policy', () => {
  it('allows a member to read their own private record in the active tenant', () => {
    expect(accessPolicy().canReadMemberRecord(member, { tenantId: 'cu-a', memberSubject: 'member-a' })).toBe(true);
  });

  it('denies a member access to another member record in the same tenant', () => {
    expect(accessPolicy().canReadMemberRecord(member, { tenantId: 'cu-a', memberSubject: 'member-b' })).toBe(false);
  });

  it('denies a member record from a different tenant', () => {
    expect(accessPolicy().canReadMemberRecord(member, { tenantId: 'cu-b', memberSubject: 'member-a' })).toBe(false);
  });

  it('never exposes member-level records to partner staff', () => {
    expect(accessPolicy().canReadMemberRecord(
      { subject: 'staff-a', tenantId: 'cu-a', role: 'partner_admin' },
      { tenantId: 'cu-a', memberSubject: 'member-a' },
    )).toBe(false);
  });

  it('allows partner aggregate reporting only for the same tenant and cohorts of at least 20', () => {
    const partner = { subject: 'staff-a', tenantId: 'cu-a', role: 'partner_admin' as const };
    expect(accessPolicy().canReadPartnerAggregate(partner, { tenantId: 'cu-a', cohortSize: 19 })).toBe(false);
    expect(accessPolicy().canReadPartnerAggregate(partner, { tenantId: 'cu-a', cohortSize: 20 })).toBe(true);
    expect(accessPolicy().canReadPartnerAggregate(partner, { tenantId: 'cu-b', cohortSize: 100 })).toBe(false);
  });

  it('denies partner aggregate access to member and support roles', () => {
    expect(accessPolicy().canReadPartnerAggregate(member, { tenantId: 'cu-a', cohortSize: 20 })).toBe(false);
    expect(accessPolicy().canReadPartnerAggregate(
      { subject: 'support-1', tenantId: 'cu-a', role: 'support' },
      { tenantId: 'cu-a', cohortSize: 20 },
    )).toBe(false);
  });

  it('allows partner analysts to read thresholded aggregates, but not member rows', () => {
    const analyst = { subject: 'analyst-1', tenantId: 'cu-a', role: 'partner_analyst' as const };
    expect(accessPolicy().canReadPartnerAggregate(analyst, { tenantId: 'cu-a', cohortSize: 20 })).toBe(true);
    expect(accessPolicy().canReadMemberRecord(analyst, { tenantId: 'cu-a', memberSubject: 'member-a' })).toBe(false);
  });
});
