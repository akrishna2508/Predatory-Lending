import { describe, expect, it } from 'vitest';
import { buildShieldDemoScenario, shiftDate } from '@/domain/shield-demo';

describe('local shield demo scenario', () => {
  it('connects fictional transaction matches to offer review and virtual payday routing', () => {
    const asOfDate = '2026-09-28';
    const scenario = buildShieldDemoScenario(asOfDate, 340);

    expect(scenario.signals.map(signal => signal.evidenceCount)).toEqual([3, 2]);
    expect(scenario.analysis.valid).toBe(true);
    if (!scenario.analysis.valid) return;
    expect(scenario.analysis.warning?.date).toBe(shiftDate(asOfDate, 28));
    expect(scenario.analysis.warning?.balanceAfter).toBe(-15);
    expect(scenario.analysis.baseline.lowestBalance).toBe(20);
    expect(scenario.routes.map(route => [route.billsReserve, route.remaining, route.billCount])).toEqual([
      [300, 0, 2],
      [0, 40, 0],
    ]);
  });

  it('keeps transaction patterns separate from the cash-flow warning', () => {
    const scenario = buildShieldDemoScenario('2026-09-28', 5_000);

    expect(scenario.analysis.valid).toBe(true);
    if (!scenario.analysis.valid) return;
    expect(scenario.analysis.warning).toBeNull();
    expect(scenario.signals).toHaveLength(2);
  });

  it('shifts sample dates across month and year boundaries', () => {
    expect(shiftDate('2026-12-25', 14)).toBe('2027-01-08');
    expect(shiftDate('2027-01-03', -7)).toBe('2026-12-27');
  });
});
