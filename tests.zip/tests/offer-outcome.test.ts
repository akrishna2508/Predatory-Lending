import { describe, expect, it } from 'vitest';

const service = await import('../src/domain/offer-outcome').catch(() => undefined);

describe('member offer outcome service', () => {
  it('accepts only the supported self-reported decision states', () => {
    expect(service, 'offer outcome service should exist').toBeDefined();
    expect(service!.parseMemberOfferOutcome({ outcome: 'accepted' })).toEqual({ valid: true, outcome: 'accepted' });
    expect(service!.parseMemberOfferOutcome({ outcome: 'declined' })).toEqual({ valid: true, outcome: 'declined' });
    expect(service!.parseMemberOfferOutcome({ outcome: 'changed_terms' })).toEqual({ valid: true, outcome: 'changed_terms' });
    expect(service!.parseMemberOfferOutcome({ outcome: 'still_deciding' })).toEqual({ valid: true, outcome: 'still_deciding' });
  });

  it('rejects free-form values, additional fields, and invalid decisions', () => {
    expect(service, 'offer outcome service should exist').toBeDefined();
    expect(service!.parseMemberOfferOutcome({ outcome: 'accepted', notes: 'private note' }).valid).toBe(false);
    expect(service!.parseMemberOfferOutcome({ outcome: 'safe' }).valid).toBe(false);
    expect(service!.parseMemberOfferOutcome({ outcome: 3 }).valid).toBe(false);
    expect(service!.parseMemberOfferOutcome(null).valid).toBe(false);
  });

  it('requires the separate self-report consent in addition to saved-comparison consent', () => {
    expect(service, 'offer outcome service should exist').toBeDefined();
    expect(service!.hasMemberOfferOutcomeConsent([
      { purpose: 'manual_financial_profile', action: 'granted' },
      { purpose: 'offer_check_storage', action: 'granted' },
    ])).toBe(false);
    expect(service!.hasMemberOfferOutcomeConsent([
      { purpose: 'manual_financial_profile', action: 'granted' },
      { purpose: 'offer_check_storage', action: 'granted' },
      { purpose: 'offer_outcome_reporting', action: 'granted' },
    ])).toBe(true);
    expect(service!.hasMemberOfferOutcomeConsent([
      { purpose: 'manual_financial_profile', action: 'granted' },
      { purpose: 'offer_check_storage', action: 'granted' },
      { purpose: 'offer_outcome_reporting', action: 'revoked' },
    ])).toBe(false);
  });
});
