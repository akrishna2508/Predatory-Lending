import { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { describe, expect, it } from 'vitest';
import Home from '@/app/page';

describe('public Aegis entry page', () => {
  it('explains the offer-check service and routes members and credit-union staff', () => {
    const page = renderToStaticMarkup(createElement(Home));

    expect(page).toContain('See the cost before you decide.');
    expect(page).toContain('href="/member"');
    expect(page).toContain('href="/partner"');
    expect(page).toContain('href="/lab"');
  });

  it('labels the public loan example and avoids an endorsement', () => {
    const page = renderToStaticMarkup(createElement(Home));

    expect(page).toContain('Illustrative example');
    expect(page).toContain('$500.00');
    expect(page).toContain('$575.00');
    expect(page).toContain('$75.00');
    expect(page).not.toContain('Safe loan');
    expect(page).not.toContain('Apply now');
  });
});
