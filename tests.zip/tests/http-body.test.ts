import { describe, expect, it } from 'vitest';

const body = await import('../src/server/http-body').catch(() => undefined);

describe('bounded JSON request reader', () => {
  it('parses valid JSON without trusting Content-Length', async () => {
    expect(body, 'bounded JSON reader should exist').toBeDefined();
    await expect(body!.readJsonBody(new Request('https://aegis.test', { method: 'POST', body: '{"ok":true}' }), 100)).resolves.toEqual({ ok: true });
  });

  it('rejects oversized streamed bodies and malformed JSON', async () => {
    expect(body, 'bounded JSON reader should exist').toBeDefined();
    await expect(body!.readJsonBody(new Request('https://aegis.test', { method: 'POST', body: 'x'.repeat(101) }), 100)).rejects.toMatchObject({ status: 413 });
    await expect(body!.readJsonBody(new Request('https://aegis.test', { method: 'POST', body: '{' }), 100)).rejects.toMatchObject({ status: 400 });
  });
});

describe('bounded text upload reader', () => {
  it('reads UTF-8 text within the byte limit and rejects invalid or oversized bodies', async () => {
    expect(body, 'bounded text reader should exist').toBeDefined();
    await expect(body!.readTextBody(new Request('https://aegis.test', { method: 'POST', body: 'Date,Description,Amount\n' }), 100)).resolves.toContain('Amount');
    await expect(body!.readTextBody(new Request('https://aegis.test', { method: 'POST', body: 'x'.repeat(101) }), 100)).rejects.toMatchObject({ status: 413 });
  });
});
