import { afterEach, beforeEach, expect, it, vi } from 'vitest';

const db = vi.hoisted(() => ({ getDatabasePool: vi.fn() }));
vi.mock('../src/server/database', () => db);

beforeEach(() => {
  vi.resetModules();
  vi.useFakeTimers();
  vi.spyOn(console, 'info').mockImplementation(() => undefined);
  vi.spyOn(console, 'error').mockImplementation(() => undefined);
});

afterEach(() => {
  vi.restoreAllMocks();
  vi.useRealTimers();
});

it('runs the retention sweep shortly after startup and once per day thereafter', async () => {
  const query = vi.fn().mockResolvedValue({ rows: [{ transactions: 2, sessions: 1, cashflow_profiles: 1 }] });
  db.getDatabasePool.mockReturnValue({ query });
  const { startRetentionScheduler } = await import('../src/server/retention-scheduler');

  startRetentionScheduler();
  startRetentionScheduler();
  await vi.advanceTimersByTimeAsync(29_999);
  expect(query).not.toHaveBeenCalled();

  await vi.advanceTimersByTimeAsync(1);
  expect(query).toHaveBeenCalledTimes(1);
  expect(query).toHaveBeenCalledWith(
    'SELECT aegis_purge_expired_imported_transactions() AS transactions, aegis_purge_expired_local_sessions() AS sessions, aegis_purge_expired_member_cashflow_profiles() AS cashflow_profiles',
  );

  await vi.advanceTimersByTimeAsync(24 * 60 * 60 * 1_000);
  expect(query).toHaveBeenCalledTimes(2);
});

it('retries a failed sweep after 15 minutes', async () => {
  const query = vi.fn()
    .mockRejectedValueOnce(new Error('database unavailable'))
    .mockResolvedValueOnce({ rows: [{ transactions: 0, sessions: 0, cashflow_profiles: 0 }] });
  db.getDatabasePool.mockReturnValue({ query });
  const { startRetentionScheduler } = await import('../src/server/retention-scheduler');

  startRetentionScheduler();
  await vi.advanceTimersByTimeAsync(30_000);
  expect(query).toHaveBeenCalledTimes(1);

  await vi.advanceTimersByTimeAsync(15 * 60 * 1_000 - 1);
  expect(query).toHaveBeenCalledTimes(1);
  await vi.advanceTimersByTimeAsync(1);
  expect(query).toHaveBeenCalledTimes(2);
});
