import { mkdtemp, readdir, rm, symlink, utimes, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';

const retention = await import('../scripts/backup-retention.mjs').catch(() => undefined);

describe('local encrypted backup retention', () => {
  it('removes only old regular Aegis backup files and preserves fresh, unrelated, and symlink entries', async () => {
    expect(retention).toBeDefined();
    const directory = await mkdtemp(join(tmpdir(), 'aegis-backup-retention-test-'));
    const oldBackup = join(directory, 'old.aegisbackup');
    const newBackup = join(directory, 'new.aegisbackup');
    const unrelated = join(directory, 'notes.txt');
    const linkedBackup = join(directory, 'linked.aegisbackup');
    const outside = `${directory}-outside.aegisbackup`;
    const now = Date.now();
    try {
      await writeFile(oldBackup, 'encrypted');
      await writeFile(newBackup, 'encrypted');
      await writeFile(unrelated, 'keep');
      await writeFile(outside, 'outside');
      await symlink(outside, linkedBackup);
      await utimes(oldBackup, new Date(now - 40 * 86400_000), new Date(now - 40 * 86400_000));

      await expect(retention!.pruneBackups(directory, 35, now)).resolves.toBe(1);
      const remaining = await readdir(directory);
      expect(remaining.sort()).toEqual(['linked.aegisbackup', 'new.aegisbackup', 'notes.txt']);
    } finally {
      await rm(directory, { recursive: true, force: true });
      await rm(outside, { force: true });
    }
  });

  it('rejects invalid retention windows and symbolic-link directories', async () => {
    expect(retention).toBeDefined();
    const directory = await mkdtemp(join(tmpdir(), 'aegis-backup-retention-test-'));
    const alias = `${directory}-alias`;
    try {
      await symlink(directory, alias);
      await expect(retention!.pruneBackups(directory, 0)).rejects.toThrow();
      await expect(retention!.pruneBackups(alias, 35)).rejects.toThrow();
    } finally {
      await rm(alias, { force: true });
      await rm(directory, { recursive: true, force: true });
    }
  });
});
