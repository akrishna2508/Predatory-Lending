import { createHash, randomBytes, scryptSync } from 'node:crypto';
import { beforeEach, describe, expect, it, vi } from 'vitest';

const testState = vi.hoisted(() => ({
  calls: [] as Array<{ sql: string; values: unknown[] }>,
  credential: null as null | { user_id: string; password_salt: Buffer; password_hash: Buffer; is_locked: boolean },
  sessionCreated: true,
}));

vi.mock('@/server/database', () => ({
  getDatabasePool: () => ({ query: async (sql: string, values: unknown[] = []) => {
    testState.calls.push({ sql, values });
    if (sql.includes('aegis_lookup_local_credential')) return { rows: testState.credential ? [testState.credential] : [] };
    if (sql.includes('aegis_create_member_session')) return { rows: [{ created: testState.sessionCreated }] };
    return { rows: [] };
  } }),
}));

const authRoute = await import('../src/app/api/auth/login/route');
const memberId = '00000000-0000-4000-8000-000000000081';
const password = 'a-strong-member-passphrase';

function loginRequest(body: unknown) {
  return new Request('https://aegis.test/api/auth/login', {
    method: 'POST', headers: { origin: 'https://aegis.test', 'content-type': 'application/json' }, body: JSON.stringify(body),
  });
}

describe('local member sign-in', () => {
  beforeEach(() => {
    testState.calls = [];
    const salt = randomBytes(16);
    testState.credential = { user_id: memberId, password_salt: salt, password_hash: scryptSync(password, salt, 64), is_locked: false };
    testState.sessionCreated = true;
  });

  it('creates a server-side hashed session and an HttpOnly cookie for valid credentials', async () => {
    const response = await authRoute.POST(loginRequest({ email: 'Member@example.test', password }));
    const cookie = response.headers.get('set-cookie') ?? '';
    expect(response.status).toBe(200);
    expect(cookie).toMatch(/^aegis_session=[A-Za-z0-9_-]{43}; HttpOnly; SameSite=Lax; Path=\//);
    expect(cookie).not.toContain(password);
    expect(testState.calls.at(-1)?.sql).toContain('aegis_create_member_session');
    expect(testState.calls.at(-1)?.values[0]).toBe(memberId);
    expect(testState.calls.at(-1)?.values[1]).toHaveLength(32);
    expect(testState.calls.at(-1)?.values[1]).not.toEqual(Buffer.from(cookie.split(';')[0].split('=')[1]));
  });

  it('uses a generic error and records failed attempts for invalid passwords', async () => {
    const response = await authRoute.POST(loginRequest({ email: 'Member@example.test', password: 'wrong-password' }));
    expect(response.status).toBe(401);
    expect(await response.json()).toEqual({ error: 'Email or password is incorrect.' });
    expect(testState.calls.at(-1)?.sql).toContain('aegis_record_local_login_failure');
  });

  it('rejects locked accounts and cross-origin requests without issuing a cookie', async () => {
    testState.credential!.is_locked = true;
    const locked = await authRoute.POST(loginRequest({ email: 'Member@example.test', password }));
    expect(locked.status).toBe(429);
    expect(locked.headers.get('set-cookie')).toBeNull();
    const crossOrigin = await authRoute.POST(new Request('https://aegis.test/api/auth/login', { method: 'POST', headers: { origin: 'https://attacker.test', 'content-type': 'application/json' }, body: '{}' }));
    expect(crossOrigin.status).toBe(403);
  });

  it('does not expose a local password or store bearer data in the browser cookie', async () => {
    const response = await authRoute.POST(loginRequest({ email: 'Member@example.test', password }));
    const token = (response.headers.get('set-cookie') ?? '').split(';')[0].split('=')[1];
    expect(createHash('sha256').update(token).digest()).not.toEqual(Buffer.from(token));
  });
});
