import { describe, expect, it } from 'vitest';
import { parseTransactionCsv, TransactionCsvError } from '../src/domain/csv-transactions';

describe('transaction CSV parser', () => {
  it('parses common US bank export columns, quoted descriptions, and expenses/income', () => {
    const result = parseTransactionCsv('Date,Description,Amount\n06/01/2026,"GROCERY, MARKET",-42.18\n2026-06-02,Payroll,1250.00');
    expect(result.transactions).toEqual([
      { date: '2026-06-01', description: 'GROCERY, MARKET', amount: -42.18 },
      { date: '2026-06-02', description: 'Payroll', amount: 1250 },
    ]);
  });

  it('parses debit and credit columns when a bank export omits a signed amount', () => {
    const result = parseTransactionCsv('Posting Date,Name,Debit,Credit\n6/1/2026,Rent,900.00,\n6/2/2026,Paycheck,,1200.00');
    expect(result.transactions.map(row => row.amount)).toEqual([-900, 1200]);
  });

  it('rejects malformed, ambiguous, oversized, and empty input with useful codes', () => {
    expect(() => parseTransactionCsv('Date,Description\n6/1/2026,Rent')).toThrow(TransactionCsvError);
    expect(() => parseTransactionCsv('Date,Description,Amount\nnot-a-date,Rent,-1')).toThrow(/row 2/i);
    expect(() => parseTransactionCsv('Date,Description,Amount\n6/1/2026,Rent,0')).toThrow(/amount/i);
    expect(() => parseTransactionCsv('Date,Description,Amount\n6/1/2026,Rent,10\n6/1/2026,Food,20', { maxRows: 1 })).toThrow(/row limit/i);
  });

  it('handles escaped quotes and rejects formula-like descriptions', () => {
    expect(parseTransactionCsv('date,description,amount\n2026-01-01,"A ""quoted"" item",-1').transactions[0]?.description).toBe('A "quoted" item');
    expect(() => parseTransactionCsv('date,description,amount\n2026-01-01,"=HYPERLINK(1)",-1')).toThrow(/description/i);
  });
});
