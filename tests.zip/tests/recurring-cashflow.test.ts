import { describe, expect, it } from 'vitest';
import { findRecurringCashflowSuggestions, type RecurringTransaction } from '../src/domain/recurring-cashflow';

const transaction = (overrides: Partial<RecurringTransaction> = {}): RecurringTransaction => ({
  accountId: 'provider-account-secret',
  name: 'CITY POWER BILL',
  merchantName: 'City Power',
  amount: -94.2,
  date: '2026-06-05',
  pending: false,
  ...overrides,
});

describe('recurring cash-flow suggestions', () => {
  it('suggests a dated repeat only after three similar posted transactions on one account', () => {
    const results = findRecurringCashflowSuggestions([
      transaction({ date: '2026-04-05' }),
      transaction({ date: '2026-05-05', amount: -95.1, name: 'CITY POWER AUTOPAY' }),
      transaction({ date: '2026-06-05', amount: -93.3 }),
    ], '2026-06-10');

    expect(results).toEqual([{
      id: expect.stringMatching(/^[a-f0-9]{16}$/),
      label: 'City Power',
      kind: 'bill',
      amount: 94.2,
      nextDate: '2026-07-05',
      cadence: 'monthly',
      evidenceCount: 3,
      confidence: 'possible',
    }]);
    expect(JSON.stringify(results)).not.toContain('provider-account-secret');
  });

  it('recognizes recurring incoming pay while separating accounts and excluding pending activity', () => {
    const results = findRecurringCashflowSuggestions([
      transaction({ merchantName: 'Northstar Payroll', name: 'PAYROLL', amount: 1_250, date: '2026-06-01' }),
      transaction({ merchantName: 'Northstar Payroll', name: 'PAYROLL', amount: 1_250, date: '2026-06-15' }),
      transaction({ merchantName: 'Northstar Payroll', name: 'PAYROLL', amount: 1_250, date: '2026-06-29' }),
      transaction({ merchantName: 'Northstar Payroll', name: 'PAYROLL', amount: 1_250, date: '2026-07-13', pending: true }),
      transaction({ accountId: 'another-account', merchantName: 'Northstar Payroll', name: 'PAYROLL', amount: 1_250, date: '2026-07-13' }),
    ], '2026-06-30');

    expect(results).toHaveLength(1);
    expect(results[0]).toMatchObject({ label: 'Northstar Payroll', kind: 'income', amount: 1_250, cadence: 'biweekly', nextDate: '2026-07-13', evidenceCount: 3 });
  });

  it('rejects noisy, irregular, stale, and one-off transaction groups', () => {
    const results = findRecurringCashflowSuggestions([
      transaction({ merchantName: 'Unusual charge', name: 'Purchase', date: '2026-01-01' }),
      transaction({ merchantName: 'Unusual charge', name: 'Purchase', date: '2026-02-20' }),
      transaction({ merchantName: 'Unusual charge', name: 'Purchase', date: '2026-04-10' }),
      transaction({ merchantName: 'Varied utility', name: 'Power', amount: -80, date: '2026-04-02' }),
      transaction({ merchantName: 'Varied utility', name: 'Power', amount: -120, date: '2026-05-02' }),
      transaction({ merchantName: 'Varied utility', name: 'Power', amount: -190, date: '2026-06-02' }),
    ], '2026-06-10');

    expect(results).toEqual([]);
  });

  it('supports weekly cadence, safe limits, and valid as-of dates', () => {
    const results = findRecurringCashflowSuggestions([
      transaction({ merchantName: 'Weekly Pay', name: 'PAYROLL', amount: 800, date: '2026-06-01' }),
      transaction({ merchantName: 'Weekly Pay', name: 'PAYROLL', amount: 800, date: '2026-06-08' }),
      transaction({ merchantName: 'Weekly Pay', name: 'PAYROLL', amount: 800, date: '2026-06-15' }),
    ], '2026-06-16');
    expect(results[0]).toMatchObject({ cadence: 'weekly', nextDate: '2026-06-22', confidence: 'possible' });
    expect(findRecurringCashflowSuggestions([], 'not-a-date')).toEqual([]);
    expect(findRecurringCashflowSuggestions(Array.from({ length: 20 }, (_, i) => transaction({ date: `2026-06-${String(i + 1).padStart(2, '0')}` })), '2026-06-22')).toHaveLength(0);
  });
});
