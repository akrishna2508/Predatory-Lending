import { describe, expect, it } from 'vitest';

const sync = await import('../src/domain/transaction-sync').catch(() => undefined);

describe('transaction sync domain', () => {
  it('collects every cursor page before exposing changes and preserves pending-to-posted corrections', async () => {
    expect(sync, 'transaction sync domain should exist').toBeDefined();
    const calls: Array<string | null> = [];
    const result = await sync!.collectTransactionUpdates(async cursor => {
      calls.push(cursor);
      if (cursor === null) return {
        added: [{ transactionId: 'pending-1', accountId: 'account-1', amount: 12.5, date: '2026-09-25', authorizedDate: null, name: 'Corner Market', merchantName: 'Corner Market', pending: true, pendingTransactionId: null, categories: ['Food'] }],
        modified: [], removed: [], hasMore: true, nextCursor: 'cursor-1',
      };
      return {
        added: [{ transactionId: 'posted-1', accountId: 'account-1', amount: 13, date: '2026-09-26', authorizedDate: null, name: 'Corner Market', merchantName: 'Corner Market', pending: false, pendingTransactionId: 'pending-1', categories: ['Food'] }],
        modified: [], removed: [{ transactionId: 'pending-1' }], hasMore: false, nextCursor: 'cursor-2',
      };
    }, null);

    expect(calls).toEqual([null, 'cursor-1']);
    expect(result.nextCursor).toBe('cursor-2');
    expect(result.changes).toEqual([
      { kind: 'added', transaction: { transactionId: 'pending-1', accountId: 'account-1', amount: 12.5, date: '2026-09-25', authorizedDate: null, name: 'Corner Market', merchantName: 'Corner Market', pending: true, pendingTransactionId: null, categories: ['Food'] } },
      { kind: 'added', transaction: { transactionId: 'posted-1', accountId: 'account-1', amount: 13, date: '2026-09-26', authorizedDate: null, name: 'Corner Market', merchantName: 'Corner Market', pending: false, pendingTransactionId: 'pending-1', categories: ['Food'] } },
      { kind: 'removed', transactionId: 'pending-1' },
    ]);
  });

  it('rejects a repeated cursor rather than looping on a broken provider response', async () => {
    expect(sync, 'transaction sync domain should exist').toBeDefined();
    await expect(sync!.collectTransactionUpdates(async () => ({
      added: [], modified: [], removed: [], hasMore: true, nextCursor: 'same-cursor',
    }), 'same-cursor')).rejects.toThrow('did not advance its cursor');
  });

  it('rejects malformed transaction amounts, dates, and identifiers before persistence', () => {
    expect(sync, 'transaction sync domain should exist').toBeDefined();
    expect(sync!.normalizeProviderTransaction({ transactionId: '', accountId: 'acct', amount: 1, date: '2026-09-25', authorizedDate: null, name: 'Shop', merchantName: null, pending: false, pendingTransactionId: null, categories: [] })).toBeNull();
    expect(sync!.normalizeProviderTransaction({ transactionId: 'tx', accountId: 'acct', amount: Number.NaN, date: '2026-09-25', authorizedDate: null, name: 'Shop', merchantName: null, pending: false, pendingTransactionId: null, categories: [] })).toBeNull();
    expect(sync!.normalizeProviderTransaction({ transactionId: 'tx', accountId: 'acct', amount: 1, date: '2026-02-30', authorizedDate: null, name: 'Shop', merchantName: null, pending: false, pendingTransactionId: null, categories: [] })).toBeNull();
  });
});
