import { beforeEach, describe, expect, it, vi } from 'vitest';

const mocks = vi.hoisted(() => ({
  identity: { tenantId: '00000000-0000-4000-8000-000000000001', userId: '00000000-0000-4000-8000-000000000011' },
  query: vi.fn(),
  resolveIdentity: vi.fn(),
  safeOrigin: vi.fn(),
}));

vi.mock('@/server/member-auth', () => ({
  MemberAuthError: class MemberAuthError extends Error {},
  resolveMemberIdentity: mocks.resolveIdentity,
  hasSafeMutationOrigin: mocks.safeOrigin,
}));

vi.mock('@/server/database', () => ({
  getDatabasePool: () => ({}),
  withMemberTransaction: async (_pool: unknown, _identity: unknown, operation: (client: { query: typeof mocks.query }) => Promise<unknown>) => operation({ query: mocks.query }),
}));

const route = await import('@/app/api/member/consents/route');

function request() {
  return new Request('https://aegis.test/api/member/consents', {
    method: 'POST',
    headers: {
      origin: 'https://aegis.test',
      'content-type': 'application/json',
      'x-aegis-tenant-id': mocks.identity.tenantId,
    },
    body: JSON.stringify({ purpose: 'cashflow_profile_storage', action: 'revoked' }),
  });
}

describe('cash-flow storage consent revocation', () => {
  beforeEach(() => {
    mocks.resolveIdentity.mockReset().mockResolvedValue(mocks.identity);
    mocks.safeOrigin.mockReset().mockReturnValue(true);
    mocks.query.mockReset().mockResolvedValue({ rows: [] });
  });

  it('uses the scoped purge function after recording the revocation', async () => {
    const response = await route.POST(request());

    expect(response.status).toBe(201);
    const sql = mocks.query.mock.calls.map(([statement]) => String(statement));
    const revokeIndex = sql.findIndex(statement => statement.includes('INSERT INTO consent_events'));
    const purgeIndex = sql.findIndex(statement => statement.includes('aegis_purge_member_cashflow_profile'));
    expect(revokeIndex).toBeGreaterThan(-1);
    expect(purgeIndex).toBeGreaterThan(revokeIndex);
    expect(sql.some(statement => statement.includes('DELETE FROM member_cashflow_profiles'))).toBe(false);
  });
});
