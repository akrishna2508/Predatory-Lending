import { beforeEach, describe, expect, it, vi } from 'vitest';

const mocks = vi.hoisted(() => ({ query: vi.fn() }));

vi.mock('@/server/database', () => ({
  getDatabasePool: () => ({ query: mocks.query }),
}));

const route = await import('@/app/api/health/route');

describe('local service health route', () => {
  beforeEach(() => {
    mocks.query.mockReset().mockResolvedValue({ rows: [{ ok: 1 }] });
  });

  it('reports ready only after PostgreSQL responds', async () => {
    const response = await route.GET();

    expect(response.status).toBe(200);
    expect(response.headers.get('cache-control')).toContain('no-store');
    expect(await response.json()).toEqual({ status: 'ok', database: 'ok' });
    expect(mocks.query).toHaveBeenCalledWith('SELECT 1');
  });

  it('returns a sanitized unavailable response when PostgreSQL is down', async () => {
    mocks.query.mockRejectedValueOnce(new Error('database password must never be returned'));
    const response = await route.GET();

    expect(response.status).toBe(503);
    expect(response.headers.get('cache-control')).toContain('no-store');
    expect(await response.json()).toEqual({ status: 'unavailable', database: 'unavailable' });
  });
});
