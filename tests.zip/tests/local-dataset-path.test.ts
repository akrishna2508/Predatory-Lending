import { afterEach, describe, expect, it } from 'vitest';
import { mkdtemp, mkdir, realpath, rm, symlink, writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { resolveLocalDataset } from '@/server/modeling-paths';

const temporaryRoots: string[] = [];
afterEach(async () => {
  await Promise.all(temporaryRoots.splice(0).map(directory => rm(directory, { recursive: true, force: true })));
});

async function rootWithDataset() {
  const root = await mkdtemp(path.join(os.tmpdir(), 'aegis-models-'));
  temporaryRoots.push(root);
  await mkdir(path.join(root, 'data', 'raw'), { recursive: true });
  await writeFile(path.join(root, 'data', 'raw', 'bench.csv'), 'col\nvalue\n');
  return root;
}

describe('local dataset path guard', () => {
  it('resolves a local CSV inside data/raw', async () => {
    const root = await rootWithDataset();

    await expect(resolveLocalDataset('bench.csv', root)).resolves.toBe(await realpath(path.join(root, 'data', 'raw', 'bench.csv')));
  });

  it('rejects path traversal and unsupported extensions', async () => {
    const root = await rootWithDataset();

    await expect(resolveLocalDataset('../secrets.csv', root)).rejects.toThrow('inside data/raw');
    await expect(resolveLocalDataset('bench.json', root)).rejects.toThrow('CSV, ZIP, or Statlog data file');
  });

  it('rejects symlinks that escape the local data directory', async () => {
    const root = await rootWithDataset();
    const outside = path.join(root, 'outside.csv');
    await writeFile(outside, 'private\nvalue\n');
    await symlink(outside, path.join(root, 'data', 'raw', 'escape.csv'));

    await expect(resolveLocalDataset('escape.csv', root)).rejects.toThrow('inside data/raw');
  });

  it('rejects directories and missing local files', async () => {
    const root = await rootWithDataset();

    await expect(resolveLocalDataset('missing.csv', root)).rejects.toThrow('not found');
    await expect(resolveLocalDataset('.', root)).rejects.toThrow();
  });
});
