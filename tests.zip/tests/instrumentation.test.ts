import { afterEach, expect, it, vi } from 'vitest';

const nodeRuntime = vi.hoisted(() => ({ startNodeRuntime: vi.fn() }));
vi.mock('../src/instrumentation.node', () => nodeRuntime);

import { register } from '../src/instrumentation';

const previousRuntime = process.env.NEXT_RUNTIME;

afterEach(() => {
  if (previousRuntime === undefined) delete process.env.NEXT_RUNTIME;
  else process.env.NEXT_RUNTIME = previousRuntime;
  nodeRuntime.startNodeRuntime.mockClear();
});

it('loads Node-only instrumentation only in the Node runtime', async () => {
  process.env.NEXT_RUNTIME = 'nodejs';
  await register();
  expect(nodeRuntime.startNodeRuntime).toHaveBeenCalledTimes(1);
});

it('does not load Node-only instrumentation in the Edge runtime', async () => {
  process.env.NEXT_RUNTIME = 'edge';
  await register();
  expect(nodeRuntime.startNodeRuntime).not.toHaveBeenCalled();
});

it('does not load runtime-specific code when the runtime is not set', async () => {
  delete process.env.NEXT_RUNTIME;
  await register();
  expect(nodeRuntime.startNodeRuntime).not.toHaveBeenCalled();
});
