const form = document.querySelector('#watch-form');
const input = document.querySelector('#site');
const list = document.querySelector('#sites');
const empty = document.querySelector('#empty');
const message = document.querySelector('#message');
const pauseMode = document.querySelector('#pause-mode');
const profileFile = document.querySelector('#profile-file');
const profileMessage = document.querySelector('#profile-message');
const profileSummary = document.querySelector('#profile-summary');
const clearProfileButton = document.querySelector('#clear-profile');
const PROFILE_KEY = 'personalShieldProfile';
const PROFILE_SIGNALS = new Set(['short_term_credit', 'financial_fees']);
chrome.storage.local.get('pauseBeforeApply', ({ pauseBeforeApply }) => { pauseMode.checked = pauseBeforeApply !== false; });
pauseMode.addEventListener('change', () => chrome.storage.local.set({ pauseBeforeApply: pauseMode.checked }));

function validPersonalProfile(profile) {
  if (!profile || profile.format !== 'aegis-personal-shield-v1' || !Array.isArray(profile.signals)
    || profile.signals.length < 1 || profile.signals.length > PROFILE_SIGNALS.size
    || profile.signals.some(signal => !PROFILE_SIGNALS.has(signal))
    || new Set(profile.signals).size !== profile.signals.length) return false;
  const generatedAt = Date.parse(profile.generatedAt);
  const expiresAt = Date.parse(profile.expiresAt);
  const now = Date.now();
  return Number.isFinite(generatedAt) && Number.isFinite(expiresAt)
    && generatedAt <= now + 5 * 60_000 && expiresAt > now
    && expiresAt > generatedAt && expiresAt - generatedAt <= 31 * 24 * 60 * 60_000;
}

async function renderPersonalProfile() {
  const stored = await chrome.storage.local.get(PROFILE_KEY);
  const profile = stored[PROFILE_KEY];
  if (!validPersonalProfile(profile)) {
    if (profile) await chrome.storage.local.remove(PROFILE_KEY);
    profileSummary.textContent = 'Optional: import the pattern-only profile from your Aegis member workspace.';
    clearProfileButton.hidden = true;
    return;
  }
  const names = profile.signals.map(signal => signal === 'short_term_credit' ? 'repeated short-term credit labels' : 'repeated fee labels');
  profileSummary.textContent = `On this device: ${names.join(' and ')}. Expires ${new Date(profile.expiresAt).toLocaleDateString()}.`;
  clearProfileButton.hidden = false;
}

profileFile.addEventListener('change', async () => {
  profileMessage.textContent = '';
  const file = profileFile.files?.[0];
  if (!file) return;
  if (file.size > 8_192) {
    profileMessage.textContent = 'That file is too large to be an Aegis pattern profile.';
    profileFile.value = '';
    return;
  }
  try {
    const profile = JSON.parse(await file.text());
    if (!validPersonalProfile(profile)) throw new Error('invalid profile');
    await chrome.storage.local.set({ [PROFILE_KEY]: {
      generatedAt: profile.generatedAt,
      expiresAt: profile.expiresAt,
      signals: [...profile.signals],
    } });
    profileMessage.textContent = 'Personal pattern profile saved on this device. Reload any watched lender page to use it.';
    await renderPersonalProfile();
  } catch {
    profileMessage.textContent = 'This profile is invalid or expired. Download a fresh one from your Aegis member workspace.';
  } finally {
    profileFile.value = '';
  }
});

clearProfileButton.addEventListener('click', async () => {
  await chrome.storage.local.remove(PROFILE_KEY);
  profileMessage.textContent = 'Personal pattern profile removed from this device.';
  await renderPersonalProfile();
});

function parseSite(value) {
  const raw = value.trim();
  if (!raw || /[\s/@?#]/.test(raw.replace(/^https?:\/\//i, ''))) return null;
  let parsed;
  try { parsed = new URL(raw.includes('://') ? raw : `https://${raw}`); } catch { return null; }
  if (!['http:', 'https:'].includes(parsed.protocol) || parsed.username || parsed.password
    || parsed.pathname !== '/' || parsed.search || parsed.hash || !parsed.hostname.includes('.')) return null;
  return parsed.hostname.toLowerCase();
}

async function getSites() {
  const stored = await chrome.storage.local.get('watchedSites');
  return Array.isArray(stored.watchedSites) ? stored.watchedSites : [];
}

async function render() {
  const sites = await getSites();
  list.replaceChildren();
  empty.hidden = sites.length > 0;
  for (const host of sites) {
    const item = document.createElement('li');
    const label = document.createElement('span');
    label.textContent = host;
    const remove = document.createElement('button');
    remove.type = 'button';
    remove.textContent = 'Remove';
    remove.setAttribute('aria-label', `Stop watching ${host}`);
    remove.addEventListener('click', () => removeSite(host));
    item.append(label, remove);
    list.append(item);
  }
}

async function addSite(host) {
  const origins = [`https://${host}/*`, `http://${host}/*`];
  const granted = await chrome.permissions.request({ origins });
  if (!granted) {
    message.textContent = 'Site permission was not granted. No pages were added.';
    return;
  }
  try {
    const existing = await chrome.scripting.getRegisteredContentScripts({ ids: [`aegis-${host}`] });
    if (existing.length) await chrome.scripting.unregisterContentScripts({ ids: [`aegis-${host}`] });
    await chrome.scripting.registerContentScripts([{
      id: `aegis-${host}`,
      js: ['watcher.js'],
      matches: origins,
      runAt: 'document_idle',
      persistAcrossSessions: true
    }]);
    const sites = await getSites();
    await chrome.storage.local.set({ watchedSites: [...new Set([...sites, host])], pauseBeforeApply: pauseMode.checked });
    message.textContent = `Aegis will watch ${host} on this browser.`;
    await render();
  } catch {
    message.textContent = 'Could not add this site. Try removing it and adding it again.';
  }
}

async function removeSite(host) {
  await chrome.scripting.unregisterContentScripts({ ids: [`aegis-${host}`] }).catch(() => {});
  const origins = [`https://${host}/*`, `http://${host}/*`];
  await chrome.permissions.remove({ origins });
  await chrome.storage.local.set({ watchedSites: (await getSites()).filter(site => site !== host) });
  message.textContent = `Aegis stopped watching ${host}.`;
  await render();
}

form.addEventListener('submit', async event => {
  event.preventDefault();
  message.textContent = '';
  const host = parseSite(input.value);
  if (!host) { message.textContent = 'Enter a site domain such as example.com.'; return; }
  await addSite(host);
  input.value = '';
});
void render();
void renderPersonalProfile();
