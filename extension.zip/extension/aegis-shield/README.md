# Aegis browser shield (local prototype)

This dependency-free Chromium extension gives a member a real, on-device pause at a user-selected lender website. It scans visible page wording for short-term loan terms. If enabled, it prevents a matching Apply, Accept, Borrow, or application-submit click/submit until the member explicitly unlocks one action for 15 seconds and clicks it themselves.

The member can also import a 30-day Aegis profile generated from opted-in transaction history. That profile contains allowlisted pattern names (`short_term_credit`, `financial_fees`) and profile expiry metadata; it contains no transaction rows, transaction dates, merchant descriptions, or amounts. On matching offer pages, the extension uses those names to explain why the member may want to pause. It never sends page content or transaction profile data to a server.

## Install in Chromium

1. Open `chrome://extensions` (or the browser's equivalent) and turn on developer mode.
2. Choose **Load unpacked** and select this `extension/aegis-shield` folder.
3. Open the Aegis extension popup. Import `aegis-personal-shield.json` from the member workspace if you have opted in and downloaded one.
4. Enter a lender domain and choose **Add site**. Grant permission for that site if you want its pages watched. Permissions are requested separately for each site.
5. Reload an already open lender page after adding it or importing a profile.

Remove a site in the popup to unregister its page watcher and revoke the site's permission. Use **Remove personal profile** to clear the transaction-derived pattern names from the browser. Imported profiles expire after 30 days; export a fresh file after importing new transactions.

## Verify the working pause

Use a watched lender site that has visible wording such as “payday loan,” “cash advance,” “title loan,” or “short-term loan,” and a button labeled **Apply**, **Accept**, or **Borrow**. With **Pause before Apply or Borrow steps** enabled, the extension should show a prompt and hold that action. Choose **Allow my next step**, then click the lender button yourself within 15 seconds. Turn off the pause setting to use wording alerts without holding actions.

For an isolated local check, use `http://127.0.0.1:3000/shield-demo`, add `127.0.0.1`, then reload the demo. The demo is fictional. To verify a profile from actual member data, follow the member-workspace instructions in the project README.

## Scope and limits

- Detection is a small set of transparent text rules, not an AI model. Page wording can be missed or matched incorrectly.
- A history match is descriptive context, not a psychological profile, risk score, affordability finding, or proof that a lender is predatory.
- The extension watches only sites explicitly added by the member. It sees visible page text but does not read form values or capture keystrokes.
- The extension can pause matching browser clicks/submissions. It cannot stop a user from turning it off, using another device/browser, or continuing through a site flow that does not match its rules.
- It does not connect to bank accounts, intercept checkout universally, or move money. The cash-flow reserve in Aegis is a planning preview, not an actual transfer.
