(() => {
  if (window.top !== window || document.getElementById('aegis-loan-pause-root')) return;
  const offerWords = /\b(payday\s+(?:loan|advance)|title\s+loan|cash\s+advance|short[- ]term\s+(?:loan|credit)|tribal\s+lending)\b/i;
  const urgencyWords = /\b(act now|limited[- ]time|offer expires|today only|instant approval|borrow now|apply now|ends tonight)\b/i;
  let queued = false;
  let dismissed = false;
  let loanOfferOnPage = false;
  let urgencyOnPage = false;
  let pauseBeforeApply = true;
  let personalShieldProfile = null;
  let allowUntil = 0;
  let root;
  let cardNode;
  let titleNode;
  let copyNode;
  let detailsNode;
  let actionsNode;
  let openLink;

  chrome.storage.local.get(['pauseBeforeApply', 'personalShieldProfile'], ({ pauseBeforeApply: stored, personalShieldProfile: profile }) => {
    pauseBeforeApply = stored !== false;
    personalShieldProfile = profile || null;
    scheduleScan();
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (changes.pauseBeforeApply) pauseBeforeApply = changes.pauseBeforeApply.newValue !== false;
    if (changes.personalShieldProfile) personalShieldProfile = changes.personalShieldProfile.newValue || null;
    if (changes.pauseBeforeApply || changes.personalShieldProfile) {
      scheduleScan();
      if (loanOfferOnPage && root && !dismissed) renderNotice(false);
    }
  });

  function personalPatternCopy() {
    if (!personalShieldProfile || Date.parse(personalShieldProfile.expiresAt) <= Date.now()
      || !Array.isArray(personalShieldProfile.signals)) return '';
    const patterns = [...new Set(personalShieldProfile.signals.filter(signal => signal === 'short_term_credit' || signal === 'financial_fees'))];
    if (!patterns.length) return '';
    const labels = patterns.map(pattern => pattern === 'short_term_credit' ? 'repeated short-term credit labels' : 'repeated fee labels');
    return `Your opt-in transaction history includes ${labels.join(' and ')}. This page contains short-term-loan wording, so review the full cost and payment dates before continuing. These labels are context, not proof that this offer is predatory or affordable.`;
  }

  function ensureCard() {
    if (root || !document.body) return;
    root = document.createElement('div');
    root.id = 'aegis-loan-pause-root';
    const shadow = root.attachShadow({ mode: 'closed' });
    const style = document.createElement('style');
    style.textContent = `:host{all:initial;position:fixed;z-index:2147483647;right:18px;bottom:18px;width:min(400px,calc(100vw - 36px));font:14px/1.5 system-ui,-apple-system,Segoe UI,sans-serif;color:#15223c}*{box-sizing:border-box}.card{background:white;border:1px solid #d4dceb;border-radius:12px;box-shadow:0 12px 42px #15223c30;overflow:hidden}.head{display:flex;align-items:center;gap:9px;padding:14px 16px 8px}.mark{background:#2659cf;color:white;width:25px;height:27px;border-radius:6px;display:grid;place-items:center;font-weight:800}.title{font-size:13px;font-weight:750}.close{margin-left:auto;background:none;border:0;color:#6e7c93;font-size:20px;cursor:pointer;padding:0 3px}.copy{padding:0 16px 13px;margin:0;color:#58677e;font-size:12px}.details{margin:0 16px 13px;padding:11px;background:#f4f6f9;border-radius:7px;color:#45536a;font-size:11px}.details[hidden]{display:none}.actions{display:flex;align-items:center;gap:8px;flex-wrap:wrap;padding:0 16px 15px}.primary,.secondary{border-radius:6px;padding:8px 10px;font-size:11px;font-weight:650;cursor:pointer}.primary{background:#2659cf;color:white;text-decoration:none;border:0}.secondary{background:white;border:1px solid #d4dceb;color:#45536a}.foot{font-size:9px;color:#7d8999;padding:0 16px 13px;margin:0}.gate{border-color:#e7c47c}.gate .mark{background:#9b6418}`;
    cardNode = document.createElement('section');
    cardNode.className = 'card';
    cardNode.setAttribute('role', 'region');
    cardNode.setAttribute('aria-label', 'Aegis loan pause');
    const head = document.createElement('div'); head.className = 'head';
    const mark = document.createElement('span'); mark.className = 'mark'; mark.textContent = 'A';
    titleNode = document.createElement('strong'); titleNode.className = 'title'; titleNode.textContent = 'Take a moment with this offer';
    const close = document.createElement('button'); close.className = 'close'; close.type = 'button'; close.setAttribute('aria-label', 'Hide Aegis alert'); close.textContent = '×';
    close.addEventListener('click', () => { dismissed = true; root.remove(); root = null; });
    head.append(mark, titleNode, close);
    copyNode = document.createElement('p'); copyNode.className = 'copy';
    detailsNode = document.createElement('div'); detailsNode.className = 'details'; detailsNode.hidden = true;
    actionsNode = document.createElement('div'); actionsNode.className = 'actions';
    openLink = document.createElement('a'); openLink.className = 'primary'; openLink.href = 'http://localhost:3000/member'; openLink.target = '_blank'; openLink.rel = 'noreferrer'; openLink.textContent = 'Open Aegis';
    const foot = document.createElement('p'); foot.className = 'foot'; foot.textContent = 'On-device wording alert · No page text is sent anywhere.';
    cardNode.append(head, copyNode, detailsNode, actionsNode, foot);
    shadow.append(style, cardNode);
    document.body.append(root);
    renderNotice(false);
  }

  function renderNotice(isGate) {
    ensureCard();
    if (!root) return;
    cardNode.className = isGate ? 'card gate' : 'card';
    titleNode.textContent = isGate ? 'Aegis paused this step' : 'Take a moment with this offer';
    copyNode.textContent = isGate
      ? `${personalPatternCopy() ? `${personalPatternCopy()} ` : ''}This watched page contains short-term-loan wording. Aegis held an Apply, Accept, or Borrow action so you can review the full repayment and due dates before choosing.`
      : personalPatternCopy() || (urgencyOnPage
        ? 'This page combines short-term-loan wording with urgency language. That can make it harder to compare terms. Check total repayment and due dates at your pace.'
        : 'This page includes payday, title-loan, or cash-advance wording. That label alone does not tell you the full cost or whether an offer is right for you.');
    detailsNode.hidden = false;
    detailsNode.textContent = 'Before continuing, check the amount you receive, total repayment, every payment date, and what bills are due before your next income. You can leave this page and come back later.';
    actionsNode.replaceChildren();
    if (isGate) {
      const allow = document.createElement('button'); allow.type = 'button'; allow.className = 'primary'; allow.textContent = 'Allow my next step';
      allow.addEventListener('click', () => {
        allowUntil = Date.now() + 15_000;
        titleNode.textContent = 'Your next step is unlocked';
        copyNode.textContent = 'Aegis will allow one matching action for the next 15 seconds. Return to the page and click it yourself.';
        actionsNode.replaceChildren(openLink);
        window.setTimeout(() => { if (Date.now() >= allowUntil) allowUntil = 0; }, 15_100);
      });
      const back = document.createElement('button'); back.type = 'button'; back.className = 'secondary'; back.textContent = 'Keep the pause';
      back.addEventListener('click', () => { titleNode.textContent = 'Aegis is holding this step'; copyNode.textContent = 'The page action is still paused. Review the amount, total repayment, and dates, or leave the page.'; });
      actionsNode.append(allow, back, openLink);
    } else {
      const checklist = document.createElement('button'); checklist.type = 'button'; checklist.className = 'secondary'; checklist.textContent = 'Review a pause checklist';
      checklist.addEventListener('click', () => { detailsNode.hidden = !detailsNode.hidden; checklist.textContent = detailsNode.hidden ? 'Review a pause checklist' : 'Hide checklist'; });
      actionsNode.append(checklist, openLink);
    }
  }

  function showPause(isGate = false) {
    if (dismissed && !isGate) return;
    ensureCard();
    renderNotice(isGate);
  }

  function scanPage() {
    if (!document.body) return;
    const visibleCopy = (document.body.innerText || '').slice(0, 300_000);
    loanOfferOnPage = offerWords.test(visibleCopy);
    urgencyOnPage = urgencyWords.test(visibleCopy);
    if (loanOfferOnPage && !root && !dismissed) showPause(false);
  }

  function hasApplyAction(event) {
    const path = event.composedPath();
    if (root && path.includes(root)) return false;
    const target = [event.submitter, ...path].find(node => node instanceof Element && node.matches('button, input[type="submit"], input[type="button"], [role="button"], a'));
    if (!(target instanceof Element)) return false;
    const actionText = `${target.innerText || ''} ${target.getAttribute('aria-label') || ''} ${target.getAttribute('value') || ''}`.trim();
    return /\b(apply|accept|borrow|request funds|submit application|continue to offer|finish application|agree and continue)\b/i.test(actionText);
  }

  function holdPageAction(event) {
    if (!pauseBeforeApply || !loanOfferOnPage || !hasApplyAction(event)) return;
    if (allowUntil > Date.now()) {
      if (event.type === 'submit') allowUntil = 0;
      return;
    }
    event.preventDefault();
    event.stopImmediatePropagation();
    showPause(true);
  }

  function scheduleScan() {
    if (queued) return;
    queued = true;
    window.setTimeout(() => { queued = false; scanPage(); }, 700);
  }

  scheduleScan();
  const observer = new MutationObserver(scheduleScan);
  observer.observe(document.documentElement, { childList: true, subtree: true, characterData: true });
  window.addEventListener('click', holdPageAction, true);
  window.addEventListener('submit', holdPageAction, true);
})();
